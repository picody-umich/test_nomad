"""Generates a markdown file with the JSON schema for the config."""

import json
import pathlib

from pytens_radtrans.load_config import Config


def main() -> None:
    """Generates the configuration reference markdown file."""
    schema = Config.model_json_schema()
    schema_str = json.dumps(schema, indent=2)

    output_path = pathlib.Path("docs/user_guide/configuration.md")
    output_path.parent.mkdir(parents=True, exist_ok=True)

    content = f"""# Configuration File Reference

This page documents all available options for the YAML configuration file. The documentation is generated directly from the Pydantic validation models in the source code.

The following is the JSON Schema that defines the structure and validation rules for the configuration file.

```json
{schema_str}
```
"""
    output_path.write_text(content, encoding="utf-8")
    print(f"Generated config schema at {output_path}")


if __name__ == "__main__":
    main()


