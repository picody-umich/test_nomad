# Installation

## Prerequisites

*   **Python**: Version 3.10 or newer.
*   **MPI**: An MPI implementation (e.g., OpenMPI, MPICH) must be installed on your system.
*   **Compilers**: A C/C++ compiler is often required for building dependencies like `mpi4py`.

## Installing the Package

We recommend installing the package in "editable" mode. This allows you to modify the source code and have changes take effect immediately without reinstalling.

### Using the Makefile (Recommended)

The easiest way to install dependencies and set up the environment is using the provided `Makefile`:

```
make init
```

This command runs `pip install -e ".[dev,docs]"` under the hood, installing the package along with all development and documentation tools.

### Manual Installation

If you prefer to use `pip` directly:

1.  **Clone the repository**:
    ```
    git clone <repository-url>
    cd pytens_radtrans
    ```

2.  **Install in editable mode**:
    ```
    pip install -e ".[dev,docs]"
    ```

## Verifying Installation

To verify that the installation was successful, you can run the test suite:

```
make test
```

