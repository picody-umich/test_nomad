# Configuration File Reference

This page documents all available options for the YAML configuration file. The documentation is generated directly from the Pydantic validation models in the source code.

The following is the JSON Schema that defines the structure and validation rules for the configuration file.

```json
{
  "$defs": {
    "APFStencil": {
      "description": "Configuration for the Asymptotic Preserving (Jiang) stencil.",
      "properties": {
        "name": {
          "const": "jiang",
          "description": "Selects the Asymptotic Preserving (Jiang) stencil.",
          "enum": [
            "jiang"
          ],
          "title": "Name",
          "type": "string"
        },
        "beta": {
          "default": 4.0,
          "description": "Parameter for the Jiang flux limiter.",
          "minimum": 0.0,
          "title": "Beta",
          "type": "number"
        },
        "tau_threshold": {
          "default": 0.001,
          "description": "Threshold for switching between transport and diffusion regimes.",
          "minimum": 0.0,
          "title": "Tau Threshold",
          "type": "number"
        },
        "alpha_threshold": {
          "default": 1e-06,
          "description": "The absorption coefficient is set to this value when it's close to zero",
          "minimum": 0.0,
          "title": "Alpha Threshold",
          "type": "number"
        }
      },
      "required": [
        "name"
      ],
      "title": "APFStencil",
      "type": "object"
    },
    "Angles": {
      "description": "Defines the angular discretization.",
      "properties": {
        "n_theta": {
          "description": "Number of polar angles (theta).",
          "exclusiveMinimum": 0,
          "title": "N Theta",
          "type": "integer"
        },
        "n_phi": {
          "description": "Number of azimuthal angles (phi).",
          "exclusiveMinimum": 0,
          "title": "N Phi",
          "type": "integer"
        }
      },
      "required": [
        "n_theta",
        "n_phi"
      ],
      "title": "Angles",
      "type": "object"
    },
    "CrookedPipe": {
      "description": "Crooked Pipe problem configuration.",
      "properties": {
        "name": {
          "const": "crooked pipe",
          "enum": [
            "crooked pipe"
          ],
          "title": "Name",
          "type": "string"
        },
        "background_temperature": {
          "description": "Initial temperature of the pipe and walls.",
          "exclusiveMinimum": 0.0,
          "title": "Background Temperature",
          "type": "number"
        },
        "source_temperature": {
          "description": "Temperature of the radiation source at the inlet.",
          "exclusiveMinimum": 0.0,
          "title": "Source Temperature",
          "type": "number"
        },
        "wall_density": {
          "description": "Density of the pipe walls.",
          "exclusiveMinimum": 0.0,
          "title": "Wall Density",
          "type": "number"
        },
        "pipe_density": {
          "description": "Density of the medium inside the pipe.",
          "exclusiveMinimum": 0.0,
          "title": "Pipe Density",
          "type": "number"
        },
        "wall_specific_absorption_opacity": {
          "description": "Specific absorption opacity of the pipe walls.",
          "exclusiveMinimum": 0.0,
          "title": "Wall Specific Absorption Opacity",
          "type": "number"
        },
        "pipe_specific_absorption_opacity": {
          "description": "Specific absorption opacity of the medium in the pipe.",
          "exclusiveMinimum": 0.0,
          "title": "Pipe Specific Absorption Opacity",
          "type": "number"
        }
      },
      "required": [
        "name",
        "background_temperature",
        "source_temperature",
        "wall_density",
        "pipe_density",
        "wall_specific_absorption_opacity",
        "pipe_specific_absorption_opacity"
      ],
      "title": "CrookedPipe",
      "type": "object"
    },
    "Equations": {
      "description": "Defines the physical parameters of the transport equations.",
      "properties": {
        "speed_of_light": {
          "description": "Speed of light in simulation units.",
          "title": "Speed Of Light",
          "type": "number"
        },
        "density": {
          "anyOf": [
            {
              "exclusiveMinimum": 0.0,
              "type": "number"
            },
            {
              "type": "null"
            }
          ],
          "default": null,
          "description": "Global material density. Not needed if problem defines it.",
          "title": "Density"
        },
        "specific_scattering_opacity": {
          "default": 0.0,
          "description": "Specific scattering opacity (sigma_s).",
          "minimum": 0.0,
          "title": "Specific Scattering Opacity",
          "type": "number"
        },
        "radiation_constant": {
          "default": 0.0,
          "description": "Radiation constant (a_r).",
          "minimum": 0.0,
          "title": "Radiation Constant",
          "type": "number"
        },
        "specific_absorption_opacity": {
          "default": 0.0,
          "description": "Specific absorption opacity (sigma_a).",
          "minimum": 0.0,
          "title": "Specific Absorption Opacity",
          "type": "number"
        },
        "source": {
          "description": "The source term model for radiation-matter interaction.",
          "discriminator": {
            "mapping": {
              "ideal gas": "#/$defs/IdealGas",
              "none": "#/$defs/NoSource",
              "scatter only": "#/$defs/ScatterOnly"
            },
            "propertyName": "name"
          },
          "oneOf": [
            {
              "$ref": "#/$defs/NoSource"
            },
            {
              "$ref": "#/$defs/IdealGas"
            },
            {
              "$ref": "#/$defs/ScatterOnly"
            }
          ],
          "title": "Source"
        }
      },
      "required": [
        "speed_of_light",
        "source"
      ],
      "title": "Equations",
      "type": "object"
    },
    "GaussianDiffusion": {
      "description": "Gaussian Diffusion problem configuration.",
      "properties": {
        "name": {
          "const": "gaussian diffusion",
          "enum": [
            "gaussian diffusion"
          ],
          "title": "Name",
          "type": "string"
        },
        "A": {
          "description": "Amplitude of the initial Gaussian pulse.",
          "exclusiveMinimum": 0.0,
          "title": "A",
          "type": "number"
        },
        "t0": {
          "description": "Effective initial time for the analytical solution.",
          "exclusiveMinimum": 0.0,
          "title": "T0",
          "type": "number"
        }
      },
      "required": [
        "name",
        "A",
        "t0"
      ],
      "title": "GaussianDiffusion",
      "type": "object"
    },
    "Geometry": {
      "description": "Defines the spatial geometry of the simulation domain.",
      "properties": {
        "dimension": {
          "description": "Number of spatial dimensions (1 or 2).",
          "exclusiveMinimum": 0,
          "maximum": 2,
          "title": "Dimension",
          "type": "integer"
        },
        "lb": {
          "description": "Lower bounds of the spatial domain.",
          "items": {
            "type": "number"
          },
          "title": "Lb",
          "type": "array"
        },
        "ub": {
          "description": "Upper bounds of the spatial domain.",
          "items": {
            "type": "number"
          },
          "title": "Ub",
          "type": "array"
        },
        "n": {
          "description": "Number of cells in each spatial dimension.",
          "items": {
            "type": "integer"
          },
          "title": "N",
          "type": "array"
        },
        "n_ghost": {
          "description": "Number of ghost cells on each side of each dimension.",
          "items": {
            "type": "integer"
          },
          "title": "N Ghost",
          "type": "array"
        },
        "domain_decomp": {
          "default": 0,
          "description": "MPI domain decomposition structure. 0 for a single domain.",
          "title": "Domain Decomp"
        }
      },
      "required": [
        "dimension",
        "lb",
        "ub",
        "n",
        "n_ghost"
      ],
      "title": "Geometry",
      "type": "object"
    },
    "Hohlraum": {
      "description": "Hohlraum problem configuration.",
      "properties": {
        "name": {
          "const": "hohlraum",
          "enum": [
            "hohlraum"
          ],
          "title": "Name",
          "type": "string"
        }
      },
      "required": [
        "name"
      ],
      "title": "Hohlraum",
      "type": "object"
    },
    "IdealGas": {
      "description": "Configuration for the ideal gas source term.",
      "properties": {
        "name": {
          "const": "ideal gas",
          "description": "Selects the ideal gas source term for energy exchange.",
          "enum": [
            "ideal gas"
          ],
          "title": "Name",
          "type": "string"
        },
        "specific_heat_capacity": {
          "anyOf": [
            {
              "type": "number"
            },
            {
              "type": "null"
            }
          ],
          "default": null,
          "description": "Specific heat capacity (Cv) of the material. Required for temperature updates.",
          "title": "Specific Heat Capacity"
        }
      },
      "required": [
        "name"
      ],
      "title": "IdealGas",
      "type": "object"
    },
    "IntensityRefinementConfig": {
      "description": "Refinement strategy based on global Mean Intensity percentiles.",
      "properties": {
        "enabled": {
          "default": false,
          "description": "Whether to enable adaptive mesh refinement.",
          "title": "Enabled",
          "type": "boolean"
        },
        "proper_nesting": {
          "default": false,
          "description": "If True, enforces a strict 2:1 size ratio between neighbors.",
          "title": "Proper Nesting",
          "type": "boolean"
        },
        "max_level": {
          "default": 10,
          "description": "Maximum refinement level allowed.",
          "minimum": 0,
          "title": "Max Level",
          "type": "integer"
        },
        "frequency": {
          "default": 1,
          "description": "Frequency of adaptation steps.",
          "minimum": 1,
          "title": "Frequency",
          "type": "integer"
        },
        "refine_neighbors": {
          "default": true,
          "description": "If True, neighbors of refined cells are also refined.",
          "title": "Refine Neighbors",
          "type": "boolean"
        },
        "strategy": {
          "const": "mean_intensity",
          "default": "mean_intensity",
          "description": "Refinement based on global intensity percentile.",
          "enum": [
            "mean_intensity"
          ],
          "title": "Strategy",
          "type": "string"
        },
        "refine_fraction": {
          "default": 0.2,
          "description": "Top fraction of global max to refine (e.g. 0.2 = top 20%).",
          "exclusiveMaximum": 1.0,
          "exclusiveMinimum": 0.0,
          "title": "Refine Fraction",
          "type": "number"
        },
        "coarsen_fraction": {
          "default": 0.5,
          "description": "Bottom fraction of global max to coarsen (e.g. 0.5 = bottom 50%).",
          "exclusiveMaximum": 1.0,
          "exclusiveMinimum": 0.0,
          "title": "Coarsen Fraction",
          "type": "number"
        }
      },
      "title": "IntensityRefinementConfig",
      "type": "object"
    },
    "LineSource": {
      "description": "Line Source problem configuration.",
      "properties": {
        "name": {
          "const": "line source",
          "enum": [
            "line source"
          ],
          "title": "Name",
          "type": "string"
        },
        "u0": {
          "description": "Amplitude of the initial pulse.",
          "exclusiveMinimum": 0.0,
          "title": "U0",
          "type": "number"
        },
        "omega": {
          "description": "Initial spread of the pulse.",
          "exclusiveMinimum": 0.0,
          "title": "Omega",
          "type": "number"
        }
      },
      "required": [
        "name",
        "u0",
        "omega"
      ],
      "title": "LineSource",
      "type": "object"
    },
    "LoadBalancing": {
      "description": "Configuration for load balancing.",
      "properties": {
        "enabled": {
          "default": false,
          "description": "Whether to enable dynamic load balancing.",
          "title": "Enabled",
          "type": "boolean"
        },
        "imbalance_threshold": {
          "default": 1.1,
          "description": "Ratio of max load to average load required to trigger rebalancing.",
          "exclusiveMinimum": 1.0,
          "title": "Imbalance Threshold",
          "type": "number"
        },
        "strategy": {
          "default": "parameters",
          "description": "Metric for load balancing: 'count' (leaves) or 'parameters' (tensor size).",
          "enum": [
            "count",
            "parameters"
          ],
          "title": "Strategy",
          "type": "string"
        },
        "frequency": {
          "default": 10,
          "description": "Frequency (in time steps) to check for load balancing.",
          "minimum": 1,
          "title": "Frequency",
          "type": "integer"
        }
      },
      "title": "LoadBalancing",
      "type": "object"
    },
    "NoSource": {
      "description": "Specifies that no source term is used.",
      "properties": {
        "name": {
          "const": "none",
          "description": "Specifies no source term is used in the equations.",
          "enum": [
            "none"
          ],
          "title": "Name",
          "type": "string"
        }
      },
      "required": [
        "name"
      ],
      "title": "NoSource",
      "type": "object"
    },
    "RankRefinementConfig": {
      "description": "Refinement strategy based on Tensor Train ranks.",
      "properties": {
        "enabled": {
          "default": false,
          "description": "Whether to enable adaptive mesh refinement.",
          "title": "Enabled",
          "type": "boolean"
        },
        "proper_nesting": {
          "default": false,
          "description": "If True, enforces a strict 2:1 size ratio between neighbors.",
          "title": "Proper Nesting",
          "type": "boolean"
        },
        "max_level": {
          "default": 10,
          "description": "Maximum refinement level allowed.",
          "minimum": 0,
          "title": "Max Level",
          "type": "integer"
        },
        "frequency": {
          "default": 1,
          "description": "Frequency of adaptation steps.",
          "minimum": 1,
          "title": "Frequency",
          "type": "integer"
        },
        "refine_neighbors": {
          "default": true,
          "description": "If True, neighbors of refined cells are also refined.",
          "title": "Refine Neighbors",
          "type": "boolean"
        },
        "strategy": {
          "const": "rank",
          "default": "rank",
          "description": "The strategy used to trigger refinement.",
          "enum": [
            "rank"
          ],
          "title": "Strategy",
          "type": "string"
        },
        "max_rank": {
          "default": 20,
          "description": "Maximum tensor rank allowed before refining.",
          "exclusiveMinimum": 0,
          "title": "Max Rank",
          "type": "integer"
        },
        "min_rank": {
          "default": 5,
          "description": "Minimum tensor rank required to keep a fine grid (coarsen if lower).",
          "minimum": 0,
          "title": "Min Rank",
          "type": "integer"
        }
      },
      "title": "RankRefinementConfig",
      "type": "object"
    },
    "Rounding": {
      "description": "Defines parameters for tensor rounding operations.",
      "properties": {
        "method": {
          "description": "Algorithm used for tensor train rounding.",
          "enum": [
            "svd",
            "gram",
            "randomized"
          ],
          "title": "Method",
          "type": "string"
        },
        "tt_sum": {
          "default": true,
          "description": "exploit sum specific rounding if available",
          "title": "Tt Sum",
          "type": "boolean"
        },
        "rank_increase_bound": {
          "default": 10000,
          "description": "rank increase bound for randomized rounding",
          "title": "Rank Increase Bound",
          "type": "integer"
        },
        "tol": {
          "description": "Rounding Tolerance",
          "exclusiveMinimum": 0.0,
          "title": "Tol",
          "type": "number"
        },
        "freq": {
          "description": "Frequency of rounding",
          "title": "Freq",
          "type": "integer"
        }
      },
      "required": [
        "method",
        "tol",
        "freq"
      ],
      "title": "Rounding",
      "type": "object"
    },
    "RusanovStencil": {
      "description": "Configuration for the Rusanov stencil.",
      "properties": {
        "name": {
          "const": "rusanov",
          "description": "Selects the Rusanov stencil.",
          "enum": [
            "rusanov"
          ],
          "title": "Name",
          "type": "string"
        },
        "wave_speed": {
          "description": "Extremal Wave Speed. For vacuum transport can choose same as speed of light.If it is too small, then scheme can be numerically unstable",
          "minimum": 0.0,
          "title": "Wave Speed",
          "type": "number"
        }
      },
      "required": [
        "name",
        "wave_speed"
      ],
      "title": "RusanovStencil",
      "type": "object"
    },
    "Saving": {
      "description": "Defines parameters for saving simulation results.",
      "properties": {
        "directory": {
          "description": "Location to save results.",
          "title": "Directory",
          "type": "string"
        },
        "plot_freq": {
          "default": 1,
          "description": "How often to generate plots.",
          "title": "Plot Freq",
          "type": "integer"
        },
        "spatial_save_freq": {
          "default": 100000,
          "description": "How often to save spatial quantities.",
          "title": "Spatial Save Freq",
          "type": "integer"
        },
        "keep_all": {
          "default": true,
          "description": "Whether or not to keep all solutions in memory.",
          "title": "Keep All",
          "type": "boolean"
        },
        "checkpoint_freq": {
          "default": 100000000,
          "description": "How often to save a checkpoint file.",
          "exclusiveMinimum": 0,
          "title": "Checkpoint Freq",
          "type": "integer"
        }
      },
      "required": [
        "directory"
      ],
      "title": "Saving",
      "type": "object"
    },
    "ScatterOnly": {
      "description": "Specifies a scatter-only source term.",
      "properties": {
        "name": {
          "const": "scatter only",
          "description": "Specifies a scatter-only source term.",
          "enum": [
            "scatter only"
          ],
          "title": "Name",
          "type": "string"
        }
      },
      "required": [
        "name"
      ],
      "title": "ScatterOnly",
      "type": "object"
    },
    "Solver": {
      "description": "Defines solver-specific parameters.",
      "properties": {
        "cfl": {
          "description": "CFL number for time step calculation.",
          "exclusiveMinimum": 0.0,
          "title": "Cfl",
          "type": "number"
        },
        "stencil": {
          "description": "The finite volume stencil to use for spatial flux.",
          "discriminator": {
            "mapping": {
              "jiang": "#/$defs/APFStencil",
              "rusanov": "#/$defs/RusanovStencil",
              "upwind": "#/$defs/UpwindStencil"
            },
            "propertyName": "name"
          },
          "oneOf": [
            {
              "$ref": "#/$defs/UpwindStencil"
            },
            {
              "$ref": "#/$defs/RusanovStencil"
            },
            {
              "$ref": "#/$defs/APFStencil"
            }
          ],
          "title": "Stencil"
        },
        "method": {
          "const": "forward euler",
          "description": "Time integration method.",
          "enum": [
            "forward euler"
          ],
          "title": "Method",
          "type": "string"
        },
        "num_steps": {
          "description": "Total number of time steps to run.",
          "exclusiveMinimum": 0,
          "title": "Num Steps",
          "type": "integer"
        },
        "rounding": {
          "allOf": [
            {
              "$ref": "#/$defs/Rounding"
            }
          ],
          "description": "Parameters for TT rounding/compression."
        },
        "order": {
          "description": "Order of variables in the tensor network.",
          "items": {
            "type": "string"
          },
          "title": "Order",
          "type": "array"
        }
      },
      "required": [
        "cfl",
        "stencil",
        "method",
        "num_steps",
        "rounding",
        "order"
      ],
      "title": "Solver",
      "type": "object"
    },
    "ThermalRelaxation": {
      "description": "Thermal Relaxation problem configuration.",
      "properties": {
        "name": {
          "const": "thermal relaxation",
          "enum": [
            "thermal relaxation"
          ],
          "title": "Name",
          "type": "string"
        },
        "Ti": {
          "description": "Initial constant temperature of the material.",
          "title": "Ti",
          "type": "number"
        },
        "Tri": {
          "description": "Initial radiation temperature for the intensity field.",
          "title": "Tri",
          "type": "number"
        }
      },
      "required": [
        "name",
        "Ti",
        "Tri"
      ],
      "title": "ThermalRelaxation",
      "type": "object"
    },
    "UpwindStencil": {
      "description": "Configuration for the Upwind stencil.",
      "properties": {
        "name": {
          "const": "upwind",
          "description": "Selects the upwind stencil.",
          "enum": [
            "upwind"
          ],
          "title": "Name",
          "type": "string"
        }
      },
      "required": [
        "name"
      ],
      "title": "UpwindStencil",
      "type": "object"
    }
  },
  "description": "The main configuration model for the entire simulation.",
  "properties": {
    "problem": {
      "description": "Problem-specific physical setup and parameters.",
      "oneOf": [
        {
          "$ref": "#/$defs/Hohlraum"
        },
        {
          "$ref": "#/$defs/ThermalRelaxation"
        },
        {
          "$ref": "#/$defs/GaussianDiffusion"
        },
        {
          "$ref": "#/$defs/LineSource"
        },
        {
          "$ref": "#/$defs/CrookedPipe"
        }
      ],
      "title": "Problem"
    },
    "geometry": {
      "allOf": [
        {
          "$ref": "#/$defs/Geometry"
        }
      ],
      "description": "Spatial domain and grid configuration."
    },
    "angles": {
      "allOf": [
        {
          "$ref": "#/$defs/Angles"
        }
      ],
      "description": "Angular discretization configuration."
    },
    "solver": {
      "allOf": [
        {
          "$ref": "#/$defs/Solver"
        }
      ],
      "description": "Numerical solver parameters."
    },
    "equations": {
      "allOf": [
        {
          "$ref": "#/$defs/Equations"
        }
      ],
      "description": "Physical constants and equation terms."
    },
    "saving": {
      "allOf": [
        {
          "$ref": "#/$defs/Saving"
        }
      ],
      "description": "Output and data saving configuration."
    },
    "checkpoint_directory": {
      "anyOf": [
        {
          "format": "directory-path",
          "type": "string"
        },
        {
          "type": "null"
        }
      ],
      "default": null,
      "description": "Checkpoint directory",
      "title": "Checkpoint Directory"
    },
    "refinement": {
      "description": "Adaptive Mesh Refinement configuration.",
      "discriminator": {
        "mapping": {
          "mean_intensity": "#/$defs/IntensityRefinementConfig",
          "rank": "#/$defs/RankRefinementConfig"
        },
        "propertyName": "strategy"
      },
      "oneOf": [
        {
          "$ref": "#/$defs/RankRefinementConfig"
        },
        {
          "$ref": "#/$defs/IntensityRefinementConfig"
        }
      ],
      "title": "Refinement"
    },
    "load_balancing": {
      "allOf": [
        {
          "$ref": "#/$defs/LoadBalancing"
        }
      ],
      "description": "Load balancing configuration."
    }
  },
  "required": [
    "problem",
    "geometry",
    "angles",
    "solver",
    "equations",
    "saving"
  ],
  "title": "Config",
  "type": "object"
}
```
