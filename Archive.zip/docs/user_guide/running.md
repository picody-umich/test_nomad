# Running Simulations

There are two ways to run simulations: using the **Makefile shortcuts** (easiest for standard examples) or using the **Command Line Interface (CLI)** directly (for custom configurations).

## 1. Quick Start: Running Standard Examples

The project includes several pre-configured example problems. You can run these using `make` commands. This handles the MPI invocation and input file selection for you.

### Available Examples

| Problem | Command | Description |
| :--- | :--- | :--- |
| **Crooked Pipe** | `make crooked_pipe` | Radiation flow through a bent pipe (2D). |
| **Hohlraum** | `make hohlraum1d`<br>`make hohlraum2d` | Radiation wave entering a vacuum. |
| **Thermal Relaxation** | `make therm_relax1d`<br>`make therm_relax2d` | Matter and radiation equilibration. |
| **Gaussian Diffusion** | `make gaussian_diffusion1d`<br>`make gaussian_diffusion2d` | Verification problems. |
| **Line Source** | `make line_source` | Radiation expanding from a center source. |

**Example:**

```
make crooked_pipe
```

## 2. Custom Runs: Using the CLI

To run a simulation with your own configuration file, use `bin/transport_solver.py`.

### Basic Syntax

```
python bin/transport_solver.py <path_to_config.yaml>
```

### Running with MPI (Parallel)

For parallel execution, use `mpiexec` (or `mpirun`). The number of processes (`-n`) must match the domain decomposition specified in your configuration file.

```
mpiexec -n <num_procs> python bin/transport_solver.py <path_to_config.yaml>
```

**Example:**
If your `my_config.yaml` specifies a domain decomposition requiring 4 ranks:
```
mpiexec -n 4 python bin/transport_solver.py my_config.yaml
```

## Output Files

Simulations output data to the directory specified in the `saving.directory` field of your YAML config (e.g., `results/crooked_pipe`).

The output directory will contain:

*   **`input.yaml`**: A copy of the exact configuration used for the run.
*   **`log.log`**: Detailed execution logs.
*   **`checkpoint_files/`**: Checkpoints allowing you to restart the simulation.
*   **`data_files/`**: Simulation data (typically `.npz` files) for post-processing.
