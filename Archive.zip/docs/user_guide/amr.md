# Adaptive Mesh Refinement (AMR)

`pytens_radtrans` supports block-structured Adaptive Mesh Refinement (AMR) to dynamically increase resolution in regions of interest while keeping the grid coarse elsewhere. This allows for significant computational savings in problems with localized features (e.g., wavefronts).

## Overview

The AMR system works by splitting "leaf" domains into $2^D$ children (Refinement) or merging $2^D$ siblings back into a parent (Coarsening).

*   **Refinement**: Triggered when a domain's complexity or intensity exceeds a threshold.
*   **Coarsening**: Triggered when all siblings in a family fall below a threshold.
*   **Balancing**: The grid maintains a 2:1 resolution balance between adjacent neighbors.

## Configuration

To enable AMR, add a `refinement` section to your YAML configuration file. The available options depend on the chosen `strategy`.

### Common Options

These options apply to all strategies:

| Option | Type | Default | Description |
| :--- | :--- | :--- | :--- |
| `enabled` | bool | `false` | Master switch to enable/disable AMR. |
| `strategy` | string | `"rank"` | The criteria used to trigger refinement. Options: `"rank"`, `"mean_intensity"`. |
| `frequency` | int | `1` | How many time steps to wait between adaptation checks. |
| `max_level` | int | `10` | Maximum depth of the refinement tree (Root = 0). Prevents infinite refinement. |
| `proper_nesting` | bool | `false` | If `true`, enforces a strict 1-level difference between neighbors. |
| `refine_neighbors` | bool | `true` | If `true`, neighbors of refined cells are also refined to create a buffer zone. |

---

### Strategy 1: Rank-Based (`rank`)

This strategy refines based on the complexity of the solution, measured by the ranks of the intensity Tensor Train. It is excellent for capturing sharp gradients and complex wavefronts.

```yaml
refinement:
  enabled: true
  strategy: "rank"
  max_rank: 15
  min_rank: 5
  max_level: 5
```

| Option | Type | Default | Description |
| :--- | :--- | :--- | :--- |
| `max_rank` | int | `20` | **Refinement Threshold**: If the max rank of the intensity tensor > `max_rank`, the domain splits. |
| `min_rank` | int | `5` | **Coarsening Threshold**: If the max rank of *all* siblings < `min_rank`, they merge. |

---

### Strategy 2: Mean Intensity (`mean_intensity`)

This strategy refines based on the magnitude of the radiation field relative to the global maximum. It is useful for tracking high-intensity regions (e.g., beams, sources) regardless of their complexity.

The thresholds are defined as fractions of the **Global Maximum Mean Intensity** ($M_{global}$).

*   **Refine Threshold**: $(1.0 - \text{refine\_fraction}) \times M_{global}$
*   **Coarsen Threshold**: $(1.0 - \text{coarsen\_fraction}) \times M_{global}$

```yaml
refinement:
  enabled: true
  strategy: "mean_intensity"
  
  # Refine if intensity is in the top 20% of the global range
  refine_fraction: 0.2
  
  # Coarsen if intensity is in the bottom 50% of the global range
  coarsen_fraction: 0.5
  
  max_level: 5
```

| Option | Type | Default | Description |
| :--- | :--- | :--- | :--- |
| `refine_fraction` | float | `0.2` | Defines the top percentile range to refine. E.g., `0.2` means refine if value > 80% of global max. |
| `coarsen_fraction` | float | `0.5` | Defines the bottom percentile range to coarsen. E.g., `0.5` means coarsen if value < 50% of global max. |

**Note:** `refine_fraction` must be smaller than `coarsen_fraction` to ensure hysteresis (preventing domains from instantly refining and coarsening in the same step).

## Load Balancing

When AMR changes the grid topology, the computational load may become imbalanced across MPI ranks. The Load Balancing system can dynamically redistribute domains to maintain efficiency.

To enable load balancing, add a `load_balancing` section to your YAML configuration.

### Example

```yaml
load_balancing:
  enabled: true
  strategy: "count"
  frequency: 10
  imbalance_threshold: 1.1
```

### Configuration Options

| Option | Type | Default | Description |
| :--- | :--- | :--- | :--- |
| `enabled` | bool | `false` | Master switch for dynamic load balancing. |
| `strategy` | string | `"parameters"` | Metric for load estimation. `"count"` balances the number of domains. `"parameters"` balances based on tensor parameters (cost). |
| `frequency` | int | `10` | How many time steps to wait between load balancing checks. |
| `imbalance_threshold` | float | `1.1` | Imbalance tolerance. Migration occurs if `max_load / avg_load > threshold`. |
