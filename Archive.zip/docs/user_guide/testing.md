# Testing & Development

To ensure code stability and correctness, we provide a suite of tests and static analysis tools.

## Running Tests

We use `pytest` for unit and integration testing.

To run the full test suite:

```
make test
```

## Static Analysis

We enforce code quality using `ruff` (linting/formatting) and `mypy` (static type checking).

### Linting & Formatting
To check for linting errors and automatically fix simple ones:
```
make lint
```

To format the code (auto-indentation, spacing):
```
make format
```

### Type Checking
To verify type hints across the codebase:
```
make type-check
```

## Running Everything

To run the formatter, linter, type checker, and tests in one go (recommended before pushing code):

```
make check-all
```

## Test Coverage

The test suite is organized by module and functionality. Here is a map of what each file tests:

| Test File | Description |
| :--- | :--- |
| **Integration & System** | |
| `test_amr_integration.py` | Full AMR cycle (Refinement $\leftrightarrow$ Coarsening) on 1D/2D problems. |
| `test_integration.py` | Standard fixed-grid simulation integration tests. |
| `test_main_loop.py` | High-level driver logic, including time-stepping and I/O orchestration. |
| **AMR & Domain Logic** | |
| `test_domain_decomp.py` | Tree structure manipulation, neighbor finding, and domain management. |
| `test_domain_decomp_amr.py` | AMR-specific tree logic: balancing constraints, refinement propagation. |
| `test_refinement.py` | Trigger logic (`should_refine`) and spatial data splitting/merging. |
| `test_load_balancing.py` | Partitioning strategies and load distribution weights. |
| `test_amr_loop.py` | The adaptation control loop (`handle_adaptation`). |
| `test_reinit.py` | Rebuilding topology operators (neighbors, comms) mid-simulation. |
| **Physics & Numerics** | |
| `test_solver.py` | Source terms (scattering, ideal gas) and time integration. |
| `test_stencil.py` | Spatial flux schemes (Upwind, Rusanov, Jiang) and masking. |
| `test_flux_corrector.py` | Flux correction logic for AMR interfaces (conservation). |
| `test_bcs.py` | Boundary condition policies (Dirichlet, Outflow, Periodic). |
| `test_discretization.py` | Spatial and angular grid generation and ghost cell handling. |
| **Infrastructure** | |
| `test_load_config.py` | Configuration file validation and schema checks. |
| `test_monitor.py` | Data I/O, checkpointing, and plotting routines. |
| `test_utils.py` | Low-level utilities, including Tensor Train wrappers. |
