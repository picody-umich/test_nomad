# pytens_radtrans

**pytens_radtrans** implements low-rank tensor solvers for thermal radiation transport problems.

## Features

*   **Tensor Network Solvers**: Efficient high-dimensional integration and solution representation.
*   **Adaptive Mesh Refinement (AMR)**: Dynamic grid resolution based on solution complexity.
*   **MPI Compliant**: Designed for parallel execution with dynamic load balancing.
*   **Flexible Configuration**: YAML-based problem setup.

## Getting Started

Check out the [Installation Guide](user_guide/installation.md) to get set up.
