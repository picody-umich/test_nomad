# Creating Custom Refinement Triggers

The AMR system decides when to refine or coarsen a domain based on a **Trigger**. The default trigger uses the rank of the intensity tensor, but you can implement custom logic (e.g., based on temperature gradients or error estimates).

## The `RefinementTrigger` Interface

All triggers must inherit from the abstract base class `RefinementTrigger` defined in `pytens_radtrans.refinement`.

```python
from abc import ABC, abstractmethod
from mpi4py import MPI
from pytens_radtrans import solver

class RefinementTrigger(ABC):
    """Abstract base class for AMR triggers."""

    def update_global_stats(self, comm: MPI.Comm, local_sols: list[solver.Solution]) -> None:
        """
        Updates global statistics needed for the trigger (e.g. global max).
        
        This is called once per adaptation step, before iterating over leaves.
        
        Args:
            comm: The MPI communicator.
            local_sols: List of local solutions on this rank.
        """
        pass  # Default implementation does nothing

    @abstractmethod
    def should_refine(self, sol: solver.Solution) -> bool:
        """
        Determines if a single domain should be refined.
        
        Args:
            sol: The local solution object for the domain.
            
        Returns:
            True if the domain should split, False otherwise.
        """
        pass

    @abstractmethod
    def should_coarsen(self, sols: list[solver.Solution]) -> bool:
        """
        Determines if a family of siblings should be coarsened.
        
        Args:
            sols: A list of Solution objects, one for each sibling.
            
        Returns:
            True if the siblings should merge, False otherwise.
        """
        pass
```

## Example: Global Gradient Trigger

Here is an example of a trigger that refines based on the spatial gradient of the temperature field, normalized by the **global maximum gradient**. This demonstrates the use of `update_global_stats`.

```python
import numpy as np
from mpi4py import MPI
from pytens_radtrans.refinement import RefinementTrigger

class NormalizedGradientTrigger(RefinementTrigger):
    def __init__(self, threshold_fraction: float):
        self.threshold_fraction = threshold_fraction
        self.global_max_grad = 1.0

    def _compute_local_max_grad(self, sol):
        temp = sol.space.get("temperature")
        if temp is None: return 0.0
        grad = np.gradient(temp)
        mag = np.sqrt(sum(g**2 for g in grad))
        return np.max(mag)

    def update_global_stats(self, comm, local_sols):
        # 1. Find max gradient on this rank
        local_max = 0.0
        for sol in local_sols:
            local_max = max(local_max, self._compute_local_max_grad(sol))
        
        # 2. Find global max across all ranks
        self.global_max_grad = comm.allreduce(local_max, op=MPI.MAX)

    def should_refine(self, sol: solver.Solution) -> bool:
        local_max = self._compute_local_max_grad(sol)
        
        # Refine if local gradient is significant compared to global max
        return local_max > (self.threshold_fraction * self.global_max_grad)

    def should_coarsen(self, sols: list[solver.Solution]) -> bool:
        # (Simplified) Coarsen if all siblings are very flat
        for sol in sols:
            if self._compute_local_max_grad(sol) > (0.1 * self.global_max_grad):
                return False
        return True
```

## Integration

To use your new trigger:

1.  Implement the class in `pytens_radtrans/refinement.py` (or a new module).
2.  Update the configuration loader in `pytens_radtrans/load_config.py` to accept a new strategy name (e.g., `"gradient"`).
3.  Update the trigger factory logic in `pytens_radtrans/main_loop_utils.py` to instantiate your class when that strategy is selected.
