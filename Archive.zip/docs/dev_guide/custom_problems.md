# Creating a New Problem

This guide walks you through the process of defining and integrating a new physics problem into `pytens_radtrans`.

The core of this process is subclassing the `Problem` abstract base class found in `pytens_radtrans.problems` and implementing its required methods.

## Step 1: Subclass the `Problem` ABC

Create a new class that inherits from `pytens_radtrans.problems.Problem`. As an example, let's create a simple "Uniform Beam" problem.

```python
# In pytens_radtrans/problems.py

from . import bcs, discretization, types

class UniformBeam(Problem):
    """
    A simple problem where a uniform beam of radiation enters from the left
    boundary into a cold, uniform medium.
    """
    # ... methods go here ...
```

## Step 2: Implement Required Methods

You must implement the abstract methods defined in the `Problem` base class.

### `ic_space`
This method sets the initial spatial conditions, like temperature and density. You should return a dictionary mapping field names to NumPy arrays.

```python
    def ic_space(
        self, disc: discretization.Discretization
    ) -> dict[str, types.NDArrayF]:
        """Sets the initial temperature and density."""
        temp = disc.to_field(self.config.background_temperature)
        density = disc.to_field(1.0)
        return {"temperature": temp, "density": density}
```

### `get_bc`
This method defines the boundary conditions for the radiation intensity. You must return a `bcs.BoundaryConditions` object that specifies a policy for each side of the domain. The `boundaries.bounds` attribute contains the set of physical boundaries for the current MPI rank's domain.

```python
    def get_bc(self, disc: discretization.Discretization) -> bcs.BoundaryConditions:
        """Defines boundary conditions for the beam problem."""
        boundaries = bcs.BoundaryConditions(disc)

        # Left boundary: Inflow with a fixed source temperature
        if types.Direction.LEFT in boundaries.bounds:
            left_bc_val = self.planck(self.config.source_temperature)
            boundaries.add_condition(types.Direction.LEFT, bcs.Dirichlet(left_bc_val))

        # Other boundaries: Outflow (zero-gradient)
        if types.Direction.RIGHT in boundaries.bounds:
            boundaries.add_condition(types.Direction.RIGHT, bcs.Outflow())
        if types.Direction.TOP in boundaries.bounds:
            boundaries.add_condition(types.Direction.TOP, bcs.Outflow())
        if types.Direction.BOTTOM in boundaries.bounds:
            boundaries.add_condition(types.Direction.BOTTOM, bcs.Outflow())

        return boundaries
```

## Step 3 (Optional): Implement Custom Plotting

You can add custom visualizations for your problem by implementing the `plot_per_step` or `plot_per_step_overlay` methods.

*   `plot_per_step`: Use this to create a completely new plot from scratch.
*   `plot_per_step_overlay`: Use this to draw on top of the default plot (e.g., adding an analytical solution line to a contour plot). This is the more common method to implement.

Here is an example of overlaying an analytical solution for our "Uniform Beam" problem.

```python
    def plot_per_step_overlay(
        self,
        plot_data: list,
        domain_manager: DomainManager,
        time: float,
        iteration: int,
        fig: Figure | None = None,
        save_filename: Path | None = None,
    ) -> Figure | None:
        """Overlays the analytical beam front position."""
        if fig is None:
            return None  # Should not happen if overlaying

        ax = fig.axes[0]
        # Assuming speed_of_light is accessible, e.g., from self.config
        speed_of_light = 2997.9 
        beam_front_x = time * speed_of_light
        
        # Plot a vertical line for the analytical beam front
        ax.axvline(x=beam_front_x, color='r', linestyle='--', label='Analytical Front')
        
        # Avoid duplicate labels
        if not ax.get_legend():
            ax.legend()
        
        return fig
```



## Step 4: Register the Problem in `load_config.py`

To make your new problem selectable in the YAML configuration file, you need to register it.

1.  **Define a Pydantic Model**: Create a model for your problem's specific configuration options in `pytens_radtrans/load_config.py`.

```python
    # In pytens_radtrans/load_config.py

    class UniformBeamConfig(pd.BaseModel):
        name: Literal["uniform beam"]
        background_temperature: float
        source_temperature: float
```

2.  **Add to the Union**: Add your new config model to the `Problem` discriminated union.

```python
    # In pytens_radtrans/load_config.py

    Problem = Annotated[
        Union[
            ...,  # Existing problem configs
            UniformBeamConfig,
        ],
        pd.Field(discriminator=problem_get_discriminator_value),
    ]
```

## Step 5: Use it in a YAML file

You can now select your problem in an input file:

```yaml
problem:
  name: 'uniform beam'
  background_temperature: 0.1
  source_temperature: 1.0
```


