# Boundary Conditions

::: pytens_radtrans.bcs
