# Stencil

::: pytens_radtrans.stencil
