# Refinement & AMR

::: pytens_radtrans.refinement
