# Discretization

::: pytens_radtrans.discretization
