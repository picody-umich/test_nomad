# Domain Decomposition

::: pytens_radtrans.domain_decomp
