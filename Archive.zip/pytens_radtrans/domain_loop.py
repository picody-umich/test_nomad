"""
Implements the core logic for a single time step within a single domain.

This module contains the `domain_step` function, which advances the simulation
state for one time step by applying an operator-splitting scheme. It handles
the hyperbolic transport update and the source term update sequentially.
"""

import logging
from collections.abc import Callable

import numpy as np
import pytens

from . import solver, utils
from .load_config import Config


def domain_step(  # pylint: disable=R0913
    prev_sol: solver.Solution,
    ii: int,
    dt: float,
    absorption_opacity_with_ghost: np.ndarray,
    scattering_opacity_with_ghost: np.ndarray,
    additive_tensors: list[pytens.TensorNetwork],
    rhs: Callable,
    config: Config,
    disc: solver.AngleDiscretization,
    indices: solver.Indices,
    logger: logging.Logger,
    flux_corrections: list[pytens.TensorNetwork] | None = None,
) -> solver.Solution:
    """
    Performs a single time step for a given domain using operator splitting.

    This function advances the solution in time by `dt` through two main steps:
    1.  **Hyperbolic Step**: Solves the transport part of the equation using an
        explicit forward Euler method. The right-hand side (RHS) is computed,
        added to the previous solution's intensity, and optionally rounded.
    2.  **Source Step**: Applies the source term (e.g., ideal gas temperature
        coupling or scattering) to the result of the hyperbolic step. The
        resulting intensity is again optionally rounded.

    Args:
        prev_sol: The solution state from the previous time step.
        ii: The current time step number, used to determine when to apply rounding.
        dt: The time step size.
        absorption_opacity_with_ghost: The absorption opacity field, including
            ghost cells.
        scattering_opacity_with_ghost: The scattering opacity field, including
            ghost cells.
        additive_tensors: A list of additional tensor networks to be included
            in the RHS calculation (e.g., for boundary conditions).
        rhs: A callable that constructs the right-hand side of the hyperbolic
            update as a `TNOPList`.
        config: The main simulation configuration object.
        disc: The angular discretization object.
        indices: The problem indices object.
        logger: The logger for recording simulation information.
        flux_corrections: An optional list of pre-computed flux correction
            tensors to be added to the final RHS.

    Returns:
        A new `Solution` object representing the state after the time step.

    Raises:
        NotImplementedError: If the solver method specified in the configuration
            is not "forward euler".
    """
    ###############################################################
    # Hyperbolic Solver Explicit Step
    ###############################################################
    if config.solver.method == "forward euler":
        sum_update = rhs(  ### rhs needs to update
            additive_tensors,
            {
                "absorption_opacity": absorption_opacity_with_ghost,
                "scattering_opacity": scattering_opacity_with_ghost,
            },
        )
        sum_update.append(utils.TT(prev_sol.intensity))
        if flux_corrections:
            for correction in flux_corrections:
                sum_update.append(utils.TT(correction))

    else:
        raise NotImplementedError("This solver not implemented")

    if ii % config.solver.rounding.freq == 0:
        # logger.info("Step %d Rounding Pre Split", ii)
        prev_ranks = prev_sol.intensity.ranks()
        tt_update = sum_update.evaluate_round(config.solver.rounding, prev_ranks)
    else:
        tt_update = sum_update.evaluate()

    # print(tt_update)
    # exit(1)
    assert prev_sol.space is not None
    new_sol = solver.Solution(prev_sol.time + dt, tt_update, prev_sol.space.copy())

    ###############################################################
    # Source term + splitting step
    ###############################################################

    # Implements a splitting scheme!
    next_intensity = None
    if config.equations.source.name == "ideal gas":
        # raise NotImplementedError("Need to fix inputs for ideal gas")
        next_intensity, next_temp = solver.temp_equation_ideal_gas(
            indices, disc, dt, new_sol, config
        )
        assert new_sol.space is not None
        new_sol.space["temperature"] = next_temp
    elif config.equations.source.name == "scatter only":
        next_intensity = solver.scatter_source(indices, disc, dt, new_sol, config)

    # If a source term was applied, update the intensity tensor
    if next_intensity is not None:
        if ii % config.solver.rounding.freq == 0:
            # logger.info("Step %d rounding", ii)
            current_ranks = new_sol.intensity.ranks()
            new_sol.intensity = next_intensity.evaluate_round(
                config.solver.rounding, current_ranks
            )
        else:
            new_sol.intensity = next_intensity.evaluate()

    return new_sol
