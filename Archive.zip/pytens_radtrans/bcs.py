import abc
import copy
from typing import cast

import numpy as np
import pytens

from .discretization import Discretization, Indices
from .load_config import Config
from .types import Direction, NDArrayF
from .utils import encode_order, reorder_list


class Condition(abc.ABC):
    """Abstract base class for a boundary condition policy."""

    @abc.abstractmethod
    def get_value(
        self, arr: NDArrayF, side: Direction, disc: Discretization
    ) -> NDArrayF | float:
        """Calculates the value to be placed in the ghost cells.

        Args:
            arr: The interior data array.
            side: The boundary side to calculate the value for.
            disc: The discretization of the domain.

        Returns:
            The value(s) for the ghost cells on the specified side.
        """
        raise NotImplementedError


class Outflow(Condition):
    """
    Policy for an outflow condition.

    The ghost cell value is set to the value of the adjacent interior cell.
    """

    def get_value(
        self, arr: NDArrayF, side: Direction, disc: Discretization
    ) -> NDArrayF | float:
        """Returns the value from the adjacent interior cells.

        Args:
            arr: The interior data array.
            side: The boundary side to get the value from.
            disc: The discretization of the domain.

        Returns:
            The value from the adjacent interior cell(s).
        """
        if side == Direction.WEST:
            return cast(NDArrayF | float, arr[0])
        if side == Direction.EAST:
            return cast(NDArrayF | float, arr[-1])
        if disc.dimension == 2:
            if side == Direction.SOUTH:
                return cast(NDArrayF | float, arr[:, 0])
            if side == Direction.NORTH:
                return cast(NDArrayF | float, arr[:, -1])
        return 0.0  # Default case if side is not applicable


class Dirichlet(Condition):
    """Policy for a Dirichlet condition with a fixed value."""

    def __init__(self, value: float | NDArrayF):
        """Initializes the Dirichlet condition.

        Args:
            value: The fixed value for the boundary condition.
        """
        self.value = value

    def get_value(
        self, arr: NDArrayF, side: Direction, disc: Discretization
    ) -> NDArrayF | float:
        """Returns the fixed Dirichlet value.

        Args:
            arr: Not used for Dirichlet conditions.
            side: Not used for Dirichlet conditions.
            disc: Not used for Dirichlet conditions.

        Returns:
            The fixed value for the boundary.
        """
        return self.value


class Periodic(Condition):
    """
    Policy for a periodic condition.

    The ghost cell value is set to the value of the cell on the opposite side.
    """

    def get_value(
        self, arr: NDArrayF, side: Direction, disc: Discretization
    ) -> NDArrayF | float:
        """Returns the value from the opposite side's interior cells.

        Args:
            arr: The interior data array.
            side: The boundary side to calculate the value for.
            disc: The discretization of the domain.

        Returns:
            The value from the interior cells on the opposite side.
        """
        if side == Direction.WEST:
            return cast(
                NDArrayF | float, arr[-1]
            )  # West ghost gets value from far East
        if side == Direction.EAST:
            return cast(NDArrayF | float, arr[0])  # East ghost gets value from far West
        if disc.dimension == 2:
            if side == Direction.SOUTH:
                return cast(
                    NDArrayF | float, arr[:, -1]
                )  # South ghost gets value from far North
            if side == Direction.NORTH:
                return cast(
                    NDArrayF | float, arr[:, 0]
                )  # North ghost gets value from far South
        return 0.0


class BoundaryConditions:
    """Manages and applies boundary conditions for a domain.

    This class holds the boundary condition policies for each side of a domain
    and provides methods to apply them to spatial data arrays and tensor networks.

    Attributes:
        disc: The discretization of the domain.
        bounds: A set of directions that are physical boundaries.
        conditions: A dictionary mapping boundary directions to condition policies.
        permut: The permutation order for tensor dimensions.
        inv_permut: The inverse permutation order.
    """

    def __init__(
        self,
        disc: Discretization,
        config: Config,
        bounds: list[Direction],
    ):
        """Initializes the BoundaryConditions manager.

        Args:
            disc: The discretization of the domain.
            config: The main simulation configuration object.
            bounds: A list of directions that represent physical boundaries.
        """
        self.disc = disc
        self.bounds = set(bounds)
        self.conditions: dict[Direction, Condition] = {}
        self.permut, self.inv_permut = encode_order(config.solver.order)

    def add_condition(self, side: Direction, condition: Condition) -> None:
        """Adds a boundary condition policy for a specific side.

        Args:
            side: The boundary side (e.g., WEST, NORTH).
            condition: The boundary condition object (e.g., Dirichlet, Outflow).
        """
        self.conditions[side] = condition

    def add_bc_ghost_to_core(self, arr: NDArrayF) -> NDArrayF:
        """Applies non-Dirichlet boundary conditions to a spatial array.

        This method first adds ghost cells to the array and then fills them
        with values determined by the non-Dirichlet boundary conditions (e.g.,
        Outflow, Periodic).

        Args:
            arr: The interior spatial data array.

        Returns:
            A new spatial data array with ghost cells added and filled.
        """
        new_space_core = self.disc.add_ghost(arr)

        bc_values: dict[Direction, NDArrayF | float] = {}

        for side, cond in self.conditions.items():
            if side in self.bounds and not isinstance(cond, Dirichlet):
                bc_values[side] = cond.get_value(arr, side, self.disc)

        left_bc = bc_values.get(Direction.WEST, 0.0)
        right_bc = bc_values.get(Direction.EAST, 0.0)
        bottom_bc = bc_values.get(Direction.SOUTH, 0.0)
        top_bc = bc_values.get(Direction.NORTH, 0.0)

        new_space_core = self.disc.update_ghost(
            new_space_core, left_bc, right_bc, bottom_bc, top_bc
        )

        return new_space_core

    def add_and_fill_in_spatial_core_ghost_cells(
        self, tens: pytens.TensorNetwork
    ) -> pytens.TensorNetwork:
        """Add ghost cells to the spatial tensor core.

        This method checks if a tensor core already has ghost cells. If not, it
        reshapes the core, adds ghost cells, fills them using the appropriate
        non-Dirichlet boundary conditions, and then reshapes it back.

        Args:
            tens: The tensor network containing the spatial core.

        Returns:
            A new tensor network with ghost cells added to its spatial core.
        """
        # --- Check if tensor already has ghost cells ---
        spatial_core_pos = self.inv_permut[0]
        spatial_core = tens.node_tensor(spatial_core_pos)
        shape = spatial_core.value.shape

        # Infer TT ranks from the core shape to avoid assumptions about
        # tens.ranks() length/order when the spatial core is last.
        if len(shape) == 2:
            if spatial_core_pos == 0:  # First core: (phys_dim, rank_out)
                rank_left, rank_right = 1, shape[-1]
            else:  # Last core: (rank_in, phys_dim)
                rank_left, rank_right = shape[0], 1
        elif len(shape) == 3:  # Middle core: (rank_in, phys_dim, rank_out)
            rank_left, rank_right = shape[0], shape[-1]
        else:
            raise ValueError("TT cores must be 2-D or 3-D.")

        total_elements = spatial_core.value.size

        # If a rank is zero, the tensor is empty. Avoid division by zero.
        if rank_left * rank_right == 0:
            spatial_elements = 0
        else:
            spatial_elements = total_elements // (rank_left * rank_right)

        interior_size = np.prod(self.disc.grid.num_cells)

        # If the number of spatial elements is larger than the interior grid size,
        # it means ghost cells have already been added. Return it as-is to
        # prevent data corruption from an incorrect reshape. This check makes
        # the function idempotent.
        if spatial_elements > interior_size:
            return tens

        # --- If not, proceed with adding ghost cells as before ---
        new_tens = copy.deepcopy(tens)
        spatial_core = new_tens.node_tensor(self.inv_permut[0])
        shape = spatial_core.value.shape

        # The reshaping logic depends on the TT core's position. The goal is
        # to reshape the core's value into a grid-like structure (e.g.,
        # [nx, ny, rank_product]), apply the BCs, and then reshape it back.
        if len(shape) == 2:  # First or last core
            if self.inv_permut[0] == 0:  # First core: (phys_dim, rank_out)
                new_core_value = self.add_bc_ghost_to_core(
                    spatial_core.value.reshape((*self.disc.grid.num_cells, shape[-1]))
                )
                new_core_value = new_core_value.reshape((-1, shape[-1]))
            else:  # Last core: (rank_in, phys_dim)
                new_core_value = self.add_bc_ghost_to_core(
                    np.moveaxis(
                        spatial_core.value.reshape(
                            (shape[0], *self.disc.grid.num_cells)
                        ),
                        0,
                        -1,
                    )
                )
                new_core_value = np.moveaxis(new_core_value, -1, 0).reshape(
                    (shape[0], -1)
                )

        else:  # Middle core: (rank_in, phys_dim, rank_out)
            new_core_value = self.add_bc_ghost_to_core(
                np.moveaxis(spatial_core.value, 0, -1).reshape(
                    (*self.disc.grid.num_cells, -1)
                )
            ).reshape((-1, shape[-1], shape[0]))
            new_core_value = np.moveaxis(new_core_value, -1, 0)

        new_core = spatial_core.update_val_size(new_core_value)
        new_tens.set_node_tensor(self.inv_permut[0], new_core)
        return new_tens

    def dirichlet_op(self) -> NDArrayF:
        """Creates an additive tensor for Dirichlet conditions.

        This method constructs a spatial array where the ghost cell regions are
        filled with the values from any applied Dirichlet conditions. Interior
        cells are zero.

        Returns:
            An array with Dirichlet boundary values in the ghost cell regions,
            or an empty array if no Dirichlet conditions are applied.
        """
        num_ghost = self.disc.grid.num_ghost
        new_shape = np.array(self.disc.grid.num_cells, dtype=np.int32) + num_ghost
        x = np.zeros(new_shape)

        if self.disc.dimension == 1:
            num_ghost_lr = num_ghost[0] // 2
            if Direction.WEST in self.bounds:
                cond = self.conditions.get(Direction.WEST)
                if isinstance(cond, Dirichlet):
                    x[:num_ghost_lr] = cond.value
            if Direction.EAST in self.bounds:
                cond = self.conditions.get(Direction.EAST)
                if isinstance(cond, Dirichlet):
                    x[-num_ghost_lr:] = cond.value
        elif self.disc.dimension == 2:
            num_ghost_lr = num_ghost[0] // 2
            num_ghost_ud = num_ghost[1] // 2
            if Direction.WEST in self.bounds:
                cond = self.conditions.get(Direction.WEST)
                if isinstance(cond, Dirichlet):
                    x[:num_ghost_lr, num_ghost_ud:-num_ghost_ud] = cond.value
            if Direction.EAST in self.bounds:
                cond = self.conditions.get(Direction.EAST)
                if isinstance(cond, Dirichlet):
                    x[-num_ghost_lr:, num_ghost_ud:-num_ghost_ud] = cond.value
            if Direction.SOUTH in self.bounds:
                cond = self.conditions.get(Direction.SOUTH)
                if isinstance(cond, Dirichlet):
                    x[num_ghost_lr:-num_ghost_lr, :num_ghost_ud] = cond.value
            if Direction.NORTH in self.bounds:
                cond = self.conditions.get(Direction.NORTH)
                if isinstance(cond, Dirichlet):
                    x[num_ghost_lr:-num_ghost_lr, -num_ghost_ud:] = cond.value

        return x if np.any(x) else np.array([])

    def get_dirichlet_op(self, ind: Indices) -> pytens.TensorNetwork | None:
        """Get potential additive term for ghost cell boundary conditions.

        Constructs a rank-1 tensor network representing the Dirichlet boundary
        conditions, which can be added to the main solution tensor network.

        Args:
            ind: The indices for the tensor network.

        Returns:
            A tensor network for the Dirichlet boundary term, or None if no
            Dirichlet conditions are present.
        """
        x = self.dirichlet_op()
        if not x.size:
            return None

        x = x.flatten()
        new_ind_space = ind.space.with_new_size(x.shape[0])
        theta = np.ones(ind.theta.size)
        phi = np.ones(ind.phi.size)
        ind_list = reorder_list([new_ind_space, ind.theta, ind.phi], self.permut)
        f = pytens.tt_rank1(ind_list, reorder_list([x, theta, phi], self.permut))
        return f
