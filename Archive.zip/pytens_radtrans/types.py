"""Type information."""

import enum

import numpy as np
import numpy.typing as npt

NDArrayF = npt.NDArray[np.float64]


class Direction(enum.Enum):
    """Enumeration for cardinal and diagonal directions."""

    EAST = 1
    WEST = 2
    NORTH = 3
    SOUTH = 4
    NORTH_EAST = 5
    NORTH_WEST = 6
    SOUTH_EAST = 7
    SOUTH_WEST = 8


def get_opposite_direction(direction: Direction) -> Direction:
    """Returns the opposite cardinal direction."""
    if direction == Direction.EAST:
        return Direction.WEST
    if direction == Direction.WEST:
        return Direction.EAST
    if direction == Direction.NORTH:
        return Direction.SOUTH
    if direction == Direction.SOUTH:
        return Direction.NORTH
    raise ValueError(f"Opposite not defined for diagonal direction {direction.name}")
