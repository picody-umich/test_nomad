"""General utility functions and classes."""

import abc
from collections.abc import Callable
from dataclasses import dataclass, field
from typing import Any, cast

import numpy as np
import pytens

from .load_config import Rounding


def reorder_list(lst: list[Any], new_order: list[int]) -> list[Any]:
    """Reorders a list according to a new index order.

    Args:
        lst: The list to reorder.
        new_order: A list of indices specifying the new order.

    Returns:
        The reordered list.
    """
    return [lst[i] for i in new_order]


def num_parameters(tt: pytens.TensorNetwork) -> int:
    """Returns the number of scalar parameters in a tensor network.

    This is a thin wrapper over the pytens ``cost()`` API used by runtime
    components (e.g., load balancing).

    Args:
        tt: Tensor network whose parameter count is requested.

    Returns:
        Integer number of parameters.
    """
    return int(tt.cost())


class TTObj(abc.ABC):
    """Abstract base class for a tensor train object wrapper."""

    @abc.abstractmethod
    def evaluate(self) -> pytens.TensorNetwork:
        """Evaluates and returns a single tensor network."""

    @abc.abstractmethod
    def evaluate_to_list(self) -> list[pytens.TensorNetwork]:
        """Evaluates and returns a list of tensor networks."""


class TT(TTObj):
    """Wrapper for a static tensor network."""

    def __init__(self, tt: pytens.TensorNetwork):
        """Initializes the TT wrapper.

        Args:
            tt: The tensor network to wrap.
        """
        self.tt = tt

    def evaluate(self) -> pytens.TensorNetwork:
        """Returns the stored tensor network."""
        return self.tt

    def evaluate_to_list(self) -> list[pytens.TensorNetwork]:
        """Returns the stored tensor network as a single-element list."""
        return [self.tt]


class TTop(TTObj):
    """Represents a Tensor Train operator application."""

    def __init__(
        self,
        tt_base: pytens.TensorNetwork,
        ind_in: list[pytens.Index],
        ind_out: list[pytens.Index],
        op: list[tuple[Callable[..., Any], ...]],
        scale: float | None = None,
    ):
        """Initializes the TTop.

        Args:
            tt_base: The base tensor network.
            ind_in: List of input indices.
            ind_out: List of output indices.
            op: List of operations (tuples of callables) to apply.
            scale: Optional scaling factor.
        """
        self.tt_base = tt_base
        self.ind_in = ind_in
        self.ind_out = ind_out
        self.op = op
        self.scale = scale

    def evaluate_to_list(self) -> list[pytens.TensorNetwork]:
        """Evaluates the operator application, returning a list of networks."""
        rename_map = {
            iout.name: iin.name
            for iout, iin in zip(self.ind_out, self.ind_in, strict=False)
        }
        out = []
        for cores in self.op:
            opc = pytens.ttop_sum_apply(
                self.tt_base, self.ind_in, self.ind_out, [cores], "A"
            ).scale(self.scale)
            opc = opc.rename_indices(rename_map)
            out.append(opc)

        return out

    def evaluate(self) -> pytens.TensorNetwork:
        """Evaluates the operator application, returning a single network."""
        opx = pytens.ttop_sum_apply(
            self.tt_base, self.ind_in, self.ind_out, self.op, "A"
        ).scale(self.scale)

        rename_map = {
            iout.name: iin.name
            for iout, iin in zip(self.ind_out, self.ind_in, strict=False)
        }

        opx = opx.rename_indices(rename_map)
        return opx


@dataclass
class TNOPList:
    """Manages a list of tensor train operations (interpreted as a sum)."""

    tt_list: list[TTObj] = field(default_factory=list)

    def append(self, tt: TTObj) -> None:
        """Appends a TT object to the list."""
        self.tt_list.append(tt)

    def evaluate(self) -> pytens.TensorNetwork:
        """Evaluates the sum of all TT objects into a single tensor network."""
        tt_evals = [tt.evaluate() for tt in self.tt_list]
        out = pytens.tt_sum(tt_evals)
        return out

    def evaluate_round(
        self, rounding_opts: Rounding, current_ranks: list[int] | np.ndarray
    ) -> pytens.TensorNetwork:
        """Evaluates and rounds the result according to configuration.

        Args:
            rounding_opts: Configuration for rounding.
            current_ranks: Current ranks of the tensor network (used for randomized
                rounding).

        Returns:
            The rounded tensor network.

        Raises:
            NotImplementedError: If the rounding method is not supported.
        """
        if rounding_opts.method == "randomized":
            rank_bound = np.array(current_ranks) + rounding_opts.rank_increase_bound
            if rounding_opts.tt_sum:
                evals = []
                for ttobj in self.tt_list:
                    ev = ttobj.evaluate_to_list()
                    evals.extend(ev)

                tt_evals = pytens.tt_rand_precond_svd_round(
                    evals, rounding_opts.tol, rank_bound
                )
                return tt_evals

            evals_single = self.evaluate()
            tt_evals = pytens.tt_rand_precond_svd_round(
                evals_single, rounding_opts.tol, rank_bound
            )
            return tt_evals

        if rounding_opts.method == "svd":
            if not rounding_opts.tt_sum:
                evals_single = self.evaluate()
                tt_evals = pytens.tt_svd_round(evals_single, rounding_opts.tol)
                return tt_evals

            raise NotImplementedError(
                "SVD rounding that exploits TT sums is not implemented."
            )

        if rounding_opts.method == "gram":
            if not rounding_opts.tt_sum:
                evals_single = self.evaluate()
                tt_evals = pytens.tt_gramsvd_round(evals_single, rounding_opts.tol)
                return tt_evals

            evals = []
            for ttobj in self.tt_list:
                ev = ttobj.evaluate_to_list()
                evals.extend(ev)

            tt_evals = pytens.tt_sum_gramsvd_round(evals, rounding_opts.tol)
            return tt_evals

        raise NotImplementedError(
            f"Rounding method: {rounding_opts.method}, is not implemented."
        )


def quartic_solve(coeff_four: np.ndarray, const_term: np.ndarray) -> np.ndarray:
    """Solves the quartic equation coeff_four * T^4 + T + const_term = 0 for T > 0.

    Implementation based on AthenaK radiation source solver.

    Args:
        coeff_four: Coefficient of the T^4 term.
        const_term: Constant term.

    Returns:
        The positive real root T.

    Raises:
        ValueError: If the solver fails to find a valid root.
    """
    # Calculate real root of z^3 - 4*tconst/coef4 * z - 1/coef4^2 = 0
    cubic = const_term**3
    delta = 0.25 - 64.0 * cubic * coeff_four / 27.0
    if np.any(delta < 0.0):
        raise ValueError("Root solver issue: delta < 0")

    delta1 = np.sqrt(delta)
    if np.any(delta1 < 0.5):
        raise ValueError("Root solver issue: delta1 < 0.5")

    zroot = delta1.copy()
    inds = delta1 > 1.0e11

    # Approximation for large delta1
    zroot[inds] = delta1[inds] ** (-2.0 / 3.0) / 3.0
    # Exact formula for smaller delta1
    zroot[~inds] = (0.5 + delta1[~inds]) ** (1.0 / 3.0) - (-0.5 + delta1[~inds]) ** (
        1.0 / 3.0
    )

    if np.any(zroot < 0.0):
        raise ValueError("Root solver issue: zroot < 0")

    zroot *= coeff_four ** (-2.0 / 3.0)

    # Calculate quartic root using cubic root
    rcoef = np.sqrt(zroot)
    delta2 = -zroot + 2.0 / (coeff_four * rcoef)
    if np.any(delta2 < 0.0):
        raise ValueError("Root solver issue: delta2 < 0")

    delta2 = np.sqrt(delta2)
    root = 0.5 * (delta2 - rcoef)
    if np.any(root < 0.0):
        raise ValueError("Root solver issue: root < 0")

    return cast(np.ndarray, root)


def encode_order(string_list: list[str]) -> tuple[list[int], list[int]]:
    """Converts a list of dimension names to permutation indices.

    Default ordering is assumed to be ["x", "theta", "phi"] -> [0, 1, 2].

    Args:
        string_list: List of strings representing the desired order.

    Returns:
        A tuple containing:
        - permutation: List of indices representing the new order.
        - inverse_permutation: List of indices to restore the original order.
    """
    default_enc = {"x": 0, "theta": 1, "phi": 2}
    permutation = [default_enc[s] for s in string_list]
    inverse_permutation = sorted(range(len(permutation)), key=lambda i: permutation[i])

    return permutation, inverse_permutation


def apply_func_to_core(
    f: Callable[..., np.ndarray], core_num: int
) -> Callable[..., np.ndarray]:
    """Wraps a function to apply it to the spatial dimension of a TT core.

    The TT core is reshaped to (n, -1) (or transposed equivalent) before applying f,
    then reshaped back. This allows applying functions defined on the spatial grid
    to the TT core directly.

    Args:
        f: The function to apply. Must accept the reshaped core as the last argument.
        core_num: The position of the core in the TT (0 for first, >0 for others).

    Returns:
        A wrapper function that handles the reshaping logic.
    """

    def apply(*args: Any) -> np.ndarray:
        core = args[-1]
        shape = core.shape

        # 2D Core (First or Last)
        if len(shape) == 2:
            if core_num == 0:  # First core: (n, r1)
                return f(*args[:-1], core)

            # Last core: (r_last, n). Transpose to (n, r_last) for function application
            return f(*args[:-1], core.T).T

        # 3D Core (Middle): (r_prev, n, r_next)
        if len(shape) != 3:
            raise ValueError("TT cores must be 2-D or 3-D.")

        # Move spatial dim (index 1) to front: (n, r_prev, r_next)
        newcore = np.moveaxis(core, 1, 0)
        newshape = newcore.shape

        # Flatten ranks: (n, r_prev * r_next)
        newcore_flat = newcore.reshape((newshape[0], -1))

        # Apply function
        processed_core = f(*args[:-1], newcore_flat)

        # Reshape back: (n, r_prev, r_next)
        processed_core = processed_core.reshape((-1, newshape[1], newshape[2]))

        # Move spatial dim back to middle: (r_prev, n, r_next)
        return np.moveaxis(processed_core, 0, 1)

    return apply


def flatten_list(nested_list: list[Any]) -> list[Any]:
    """Flattens a nested list structure into a single list.

    Args:
        nested_list: The list to flatten.

    Returns:
        A new flat list containing all non-list elements.
    """
    flat_list = []
    for item in nested_list:
        if isinstance(item, list):
            flat_list.extend(flatten_list(item))
        else:
            flat_list.append(item)
    return flat_list
