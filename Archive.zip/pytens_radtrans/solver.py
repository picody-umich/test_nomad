"""Provides solver-related utilities for the radiation transport simulation."""

import pathlib
import pickle
from collections.abc import Callable
from dataclasses import dataclass, field

import numpy as np
import pytens

from . import stencil
from .discretization import AngleDiscretization, Discretization, Indices
from .load_config import (
    APFStencil,
    Config,
    IdealGas,
    NoSource,
    RusanovStencil,
    UpwindStencil,
)
from .utils import TT, TNOPList, encode_order, quartic_solve, reorder_list


@dataclass
class Solution:
    """
    Represents the state of the simulation at a specific time.

    Attributes:
        time: The simulation time of the solution.
        intensity: The radiation intensity field, represented as a
            `pytens.TensorNetwork`.
        space: A dictionary containing spatial fields, such as "temperature"
            and "density", as NumPy arrays.
        aux: A dictionary for storing auxiliary data, such as computed
            quantities like mean intensity.
    """

    time: float
    intensity: pytens.TensorNetwork
    space: dict[str, np.ndarray] | None
    aux: dict[str, np.ndarray] = field(default_factory=dict)

    def save(self, filename: pathlib.Path) -> None:
        """
        Serializes and saves the Solution object to a file using pickle.

        Args:
            filename: The path to the file where the solution will be saved.

        Raises:
            IOError: If there is an error writing to the file.
        """
        with open(filename, "wb") as fp:
            pickle.dump(self, fp, pickle.HIGHEST_PROTOCOL)

    @classmethod
    def from_file(cls, filename: pathlib.Path) -> "Solution":
        """
        Loads a Solution object from a pickle file.

        Args:
            filename: The path to the file from which to load the solution.

        Returns:
            An instance of the Solution class.

        Raises:
            FileNotFoundError: If the specified file does not exist.
            pickle.UnpicklingError: If the file cannot be deserialized.
            AssertionError: If the loaded object is not an instance of Solution.
        """
        with open(filename, "rb") as fp:
            obj = pickle.load(fp)
        assert isinstance(obj, Solution)
        return obj


def create_stencil(
    config: Config,
    discretization: Discretization,
    angle_disc: AngleDiscretization,
) -> stencil.Stencil:
    """Creates and returns a stencil object based on the configuration.

    This factory function selects the appropriate stencil class (e.g., Upwind,
    Rusanov) and initializes it with the necessary simulation parameters.

    Args:
        config: The main simulation configuration object.
        discretization: The spatial discretization information.
        angle_disc: The angular discretization information.

    Returns:
        An initialized instance of a `Stencil` subclass.

    Raises:
        NotImplementedError: If the stencil specified in the config is not supported.
    """
    sin_theta = np.sin(angle_disc.theta)
    cos_phi = np.cos(angle_disc.phi)
    sin_phi = np.sin(angle_disc.phi)

    stencil_args = (
        config.equations.speed_of_light,
        sin_theta,
        cos_phi,
        sin_phi,
        discretization,
        config,
    )

    stencil_cfg = config.solver.stencil
    stencil_obj: stencil.Stencil

    if isinstance(stencil_cfg, UpwindStencil):
        stencil_obj = stencil.UpwindStencil(*stencil_args)
    elif isinstance(stencil_cfg, RusanovStencil):
        stencil_obj = stencil.RusanovStencil(stencil_cfg.wave_speed, *stencil_args)
    elif isinstance(stencil_cfg, APFStencil):
        stencil_obj = stencil.JiangStencil(
            *stencil_args,
            beta=stencil_cfg.beta,
            tau_threshold=stencil_cfg.tau_threshold,
            alpha_threshold=stencil_cfg.alpha_threshold,
        )
    else:
        raise NotImplementedError(
            f"Stencil {config.solver.stencil.name} not yet implemented"
        )
    return stencil_obj


def get_transport_term(
    indices: Indices,
    discretization: Discretization,
    angle_disc: AngleDiscretization,
    config: Config,
    scale: float,
    flux_mask: dict[str, np.ndarray] | None = None,
) -> Callable:
    """
    Constructs the tensor train operator for the transport term.

    This function selects a spatial discretization stencil (e.g., upwind, Rusanov)
    based on the configuration and builds the corresponding tensor train operator
    that represents the spatial transport of radiation.

    Args:
        indices: The tensor indices for the problem dimensions.
        discretization: The spatial discretization information.
        angle_disc: The angular discretization information.
        config: The main simulation configuration object.
        scale: A scaling factor to apply to the operator, typically related
            to the time step size.

    Returns:
        A `Callable` object representing the transport operator.

    Raises:
        NotImplementedError: If the stencil specified in the config is not supported.
    """
    stencil_obj = create_stencil(config, discretization, angle_disc)
    return stencil_obj.get_ttop(indices, scale, flux_mask)


def mean_intensity(
    indices: Indices, disc: AngleDiscretization, intensity: pytens.TensorNetwork
) -> np.ndarray:
    """
    Computes the mean intensity (J) by integrating radiation intensity over all angles.

    The mean intensity is defined as J = (1 / 4π) ∫ I dΩ, where I is the
    radiation intensity and Ω is the solid angle.

    Args:
        indices: The tensor indices for the problem dimensions, used to identify
            the angular indices for integration.
        disc: The angular discretization containing integration weights.
        intensity: The radiation intensity field as a `pytens.TensorNetwork`.

    Returns:
        A NumPy array containing the mean intensity for each spatial cell.
    """
    integral: np.ndarray = (
        intensity.integrate(
            [indices.theta, indices.phi], [disc.delta_theta, disc.delta_phi]
        )
        .contract()
        .value
    )

    integral /= 4 * np.pi

    # Enforce physical non-negativity.
    # Extrapolation in the Tensor Train spatial cores (during AMR) can sometimes
    # produce slightly negative values in the tails of distributions (e.g. Gaussian).
    # We clamp the physical observable (Mean Intensity) to zero to prevent
    # these numerical artifacts from crashing the source term solvers.
    integral = np.maximum(integral, 0.0)

    return integral


def _create_intensity_update_operator(
    sol: Solution,
    indices: Indices,
    config: Config,
    angle_disc: AngleDiscretization,
    scale_term: np.ndarray,
    const_term: np.ndarray,
) -> tuple[TNOPList, pytens.TensorNetwork]:
    """
    Helper to create tensor train operators for updating radiation intensity.

    This function constructs a multiplicative term and an additive term as
    tensor networks, then combines them into a `TNOPList` representing the
    update rule: I' = I * scale_term + const_term.

    Args:
        sol: The current solution state.
        indices: The tensor indices for the problem dimensions.
        config: The main simulation configuration object.
        angle_disc: The angular discretization.
        scale_term: A NumPy array representing the multiplicative factor, which
            will be broadcasted across the angular dimensions.
        const_term: A NumPy array representing the additive term, which will be
            broadcasted across the angular dimensions.

    Returns:
        A tuple containing:
        - A `TNOPList` representing the full update operation.
        - The additive term as a `pytens.TensorNetwork`.
    """
    permut, _ = encode_order(config.solver.order)
    ind = reorder_list([indices.space, indices.theta, indices.phi], permut)
    one_theta = np.ones(angle_disc.theta.shape[0])
    one_phi = np.ones(angle_disc.phi.shape[0])

    mult_term = pytens.tt_rank1(
        ind, reorder_list([scale_term, one_theta, one_phi], permut)
    )
    add_term = pytens.tt_rank1(
        ind, reorder_list([const_term, one_theta, one_phi], permut)
    )

    next_intensity = TNOPList()
    next_intensity.append(TT(sol.intensity * mult_term))
    next_intensity.append(TT(add_term))

    return next_intensity, add_term


def temp_equation_ideal_gas(  # pylint: disable=R0914
    indices: Indices,
    angle_disc: AngleDiscretization,
    dt: float,
    sol: Solution,
    config: Config,
) -> tuple[TNOPList, np.ndarray]:
    """
    Performs a semi-implicit update step for matter-radiation coupling.

    This function solves the temperature equation for an ideal gas source term,
    updating both the temperature and the radiation intensity implicitly. It is
    designed to be used within an operator splitting scheme.

    Args:
        indices: The tensor indices for the problem dimensions.
        angle_disc: The angular discretization.
        dt: The time step size.
        sol: The current solution state.
        config: The main simulation configuration object.

    Returns:
        A tuple containing:
        - A `TNOPList` for the updated intensity.
        - A NumPy array for the new temperature field.

    Raises:
        ValueError: If the source is `IdealGas` but `specific_heat_capacity`
            is not defined.
    """
    assert isinstance(config.equations.source, IdealGas)
    if config.equations.source.specific_heat_capacity is None:
        raise ValueError("Specific heat capacity must be defined for IdealGas source.")
    assert sol.space is not None

    alpha_a = sol.space["absorption_opacity"].flatten()
    if np.allclose(alpha_a, 0.0):
        next_intensity = scatter_source(indices, angle_disc, dt, sol, config)
        return next_intensity, sol.space["temperature"]

    alpha_s = sol.space["scattering_opacity"].flatten()
    density = sol.space["density"].flatten()
    current_temp = sol.space["temperature"].flatten()

    c = config.equations.speed_of_light
    cdt = c * dt
    c4pi = c / (4 * np.pi)

    xi_a = (1.0 / cdt + alpha_a) ** -1
    xi_t = (1.0 / cdt + alpha_a + alpha_s) ** -1
    zeta_a = alpha_a / (density * config.equations.source.specific_heat_capacity)

    J = mean_intensity(indices, angle_disc, sol.intensity)
    const_term = -zeta_a * xi_a / c4pi * J - current_temp
    fourth_term = zeta_a * xi_a * config.equations.radiation_constant
    Tprime = quartic_solve(fourth_term, const_term)

    term2 = alpha_a * c4pi * config.equations.radiation_constant * Tprime**4
    Jprime = xi_a * (J / cdt + term2)

    scale_term = xi_t / cdt
    const_term_update = xi_t * term2 + xi_t * alpha_s * Jprime

    next_intensity, add_term = _create_intensity_update_operator(
        sol, indices, config, angle_disc, scale_term, const_term_update
    )

    # next_mean_intensity = (
    #     mean_intensity(indices, angle_disc, sol.intensity) * scale_term
    # )
    next_mean_intensity = J * scale_term
    next_mean_intensity += mean_intensity(indices, angle_disc, add_term)

    den = c * density * config.equations.source.specific_heat_capacity
    rhs = (4 * np.pi * J - 4 * np.pi * next_mean_intensity) / den
    rhs = rhs.reshape(sol.space["temperature"].shape)
    next_temp = sol.space["temperature"] + rhs

    return next_intensity, next_temp


def scatter_source(
    indices: Indices,
    angle_disc: AngleDiscretization,
    dt: float,
    sol: Solution,
    config: Config,
) -> TNOPList:
    """
    Constructs the operator for the scattering source term.

    This function calculates the update to the radiation intensity due to
    isotropic scattering. It is designed for use in an operator splitting scheme.

    Args:
        indices: The tensor indices for the problem dimensions.
        angle_disc: The angular discretization.
        dt: The time step size.
        sol: The current solution state.
        config: The main simulation configuration object.

    Returns:
        A `TNOPList` representing the scattering update operator. If the
        configured source is `NoSource`, an empty list is returned.
    """
    if isinstance(config.equations.source, NoSource):
        return TNOPList()
    assert sol.space is not None

    c = config.equations.speed_of_light
    cdt = c * dt
    alpha_s = sol.space["scattering_opacity"].flatten()
    xi_t = (1.0 / cdt + alpha_s) ** -1

    J = mean_intensity(indices, angle_disc, sol.intensity)

    const_term = xi_t * alpha_s * J
    scale_term = xi_t / cdt

    next_intensity, _ = _create_intensity_update_operator(
        sol, indices, config, angle_disc, scale_term, const_term
    )

    return next_intensity
