"""Functions used in the main_loop."""

import glob
import logging
import os
import pathlib
from collections import defaultdict
from collections.abc import Callable
from dataclasses import dataclass
from typing import Any, NamedTuple, cast

import numpy as np
import pytens
from mpi4py import MPI

from . import (
    comms,
    contracts,
    domain_decomp,
    flux_corrector,
    load_balancing,
    load_config,
    problems,
    refinement,
    solver,
    utils,
)
from .domain_decomp import DomainManager
from .domain_loop import domain_step
from .load_config import Config
from .monitor import Monitor

comm = MPI.COMM_WORLD
rank = comm.Get_rank()
size = comm.Get_size()


def _load_checkpoint_metadata(
    config: Config,
) -> dict[str, Any] | None:
    """Loads and broadcasts checkpoint metadata from Rank 0.

    This function searches for a checkpoint file for domain 0 in the specified
    directory, parses the iteration number and time string from the filename,
    and broadcasts this metadata to all other ranks.

    Args:
        config: The simulation configuration containing the checkpoint directory.

    Returns:
        A dictionary containing:
            - 'dir': The checkpoint directory path.
            - 'itera': The iteration number (int).
            - 'time_str': The time string from the filename.
        Returns None if called on a rank other than 0 (before broadcast),
        but the return value is synchronized across all ranks via broadcast.

    Raises:
        FileNotFoundError: If no domain 0 checkpoint file is found on Rank 0.
    """
    checkpoint_metadata = None
    if rank == 0:
        dirname = config.checkpoint_directory
        # We assume domain 0 always exists and use it to get the iteration/time
        any_domain_file = glob.glob(os.path.join(str(dirname), "*domain_0_*.pkl"))
        if not any_domain_file:
            raise FileNotFoundError(
                "Could not find domain 0 file to parse checkpoint metadata."
            )

        filename_base = os.path.basename(any_domain_file[0])
        # Expected format: checkpoint_{iteration}_domain_{idx}_{time}.pkl
        parts = filename_base.replace(".pkl", "").split("_")
        # parts: ['checkpoint', '100', 'domain', '0', '1.23e-01']
        iteration = int(parts[1])
        time_str = parts[-1]
        checkpoint_metadata = {
            "dir": dirname,
            "itera": iteration,
            "time_str": time_str,
        }

    # Broadcast the parsed metadata
    checkpoint_metadata = cast(
        dict[str, Any] | None, comm.bcast(checkpoint_metadata, root=0)
    )
    return checkpoint_metadata


def initialize_solutions(
    config: Config,
    problem: problems.Problem,
    permut: list[int],
    domain_manager: DomainManager,
    local_indices: list[int],
    logger: logging.Logger,
) -> tuple[list[solver.Solution], float]:
    """Initialize solutions, either from a checkpoint directory or from the problem.

    Args:
        config: The simulation configuration.
        problem: The problem instance.
        permut: The permutation order for tensors.
        domain_manager: The domain manager.
        local_indices: List of global leaf indices managed by this rank.
        logger: Logger instance.

    Returns:
        A tuple containing the list of local solutions and the current simulation time.

    Raises:
        FileNotFoundError: If checkpoint files are missing.
        ValueError: If checkpoint metadata cannot be broadcast.
    """
    if config.checkpoint_directory:
        logger.info("Loading solutions from checkpoint.")
        checkpoint_metadata = _load_checkpoint_metadata(config)

        if checkpoint_metadata is None:
            raise ValueError("Failed to broadcast checkpoint metadata.")

        local_sol_list = []
        for global_idx in local_indices:
            fname = (
                f"checkpoint_{checkpoint_metadata['itera']}_"
                f"domain_{global_idx}_{checkpoint_metadata['time_str']}.pkl"
            )
            dir_path = checkpoint_metadata["dir"]
            assert isinstance(dir_path, str | pathlib.Path)
            filepath = pathlib.Path(dir_path) / fname
            sol_item = solver.Solution.from_file(pathlib.Path(filepath))
            local_sol_list.append(sol_item)

        # Determine time from the first loaded solution (or 0.0 if list empty)
        time_val = local_sol_list[0].time if local_sol_list else 0.0
        # Broadcast to ensure consistency across ranks (though they should match)
        time = comm.bcast(time_val, root=0)
        return local_sol_list, time

    # generate new solution
    logger.info("Generating new solution from initial conditions.")
    local_sol_list = []
    for global_idx in local_indices:
        leaf = domain_manager.leaves[global_idx]
        index, fields = problem.ic_intensity(leaf.disc)
        initial_solution = pytens.tt_rank1(
            utils.reorder_list(index, permut), utils.reorder_list(fields, permut)
        )
        local_sol_list.append(
            solver.Solution(0.0, initial_solution, problem.ic_space(leaf.disc))
        )

    # Initial time is 0.0
    return local_sol_list, 0.0


class PackOp(NamedTuple):
    """Pre-computed operators for packing data to be sent to a receiver."""

    receiver_idx: int
    space_func: Callable[[np.ndarray], np.ndarray]
    tt_func: Callable[[pytens.TensorNetwork], pytens.TensorNetwork]


class ReconstructOp(NamedTuple):
    """Pre-computed operators for reconstructing received data."""

    sender_idx: int
    space_func: Callable[[np.ndarray], np.ndarray]
    tt_func: Callable[[pytens.TensorNetwork], pytens.TensorNetwork]


@dataclass
class InitializationData:
    """A container for all data initialized before the time loop."""

    dt: float
    time: float
    dimension: int
    permut: np.ndarray
    inv_permut: np.ndarray
    problem: problems.Problem
    domain_manager: DomainManager
    monitor: Monitor
    local_sol: list[solver.Solution]
    local_indices: list[int]
    leaf_to_rank_map: dict[int, int]
    local_bc: list[problems.bcs.BoundaryConditions]
    local_bc_dirichlet: list[pytens.TensorNetwork | None]
    local_rhs: list[Any]
    local_flux_calculators: list[dict[int, flux_corrector.FluxCalculator]]
    pack_ops_by_leaf: dict[int, list[PackOp]]
    reconstruct_ops_by_leaf: dict[int, list[ReconstructOp]]
    receive_plans_by_leaf: dict[int, list[domain_decomp.CommPlan]]
    local_indices_chunked: list[np.ndarray] | None


def _setup_global_parameters(
    config: Config, logger: logging.Logger
) -> tuple[problems.Problem, DomainManager, list[int], list[int], float, int]:
    """Initializes and broadcasts global simulation parameters.

    Rank 0 loads the problem, creates the domain manager, and calculates
    global constants like the time step (dt). These objects are then
    broadcast to all other ranks to ensure a consistent simulation state.

    Args:
        config: The simulation configuration.
        logger: The logger instance.

    Returns:
        A tuple containing:
            - problem: The Problem instance.
            - domain_manager: The DomainManager instance.
            - permut: The tensor permutation order.
            - inv_permut: The inverse tensor permutation order.
            - dt: The time step size.
            - dimension: The spatial dimension of the problem.
    """
    problem, domain_manager, permut, inv_permut, dt, dimension = (None,) * 6

    if rank == 0:
        logger.info("Rank 0: Initializing global simulation parameters.")
        permut, inv_permut = utils.encode_order(config.solver.order)
        problem = problems.load_problem(config)
        domain_manager = domain_decomp.create_domain_manager(config, problem, logger)
        dimension = domain_manager.dimension()
        min_dx = domain_manager.min_dx()
        dt = config.solver.cfl * min_dx / config.equations.speed_of_light
        logger.info("Dimension = %i, Min dx = %3.2E, dt = %3.2E", dimension, min_dx, dt)

    problem = comm.bcast(problem, root=0)
    domain_manager = comm.bcast(domain_manager, root=0)
    permut = comm.bcast(permut, root=0)
    inv_permut = comm.bcast(inv_permut, root=0)
    dt = comm.bcast(dt, root=0)
    dimension = comm.bcast(dimension, root=0)
    comm.Barrier()
    logger.info("All ranks have received global parameters.")

    assert problem is not None
    assert domain_manager is not None
    assert permut is not None
    assert inv_permut is not None
    assert dt is not None
    assert dimension is not None

    return problem, domain_manager, permut, inv_permut, dt, dimension


def _partition_domain(
    domain_manager: DomainManager, logger: logging.Logger
) -> tuple[list[int], dict[int, int], list[np.ndarray] | None]:
    """Partitions the domain leaves among MPI ranks.

    Rank 0 splits the list of global leaf indices into chunks and scatters
    them to all ranks. It also creates a global map of leaf-to-rank assignments.

    Args:
        domain_manager: The global domain manager.
        logger: The logger instance.

    Returns:
        A tuple containing:
            - local_indices: A list of global leaf indices assigned to this rank.
            - leaf_to_rank_map: A dictionary mapping global leaf index to rank ID.
            - local_indices_chunked: A list of arrays (one per rank) containing
              the leaf indices for that rank (only valid on Rank 0, else None).
    """
    local_indices_chunked = None
    num_domains = domain_manager.num_domains()

    if rank == 0:
        indices = np.arange(num_domains)
        local_indices_chunked = np.array_split(indices, size)
        leaf_to_rank_map = {
            global_idx: r_id
            for r_id, chunk in enumerate(local_indices_chunked)
            for global_idx in chunk
        }
    else:
        leaf_to_rank_map = None

    local_indices_arr = comm.scatter(local_indices_chunked, root=0)
    assert local_indices_arr is not None
    local_indices = local_indices_arr.tolist()
    leaf_to_rank_map = comm.bcast(leaf_to_rank_map, root=0)
    logger.info(
        "Work partitioning complete. This rank manages %d leaves.", len(local_indices)
    )

    assert leaf_to_rank_map is not None

    return local_indices, leaf_to_rank_map, local_indices_chunked


def _update_rank_map(
    local_indices: list[int], num_domains: int, logger: logging.Logger
) -> tuple[dict[int, int], list[np.ndarray] | None]:
    """Dynamically reconstructs the global leaf-to-rank map.

    Unlike _partition_domain, which dictates a static partitioning, this function
    discovers the actual distribution of leaves across ranks after adaptation.

    Args:
        local_indices: The list of global leaf indices owned by this rank.
        num_domains: The total number of domains in the global topology.
        logger: Logger instance.

    Returns:
        A tuple containing:
            - leaf_to_rank_map: Dict mapping global leaf index to rank ID.
            - local_indices_chunked: List of arrays (one per rank) containing
              the leaf indices for that rank (valid on all ranks).
    """
    # Gather the actual indices owned by each rank
    # gathered_indices will be a list of lists: [[0, 1, ...], [10, 11, ...], ...]
    gathered_indices = comm.allgather(local_indices)

    leaf_to_rank_map: dict[int, int] = {}
    local_indices_chunked: list[np.ndarray] = []

    # Reconstruct the map and the chunked list
    for r_id, indices in enumerate(gathered_indices):
        indices_arr = np.array(indices)
        local_indices_chunked.append(indices_arr)
        for global_idx in indices:
            contracts.assign_unique_leaf_owner(leaf_to_rank_map, global_idx, r_id)

    # Sanity check: Ensure all domains are accounted for
    contracts.validate_leaf_coverage(
        leaf_to_rank_map,
        num_domains,
        context="Rank map reconstruction",
    )

    return leaf_to_rank_map, local_indices_chunked


def migrate_solutions(
    init_data: InitializationData,
    migration_map: dict[int, int],
    logger: logging.Logger,
) -> InitializationData:
    """Moves Solution objects between ranks based on a migration map.

    Args:
        init_data: The current simulation state.
        migration_map: A dictionary mapping {global_leaf_idx: target_rank_id}.
            Only leaves that need to move should be in this map.
        logger: Logger instance.

    Returns:
        Updated InitializationData with modified local_sol and local_indices.
    """
    if len(init_data.local_indices) != len(init_data.local_sol):
        logger.error(
            "Migration precheck failed: local_indices (%d) and local_sol (%d) differ.",
            len(init_data.local_indices),
            len(init_data.local_sol),
        )
        raise RuntimeError(
            "Migration precheck failed: local index/solution length mismatch."
        )

    if len(set(init_data.local_indices)) != len(init_data.local_indices):
        raise RuntimeError("Migration precheck failed: duplicate local leaf indices.")

    missing_in_rank_map = set(migration_map.keys()) - set(init_data.leaf_to_rank_map)
    if missing_in_rank_map:
        raise RuntimeError(
            "Migration map references leaves missing from rank map: "
            f"{sorted(missing_in_rank_map)}"
        )

    local_index_set = set(init_data.local_indices)
    for idx, target_rank in migration_map.items():
        source_rank = init_data.leaf_to_rank_map[idx]
        if source_rank == rank and target_rank != rank and idx not in local_index_set:
            raise RuntimeError(
                "Migration precheck failed: local rank marked as source for "
                f"leaf {idx}, but leaf is not locally present."
            )
        if idx in local_index_set and source_rank != rank:
            raise RuntimeError(
                "Migration precheck failed: leaf "
                f"{idx} is local but rank map says source rank {source_rank}."
            )

    # 1. Identify outgoing solutions
    outgoing_sols: dict[int, list[tuple[int, solver.Solution]]] = defaultdict(list)
    kept_indices = []
    kept_sols = []

    for idx, sol in zip(init_data.local_indices, init_data.local_sol, strict=False):
        if idx in migration_map:
            target_rank = migration_map[idx]
            if target_rank != rank:
                outgoing_sols[target_rank].append((idx, sol))
            else:
                # Migration to self (no-op)
                kept_indices.append(idx)
                kept_sols.append(sol)
        else:
            kept_indices.append(idx)
            kept_sols.append(sol)

    # 2. Identify incoming expectations
    # We need to know what we are receiving.
    # migration_map is global. Iterate it to find what is coming to us.
    incoming_expectations = []
    for global_idx, target_rank in migration_map.items():
        if target_rank == rank:
            # Who owns it now?
            source_rank = init_data.leaf_to_rank_map[global_idx]
            if source_rank != rank:
                incoming_expectations.append((source_rank, global_idx))

    # 3. Execute Transfer via Comms
    received_items = comms.transfer_solutions(
        outgoing_sols, incoming_expectations, comm, logger
    )

    # 4. Update Local State
    for idx, sol in received_items:
        kept_indices.append(idx)
        kept_sols.append(sol)

    # Sort to maintain consistent order
    if kept_indices:
        sorted_pairs = sorted(
            zip(kept_indices, kept_sols, strict=False), key=lambda x: x[0]
        )
        init_data.local_indices = [p[0] for p in sorted_pairs]
        init_data.local_sol = [p[1] for p in sorted_pairs]
    else:
        init_data.local_indices = []
        init_data.local_sol = []

    if len(set(init_data.local_indices)) != len(init_data.local_indices):
        raise RuntimeError(
            "Migration postcheck failed: duplicate local leaf indices after transfer."
        )

    # Update the global map locally
    for idx, target in migration_map.items():
        init_data.leaf_to_rank_map[idx] = target

    if len(outgoing_sols) > 0 or len(received_items) > 0:
        logger.info(
            "Migration: Sent %d leaves, Received %d leaves.",
            sum(len(v) for v in outgoing_sols.values()),
            len(received_items),
        )

    return init_data


def _disc_lower_bounds(disc: Any) -> tuple[float, ...]:
    """Return the lower bounds of a discretization across all spatial dimensions."""
    return tuple(float(disc.grid.cell_edges[d][0]) for d in range(disc.dimension))


def _order_children_for_parent_merge(
    parent_disc: Any,
    children: list[tuple[int, solver.Solution, Any]],
) -> list[tuple[int, solver.Solution, Any]]:
    """Order child (index, solution, disc) triples to match parent.split() order.

    This removes the implicit assumption that leaf index ordering is always the same
    as geometric child ordering. Merge routines in refinement depend on this order.
    """
    expected_discs = parent_disc.split()
    if len(children) != len(expected_discs):
        raise RuntimeError(
            "Cannot order child domains for merge: expected "
            f"{len(expected_discs)} children from parent split, got {len(children)}."
        )

    expected_lbs = [_disc_lower_bounds(disc) for disc in expected_discs]
    ordered: list[tuple[int, solver.Solution, Any] | None] = [None] * len(expected_lbs)

    for item in children:
        child_lb = _disc_lower_bounds(item[2])
        matches = [
            i
            for i, expected_lb in enumerate(expected_lbs)
            if all(np.isclose(a, b) for a, b in zip(child_lb, expected_lb, strict=True))
        ]
        if len(matches) != 1:
            raise RuntimeError(
                "Cannot uniquely match child domain to parent split slot. "
                f"child_lb={child_lb}, expected_lbs={expected_lbs}"
            )
        slot = matches[0]
        if ordered[slot] is not None:
            raise RuntimeError(
                "Duplicate child mapping detected for parent split slot "
                f"{slot} with lower bound {expected_lbs[slot]}."
            )
        ordered[slot] = item

    if any(item is None for item in ordered):
        raise RuntimeError(
            "Missing child mapping for parent split ordering. "
            f"expected_lbs={expected_lbs}"
        )

    return cast(list[tuple[int, solver.Solution, Any]], ordered)


def _build_local_operators(
    config: Config,
    problem: problems.Problem,
    domain_manager: DomainManager,
    local_indices: list[int],
    dt: float,
    dimension: int,
    permut: list[int],
    inv_permut: list[int],
) -> tuple[
    list[problems.bcs.BoundaryConditions],
    list[pytens.TensorNetwork | None],
    list[Callable],
    list[dict[int, flux_corrector.FluxCalculator]],
]:
    """Builds boundary conditions and RHS operators for local leaves.

    For each leaf domain managed by this rank, this function constructs the
    necessary boundary condition managers, Dirichlet operators, and transport
    term operators (RHS). For coarse domains at coarse-fine interfaces, it also
    creates masked RHS operators and the necessary `FluxCalculator`s.

    Args:
        config: The simulation configuration.
        problem: The problem instance.
        domain_manager: The global domain manager.
        local_indices: List of global leaf indices managed by this rank.
        dt: The time step size.
        dimension: The spatial dimension of the problem.
        permut: The tensor permutation order.
        inv_permut: The inverse permutation order.

    Returns:
        A tuple containing:
            - local_bc: A list of BoundaryConditions objects.
            - local_bc_dirichlet: A list of Dirichlet operator tensors (or None).
            - local_rhs: A list of transport term callables.
            - local_flux_calculators: A list of flux calculator dictionaries.
    """
    local_bc = []
    local_bc_dirichlet = []
    local_rhs = []
    local_flux_calculators = []

    coarse_domain_plans: dict[int, list[domain_decomp.CommPlan]] = defaultdict(list)
    # UNCOMMENT BELOW TO ENABLE FLUX CORRECTION
    for plan in domain_manager.comm_plans:
        if plan.flux_correction_plan is not None:
            coarse_domain_plans[plan.receiver_leaf_idx].append(plan)

    for jj_global in local_indices:
        leaf = domain_manager.leaves[jj_global]
        map_item = domain_manager.leaf_neighbor_map[jj_global]
        assert map_item is not None, f"Neighbor map for leaf {jj_global} is missing."
        _map_item, boundaries = map_item

        local_bc.append(problem.get_bc(leaf.disc, config, boundaries))
        bc_manager = local_bc[-1]
        local_bc_dirichlet.append(bc_manager.get_dirichlet_op(problem.indices))

        flux_mask: dict[str, np.ndarray] | None = None
        flux_calculators: dict[int, flux_corrector.FluxCalculator] = {}

        if jj_global in coarse_domain_plans:
            disc = leaf.disc
            flux_mask = flux_corrector.create_flux_mask(
                disc, coarse_domain_plans[jj_global]
            )

            for plan in coarse_domain_plans[jj_global]:
                fcp = plan.flux_correction_plan
                assert fcp is not None

                flux_calculators[plan.sender_leaf_idx] = (
                    flux_corrector.create_flux_calculator(
                        plan=fcp,
                        config=config,
                        domain_angles=domain_manager.domain_angles,
                        permut=list(permut),
                        inv_permute=list(inv_permut),
                        num_sender_indices=plan.num_sender_indices,
                    )
                )

        local_flux_calculators.append(flux_calculators)

        local_rhs.append(
            solver.get_transport_term(
                problem.indices,
                leaf.disc,
                domain_manager.domain_angles,
                config,
                -dt,
                flux_mask,
            )
        )
    return local_bc, local_bc_dirichlet, local_rhs, local_flux_calculators


def _organize_comm_plans(
    domain_manager: DomainManager, local_indices: list[int]
) -> tuple[
    dict[int, list[domain_decomp.CommPlan]], dict[int, list[domain_decomp.CommPlan]]
]:
    """Filters and organizes communication plans by local leaf.

    This function iterates through all global communication plans and extracts
    those relevant to the leaves managed by this rank. It separates them into
    sending plans (where this rank sends data) and receiving plans (where this
    rank receives data).

    Args:
        domain_manager: The global domain manager containing all comm plans.
        local_indices: List of global leaf indices managed by this rank.

    Returns:
        A tuple containing:
            - send_plans_by_leaf: Dict mapping sender leaf index to list of plans.
            - receive_plans_by_leaf: Dict mapping receiver leaf index to list of plans.
    """
    send_plans_by_leaf: dict[int, list[domain_decomp.CommPlan]] = {
        idx: [] for idx in local_indices
    }
    receive_plans_by_leaf: dict[int, list[domain_decomp.CommPlan]] = {
        idx: [] for idx in local_indices
    }
    for plan in domain_manager.comm_plans:
        if plan.sender_leaf_idx in local_indices:
            send_plans_by_leaf[plan.sender_leaf_idx].append(plan)
        if plan.receiver_leaf_idx in local_indices:
            receive_plans_by_leaf[plan.receiver_leaf_idx].append(plan)
    return send_plans_by_leaf, receive_plans_by_leaf


def _precompute_pack_ops(
    domain_manager: DomainManager,
    local_indices: list[int],
    send_plans_by_leaf: dict[int, list[domain_decomp.CommPlan]],
    dimension: int,
    problem: problems.Problem,
    permut: list[int],
    inv_permut: list[int],
) -> dict[int, list[PackOp]]:
    """Pre-computes packing operators for all local leaves that send data.

    This function creates and stores the operators needed to implement the
    "pack" phase of the halo exchange. For each local leaf that acts as a
    sender, it iterates through its neighbors (receivers) and creates a
    specialized `PackOp`.

    The `PackOp` contains functions to transform a full solution tensor or a
    full opacity array into a small, dense package of raw boundary data ready
    for MPI transfer.

    A key feature is that it groups multiple `CommPlan`s by receiver. This is
    important for cases like periodic boundary conditions, where a single
    neighbor might be connected through multiple geometric faces, ensuring that
    all data destined for that neighbor is packed into a single, combined package.

    Args:
        domain_manager: The global `DomainManager`.
        local_indices: List of global leaf indices managed by this rank.
        send_plans_by_leaf: Dict mapping a local sender leaf index to the list
            of `CommPlan`s for its neighbors.
        dimension: The spatial dimension of the problem.
        problem: The problem specification.
        permut: The tensor permutation order.
        inv_permut: The inverse permutation order.

    Returns:
        A dictionary mapping each local sender leaf index to a list of `PackOp`
        namedtuples, one for each of its receiving neighbors.
    """
    pack_ops_by_leaf = {}

    for sender_idx in local_indices:
        plans = send_plans_by_leaf[sender_idx]
        ops_list = []

        plans_by_receiver: dict[int, list[domain_decomp.CommPlan]] = {}
        for plan in plans:
            plans_by_receiver.setdefault(plan.receiver_leaf_idx, []).append(plan)

        for receiver_idx in sorted(plans_by_receiver):
            receiver_plans = plans_by_receiver[receiver_idx]
            if len(receiver_plans) > 1:
                first_plan = receiver_plans[0]
                all_sender_indices = np.concatenate(
                    [p.sender_indices for p in receiver_plans]
                )
                all_receiver_indices = np.concatenate(
                    [p.receiver_indices for p in receiver_plans]
                )
                all_weights = np.concatenate([p.weights for p in receiver_plans])
                final_plan = domain_decomp.CommPlan(
                    sender_leaf_idx=first_plan.sender_leaf_idx,
                    receiver_leaf_idx=first_plan.receiver_leaf_idx,
                    sender_indices=all_sender_indices,
                    receiver_indices=all_receiver_indices,
                    weights=all_weights,
                    num_sender_indices=len(all_sender_indices),
                )
            else:
                final_plan = receiver_plans[0]

            if not hasattr(final_plan, "num_sender_indices"):
                # Backwards compatibility for old checkpointed CommPlan objects
                final_plan.num_sender_indices = len(final_plan.sender_indices)

            space_func = domain_decomp.create_pack_executor(final_plan)

            new_space_idx = pytens.Index("x", final_plan.num_sender_indices)
            indices_out = solver.Indices(
                dimension,
                new_space_idx,
                problem.indices.theta,
                problem.indices.phi,
            )
            tt_func = domain_decomp.transfer_boundaries(
                space_func,
                problem.indices,
                indices_out,
                permut,
                inv_permut,
            )

            ops_list.append(PackOp(receiver_idx, space_func, tt_func))

        pack_ops_by_leaf[sender_idx] = ops_list

    return pack_ops_by_leaf


def _precompute_reconstruct_ops(
    domain_manager: DomainManager,
    local_indices: list[int],
    receive_plans_by_leaf: dict[int, list[domain_decomp.CommPlan]],
    dimension: int,
    problem: problems.Problem,
    permut: list[int],
    inv_permut: list[int],
) -> dict[int, list[ReconstructOp]]:
    """Pre-computes reconstruction operators for all local receiving leaves.

    This function creates and stores the operators for the "reconstruct" phase
    of the halo exchange. For each local leaf that acts as a receiver, it
    creates a `ReconstructOp` for each of its sending neighbors.

    The `ReconstructOp` contains functions that perform the inverse of packing:
    they take a small, dense data package received from a neighbor and transform
    it back into a large, sparse array representing the weighted contribution to
    the receiver's ghost cells.

    Symmetrically with `_precompute_pack_ops`, this function groups `CommPlan`s
    by the sender. This ensures that if a single neighbor sends a combined
    package (e.g., due to periodic BCs), a single, corresponding reconstruction
    operator is created to correctly process that package.

    Args:
        domain_manager: The global `DomainManager`.
        local_indices: List of global leaf indices managed by this rank.
        receive_plans_by_leaf: Dict mapping a local receiver leaf index to the
            list of `CommPlan`s from its neighbors.
        dimension: The spatial dimension of the problem.
        problem: The problem specification.
        permut: The tensor permutation order.
        inv_permut: The inverse permutation order.

    Returns:
        A dictionary mapping each local receiver leaf index to a list of
        `ReconstructOp` namedtuples, one for each of its sending neighbors.
    """
    reconstruct_ops_by_leaf = {}

    for receiver_idx in local_indices:
        plans = receive_plans_by_leaf[receiver_idx]
        ops_list = []

        # Group plans by sender to handle cases like periodic BCs where one
        # leaf may be a neighbor in multiple directions.
        plans_by_sender: dict[int, list[domain_decomp.CommPlan]] = {}
        for p in plans:
            plans_by_sender.setdefault(p.sender_leaf_idx, []).append(p)

        for sender_idx, sender_plans in plans_by_sender.items():
            # Combine multiple plans from the same sender into one
            if len(sender_plans) > 1:
                all_sender_indices = np.concatenate(
                    [p.sender_indices for p in sender_plans]
                )
                all_receiver_indices = np.concatenate(
                    [p.receiver_indices for p in sender_plans]
                )
                all_weights = np.concatenate([p.weights for p in sender_plans])
                plan = domain_decomp.CommPlan(
                    sender_leaf_idx=sender_idx,
                    receiver_leaf_idx=receiver_idx,
                    sender_indices=all_sender_indices,
                    receiver_indices=all_receiver_indices,
                    weights=all_weights,
                    num_sender_indices=len(all_sender_indices),
                )
            else:
                plan = sender_plans[0]

            if not hasattr(plan, "num_sender_indices"):
                # Backwards compatibility for old checkpointed CommPlan objects
                plan.num_sender_indices = len(plan.sender_indices)

            receiver_leaf = domain_manager.leaves[receiver_idx]
            receiver_disc = receiver_leaf.disc
            receiver_flat_dim = int(
                np.prod(
                    [
                        n + g
                        for n, g in zip(
                            receiver_disc.grid.num_cells,
                            receiver_disc.grid.num_ghost,
                            strict=False,
                        )
                    ]
                )
            )
            space_func = domain_decomp.create_reconstruct_executor(
                plan, receiver_flat_dim
            )

            # Input tensor for this op is the small, dense one
            in_space_idx = pytens.Index("x", plan.num_sender_indices)
            indices_in = solver.Indices(
                dimension,
                in_space_idx,
                problem.indices.theta,
                problem.indices.phi,
            )

            # Output tensor is the large, sparse one
            out_space_idx = pytens.Index("x", receiver_flat_dim)
            indices_out = solver.Indices(
                dimension,
                out_space_idx,
                problem.indices.theta,
                problem.indices.phi,
            )

            tt_func = domain_decomp.transfer_boundaries(
                space_func,
                indices_in,
                indices_out,
                permut,
                inv_permut,
            )
            ops_list.append(ReconstructOp(plan.sender_leaf_idx, space_func, tt_func))

        reconstruct_ops_by_leaf[receiver_idx] = ops_list

    return reconstruct_ops_by_leaf


def rebuild_topology_operators(
    config: Config,
    problem: problems.Problem,
    domain_manager: DomainManager,
    local_indices: list[int],
    dt: float,
    dimension: int,
    permut: list[int] | np.ndarray,
    inv_permut: list[int] | np.ndarray,
    logger: logging.Logger,
) -> tuple[
    list[problems.bcs.BoundaryConditions],
    list[pytens.TensorNetwork | None],
    list[Callable],
    list[dict[int, flux_corrector.FluxCalculator]],
    dict[int, list[PackOp]],
    dict[int, list[ReconstructOp]],
    dict[int, list[domain_decomp.CommPlan]],
]:
    """Rebuilds all topology-dependent operators.

    This function is used during initialization and after any AMR adaptation event
    to regenerate boundary conditions, RHS operators, flux calculators, and
    MPI communication operators (pack/reconstruct) based on the current
    domain topology.

    Args:
        config: Simulation configuration.
        problem: Problem definition.
        domain_manager: Current domain manager (topology).
        local_indices: List of leaf indices owned by this rank.
        dt: Current time step.
        dimension: Spatial dimension.
        permut: Tensor permutation order.
        inv_permut: Inverse tensor permutation order.
        logger: Logger instance.

    Returns:
        A tuple containing:
        - local_bc: Boundary conditions for each local leaf.
        - local_bc_dirichlet: Dirichlet operators for each local leaf.
        - local_rhs: Transport term operators for each local leaf.
        - local_flux_calculators: Flux calculators for coarse-fine interfaces.
        - pack_ops: Operators to pack boundary data for sending.
        - reconstruct_ops: Operators to reconstruct ghost data from received packages.
        - receive_plans: Communication plans for receiving data.
    """
    # Ensure permut/inv_permut are lists for internal functions
    permut_list = list(permut)
    inv_permut_list = list(inv_permut)

    logger.info("Building local operators and communication plans...")
    local_bc, local_bc_dirichlet, local_rhs, local_flux_calculators = (
        _build_local_operators(
            config,
            problem,
            domain_manager,
            local_indices,
            dt,
            dimension,
            permut_list,
            inv_permut_list,
        )
    )
    send_plans, receive_plans = _organize_comm_plans(domain_manager, local_indices)

    logger.info("Pre-computing halo packing operators...")
    pack_ops = _precompute_pack_ops(
        domain_manager,
        local_indices,
        send_plans,
        dimension,
        problem,
        permut_list,
        inv_permut_list,
    )

    logger.info("Pre-computing halo reconstruction operators...")
    reconstruct_ops = _precompute_reconstruct_ops(
        domain_manager,
        local_indices,
        receive_plans,
        dimension,
        problem,
        permut_list,
        inv_permut_list,
    )

    return (
        local_bc,
        local_bc_dirichlet,
        local_rhs,
        local_flux_calculators,
        pack_ops,
        reconstruct_ops,
        receive_plans,
    )


def handle_adaptation(  # pylint: disable=R0914,R0915
    init_data: InitializationData,
    config: Config,
    logger: logging.Logger,
    iteration: int,
) -> InitializationData:
    """Checks for AMR triggers and updates the simulation topology if needed.

    This function executes a sequential adaptation strategy:
    1. Refinement: Checks triggers, updates topology, and splits data.
    2. Coarsening: Translates coarsening candidates to the new grid indices,
       updates topology, and merges data.
    3. Load Balancing: Checks for load imbalance and migrates domains.

    Args:
        init_data: The current simulation state.
        config: The simulation configuration.
        logger: Logger instance.
        iteration: The current time step iteration.

    Returns:
        The updated initialization data (potentially with new topology/operators).
    """
    # Check if any adaptation feature is enabled and due to run
    refinement_due = (
        config.refinement.enabled and iteration % config.refinement.frequency == 0
    )
    lb_due = (
        config.load_balancing.enabled
        and iteration % config.load_balancing.frequency == 0
    )

    if not refinement_due and not lb_due:
        return init_data

    current_manager = init_data.domain_manager
    refinement_occurred = False
    coarsening_occurred = False

    # Temporary variables to hold state between AMR phases
    temp_local_sol = init_data.local_sol
    temp_local_indices = init_data.local_indices
    expected_post_lb_rank_map: dict[int, int] | None = None

    # --- AMR Logic ---
    if refinement_due:
        logger.debug("AMR: Checking triggers...")

        # --- 1. Check Triggers ---
        trigger: refinement.RefinementTrigger

        if config.refinement.strategy == "rank":
            # Cast to RankRefinementConfig to satisfy type checker if needed
            rank_conf = cast(load_config.RankRefinementConfig, config.refinement)
            trigger = refinement.MaxRankTrigger(
                max_rank=rank_conf.max_rank,
                min_rank=rank_conf.min_rank,
            )
        elif config.refinement.strategy == "mean_intensity":
            int_conf = cast(load_config.IntensityRefinementConfig, config.refinement)
            trigger = refinement.MeanIntensityTrigger(
                refine_fraction=int_conf.refine_fraction,
                coarsen_fraction=int_conf.coarsen_fraction,
            )
        else:
            raise ValueError(
                f"Unknown refinement strategy: {config.refinement.strategy}"
            )

        # Update global stats (e.g. compute global max intensity)
        trigger.update_global_stats(comm, init_data.local_sol)

        local_refine = []
        local_coarsen = []

        for idx, sol in zip(init_data.local_indices, init_data.local_sol, strict=False):
            if trigger.should_refine(sol):
                local_refine.append(idx)
            elif trigger.should_coarsen([sol]):
                local_coarsen.append(idx)

        # Gather requests from all ranks
        all_refine_nested = comm.gather(local_refine, root=0)
        all_coarsen_nested = comm.gather(local_coarsen, root=0)

        # --- 2. Phase 1: Refinement ---
        refine_map: dict[int, list[int]] = {}

        if rank == 0:
            assert all_refine_nested is not None
            refine_candidates = [
                item for sublist in all_refine_nested for item in sublist
            ]

            # --- New Logic Start ---
            if config.refinement.refine_neighbors:
                unique_candidates = set(refine_candidates)
                neighbors_to_add = set()

                for idx in unique_candidates:
                    # leaf_neighbor_map is a list where index i corresponds to leaf i
                    # It contains tuple[LeafNeighbor, list[Direction]] | None
                    map_item = current_manager.leaf_neighbor_map[idx]

                    if map_item is not None:
                        neighbor_data = map_item[0]  # LeafNeighbor object
                        for n_info in neighbor_data.neighbors:
                            # neighbor >= 0 means it is a real domain, not a boundary
                            if n_info.neighbor >= 0:
                                neighbors_to_add.add(n_info.neighbor)

                if neighbors_to_add:
                    # We only log if we are actually adding new people
                    new_neighbors = neighbors_to_add - unique_candidates
                    if new_neighbors:
                        logger.info(
                            "AMR: Neighbor refinement triggered. "
                            "Adding %d neighbors to %d candidates.",
                            len(new_neighbors),
                            len(unique_candidates),
                        )
                    unique_candidates.update(neighbors_to_add)

                refine_candidates = list(unique_candidates)
            # --- New Logic End ---

            if refine_candidates:
                current_manager, refine_map = current_manager.propose_refinement(
                    refine_candidates, config, init_data.problem
                )
                refinement_occurred = True
                logger.info(
                    "AMR: Refinement triggered. Domains: %d -> %d",
                    init_data.domain_manager.num_domains(),
                    current_manager.num_domains(),
                )
            else:
                # Identity map if no refinement
                for i in range(current_manager.num_domains()):
                    refine_map[i] = [i]

        refinement_occurred = comm.bcast(refinement_occurred, root=0)
        current_manager = comm.bcast(current_manager, root=0)
        refine_map = comm.bcast(refine_map, root=0)

        # Data Migration (Split)
        temp_local_sol = []
        temp_local_indices = []

        if refinement_occurred:
            for i, old_idx in enumerate(init_data.local_indices):
                new_indices = sorted(refine_map[old_idx])
                if len(new_indices) > 1:
                    # Split
                    parent_sol = init_data.local_sol[i]
                    parent_disc = init_data.domain_manager.leaves[old_idx].disc
                    child_discs = [current_manager.leaves[k].disc for k in new_indices]
                    child_sols = refinement.split_solution(
                        parent_sol,
                        parent_disc,
                        child_discs,
                        list(init_data.permut),
                        init_data.domain_manager.domain_angles,
                        config.solver.rounding,
                        logger,
                    )
                    temp_local_sol.extend(child_sols)
                    temp_local_indices.extend(new_indices)
                else:
                    # Copy / No Change
                    temp_local_sol.append(init_data.local_sol[i])
                    temp_local_indices.append(new_indices[0])
        else:
            temp_local_sol = init_data.local_sol
            temp_local_indices = init_data.local_indices

        # --- 3. Phase 2: Coarsening ---
        coarsen_map: dict[int, int] = {}
        migration_map: dict[int, int] = {}
        pre_coarsen_manager = current_manager

        if rank == 0:
            assert all_coarsen_nested is not None
            raw_coarsen_candidates = [
                item for sublist in all_coarsen_nested for item in sublist
            ]

            # 1. Translate candidates
            potential_candidates = []
            for old_idx in raw_coarsen_candidates:
                new_indices = refine_map[old_idx]
                if len(new_indices) == 1:
                    potential_candidates.append(new_indices[0])

            # 2. Build intermediate rank map
            intermediate_rank_map = {}
            for old_idx, r_id in init_data.leaf_to_rank_map.items():
                if old_idx in refine_map:
                    for new_idx in refine_map[old_idx]:
                        intermediate_rank_map[new_idx] = r_id

            # 3. Identify Distributed Siblings & Plan Migration
            node_to_idx = {leaf: i for i, leaf in enumerate(current_manager.leaves)}
            idx_to_node = {i: leaf for i, leaf in enumerate(current_manager.leaves)}

            candidates_by_parent = defaultdict(list)
            for idx in potential_candidates:
                node = idx_to_node[idx]
                if node.parent:
                    candidates_by_parent[node.parent].append(idx)

            translated_candidates = []

            for parent, indices in candidates_by_parent.items():
                if not parent.children:
                    continue

                # Ensure all children are currently leaves
                if not all(c in node_to_idx for c in parent.children):
                    continue

                # We need ALL children to be candidates to coarsen
                child_indices = [node_to_idx[c] for c in parent.children]
                if len(indices) != len(child_indices):
                    continue  # Not all siblings requested coarsening

                # Check ranks
                child_ranks = set()
                for c_idx in child_indices:
                    if c_idx in intermediate_rank_map:
                        child_ranks.add(intermediate_rank_map[c_idx])

                if len(child_ranks) > 1:
                    # Distributed! Plan migration.
                    target_rank = intermediate_rank_map[child_indices[0]]
                    for c_idx in child_indices:
                        if intermediate_rank_map[c_idx] != target_rank:
                            migration_map[c_idx] = target_rank
                            intermediate_rank_map[c_idx] = target_rank

                    logger.info(
                        "AMR: Planning migration for siblings %s to rank %d",
                        child_indices,
                        target_rank,
                    )

                translated_candidates.extend(indices)

            if translated_candidates:
                current_manager, coarsen_map = current_manager.propose_coarsening(
                    translated_candidates, config, init_data.problem
                )
                if len(set(coarsen_map.values())) < len(coarsen_map):
                    coarsening_occurred = True
                    logger.info(
                        "AMR: Coarsening triggered. Domains -> %d",
                        current_manager.num_domains(),
                    )

            if not coarsening_occurred:
                for i in range(current_manager.num_domains()):
                    coarsen_map[i] = i

        # Execute Migration for Coarsening
        migration_map = comm.bcast(migration_map, root=0)
        if migration_map:
            # We need to update init_data temporarily to use migrate_solutions
            init_data.local_sol = temp_local_sol
            init_data.local_indices = temp_local_indices
            if refinement_occurred:
                # Coarsening migration uses post-refinement leaf IDs, while
                # leaf_to_rank_map still keys pre-refinement IDs at this point.
                # Translate ownership through refine_map without relying on the
                # already-updated coarsened topology size.
                translated_rank_map: dict[int, int] = {}
                for old_idx, owner_rank in init_data.leaf_to_rank_map.items():
                    if old_idx not in refine_map:
                        continue
                    for new_idx in refine_map[old_idx]:
                        translated_rank_map[new_idx] = owner_rank
                init_data.leaf_to_rank_map = translated_rank_map
            init_data = migrate_solutions(init_data, migration_map, logger)
            temp_local_sol = init_data.local_sol
            temp_local_indices = init_data.local_indices

        coarsening_occurred = comm.bcast(coarsening_occurred, root=0)
        current_manager = comm.bcast(current_manager, root=0)
        coarsen_map = comm.bcast(coarsen_map, root=0)

        # Data Migration (Merge)
        if coarsening_occurred:
            final_local_sol = []
            final_local_indices = []
            groups: dict[int, list[tuple[int, solver.Solution]]] = defaultdict(list)
            for i, inter_idx in enumerate(temp_local_indices):
                final_idx = coarsen_map[inter_idx]
                groups[final_idx].append((inter_idx, temp_local_sol[i]))

            for final_idx in sorted(groups.keys()):
                items = groups[final_idx]
                items.sort(key=lambda x: x[0])
                sibling_sols = [x[1] for x in items]

                if len(sibling_sols) > 1:
                    parent_disc = current_manager.leaves[final_idx].disc
                    if pre_coarsen_manager is None:
                        raise RuntimeError(
                            "Pre-coarsen manager is unavailable for child ordering."
                        )
                    child_items_with_disc = [
                        (
                            inter_idx,
                            sol_item,
                            pre_coarsen_manager.leaves[inter_idx].disc,
                        )
                        for inter_idx, sol_item in items
                    ]
                    ordered_child_items = _order_children_for_parent_merge(
                        parent_disc, child_items_with_disc
                    )
                    sibling_sols = [child[1] for child in ordered_child_items]
                    child_discs = [child[2] for child in ordered_child_items]
                    merged_sol = refinement.merge_solution(
                        sibling_sols,
                        child_discs,
                        parent_disc,
                        list(init_data.permut),
                        init_data.domain_manager.domain_angles,
                        config.solver.rounding,
                        logger,
                    )
                    final_local_sol.append(merged_sol)
                else:
                    final_local_sol.append(sibling_sols[0])
                final_local_indices.append(final_idx)

            temp_local_sol = final_local_sol
            temp_local_indices = final_local_indices

    # --- Load Balancing ---
    lb_occurred = False
    if lb_due:
        # 1. Compute weights locally
        local_weights = load_balancing.compute_local_weights(
            temp_local_sol, config.load_balancing.strategy
        )

        # 2. Gather weights at Rank 0
        all_weights_nested = comm.gather(local_weights, root=0)
        all_indices_nested = comm.gather(temp_local_indices, root=0)

        lb_migration_map = None
        if rank == 0:
            assert all_weights_nested is not None
            assert all_indices_nested is not None

            (
                global_weights,
                current_rank_map,
            ) = contracts.build_global_weight_and_rank_maps(
                all_indices_nested,
                all_weights_nested,
                num_domains=current_manager.num_domains(),
                num_ranks=size,
            )

            lb_migration_map = load_balancing.propose_partition(
                current_manager,
                size,
                current_rank_map,
                global_weights,
                config.load_balancing.imbalance_threshold,
            )

            if lb_migration_map:
                contracts.validate_lb_migration_map(
                    lb_migration_map,
                    current_rank_map=current_rank_map,
                    num_ranks=size,
                )
                logger.info("Load Balancing: Moving %d leaves.", len(lb_migration_map))
                expected_post_lb_rank_map = dict(current_rank_map)
                for leaf_idx, target_rank in lb_migration_map.items():
                    expected_post_lb_rank_map[leaf_idx] = target_rank

        lb_migration_map = comm.bcast(lb_migration_map, root=0)
        expected_post_lb_rank_map = comm.bcast(expected_post_lb_rank_map, root=0)

        if lb_migration_map:
            # Update init_data to match current temp state before migration
            init_data.local_sol = temp_local_sol
            init_data.local_indices = temp_local_indices
            # We also need to ensure leaf_to_rank_map is current for migrate_solutions
            # (migrate_solutions uses it to find source ranks)
            # If AMR happened, we need to rebuild it.
            if refinement_occurred or coarsening_occurred:
                # Quick reconstruction of map for migration utility
                # (migrate_solutions updates it internally, but needs a starting point)
                # We can use _update_rank_map, but that requires communication.
                # Alternatively, we can rely on the fact that migrate_solutions
                # only needs it to find *other* ranks.
                # Let's do a proper update to be safe.
                new_map, _ = _update_rank_map(
                    temp_local_indices, current_manager.num_domains(), logger
                )
                init_data.leaf_to_rank_map = new_map

            init_data = migrate_solutions(init_data, lb_migration_map, logger)
            temp_local_sol = init_data.local_sol
            temp_local_indices = init_data.local_indices
            lb_occurred = True

    # --- Finalize ---
    if not (refinement_occurred or coarsening_occurred or lb_occurred):
        return init_data

    init_data.domain_manager = current_manager
    init_data.local_indices = temp_local_indices
    init_data.local_sol = temp_local_sol

    # Re-map ranks based on actual data distribution (Dynamic Discovery)
    new_leaf_to_rank_map, new_local_indices_chunked = _update_rank_map(
        temp_local_indices, current_manager.num_domains(), logger
    )
    if lb_occurred and expected_post_lb_rank_map is not None:
        contracts.validate_post_lb_rank_map(
            new_leaf_to_rank_map, expected_post_lb_rank_map
        )
    init_data.leaf_to_rank_map = new_leaf_to_rank_map
    init_data.local_indices_chunked = new_local_indices_chunked

    init_data.monitor.update_topology(current_manager, temp_local_indices)

    # Recompute dt based on new grid
    min_dx = current_manager.min_dx()
    new_dt = config.solver.cfl * min_dx / config.equations.speed_of_light
    if not np.all(np.isclose(new_dt, init_data.dt)):
        logger.info("AMR: Updating time step. dt: %.2e -> %.2e", init_data.dt, new_dt)
        init_data.dt = new_dt

    (
        init_data.local_bc,
        init_data.local_bc_dirichlet,
        init_data.local_rhs,
        init_data.local_flux_calculators,
        init_data.pack_ops_by_leaf,
        init_data.reconstruct_ops_by_leaf,
        init_data.receive_plans_by_leaf,
    ) = rebuild_topology_operators(
        config,
        init_data.problem,
        init_data.domain_manager,
        init_data.local_indices,
        init_data.dt,
        init_data.dimension,
        init_data.permut,
        init_data.inv_permut,
        logger,
    )

    return init_data


def initialize_simulation(config: Config, logger: logging.Logger) -> InitializationData:
    """Orchestrates the entire parallel setup of the simulation.

    Args:
        config: The simulation configuration.
        logger: Logger instance.

    Returns:
        An InitializationData object containing all necessary components for
        the time loop.
    """
    # 1. Global Parameters
    (
        problem,
        domain_manager,
        permut,
        inv_permut,
        dt,
        dimension,
    ) = _setup_global_parameters(config, logger)

    # 2. Domain Partitioning
    local_indices, leaf_to_rank_map, local_indices_chunked = _partition_domain(
        domain_manager, logger
    )

    # 3. Local State Initialization
    monitor = Monitor(domain_manager, problem, local_indices)
    local_sol, time = initialize_solutions(
        config, problem, permut, domain_manager, local_indices, logger
    )
    monitor.add_solution(local_sol, time)
    logger.info("Local monitor and initial solution are ready.")

    # 4. Local Operators & Comm Plans
    (
        local_bc,
        local_bc_dirichlet,
        local_rhs,
        local_flux_calculators,
        pack_ops,
        reconstruct_ops,
        receive_plans,
    ) = rebuild_topology_operators(
        config,
        problem,
        domain_manager,
        local_indices,
        dt,
        dimension,
        permut,
        inv_permut,
        logger,
    )

    logger.info("All ranks have built their local components.")
    comm.Barrier()

    return InitializationData(
        dt=dt,
        time=time,
        dimension=dimension,
        permut=np.array(permut),
        inv_permut=np.array(inv_permut),
        problem=problem,
        domain_manager=domain_manager,
        monitor=monitor,
        local_sol=local_sol,
        local_indices=local_indices,
        leaf_to_rank_map=leaf_to_rank_map,
        local_bc=local_bc,
        local_bc_dirichlet=local_bc_dirichlet,
        local_rhs=local_rhs,
        local_flux_calculators=local_flux_calculators,
        pack_ops_by_leaf=pack_ops,
        reconstruct_ops_by_leaf=reconstruct_ops,
        receive_plans_by_leaf=receive_plans,
        local_indices_chunked=local_indices_chunked,
    )


class HaloUpdates(NamedTuple):
    """Container for halo exchange updates.

    Attributes:
        additive: A list (per local leaf) of lists of TensorNetworks representing
            additive updates (e.g., boundary fluxes).
        flux_corrections: A list (per local leaf) of lists of TensorNetworks
            representing conservative flux corrections from fine neighbors.
        a_ghost: A list (per local leaf) of arrays containing the updated
            absorption opacity in the ghost cells.
        s_ghost: A list (per local leaf) of arrays containing the updated
            scattering opacity in the ghost cells.
    """

    additive: list[list[pytens.TensorNetwork]]
    flux_corrections: list[list[pytens.TensorNetwork]]
    a_ghost: list[np.ndarray]
    s_ghost: list[np.ndarray]


def prepare_ghost_packages_for_leaf(
    local_sol_item: solver.Solution,
    pack_ops: list[PackOp],
    init_data: InitializationData,
) -> dict[int, dict]:
    """Prepares all data packages to be sent from a single leaf to its neighbors.

    Args:
        local_sol_item: The solution data for the sending leaf.
        pack_ops: A list of pre-computed packing operators for all neighbors.
        init_data: The main simulation initialization data container.

    Returns:
        A dictionary where keys are the global indices of receiver leaves and
        values are the corresponding data packages to be sent.
    """
    if local_sol_item.space is None:
        raise ValueError("Local solution space cannot be None during halo exchange.")

    outgoing_packages = {}
    fields_to_pack = local_sol_item.space

    # Iterate over pre-computed operators
    for op in pack_ops:
        tt_result = op.tt_func(local_sol_item.intensity)

        packed_arrays = {}
        for key, field_data in fields_to_pack.items():
            packed_arrays[key] = np.ascontiguousarray(
                op.space_func(field_data.flatten()[:, np.newaxis])
            )

        package = {"tn": tt_result, "arrays": packed_arrays}
        outgoing_packages[op.receiver_idx] = package

    return outgoing_packages


def aggregate_ghost_packages_for_leaf(
    incoming_packages: dict[int, dict],
    reconstruct_ops: list[ReconstructOp],
) -> tuple[list, np.ndarray | None, np.ndarray | None]:
    """Aggregates all received data packages for a single receiving leaf.

    This function takes small, dense packages, reconstructs the large, sparse
    ghost-cell contributions using pre-computed operators, and aggregates them.

    Args:
        incoming_packages: Dict mapping sender indices to received data packages.
        reconstruct_ops: List of pre-computed reconstruction operators.

    Returns:
        A tuple containing the aggregated ghost cell contributions.
    """
    if not incoming_packages:
        return [], None, None

    aggregated_additive_updates = []
    reconstruct_ops_map = {op.sender_idx: op for op in reconstruct_ops}

    # Initialize aggregated arrays using the shape from the first reconstructed package
    first_sender_idx = min(incoming_packages.keys())
    first_op = reconstruct_ops_map[first_sender_idx]
    first_package = incoming_packages[first_sender_idx]
    a_ghost_shape = first_op.space_func(
        first_package["arrays"]["absorption_opacity"]
    ).shape
    s_ghost_shape = first_op.space_func(
        first_package["arrays"]["scattering_opacity"]
    ).shape
    aggregated_a_ghost = np.zeros(a_ghost_shape)
    aggregated_s_ghost = np.zeros(s_ghost_shape)

    for sender_idx in sorted(incoming_packages):
        package = incoming_packages[sender_idx]
        # Find the correct reconstruction operator for this sender
        op = reconstruct_ops_map[sender_idx]

        # Reconstruct the large, sparse contributions from the small, dense data
        tn_reconstructed = op.tt_func(package["tn"])
        a_reconstructed = op.space_func(package["arrays"]["absorption_opacity"])
        s_reconstructed = op.space_func(package["arrays"]["scattering_opacity"])

        # Collect TensorNetwork updates into a new list
        aggregated_additive_updates.append(tn_reconstructed)

        # Sum the opacity array updates
        aggregated_a_ghost += a_reconstructed.reshape(a_ghost_shape)
        aggregated_s_ghost += s_reconstructed.reshape(s_ghost_shape)

    return aggregated_additive_updates, aggregated_a_ghost, aggregated_s_ghost


def perform_halo_exchange(
    init_data: InitializationData,
    comm: MPI.Comm,
    logger: logging.Logger,
    iteration: int | None = None,
) -> HaloUpdates:
    """Orchestrates the full halo exchange for all local domains.

    This function manages the entire multi-step process of populating ghost
    cells for all leaves managed by the current MPI rank. It follows a
    prepare-communicate-apply pattern to efficiently handle both physical
    boundary conditions and inter-process communication.

    The process is as follows:
    1.  **Local BCs**: First, it initializes the ghost cell data for each
        local leaf by applying its physical boundary conditions (e.g.,
        Dirichlet, Outflow). This provides a baseline set of ghost cell values.
    2.  **Prepare Packages (Pack)**: It iterates through all local leaves that
        need to send data. Using the pre-computed "pack" operators, it
        extracts the boundary data from the solution and opacity fields,
        creating small, dense data packages destined for neighboring leaves.
    3.  **Communicate**: All prepared packages from all ranks are exchanged
        simultaneously using a single, optimized MPI collective operation
        (`exchange_packages_mpi`).
    4.  **Apply Packages (Reconstruct & Aggregate)**: After receiving packages
        from its neighbors, each local leaf uses its pre-computed
        "reconstruct" operators to transform the small, dense packages back
        into large, sparse ghost cell contributions. These contributions are
        then summed (aggregated) with the baseline data from step 1.

    Args:
        init_data: The main simulation initialization data container.
        comm: The MPI communicator.
        logger: The logger instance.

    Returns:
        A `HaloUpdates` object containing the fully populated and aggregated
        ghost cell data for all local leaves.
    """
    # --- 1. Initialize ghost cell data from physical boundaries ---
    all_additive_updates = []
    all_a_ghost_add = []
    all_s_ghost_add = []
    for i, global_idx in enumerate(init_data.local_indices):
        leaf = init_data.domain_manager.leaves[global_idx]
        local_sol_item = init_data.local_sol[i]
        if local_sol_item.space is None:
            raise ValueError(f"Solution space for leaf {global_idx} is None.")
        i_ghost = init_data.local_bc[i].add_and_fill_in_spatial_core_ghost_cells(
            local_sol_item.intensity
        )
        additive_updates = [i_ghost]
        if init_data.local_bc_dirichlet[i] is not None:
            additive_updates.append(init_data.local_bc_dirichlet[i])
        a_ghost_add = leaf.disc.add_ghost(local_sol_item.space["absorption_opacity"])
        s_ghost_add = leaf.disc.add_ghost(local_sol_item.space["scattering_opacity"])
        all_additive_updates.append(additive_updates)
        all_a_ghost_add.append(a_ghost_add)
        all_s_ghost_add.append(s_ghost_add)

    # --- 2. PREPARE: Generate all outgoing data packages for this rank ---
    all_outgoing_packages = {}
    for sender_idx, ops in init_data.pack_ops_by_leaf.items():
        sender_local_idx = list(init_data.local_indices).index(sender_idx)
        local_sol_item = init_data.local_sol[sender_local_idx]

        # This function creates packages for all neighbors of a single leaf
        outgoing_for_leaf = prepare_ghost_packages_for_leaf(
            local_sol_item, ops, init_data
        )
        for receiver_idx, package in outgoing_for_leaf.items():
            all_outgoing_packages[(sender_idx, receiver_idx)] = package

    # --- 3. COMMUNICATE: Exchange all packages with other ranks ---
    received_packages_by_leaf = comms.exchange_packages_mpi(
        all_outgoing_packages,
        init_data,
        comm,
        logger,
        iteration=iteration,
    )

    # --- 4. APPLY: Process all received data ---
    all_flux_corrections: list[list[pytens.TensorNetwork]] = [
        [] for _ in init_data.local_indices
    ]
    for receiver_local_idx, incoming_packages in received_packages_by_leaf.items():
        if not incoming_packages:
            continue

        calculators_for_leaf = init_data.local_flux_calculators[receiver_local_idx]
        regular_packages = {}

        flux_senders: set[int] = set()
        for sender_idx in sorted(incoming_packages):
            package = incoming_packages[sender_idx]
            if sender_idx in calculators_for_leaf:
                # Process this fine-to-coarse package to get a flux correction
                calculator = calculators_for_leaf[sender_idx]
                receiver_global_idx = init_data.local_indices[receiver_local_idx]
                coarse_sol = init_data.local_sol[receiver_local_idx]
                coarse_disc = init_data.domain_manager.leaves[receiver_global_idx].disc

                correction_term = calculator(
                    coarse_sol,
                    package["tn"],
                    package["arrays"],
                    coarse_disc,
                    init_data.dt,
                    init_data.problem.indices,
                )
                all_flux_corrections[receiver_local_idx].append(correction_term)
                flux_senders.add(sender_idx)

            # This is a regular package for ghost cell reconstruction
            regular_packages[sender_idx] = package

        # Aggregate ghost cell contributions from regular neighbors
        if regular_packages:
            receiver_global_idx = init_data.local_indices[receiver_local_idx]
            reconstruct_ops = init_data.reconstruct_ops_by_leaf[receiver_global_idx]

            (
                agg_additive,
                agg_a_ghost,
                agg_s_ghost,
            ) = aggregate_ghost_packages_for_leaf(
                regular_packages,
                reconstruct_ops,
            )

            if agg_additive:
                all_additive_updates[receiver_local_idx].extend(agg_additive)
            if agg_a_ghost is not None:
                all_a_ghost_add[receiver_local_idx] += agg_a_ghost.reshape(
                    all_a_ghost_add[receiver_local_idx].shape
                )
            if agg_s_ghost is not None:
                all_s_ghost_add[receiver_local_idx] += agg_s_ghost.reshape(
                    all_s_ghost_add[receiver_local_idx].shape
                )

    return HaloUpdates(
        additive=all_additive_updates,
        flux_corrections=all_flux_corrections,
        a_ghost=all_a_ghost_add,
        s_ghost=all_s_ghost_add,
    )


def advance_local_solutions(
    config: Config,
    updates: HaloUpdates,
    init_data: InitializationData,
    step_num: int,
    logger: logging.Logger,
) -> list[solver.Solution]:
    """Calls the domain_step solver for each local leaf.

    Args:
        config: Simulation configuration.
        updates: Halo updates.
        init_data: Initialization data.
        step_num: Current step number.
        logger: Logger instance.

    Returns:
        List of updated local solutions.
    """
    new_local_sol = []
    for ii, _global_idx in enumerate(init_data.local_indices):
        next_sol_item = domain_step(
            init_data.local_sol[ii],
            step_num,
            init_data.dt,
            updates.a_ghost[ii],
            updates.s_ghost[ii],
            updates.additive[ii],
            init_data.local_rhs[ii],
            config,
            init_data.domain_manager.domain_angles,
            init_data.problem.indices,
            logger,
            updates.flux_corrections[ii],
        )
        new_local_sol.append(next_sol_item)
    return new_local_sol


def handle_post_step_io(
    new_local_sol: list[solver.Solution],
    init_data: InitializationData,
    config: Config,
    save_dir: pathlib.Path,
    iteration: int,
    fig_overlay: Any,
    comm: MPI.Comm,
    logger: logging.Logger,
) -> tuple[InitializationData, Any]:
    """Handles saving, plotting, and memory management for the step.

    Args:
        new_local_sol: The updated local solutions.
        init_data: The initialization data (state).
        config: Simulation configuration.
        save_dir: Directory to save output.
        iteration: Current iteration number.
        fig_overlay: Figure object for overlay plots.
        comm: MPI communicator.
        logger: Logger instance.

    Returns:
        Tuple of updated InitializationData and the figure object.
    """
    rank = comm.Get_rank()

    # 1. Update state for the next iteration
    init_data.local_sol = new_local_sol
    init_data.time += init_data.dt
    init_data.monitor.add_solution(init_data.local_sol, init_data.time)

    if iteration % config.saving.plot_freq == 0:
        ranks_summary(init_data, logger)

    # 2. Save checkpoints (parallel I/O)
    if iteration % config.saving.checkpoint_freq == 0:
        init_data.monitor.save_checkpoint(save_dir, iteration)

    if iteration % config.saving.spatial_save_freq == 0:
        init_data.monitor.save_datafiles(save_dir, iteration)

    # 3. Plotting (compute locally, gather results)
    init_data.monitor.compute_aux_last_sol()
    if iteration % config.saving.plot_freq == 0:
        local_mean_intensities = [
            s.aux.get("mean_intensity") for s in init_data.local_sol
        ]
        local_temperatures = [
            s.space.get("temperature", None) if s.space else None
            for s in init_data.local_sol
        ]

        # 2. Gather each list of NumPy arrays individually. This is robust.
        all_mean_intensities_chunked = comm.gather(local_mean_intensities, root=0)
        all_temperatures_chunked = comm.gather(local_temperatures, root=0)

        if rank == 0:
            if (
                init_data.domain_manager is not None
                and init_data.local_indices_chunked is not None
            ):
                num_domains = init_data.domain_manager.num_domains()
                global_mean_intensities: list[np.ndarray | None] = [None] * num_domains
                if all_mean_intensities_chunked:
                    for rank_id, chunk_indices in enumerate(
                        init_data.local_indices_chunked
                    ):
                        if all_mean_intensities_chunked[rank_id]:
                            for ind, global_idx in enumerate(chunk_indices):
                                global_mean_intensities[global_idx] = (
                                    all_mean_intensities_chunked[rank_id][ind]
                                )

                global_temperatures: list[np.ndarray | None] = [None] * num_domains
                if all_temperatures_chunked:
                    for rank_id, chunk_indices in enumerate(
                        init_data.local_indices_chunked
                    ):
                        if all_temperatures_chunked[rank_id]:
                            for ind, global_idx in enumerate(chunk_indices):
                                global_temperatures[global_idx] = (
                                    all_temperatures_chunked[rank_id][ind]
                                )

            global_plot_data = []
            for i in range(num_domains):
                global_plot_data.append(
                    {
                        "mean_intensity": global_mean_intensities[i],
                        "temperature": global_temperatures[i],
                    }
                )

            fig_overlay = init_data.monitor.plot_last_sol(
                global_plot_data, init_data.time, save_dir, iteration, fig_overlay
            )

    # 4. Memory management (all ranks)
    if not config.saving.keep_all:
        init_data.monitor.del_prev_sol()

    return init_data, fig_overlay


def ranks_summary(init_data: InitializationData, logger: logging.Logger) -> None:
    """Log summary statistics of tensor ranks across all domains.

    Args:
        init_data: The initialization data containing local solutions.
        logger: Logger instance.
    """
    local_ranks_list = [s.intensity.ranks() for s in init_data.local_sol]
    all_ranks_chunked = comm.gather(local_ranks_list, root=0)

    if rank == 0:
        # 3. On Rank 0, process the gathered data and log a summary.
        all_ranks_flat = []
        if all_ranks_chunked:
            for chunk in all_ranks_chunked:
                if chunk:
                    for rank_array in chunk:
                        all_ranks_flat.append(rank_array)

        if all_ranks_flat:
            # Convert to a single NumPy array for easy computation.
            # Flattening completely is safest for simple stats to avoid ragged arrays.
            all_values = np.concatenate([np.array(r).flatten() for r in all_ranks_flat])

            # Calculate summary statistics. The max rank is often the most important.
            min_rank = np.min(all_values)
            mean_rank = np.mean(all_values)
            max_rank = np.max(all_values)

            logger.info(
                "TT Ranks Summary -- Min: %d, Mean: %.2f, Max: %d",
                min_rank,
                mean_rank,
                max_rank,
            )
