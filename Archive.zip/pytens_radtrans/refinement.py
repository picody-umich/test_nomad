"""Defines triggers and logic for Adaptive Mesh Refinement."""

import abc
import logging
from typing import TYPE_CHECKING, cast

import numpy as np
import pytens
from mpi4py import MPI

from . import load_config, solver, utils
from .discretization import Discretization
from .types import NDArrayF

if TYPE_CHECKING:
    pass


from . import domain_decomp
from .discretization import AngleDiscretization, Indices


class RefinementTrigger(abc.ABC):
    """Abstract base class for AMR triggers."""

    def update_global_stats(  # noqa: B027
        self, comm: MPI.Comm, local_sols: list["solver.Solution"]
    ) -> None:
        """
        Updates global statistics needed for the trigger (e.g. global max).

        Args:
            comm: The MPI communicator.
            local_sols: List of local solutions on this rank.
        """
        pass  # Default implementation does nothing

    @abc.abstractmethod
    def should_refine(self, sol: "solver.Solution") -> bool:
        """
        Determines if a specific domain (solution) requires refinement.

        Args:
            sol: The solution state on the current leaf.

        Returns:
            True if the domain should be split, False otherwise.
        """

    @abc.abstractmethod
    def should_coarsen(self, sols: list["solver.Solution"]) -> bool:
        """
        Determines if a group of sibling domains can be coarsened.

        Args:
            sols: A list of solution states for the sibling leaves.

        Returns:
            True if the siblings should be merged, False otherwise.
        """


class MaxRankTrigger(RefinementTrigger):
    """
    Triggers refinement based on the ranks of the intensity tensor network.

    Refines if the maximum rank of the tensor network exceeds `max_rank`.
    Coarsens if the maximum rank of all sibling tensor networks is below `min_rank`.
    """

    def __init__(self, max_rank: int, min_rank: int):
        """
        Initialize the trigger.

        Args:
            max_rank: Threshold for refinement.
            min_rank: Threshold for coarsening.
        """
        self.max_rank = max_rank
        self.min_rank = min_rank

    def should_refine(self, sol: "solver.Solution") -> bool:
        """Check if max rank exceeds threshold."""
        # .ranks() returns a list of integers (e.g. [1, r1, r2, ..., 1])
        current_max = int(max(sol.intensity.ranks()))
        # current_max = int(np.mean(sol.intensity.ranks()))
        return current_max > self.max_rank

    def should_coarsen(self, sols: list["solver.Solution"]) -> bool:
        """Check if max rank of all siblings is below threshold."""
        for sol in sols:
            if int(max(sol.intensity.ranks())) >= self.min_rank:
                return False
            # if int(np.mean(sol.intensity.ranks())) >= self.min_rank:
            #     return False
        return True


class MeanIntensityTrigger(RefinementTrigger):
    """
    Triggers refinement based on the global maximum of Mean Intensity.

    Refines if local max > (1 - refine_fraction) * GlobalMax.
    Coarsens if local max < (1 - coarsen_fraction) * GlobalMax.
    """

    def __init__(self, refine_fraction: float, coarsen_fraction: float):
        self.refine_frac = refine_fraction
        self.coarsen_frac = coarsen_fraction
        self.global_max = 0.0

    def update_global_stats(
        self, comm: MPI.Comm, local_sols: list["solver.Solution"]
    ) -> None:
        """Compute the global maximum of mean intensity across all ranks."""
        local_max = 0.0
        for sol in local_sols:
            val = sol.aux.get("mean_intensity")
            if val is not None:
                # Handle potential empty arrays or None
                if val.size > 0:
                    local_max = max(local_max, float(np.max(val)))

        self.global_max = comm.allreduce(local_max, op=MPI.MAX)

    def should_refine(self, sol: "solver.Solution") -> bool:
        val = sol.aux.get("mean_intensity")
        if val is None:
            raise ValueError("Mean intensity not found in solution auxiliary data.")
        if val.size == 0:
            return False

        # Refine if in top X percentile (value > threshold)
        threshold = (1.0 - self.refine_frac) * self.global_max
        return float(np.max(val)) > threshold

    def should_coarsen(self, sols: list["solver.Solution"]) -> bool:
        # Coarsen if ALL siblings are in bottom Y percentile (value < threshold)
        threshold = (1.0 - self.coarsen_frac) * self.global_max

        for sol in sols:
            val = sol.aux.get("mean_intensity")
            if val is None:
                raise ValueError("Mean intensity not found in solution auxiliary data.")
            if val.size == 0:
                return False  # Safety, shouldn't happen if initialized

            if float(np.max(val)) >= threshold:
                return False
        return True


def _interp_1d_axis(
    arr: np.ndarray,
    old_coords: np.ndarray,
    new_coords: np.ndarray,
    axis: int,
    order: int,
    edges: np.ndarray | None = None,
) -> np.ndarray:
    """
    Interpolate array along a specific axis.

    Supports linear interpolation between centers (order=1) and piecewise
    constant interpolation based on cell containment (order=0).

    Args:
        arr: The input array to interpolate.
        old_coords: Coordinate points of the input array along `axis` (usually centers).
        new_coords: Coordinate points to interpolate onto.
        axis: The axis of `arr` corresponding to the spatial dimension.
        order: Interpolation order. 0 for constant, 1 for linear.
        edges: (Optional) Cell edges of the input grid. Required if order=0 to
            determine cell containment accurately.

    Returns:
        The interpolated array with the same shape as `arr` except for `axis`,
        which will have size equal to `len(new_coords)`.
    """
    # Move the target axis to the front (0) for uniform handling
    # Shape becomes (N_old, ...)
    arr_swapped = np.moveaxis(arr, axis, 0)

    if order == 0:
        # Constant interpolation (Nearest/Cell containment)
        if edges is None:
            # Fallback to nearest center if edges not provided
            # Calculate midpoints between centers to act as boundaries
            edges = (old_coords[:-1] + old_coords[1:]) / 2.0
            # Add -inf and +inf to handle boundaries
            edges = np.concatenate(([-np.inf], edges, [np.inf]))
            indices = np.searchsorted(edges, new_coords) - 1
        else:
            # Use actual grid edges to find which cell new_coords fall into
            # edges has length N+1
            indices = np.searchsorted(edges, new_coords) - 1

        # Clip indices to valid range [0, N_old - 1]
        indices = np.clip(indices, 0, arr_swapped.shape[0] - 1)

        # Gather values
        out_swapped = arr_swapped[indices]

    elif order == 1:
        # Linear interpolation between centers
        # Find indices such that old_coords[i] <= new_coords < old_coords[i+1]
        indices = np.searchsorted(old_coords, new_coords, side="right") - 1
        indices = np.clip(indices, 0, len(old_coords) - 2)

        x0 = old_coords[indices]
        x1 = old_coords[indices + 1]

        # Compute weights
        # Avoid division by zero if points are identical (unlikely in valid grid)
        denom = x1 - x0
        weights = np.divide(
            (new_coords - x0), denom, out=np.zeros_like(denom), where=denom != 0
        )
        # We allow weights < 0 or > 1 to permit linear extrapolation, which
        # preserves gradients better than constant extension.

        val0 = arr_swapped[indices]
        val1 = arr_swapped[indices + 1]

        # Reshape weights for broadcasting: (N_new, 1, 1, ...)
        # We need to append singleton dimensions for all trailing dimensions
        # of arr_swapped
        broadcast_shape = [-1] + [1] * (arr_swapped.ndim - 1)
        w = weights.reshape(broadcast_shape)

        out_swapped = (1.0 - w) * val0 + w * val1

    else:
        raise ValueError(f"Unsupported interpolation order: {order}")

    # Move the axis back to its original position
    return np.moveaxis(out_swapped, 0, axis)


def split_spatial_data(
    parent_arr: NDArrayF,
    parent_disc: Discretization,
    child_disc: Discretization,
    order: int = 1,
) -> NDArrayF:
    """
    Interpolates spatial data from a parent domain to a child domain.

    This function handles the mathematical splitting of data fields (e.g.,
    temperature, opacity) or tensor train spatial cores when a domain is refined.
    It supports arbitrary trailing dimensions (ranks, groups, etc.), assuming
    the leading dimensions correspond to the spatial dimensions of the
    discretization.

    For a 1D problem, `parent_arr` is expected to be `(nx, ...)`.
    For a 2D problem, `parent_arr` is expected to be `(nx, ny, ...)`.

    Args:
        parent_arr: The data array on the parent grid.
        parent_disc: The discretization object for the parent domain.
        child_disc: The discretization object for the child domain.
        order: Interpolation order.
            0: Constant interpolation (value of the containing cell).
            1: Linear interpolation (between cell centers).

    Returns:
        The data array interpolated onto the child grid. The shape will match
        `parent_arr` except for the spatial dimensions, which will match
        `child_disc.grid.num_cells`.
    """
    out = parent_arr

    # Iterate over each spatial dimension (e.g., x, then y)
    for d in range(parent_disc.dimension):
        old_centers = parent_disc.grid.cell_centers[d]
        new_centers = child_disc.grid.cell_centers[d]

        # For order=0, we need edges to determine cell containment accurately
        edges = parent_disc.grid.cell_edges[d] if order == 0 else None

        out = _interp_1d_axis(
            out, old_centers, new_centers, axis=d, order=order, edges=edges
        )

    return out


def merge_spatial_data(
    child_arrs: list[NDArrayF],
    child_discs: list[Discretization],
    parent_disc: Discretization,
) -> NDArrayF:
    """
    Merges spatial data from multiple child domains into a parent domain.

    This function performs the inverse of splitting: it aggregates data from
    children and restricts (averages) it onto the coarser parent grid. This
    ensures conservation for finite-volume quantities.

    The function assumes the children are provided in the standard order
    produced by `Discretization.split()`:
    - 1D: [Left, Right]
    - 2D: [Lower-Left, Upper-Left, Upper-Right, Lower-Right]

    Args:
        child_arrs: A list of data arrays, one for each child.
        child_discs: A list of discretization objects for each child.
        parent_disc: The discretization object for the parent domain.

    Returns:
        The merged data array on the parent grid.

    Raises:
        ValueError: If the combined shape of children does not match the
            expected parent shape (accounting for the 2x refinement factor).
        NotImplementedError: If the dimension is not 1 or 2.
    """
    dim = parent_disc.dimension

    if dim == 1:
        # 1D: Concatenate along axis 0 (x)
        # child_arrs[0] is Left, child_arrs[1] is Right
        full = np.concatenate(child_arrs, axis=0)

        # Downsample by averaging adjacent pairs to return to parent resolution
        # Parent has N cells. Children combined have 2N cells.
        # We reshape (2N, ...) -> (N, 2, ...) and mean over axis 1.
        shape = list(full.shape)
        n_parent = parent_disc.grid.num_cells[0]

        if shape[0] != 2 * n_parent:
            raise ValueError(
                f"Combined child shape {shape} does not match expected size "
                f"{2 * n_parent}"
            )

        new_shape = [n_parent, 2] + shape[1:]
        full_reshaped = full.reshape(new_shape)
        return cast(NDArrayF, full_reshaped.mean(axis=1))

    if dim == 2:
        # 2D: Reconstruct the full (2Nx, 2Ny) array from quadrants
        # Layout from Discretization.split():
        # 0: LL, 1: UL, 2: UR, 3: LR

        # Construct Left Strip (x in [0, mid])
        # Stack LL and UL along y-axis (axis 1)
        left = np.concatenate([child_arrs[0], child_arrs[1]], axis=1)

        # Construct Right Strip (x in [mid, end])
        # Stack LR and UR along y-axis (axis 1)
        right = np.concatenate([child_arrs[3], child_arrs[2]], axis=1)

        # Construct Full Plane
        # Stack Left and Right along x-axis (axis 0)
        full = np.concatenate([left, right], axis=0)

        # Downsample
        nx, ny = parent_disc.grid.num_cells

        # Reshape to (Nx, 2, Ny, 2, ...)
        # We want to average every 2x2 block into 1 cell
        shape = list(full.shape)
        # Insert '2' after x-dim and y-dim
        new_shape = [nx, 2, ny, 2] + shape[2:]
        full_reshaped = full.reshape(new_shape)

        # Mean over the reduction axes (1 and 3)
        return cast(NDArrayF, full_reshaped.mean(axis=(1, 3)))

    raise NotImplementedError("Only 1D and 2D supported.")


def split_solution(
    parent_sol: "solver.Solution",
    parent_disc: Discretization,
    child_discs: list[Discretization],
    permut: list[int],
    domain_angles: AngleDiscretization,
    rounding_opts: "load_config.Rounding",
    logger: logging.Logger,
) -> list["solver.Solution"]:
    """
    Splits a solution from a parent domain to multiple child domains.

    Args:
        parent_sol: The solution on the parent domain.
        parent_disc: The parent discretization.
        child_discs: The list of child discretizations.
        permut: The permutation order of the tensor dimensions.
        domain_angles: The angular discretization for the domain.
        rounding_opts: The configuration for rounding the resulting tensor train.
        logger: The logger instance for logging.

    Returns:
        A list of solutions for the child domains.
    """
    # 1. Setup for Tensor Train splitting
    inv_permute = list(np.argsort(permut))
    parent_spatial_shape = parent_disc.grid.num_cells

    # Create parent Indices object
    space_p = pytens.Index("x", np.prod(parent_disc.grid.num_cells).item())
    theta_p = pytens.Index("theta", domain_angles.theta.size)
    phi_p = pytens.Index("phi", domain_angles.phi.size)
    parent_indices = Indices(
        space=space_p, theta=theta_p, phi=phi_p, dimension=parent_disc.dimension
    )

    # 2. Split Tensor Train for each child by creating and applying an operator
    child_tts = []
    for child_disc in child_discs:
        # Create child Indices object (spatial size is the same)
        space_c = pytens.Index("x", np.prod(child_disc.grid.num_cells).item())
        child_indices = Indices(
            space=space_c, theta=theta_p, phi=phi_p, dimension=child_disc.dimension
        )

        # Define the interpolation operation for the spatial core
        def interp_op(
            core_flat_spatial: np.ndarray,
            target_disc: Discretization = child_disc,
        ) -> np.ndarray:
            full_shape = list(parent_spatial_shape) + [-1]
            core_shaped = core_flat_spatial.reshape(full_shape)
            # TEST: Use order=0 (Constant) to avoid introducing "kinks" or
            # negative tails in the Gaussian profile during refinement.
            new_core_shaped = split_spatial_data(
                core_shaped, parent_disc, target_disc, order=0
            )
            # new_core_shaped = split_spatial_data(
            #     core_shaped, parent_disc, target_disc, order=1
            # )
            return new_core_shaped.reshape(-1, core_flat_spatial.shape[-1])

        # Build and apply the operator
        op = domain_decomp.transfer_boundaries(
            interp_op, parent_indices, child_indices, permut, inv_permute
        )
        child_tt = op(parent_sol.intensity)
        logger.info(f"Child TT ranks before rounding: {child_tt.ranks()}")

        # Use the rounding utility from utils.py.
        # tn_list = utils.TNOPList()
        # tn_list.append(utils.TT(child_tt))
        # rounded_child_tt = tn_list.evaluate_round(
        #     rounding_opts, parent_sol.intensity.ranks()
        # )
        # logger.info(f"Child TT ranks after rounding: {rounded_child_tt.ranks()}")
        # child_tts.append(rounded_child_tt)

        child_tts.append(child_tt)

    # 3. Split spatial fields and create child solutions
    child_sols = []
    for i, child_disc in enumerate(child_discs):
        new_space = {}
        if parent_sol.space:
            for key, arr in parent_sol.space.items():
                # TEST: Use order=0 (Constant) for all spatial fields.
                # This ensures consistency with the Tensor Train interpolation above.
                new_space[key] = split_spatial_data(
                    arr, parent_disc, child_disc, order=0
                )
                # new_space[key] = split_spatial_data(
                #     arr, parent_disc, child_disc, order=1
                # )

        child_sols.append(
            solver.Solution(
                time=parent_sol.time, intensity=child_tts[i], space=new_space
            )
        )
    return child_sols


def merge_solution(
    child_sols: list["solver.Solution"],
    child_discs: list[Discretization],
    parent_disc: Discretization,
    permut: list[int],
    domain_angles: AngleDiscretization,
    rounding_opts: "load_config.Rounding",
    logger: logging.Logger,
) -> "solver.Solution":
    """
    Merges solutions from child domains into a parent domain.

    Args:
        child_sols: List of child solutions.
        child_discs: List of child discretizations.
        parent_disc: Parent discretization.
        permut: The permutation order of the tensor dimensions.
        domain_angles: The angular discretization for the domain.
        rounding_opts: The configuration for rounding the resulting tensor train.
        logger: The logger instance for logging.

    Returns:
        The merged solution on the parent domain.
    """
    # 1. Merge Spatial Fields
    new_space: dict[str, NDArrayF] | None = None

    # Assume all children have the same keys
    if child_sols[0].space is not None:
        new_space = {}
        keys = child_sols[0].space.keys()
        for key in keys:
            child_arrs = [
                cast(NDArrayF, sol.space[key])
                for sol in child_sols
                if sol.space is not None
            ]
            new_space[key] = merge_spatial_data(child_arrs, child_discs, parent_disc)

    # 2. Merge Tensor Trains
    inv_permute = list(np.argsort(permut))

    # Parent Indices
    space_p = pytens.Index("x", np.prod(parent_disc.grid.num_cells).item())
    theta_p = pytens.Index("theta", domain_angles.theta.size)
    phi_p = pytens.Index("phi", domain_angles.phi.size)
    parent_indices = Indices(
        space=space_p, theta=theta_p, phi=phi_p, dimension=parent_disc.dimension
    )

    tn_list = utils.TNOPList()

    for i, child_sol in enumerate(child_sols):
        child_disc = child_discs[i]

        # Child Indices
        space_c = pytens.Index("x", np.prod(child_disc.grid.num_cells).item())
        child_indices = Indices(
            space=space_c, theta=theta_p, phi=phi_p, dimension=child_disc.dimension
        )

        # Define merge operator for this child
        def merge_op(
            core_flat_spatial: np.ndarray,
            c_disc: Discretization = child_disc,
            idx: int = i,
        ) -> np.ndarray:
            # Reshape to spatial dims + (R,)
            child_shape = list(c_disc.grid.num_cells) + [-1]
            core_shaped = core_flat_spatial.reshape(child_shape)

            # Create list of arrays for merge_spatial_data
            # We need arrays for all children.
            # The current child is 'i'. Others are zeros.
            child_arrs_for_merge = []
            for k, disc_k in enumerate(child_discs):
                if k == idx:
                    child_arrs_for_merge.append(core_shaped)
                else:
                    # Create zeros of same shape as this child's core would be
                    shape_k = list(disc_k.grid.num_cells) + [core_shaped.shape[-1]]
                    child_arrs_for_merge.append(
                        np.zeros(shape_k, dtype=core_shaped.dtype)
                    )

            parent_core = merge_spatial_data(
                child_arrs_for_merge, child_discs, parent_disc
            )
            return parent_core.reshape(-1, core_flat_spatial.shape[-1])

        # Build and apply operator
        op = domain_decomp.transfer_boundaries(
            merge_op, child_indices, parent_indices, permut, inv_permute
        )

        # Apply to child intensity
        res_tn = op(child_sol.intensity)
        tn_list.append(utils.TT(res_tn))

    # Sum and Round
    # Use the max ranks across children as a heuristic for current ranks
    child_ranks = [sol.intensity.ranks() for sol in child_sols]
    max_ranks = np.max(child_ranks, axis=0)

    new_intensity = tn_list.evaluate_round(rounding_opts, max_ranks)
    logger.info(f"Merged TT ranks: {new_intensity.ranks()}")

    return solver.Solution(
        time=child_sols[0].time, intensity=new_intensity, space=new_space
    )
