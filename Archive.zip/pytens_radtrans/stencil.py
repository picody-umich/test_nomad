"""
Provides spatial discretization stencils for the transport equation.

This module contains the abstract base class `Stencil` and concrete implementations
for various numerical flux schemes, including Upwind, Rusanov, and the Asymptotic
Preserving (Jiang) flux. These stencils are responsible for constructing the
tensor train operators that represent the spatial advection term.
"""

import abc
from collections.abc import Callable, Sequence
from functools import partial
from typing import Any, cast

import numpy as np
import pytens

from .discretization import Discretization, Indices
from .load_config import Config
from .utils import TNOPList, TTop, encode_order, reorder_list
from .utils import apply_func_to_core as afc


class Stencil(abc.ABC):
    """Abstract base class for a spatial discretization stencil."""

    def __init__(
        self,
        speed_of_light: float,
        sin_theta: np.ndarray,
        cos_phi: np.ndarray,
        sin_phi: np.ndarray,
        disc: Discretization,
        config: Config,
    ):
        """Initializes the Stencil.

        Args:
            speed_of_light: The speed of light.
            sin_theta: Array of sin(theta) for each angle.
            cos_phi: Array of cos(phi) for each angle.
            sin_phi: Array of sin(phi) for each angle.
            disc: The spatial discretization of the domain.
            config: The main simulation configuration object.
        """
        self.speed_of_light = speed_of_light
        self.disc = disc
        self.sin_theta = sin_theta
        self.cos_phi = cos_phi
        self.sin_phi = sin_phi
        self.permut, self.inv_permut = encode_order(config.solver.order)
        self.order = config.solver.order

    def masks_minus_plus(self, mask_arr: np.ndarray) -> tuple[np.ndarray, np.ndarray]:
        """Splits an array into its positive and negative components.

        Given an input array, this method returns two new arrays of the same
        shape. One contains only the negative values from the input (with other
        elements being zero), and the other contains only the positive values.

        Args:
            mask_arr: The input NumPy array.

        Returns:
            A tuple containing two NumPy arrays: (mask_left, mask_right),
            representing the negative and positive parts of `mask_arr`.
        """
        mask_right = np.zeros(len(mask_arr))
        mask_left = np.zeros(len(mask_arr))
        ind_right = mask_arr > 0.0
        ind_left = mask_arr < 0.0
        mask_right[ind_right] = mask_arr[ind_right]
        mask_left[ind_left] = mask_arr[ind_left]

        return mask_left, mask_right

    class StencilCores:
        """A container for the functions that define a tensor train operator.

        This class holds the list of function tuples that represent the cores of
        one or more TT operators. It also handles the logic for reordering these
        functions based on the user-specified tensor dimension order.
        """

        def __init__(
            self,
            cores: Sequence[tuple[Callable[..., Any], ...]],
            order: list[str],
            apply: bool = True,
        ):
            """Initializes the StencilCores.

            Args:
                cores: A sequence where each element is a tuple of functions.
                    Each tuple represents a single TT operator, and each function
                    within the tuple defines a core for a specific dimension
                    (e.g., space, theta, phi).
                order: A list of strings defining the tensor dimension order.
                apply: If True, preprocesses the core functions to handle
                    non-default dimension ordering.
            """
            self.order = order
            self.permut, self.inv_permut = encode_order(order)

            self.cores: list[tuple[Callable[..., Any], ...]]
            if apply:
                new_cores: list[tuple[Callable[..., Any], ...]] = []
                for core in cores:
                    processed_core = [
                        afc(func, self.inv_permut[j]) for j, func in enumerate(core)
                    ]
                    new_cores.append(tuple(reorder_list(processed_core, self.permut)))
                self.cores = new_cores
            else:
                self.cores = list(cores)

        def apply_spatial_vars_to_cores(
            self, spatial_vars: dict[str, Any]
        ) -> "Stencil.StencilCores":
            """Applies spatially-dependent variables to the stencil cores.

            This is a placeholder in the base class. Subclasses like
            `JiangStencilCores` override it to handle state-dependent operators
            (e.g., those dependent on opacity).

            Args:
                spatial_vars: A dictionary of spatial variables.

            Returns:
                The `StencilCores` object, possibly with updated core functions.
            """
            _ = spatial_vars
            return self

        def get_op(
            self, ind: list[pytens.Index], ind_out: list[pytens.Index], scale: float
        ) -> Callable[[list[pytens.TensorNetwork], dict[str, Any]], TNOPList]:
            """Builds and returns the final tensor train operator function.

            Args:
                ind: The input indices for the operator.
                ind_out: The output indices for the operator.
                scale: A scaling factor to apply to the operator.

            Returns:
                A callable function that takes a tensor network and spatial
                variables and returns a `TNOPList` representing the applied
                operator.
            """

            def ttop(
                tt_in: list[pytens.TensorNetwork],
                spatial_vars: dict[str, Any],
            ) -> TNOPList:
                """Apply ops to list of cores and sum them."""
                updated_stencil = self.apply_spatial_vars_to_cores(spatial_vars)

                tn_out = TNOPList()
                for tt in tt_in:
                    tn_out.append(TTop(tt, ind, ind_out, updated_stencil.cores, scale))

                return tn_out

            return ttop

    cores_class: type[StencilCores] = StencilCores

    @abc.abstractmethod
    def get_flux_cores_1d(self) -> "Stencil.StencilCores":
        """Constructs the flux `StencilCores` for a 1D problem."""

    @abc.abstractmethod
    def get_flux_cores_2d(
        self,
    ) -> list[tuple[Callable, str, tuple[Callable, Callable]]]:
        """Constructs the 1D flux cores and metadata for a 2D problem.

        Returns:
            A list where each item is a tuple containing:
            - A callable for the 1D flux calculation.
            - A string indicating the direction ('x' or 'y').
            - A tuple of the remaining core functions (e.g., for theta, phi).
        """

    def stencil1d(self, flux_mask: dict[str, np.ndarray] | None = None) -> StencilCores:
        """Constructs the `StencilCores` for a 1D problem by applying the
        divergence operator to the underlying flux cores.
        """
        h = self.disc.grid.dx[0]
        flux_cores_obj = self.get_flux_cores_1d()

        mask_arr = flux_mask.get("x") if flux_mask is not None else None

        rhs_cores_list = []

        def make_rhs_func(
            flux_f: Callable, h_val: float, mask: np.ndarray | None
        ) -> Callable:
            def rhs_wrapper(*args: Any, **kwargs: Any) -> np.ndarray:
                flux_result = flux_f(*args, **kwargs)
                return self.get_rhs(flux_result, h_val, mask)

            return rhs_wrapper

        # The cores from get_flux_cores_1d are now raw and in canonical order
        for core_tuple in flux_cores_obj.cores:
            new_core_tuple_list = list(core_tuple)
            flux_func = new_core_tuple_list[0]  # Space is always at index 0
            new_core_tuple_list[0] = make_rhs_func(flux_func, h, mask_arr)
            rhs_cores_list.append(tuple(new_core_tuple_list))

        # The final StencilCores object applies afc wrapping and permutation.
        CoresType = type(flux_cores_obj)
        return CoresType(rhs_cores_list, self.order, apply=True)

    def stencil2d(self, flux_mask: dict[str, np.ndarray] | None = None) -> StencilCores:
        """Constructs the `StencilCores` for a 2D problem by applying the
        divergence operator to the underlying flux cores.
        """
        hx, hy = self.disc.grid.dx
        h_map = {"x": hx, "y": hy}

        flux_info_list = self.get_flux_cores_2d()

        def make_rhs_1d_func(
            flux_f: Callable, h_val: float, mask: np.ndarray | None
        ) -> Callable:
            def rhs_wrapper(*args: Any, **kwargs: Any) -> np.ndarray:
                flux_result = flux_f(*args, **kwargs)
                return self.get_rhs(flux_result, h_val, mask)

            return rhs_wrapper

        final_cores = []
        for flux_1d_func, direction, other_cores in flux_info_list:
            h = h_map[direction]
            mask_for_dir = flux_mask.get(direction) if flux_mask else None

            # For the 'y' direction, the spatial data is transposed before the
            # flux calculation. The mask must also be transposed to align.
            if direction == "y" and mask_for_dir is not None:
                mask_for_dir = mask_for_dir.T

            rhs_1d_func = make_rhs_1d_func(flux_1d_func, h, mask_for_dir)

            nx, ny = self.disc.grid.num_cells
            output_size = nx * ny
            spatial_2d_func = self.create_2d_spatial_core_func(
                rhs_1d_func, direction, output_size
            )

            # The order of cores is always (space, theta, phi) before permutation
            # The other_cores should be (theta_func, phi_func)
            full_core = (spatial_2d_func,) + other_cores
            final_cores.append(full_core)

        return self.cores_class(final_cores, self.order)

    def get_ul_dc(self, core_vals: np.ndarray, dim: int) -> np.ndarray:
        """Extracts the left-side cell values at each interface ("donor cell").

        Args:
            core_vals: A 1D array of cell values, including ghost cells.
            dim: The dimension index (0 for x, 1 for y) from which to get
                discretization info.

        Returns:
            A 1D array of the left-side values for each cell interface.
        """
        n_ghost = int(self.disc.grid.num_ghost[dim] / 2)
        n_cells = self.disc.grid.num_cells[dim]
        if n_ghost == 0:
            # print(
            #     f"\n[DEBUG] get_ul_dc (Flux Correction Context):\n"
            #     f"  Input shape: {core_vals.shape}"
            # )
            # For flux F_{i+1/2}, u_l is u_i. This operator should extract u_i.
            # The flux is stored at index i, so we want all but the last cell value.
            result = core_vals[:-1]
            # print(f"  ul shape: {result.shape}, max: {np.max(result):.4e}")
            return cast(np.ndarray, result)

        left_start = n_ghost - 1
        right_end = n_ghost + n_cells
        return cast(np.ndarray, core_vals[left_start:right_end])

    def get_ur_dc(self, core_vals: np.ndarray, dim: int) -> np.ndarray:
        """Extracts the right-side cell values at each interface ("donor cell").

        Args:
            core_vals: A 1D array of cell values, including ghost cells.
            dim: The dimension index (0 for x, 1 for y) from which to get
                discretization info.

        Returns:
            A 1D array of the right-side values for each cell interface.
        """
        n_ghost = int(self.disc.grid.num_ghost[dim] / 2)
        n_cells = self.disc.grid.num_cells[dim]
        if n_ghost == 0:
            # For flux F_{i+1/2}, u_r is u_{i+1}. This operator should extract u_{i+1}.
            # The flux is stored at index i, so we want all but the first cell value.
            result = core_vals[1:]
            # print(f"  ur shape: {result.shape}, max: {np.max(result):.4e}")
            return cast(np.ndarray, result)

        left_start = n_ghost
        right_end = n_ghost + n_cells + 1
        return cast(np.ndarray, core_vals[left_start:right_end])

    def get_rhs(
        self, flux: np.ndarray, h: float, flux_mask: np.ndarray | None = None
    ) -> np.ndarray:
        """Computes the 1D finite volume divergence of a flux.

        This calculates `(flux_{i+1/2} - flux_{i-1/2}) / h` for all interior cells.
        An optional mask can be applied to the flux before differencing.

        Args:
            flux: An array of numerical fluxes at the cell interfaces.
            h: The cell spacing (dx or dy).
            flux_mask: An optional array to multiply the flux by before differencing.

        Returns:
            An array representing the divergence of the flux in each cell.
        """
        if flux_mask is not None:
            assert flux.shape[: flux_mask.ndim] == flux_mask.shape, (
                f"Flux shape {flux.shape} and mask shape {flux_mask.shape} "
                "are incompatible."
            )
            # Mask can be 1D or 2D. Flux can be 2D or 3D. We need to add
            # trailing dimensions to the mask to make it broadcastable.
            dims_to_add = flux.ndim - flux_mask.ndim
            new_shape = list(flux_mask.shape) + [1] * dims_to_add
            flux = flux * flux_mask.reshape(new_shape)

        out = (flux[1:] - flux[:-1]) / h
        return cast(np.ndarray, out)

    def create_2d_spatial_core_func(
        self, func_1d: Callable, direction: str, output_spatial_size: int
    ) -> Callable:
        """Creates a spatial core function for 2D stencils from a 1D function.

        This helper encapsulates the logic for applying a 1D stencil
        function along a specified direction ('x' or 'y') of a 2D grid that has
        been flattened into a 1D vector.

        Args:
            func_1d: A callable that implements the 1D stencil logic.
            direction: The direction to apply the stencil, either "x" or "y".
            output_spatial_size: The size of the flattened spatial dimension for
                the output array.

        Returns:
            A new callable that can be used as the spatial core function.
        """
        nx, ny = self.disc.grid.num_cells
        ngx = int(self.disc.grid.num_ghost[0] / 2)
        ngy = int(self.disc.grid.num_ghost[1] / 2)
        nx_g = nx + 2 * ngx
        ny_g = ny + 2 * ngy

        if direction == "x":

            def spatial_func(*args: Any) -> np.ndarray:
                v = args[-1]
                v_reshaped = v.reshape((nx_g, ny_g, -1))
                func_args = args[:-1] + (v_reshaped,)
                result = func_1d(*func_args)
                slicer = slice(ngy, -ngy if ngy > 0 else None)
                final_result = result[:, slicer, :]
                return cast(np.ndarray, final_result.reshape((output_spatial_size, -1)))

            return spatial_func

        if direction == "y":

            def spatial_func(*args: Any) -> np.ndarray:
                v = args[-1]
                v_reshaped_transposed = v.reshape((nx_g, ny_g, -1)).transpose(1, 0, 2)
                opacities_transposed = [op.T for op in args[:-1]]
                func_args = opacities_transposed + [v_reshaped_transposed]
                result = func_1d(*func_args)
                slicer = slice(ngx, -ngx if ngx > 0 else None)
                final_result = result[:, slicer, :]
                transposed_back = final_result.transpose(1, 0, 2)
                return cast(
                    np.ndarray, transposed_back.reshape(output_spatial_size, -1)
                )

            return spatial_func

        raise ValueError("Direction must be 'x' or 'y'")

    def get_ttop(
        self,
        indices: Indices,
        scale: float,
        flux_mask: dict[str, np.ndarray] | None = None,
    ) -> Callable[[list[pytens.TensorNetwork], dict[str, Any]], TNOPList]:
        """Builds and returns the complete tensor train operator for the stencil.

        This method selects the appropriate 1D or 2D stencil implementation
        based on the domain dimension and constructs the final callable operator.

        Args:
            indices: The tensor indices for the problem dimensions.
            scale: A scaling factor to apply to the operator (e.g., timestep).

        Returns:
            A callable object representing the transport operator.

        Raises:
            NotImplementedError: If the domain dimension is not 1 or 2.
        """
        ind = reorder_list([indices.space, indices.theta, indices.phi], self.permut)
        ind_out = [pytens.Index(f"{i.name}p", i.size) for i in ind]

        assert flux_mask is None or isinstance(flux_mask, dict)

        if self.disc.dimension == 1:
            ttop = self.stencil1d(flux_mask).get_op(ind, ind_out, scale)
        elif self.disc.dimension == 2:
            ttop = self.stencil2d(flux_mask).get_op(ind, ind_out, scale)
        else:
            raise NotImplementedError("Dimensions greater than 2.")

        return ttop


class UpwindStencil(Stencil):
    """Implements a first-order upwind flux scheme."""

    def get_flux_cores_1d(self) -> Stencil.StencilCores:
        """Constructs the flux `StencilCores` for the 1D upwind stencil."""
        mask_left, mask_right = self.masks_minus_plus(
            self.cos_phi * self.speed_of_light
        )
        return Stencil.StencilCores(
            [
                (
                    lambda v: self.get_ul_dc(v, 0),
                    lambda v: v * self.sin_theta[:, np.newaxis],
                    lambda v: v * mask_right[:, np.newaxis],
                ),
                (
                    lambda v: self.get_ur_dc(v, 0),
                    lambda v: v * self.sin_theta[:, np.newaxis],
                    lambda v: v * mask_left[:, np.newaxis],
                ),
            ],
            self.order,
            apply=False,
        )

    def get_flux_cores_2d(
        self,
    ) -> list[tuple[Callable, str, tuple[Callable, Callable]]]:
        """Constructs the 1D flux cores for the 2D upwind stencil."""

        # Define the simple 1D flux functions for each direction
        def ul_flux_x(v: np.ndarray) -> np.ndarray:
            return cast(np.ndarray, self.get_ul_dc(v, 0))

        def ur_flux_x(v: np.ndarray) -> np.ndarray:
            return cast(np.ndarray, self.get_ur_dc(v, 0))

        def ul_flux_y(v_t: np.ndarray) -> np.ndarray:
            return cast(np.ndarray, self.get_ul_dc(v_t, 1))

        def ur_flux_y(v_t: np.ndarray) -> np.ndarray:
            return cast(np.ndarray, self.get_ur_dc(v_t, 1))

        mask_left, mask_right = self.masks_minus_plus(
            self.cos_phi * self.speed_of_light
        )
        mask_down, mask_up = self.masks_minus_plus(self.sin_phi * self.speed_of_light)

        def theta_core(v: np.ndarray) -> np.ndarray:
            return cast(np.ndarray, v * self.sin_theta[:, np.newaxis])

        def phi_right(v: np.ndarray) -> np.ndarray:
            return cast(np.ndarray, v * mask_right[:, np.newaxis])

        def phi_left(v: np.ndarray) -> np.ndarray:
            return cast(np.ndarray, v * mask_left[:, np.newaxis])

        def phi_up(v: np.ndarray) -> np.ndarray:
            return cast(np.ndarray, v * mask_up[:, np.newaxis])

        def phi_down(v: np.ndarray) -> np.ndarray:
            return cast(np.ndarray, v * mask_down[:, np.newaxis])

        flux_info = [
            (ul_flux_x, "x", (theta_core, phi_right)),
            (ur_flux_x, "x", (theta_core, phi_left)),
            (ul_flux_y, "y", (theta_core, phi_up)),
            (ur_flux_y, "y", (theta_core, phi_down)),
        ]
        return flux_info


class RusanovStencil(Stencil):
    """Implements a Rusanov flux scheme (central scheme with dissipation)."""

    def __init__(self, wave_speed: float, *args: Any):
        """Initializes the RusanovStencil.

        Args:
            wave_speed: The maximum wave speed for the artificial dissipation term.
            *args: Arguments to be passed to the base `Stencil` constructor.
        """
        self.wave_speed = wave_speed
        super().__init__(*args)

    def first_half(self, ul: np.ndarray, ur: np.ndarray) -> np.ndarray:
        """Calculates the central difference component of the Rusanov flux.

        Args:
            ul: The left-side cell values at each interface.
            ur: The right-side cell values at each interface.

        Returns:
            The averaged value, (ul + ur) / 2.
        """
        out = (ul + ur) / 2.0
        return cast(np.ndarray, out)

    def second_half(self, ul: np.ndarray, ur: np.ndarray) -> np.ndarray:
        """Calculates the artificial dissipation component of the Rusanov flux.

        Args:
            ul: The left-side cell values at each interface.
            ur: The right-side cell values at each interface.

        Returns:
            The scaled difference, (ul - ur) / 2 * self.wave_speed.
        """
        out = (ul - ur) / 2.0 * self.wave_speed
        return cast(np.ndarray, out)

    def get_flux_cores_1d(self) -> Stencil.StencilCores:
        """Constructs the flux `StencilCores` for the 1D Rusanov stencil."""

        def first_half_flux(v: np.ndarray) -> np.ndarray:
            return self.first_half(self.get_ul_dc(v, 0), self.get_ur_dc(v, 0))

        def second_half_flux(v: np.ndarray) -> np.ndarray:
            return self.second_half(self.get_ul_dc(v, 0), self.get_ur_dc(v, 0))

        return Stencil.StencilCores(
            [
                (
                    first_half_flux,
                    lambda v: v * self.sin_theta[:, np.newaxis],
                    lambda v: v * self.cos_phi[:, np.newaxis] * self.speed_of_light,
                ),
                (
                    second_half_flux,
                    lambda v: v,
                    lambda v: v,
                ),
            ],
            self.order,
            apply=False,
        )

    def get_flux_cores_2d(
        self,
    ) -> list[tuple[Callable, str, tuple[Callable, Callable]]]:
        """Constructs the 1D flux cores for the 2D Rusanov stencil."""

        # Define 1D flux logic for each direction and term
        def first_half_flux_x(v: np.ndarray) -> np.ndarray:
            return self.first_half(self.get_ul_dc(v, 0), self.get_ur_dc(v, 0))

        def second_half_flux_x(v: np.ndarray) -> np.ndarray:
            return self.second_half(self.get_ul_dc(v, 0), self.get_ur_dc(v, 0))

        def first_half_flux_y(v_t: np.ndarray) -> np.ndarray:
            return self.first_half(self.get_ul_dc(v_t, 1), self.get_ur_dc(v_t, 1))

        def second_half_flux_y(v_t: np.ndarray) -> np.ndarray:
            return self.second_half(self.get_ul_dc(v_t, 1), self.get_ur_dc(v_t, 1))

        flux_info = [
            (
                first_half_flux_x,
                "x",
                (
                    lambda v: v * self.sin_theta[:, np.newaxis],
                    lambda v: v * self.cos_phi[:, np.newaxis] * self.speed_of_light,
                ),
            ),
            (second_half_flux_x, "x", (lambda v: v, lambda v: v)),
            (
                first_half_flux_y,
                "y",
                (
                    lambda v: v * self.sin_theta[:, np.newaxis],
                    lambda v: v * self.sin_phi[:, np.newaxis] * self.speed_of_light,
                ),
            ),
            (second_half_flux_y, "y", (lambda v: v, lambda v: v)),
        ]
        return flux_info


class JiangStencil(Stencil):  # pylint: disable=R0902
    """Implements the Asymptotic Preserving (Jiang) flux scheme."""

    def __init__(
        self,
        *args: Any,
        beta: float = 4.0,
        tau_threshold: float = 1e-3,
        alpha_threshold: float = 1e-6,
    ):
        """Initializes the JiangStencil.

        Args:
            *args: Arguments passed to the base `Stencil` constructor.
            beta: A parameter controlling the harmonic mean in the tau calculation.
            tau_threshold: The threshold for optical depth below which a Taylor
                approximation is used for the switching functions.
            alpha_threshold: A floor value for opacities to prevent division
                by zero.
        """
        super().__init__(*args)

        self.beta = beta
        self.tau_threshold = tau_threshold
        self.alpha_threshold = alpha_threshold

    def get_tau(
        self, dx: float, absorption_opacity: np.ndarray, scattering_opacity: np.ndarray
    ) -> np.ndarray:
        """Computes the optical depth `tau` at cell interfaces.

        Args:
            dx: The spatial cell width.
            absorption_opacity: Array of absorption opacities, including ghost cells.
            scattering_opacity: Array of scattering opacities, including ghost cells.

        Returns:
            A 1D array of optical depths at each cell interface.
        """

        alpha_a = np.maximum(
            absorption_opacity, self.alpha_threshold
        )  # Section 4.2.3, Warning 2(a)
        alpha_s = np.maximum(
            scattering_opacity, self.alpha_threshold
        )  # Section 4.2.3, Warning 2(a)

        alpha_sum = alpha_a + alpha_s
        alpha_sum_inv = alpha_sum**-1

        tau_shape = list(alpha_sum.shape)
        tau_shape[0] -= 1  # to get to number of fluxes and alpha has ghost cells
        tau = np.zeros(tau_shape)
        tau = 2 * self.beta * dx / (alpha_sum_inv[:-1] + alpha_sum_inv[1:])
        return cast(np.ndarray, tau)

    def get_tau_switch_conditions(
        self, tau: np.ndarray
    ) -> tuple[np.ndarray, np.ndarray]:
        """Calculates the switching functions that depend on optical depth.

        These functions smoothly transition the scheme from the transport regime
        (optically thin) to the diffusion regime (optically thick).

        Args:
            tau: An array of optical depths.

        Returns:
            A tuple of two arrays (term1, term2) representing the switching
            conditions.
        """
        tau_s = tau**2
        tmp0 = np.sqrt((1 - np.exp(-tau_s)) / tau_s)
        tmp2 = -np.sqrt((1 - np.exp(-(tau_s**2))) / tau_s)
        tmp3 = -tau

        tau_mask_less = tau < self.tau_threshold

        # compute the two terms that then form Sr1/2 and Sl1/2
        # each term has two components (above and below the tau threshold)
        # the two terms are also relevant for when cnx > 0 and cnx < 0

        term1 = tmp0
        term1[tau_mask_less] = np.sqrt(1 - 0.5 * tau_s[tau_mask_less])

        term2 = tmp2
        term2[tau_mask_less] = tmp3[tau_mask_less]

        return term1, term2

    def apf_flux(
        self,
        ul: np.ndarray,
        ur: np.ndarray,
        sr: np.ndarray,
        sl: np.ndarray,
        prod_term: np.ndarray,
        diff_term: np.ndarray,
    ) -> np.ndarray:
        """Computes the final Asymptotic Preserving Flux value.

        Args:
            ul: The left-side cell values.
            ur: The right-side cell values.
            sr: The right-side switching function.
            sl: The left-side switching function.
            prod_term: The product of the switching terms.
            diff_term: The difference between the switching terms.

        Returns:
            The calculated numerical flux.
        """
        diff_u = ur - ul
        flux = sr * ul - sl * ur + prod_term * diff_u
        flux = np.divide(flux, diff_term)
        flux = np.nan_to_num(flux, posinf=0, neginf=0)
        return cast(np.ndarray, flux)

    def _calculate_apf_flux(
        self,
        dx: float,
        absorption_opacity: np.ndarray,
        scattering_opacity: np.ndarray,
        ul: np.ndarray,
        ur: np.ndarray,
        positive_direction: bool,
    ) -> np.ndarray:
        """Helper to compute the APF flux for a given direction.

        This method computes tau, gets the switching conditions, and assembles
        the final flux based on whether the direction is positive or negative.

        Args:
            dx: The spatial cell width.
            absorption_opacity: Absorption opacities.
            scattering_opacity: Scattering opacities.
            ul: Left-side cell values.
            ur: Right-side cell values.
            positive_direction: True if flow is in the positive direction (right/up),
                False otherwise.

        Returns:
            The calculated numerical flux.
        """
        tau = self.get_tau(dx, absorption_opacity, scattering_opacity)
        term1, term2 = self.get_tau_switch_conditions(tau[..., np.newaxis])

        sr = term1 if positive_direction else term2
        sl = term2 if positive_direction else term1

        prod_term = term1 * term2
        diff_term = sr - sl

        return self.apf_flux(ul, ur, sr, sl, prod_term, diff_term)

    def flux_plus(
        self,
        dx: float,
        absorption_opacity: np.ndarray,
        scattering_opacity: np.ndarray,
        ul: np.ndarray,
        ur: np.ndarray,
    ) -> np.ndarray:
        """Calculates the APF flux for flow in the positive direction (right/up).

        Args:
            dx: The spatial cell width.
            absorption_opacity: Absorption opacities.
            scattering_opacity: Scattering opacities.
            ul: Left-side cell values.
            ur: Right-side cell values.

        Returns:
            The calculated numerical flux.
        """
        return self._calculate_apf_flux(
            dx, absorption_opacity, scattering_opacity, ul, ur, positive_direction=True
        )

    def flux_minus(
        self,
        dx: float,
        absorption_opacity: np.ndarray,
        scattering_opacity: np.ndarray,
        ul: np.ndarray,
        ur: np.ndarray,
    ) -> np.ndarray:
        """Calculates the APF flux for flow in the negative direction (left/down).

        Args:
            dx: The spatial cell width.
            absorption_opacity: Absorption opacities.
            scattering_opacity: Scattering opacities.
            ul: Left-side cell values.
            ur: Right-side cell values.

        Returns:
            The calculated numerical flux.
        """
        return self._calculate_apf_flux(
            dx, absorption_opacity, scattering_opacity, ul, ur, positive_direction=False
        )

    class JiangStencilCores(Stencil.StencilCores):
        """A `StencilCores` subclass that is updatable with opacities."""

        def apply_spatial_vars_to_cores(
            self, spatial_vars: dict[str, Any]
        ) -> "Stencil.StencilCores":
            """Applies opacity fields to the spatial core functions.

            This method uses `functools.partial` to bind the current absorption
            and scattering opacity arrays to the spatial core functions,
            making the operator state-dependent.

            Args:
                spatial_vars: A dictionary containing "absorption_opacity" and
                    "scattering_opacity" as NumPy arrays.

            Returns:
                A new `StencilCores` object with the updated core functions.
            """
            new_cores_list = []
            spatial_idx = self.order.index("x")
            for ttop in self.cores:
                new_ttop = list(ttop)
                # Spatial core position depends on tensor order.
                spatial_func = ttop[spatial_idx]
                new_ttop[spatial_idx] = partial(
                    spatial_func,
                    spatial_vars["absorption_opacity"],
                    spatial_vars["scattering_opacity"],
                )
                new_cores_list.append(tuple(new_ttop))
            # Return a new object with the same type as self.
            return type(self)(new_cores_list, self.order, apply=False)

    cores_class = JiangStencilCores

    def get_flux_cores_1d(self) -> Stencil.StencilCores:
        """Constructs the flux `StencilCores` for the 1D Jiang stencil."""
        h = self.disc.grid.dx[0]
        nx = self.disc.grid.num_cells[0]
        nxg = int(self.disc.grid.num_ghost[0] / 2)

        # left_ind = nxg - 1
        left_ind = nxg - 1 if nxg > 0 else 0
        right_ind = nx + nxg + 1
        mask_left, mask_right = self.masks_minus_plus(
            self.cos_phi * self.speed_of_light
        )
        return JiangStencil.JiangStencilCores(
            [
                (
                    lambda a, s, v: self.flux_plus(
                        h,
                        a[left_ind:right_ind],
                        s[left_ind:right_ind],
                        self.get_ul_dc(v, 0),
                        self.get_ur_dc(v, 0),
                    ),
                    lambda v: v * self.sin_theta[:, np.newaxis],
                    lambda v: v * mask_right[:, np.newaxis],
                ),
                (
                    lambda a, s, v: self.flux_minus(
                        h,
                        a[left_ind:right_ind],
                        s[left_ind:right_ind],
                        self.get_ul_dc(v, 0),
                        self.get_ur_dc(v, 0),
                    ),
                    lambda v: v * self.sin_theta[:, np.newaxis],
                    lambda v: v * mask_left[:, np.newaxis],
                ),
            ],
            self.order,
            apply=False,
        )

    def get_flux_cores_2d(
        self,
    ) -> list[tuple[Callable, str, tuple[Callable, Callable]]]:
        """Constructs the 1D flux cores for the 2D Jiang stencil."""
        hx, hy = self.disc.grid.dx
        nx, ny = self.disc.grid.num_cells
        ngx, ngy = (
            int(self.disc.grid.num_ghost[0] / 2),
            int(self.disc.grid.num_ghost[1] / 2),
        )

        left_ind = ngx - 1 if ngx > 0 else 0
        right_ind = nx + ngx + 1
        bottom_ind = ngy - 1 if ngy > 0 else 0
        top_ind = ny + ngy + 1

        # left_ind, right_ind = ngx - 1, nx + ngx + 1
        # bottom_ind, top_ind = ngy - 1, ny + ngy + 1

        # Define 1D logic for each direction and flux type
        def flux_plus_1d_x(a: np.ndarray, s: np.ndarray, v: np.ndarray) -> np.ndarray:
            return self.flux_plus(
                hx,
                a[left_ind:right_ind],
                s[left_ind:right_ind],
                self.get_ul_dc(v, 0),
                self.get_ur_dc(v, 0),
            )

        def flux_minus_1d_x(a: np.ndarray, s: np.ndarray, v: np.ndarray) -> np.ndarray:
            return self.flux_minus(
                hx,
                a[left_ind:right_ind],
                s[left_ind:right_ind],
                self.get_ul_dc(v, 0),
                self.get_ur_dc(v, 0),
            )

        def flux_plus_1d_y(
            a_T: np.ndarray, s_T: np.ndarray, v_T: np.ndarray
        ) -> np.ndarray:
            return self.flux_plus(
                hy,
                a_T[bottom_ind:top_ind],
                s_T[bottom_ind:top_ind],
                self.get_ul_dc(v_T, 1),
                self.get_ur_dc(v_T, 1),
            )

        def flux_minus_1d_y(
            a_T: np.ndarray, s_T: np.ndarray, v_T: np.ndarray
        ) -> np.ndarray:
            return self.flux_minus(
                hy,
                a_T[bottom_ind:top_ind],
                s_T[bottom_ind:top_ind],
                self.get_ul_dc(v_T, 1),
                self.get_ur_dc(v_T, 1),
            )

        mask_left, mask_right = self.masks_minus_plus(
            self.cos_phi * self.speed_of_light
        )
        mask_down, mask_up = self.masks_minus_plus(self.sin_phi * self.speed_of_light)

        def theta_core(v: np.ndarray) -> np.ndarray:
            return cast(np.ndarray, v * self.sin_theta[:, np.newaxis])

        def phi_right(v: np.ndarray) -> np.ndarray:
            return cast(np.ndarray, v * mask_right[:, np.newaxis])

        def phi_left(v: np.ndarray) -> np.ndarray:
            return cast(np.ndarray, v * mask_left[:, np.newaxis])

        def phi_up(v: np.ndarray) -> np.ndarray:
            return cast(np.ndarray, v * mask_up[:, np.newaxis])

        def phi_down(v: np.ndarray) -> np.ndarray:
            return cast(np.ndarray, v * mask_down[:, np.newaxis])

        flux_info = [
            (flux_plus_1d_x, "x", (theta_core, phi_right)),
            (flux_minus_1d_x, "x", (theta_core, phi_left)),
            (flux_plus_1d_y, "y", (theta_core, phi_up)),
            (flux_minus_1d_y, "y", (theta_core, phi_down)),
        ]
        return flux_info
