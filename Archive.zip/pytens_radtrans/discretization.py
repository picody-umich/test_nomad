"""Setting up the discretizations of angles and space."""

from dataclasses import dataclass

import numpy as np
import pytens

from .load_config import Config
from .types import NDArrayF


@dataclass
class Indices:
    """Indices involved in the problem"""

    dimension: int
    space: pytens.Index
    theta: pytens.Index
    phi: pytens.Index

    @classmethod
    def from_config(cls, config: Config) -> "Indices":
        """Build indices from a configuration object.

        Args:
            config: The configuration object.

        Returns:
            A new Indices object.
        """
        n = np.prod(list(config.geometry.n))  # because cell centered
        pos = pytens.Index("x", n)
        theta = pytens.Index("theta", config.angles.n_theta)
        phi = pytens.Index("phi", config.angles.n_phi)
        out = cls(config.geometry.dimension, pos, theta, phi)
        return out

    def __repr__(self) -> str:
        out = f"Indices({self.dimension!r},{self.space!r}, {self.theta!r}, {self.phi})"
        return out

    def increase_space_index(self, num: int) -> "Indices":
        """Return a new Indices object with an increased spatial index size.

        Args:
            num: The number by which to increase the spatial index size.

        Returns:
            A new Indices object with the updated spatial index.
        """
        new_size = self.space.size + num
        return Indices(
            self.dimension, self.space.with_new_size(new_size), self.theta, self.phi
        )


@dataclass
class Grid:
    """Store geometry information about the spatial grid."""

    cell_centers: tuple[NDArrayF, ...]
    cell_edges: tuple[NDArrayF, ...]
    dx: tuple[float, ...]
    num_cells: tuple[int, ...]
    num_ghost: tuple[int, ...]  # number of ghost cells total for each dimension


@dataclass
class Discretization:  # pylint: disable=R0902
    """Discretization structure.

    Note on 2D Array Convention:
        Throughout this codebase, 2D spatial arrays are consistently handled
        with the shape `(nx, ny)`, where `nx` is the number of cells in the
        x-dimension and `ny` is the number of cells in the y-dimension. This
        corresponds to a column-major data layout, where the y-index is the
        fastest-varying index when flattening the array.
    """

    dimension: int
    grid: Grid

    def num_space(self) -> int:
        """Get the total number of grid points in the discretization."""
        return int(np.prod(self.grid.num_cells))

    def to_field(self, val: float | np.ndarray) -> np.ndarray:
        """Convert a scalar or array into a field quantity on the grid.

        If the input is a scalar, it creates an array of the grid's shape
        filled with that value. If the input is an array, it is returned
        unchanged.

        Args:
            val: The scalar or array to convert.

        Returns:
            A numpy array representing the value as a field on the grid.
        """
        if isinstance(val, float):
            if self.dimension == 1:
                return np.ones(self.grid.num_cells[0]) * val
            if self.dimension == 2:
                return np.ones((self.grid.num_cells[0], self.grid.num_cells[1])) * val
            raise NotImplementedError("Dimensions greater than 2.")
        # elif val.ndim == 1:
        #     return val[:xis]

        return val

    def add_ghost(self, val: np.ndarray) -> np.ndarray:
        """Add ghost cells to spatial dimensions of an array.

        Args:
            val: The array to pad with ghost cells. The first `self.dimension`
                axes are assumed to be spatial.

        Returns:
            A new array with ghost cells added to the spatial dimensions.
        """
        if val.ndim < self.dimension:
            raise ValueError(
                "Input must have at least the same number of dimensions as the grid."
            )

        pad_width = []
        for i in range(self.dimension):
            ghosts = int(self.grid.num_ghost[i] / 2)
            pad_width.append((ghosts, ghosts))

        for _ in range(val.ndim - self.dimension):
            pad_width.append((0, 0))

        return np.pad(val, pad_width)

    def update_ghost(  # pylint: disable=R0913
        self,
        val: np.ndarray,
        vals_left: NDArrayF | float,
        vals_right: NDArrayF | float,
        vals_bottom: NDArrayF | float,
        vals_top: NDArrayF | float,
    ) -> np.ndarray:
        """Fill in ghost cells at all edges of the domain.

        Args:
            val: The array with ghost cells to be updated.
            vals_left: Values to fill in the left ghost cells.
            vals_right: Values to fill in the right ghost cells.
            vals_bottom: Values to fill in the bottom ghost cells (for 2D).
            vals_top: Values to fill in the top ghost cells (for 2D).

        Returns:
            The array with updated ghost cell values.
        """
        if self.dimension == 2:
            # print("riht", vals_right.shape)
            # print("top ", vals_top.shape)
            # print("val", val.shape)

            ind1_s = int(self.grid.num_ghost[0] / 2)
            ind2_s = int(self.grid.num_ghost[1] / 2)
            # Direct assignment works for left/right due to simple broadcasting.
            val[:ind1_s, ind2_s:-ind2_s, :] = vals_left
            val[-ind1_s:, ind2_s:-ind2_s, :] = vals_right
            # A loop is more robust for bottom/top to handle scalars and arrays
            # without complex broadcasting.
            for ii in range(ind2_s):
                val[ind1_s:-ind1_s, ii, :] = vals_bottom
                val[ind1_s:-ind1_s, -(ii + 1), :] = vals_top
            # print("val after shape = ", val.shape)
        elif self.dimension == 1:
            ind1_s = int(self.grid.num_ghost[0] / 2)
            val[:ind1_s, :] = vals_left
            val[-ind1_s:, :] = vals_right
        return val

    def split(self) -> list["Discretization"]:
        """Split the discretization into subdomains.

        For 1D, splits into two equal subdomains.
        For 2D, splits into four equal subdomains (quadrants).

        Returns:
            A list of new Discretization objects representing the subdomains.
        """
        if self.dimension == 1:
            lb_left = self.grid.cell_edges[0][0]
            ub_right = self.grid.cell_edges[0][-1]
            mid = (lb_left + ub_right) / 2
            n = self.grid.num_cells[0]

            left = Discretization.from_geom(
                [lb_left], [mid], [n], [self.grid.num_ghost[0]]
            )
            right = Discretization.from_geom(
                [mid], [ub_right], [n], [self.grid.num_ghost[0]]
            )
            return [left, right]
        else:
            lb_left = self.grid.cell_edges[0][0]
            lb_down = self.grid.cell_edges[1][0]

            ub_right = self.grid.cell_edges[0][-1]
            ub_down = self.grid.cell_edges[1][-1]

            mid_lr = (lb_left + ub_right) / 2
            mid_ud = (lb_down + ub_down) / 2

            lower_left = Discretization.from_geom(
                [lb_left, lb_down],
                [mid_lr, mid_ud],
                list(self.grid.num_cells),
                list(self.grid.num_ghost),
            )
            upper_left = Discretization.from_geom(
                [lb_left, mid_ud],
                [mid_lr, ub_down],
                list(self.grid.num_cells),
                list(self.grid.num_ghost),
            )
            upper_right = Discretization.from_geom(
                [mid_lr, mid_ud],
                [ub_right, ub_down],
                list(self.grid.num_cells),
                list(self.grid.num_ghost),
            )
            lower_right = Discretization.from_geom(
                [mid_lr, lb_down],
                [ub_right, mid_ud],
                list(self.grid.num_cells),
                list(self.grid.num_ghost),
            )

            return [lower_left, upper_left, upper_right, lower_right]

    def shift(self, shift_vec: list[float]) -> "Discretization":
        """Return a new Discretization with shifted coordinates.

        Args:
            shift_vec: A vector specifying the shift amount for each dimension.

        Returns:
            A new Discretization object with translated coordinates.
        """
        if len(shift_vec) != self.dimension:
            raise ValueError("shift_vec must have the same length as the dimension.")

        new_lb = [
            self.grid.cell_edges[i][0] + shift_vec[i] for i in range(self.dimension)
        ]
        new_ub = [
            self.grid.cell_edges[i][-1] + shift_vec[i] for i in range(self.dimension)
        ]

        return Discretization.from_geom(
            new_lb, new_ub, list(self.grid.num_cells), list(self.grid.num_ghost)
        )

    @classmethod
    def from_geom(
        cls, lb: list[float], ub: list[float], n: list[int], num_ghost: list[int]
    ) -> "Discretization":  # pylint: disable=R0914
        """Build discretization from geometric parameters.

        Args:
            lb: Lower bounds for each dimension.
            ub: Upper bounds for each dimension.
            n: Number of cells in each dimension.
            num_ghost: Number of ghost cells for each dimension.

        Returns:
            A new Discretization object.
        """
        dimension = len(lb)
        cell_centers: list[NDArrayF] = []
        cell_edges: list[NDArrayF] = []
        dx: list[float] = []
        num_cells: list[int] = []
        for ii in range(dimension):
            grid_pts = np.linspace(lb[ii], ub[ii], n[ii] + 1)
            cell_edges.append(grid_pts)
            cell_centers.append((grid_pts[:-1] + grid_pts[1:]) / 2)  # uniform grid
            dx.append(grid_pts[1] - grid_pts[0])
            num_cells.append(n[ii])

        grid_obj = Grid(
            tuple(cell_centers),
            tuple(cell_edges),
            tuple(dx),
            tuple(num_cells),
            tuple(num_ghost),
        )

        return cls(dimension, grid_obj)

    @classmethod
    def from_config(cls, config: Config) -> "Discretization":  # pylint: disable=R0914
        """Build discretization from a configuration object.

        Args:
            config: The configuration object containing geometry info.

        Returns:
            A new Discretization object.
        """
        return cls.from_geom(
            config.geometry.lb,
            config.geometry.ub,
            config.geometry.n,
            config.geometry.n_ghost,
        )


@dataclass
class AngleDiscretization:
    theta: NDArrayF
    phi: NDArrayF
    delta_theta: NDArrayF
    delta_phi: NDArrayF

    @classmethod
    def from_config(cls, config: Config) -> "AngleDiscretization":  # pylint: disable=R0914
        """Build angular discretization from a configuration object.

        Args:
            config: The configuration object containing angle info.

        Returns:
            A new AngleDiscretization object.
        """
        uni = np.linspace(1.0, -1.0, config.angles.n_theta + 1)
        theta_edge = np.arccos(uni)

        term1 = theta_edge[1:] * np.cos(theta_edge[1:]) - theta_edge[:-1] * np.cos(
            theta_edge[:-1]
        )
        term2 = np.sin(theta_edge[1:]) - np.sin(theta_edge[:-1])
        num = term1 - term2
        den = np.cos(theta_edge[1:]) - np.cos(theta_edge[:-1])
        theta = num / den

        # solid angle
        # delta_theta = np.sin(theta) / theta.shape[0] * np.pi
        delta_theta = -(np.cos(theta_edge[1:]) - np.cos(theta_edge[:-1]))

        # theta_temp = np.linspace(0, np.pi, config.angles.n_theta + 1)
        phi_temp = np.linspace(0, 2 * np.pi, config.angles.n_phi + 1)
        phi = (phi_temp[1:] + phi_temp[:-1]) / 2.0
        delta_phi = np.ones(phi.shape[0]) / phi.shape[0] * 2 * np.pi

        return cls(theta, phi, delta_theta, delta_phi)
