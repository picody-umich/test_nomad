"""Module for monitoring simulation progress and handling I/O.

This module provides the `Monitor` class, which is responsible for tracking the
evolution of the solution over time. It handles:
- Storing the solution history (with memory management).
- Saving checkpoints for restart capability.
- Saving raw data files for post-processing.
- Generating in-situ plots of the solution and tensor compression statistics.
"""

import logging
import pathlib
import pickle

import matplotlib.pyplot as plt
import numpy as np
from matplotlib.figure import Figure
from mpi4py import MPI

from . import solver
from .domain_decomp import DomainManager
from .problems import Problem

comm = MPI.COMM_WORLD
# These globals are kept for backward compatibility or default values,
# but the class now prefers dependency injection.
global_rank = comm.Get_rank()
global_size = comm.Get_size()


class Monitor:
    """Monitors the simulation progress, saving data and plotting results.

    The Monitor class acts as the central hub for I/O operations during the
    time-stepping loop. It maintains a history of solution states (managing
    memory by pruning heavy data from older steps), computes auxiliary quantities
    like mean intensity on demand, and handles file output for checkpoints and
    visualization.

    Attributes:
        sol: A list of lists, where `sol[t]` contains the list of `Solution`
            objects for the local leaves at time step `t`.
        time: A list of simulation times corresponding to the steps in `sol`.
        ranks: A list of lists, storing the Tensor Train ranks of the solution
            tensors for analysis of compression efficiency.
        domain_manager: Reference to the `DomainManager` handling the grid.
        problem: Reference to the `Problem` definition.
        local_leaf_indices: List of global indices corresponding to the leaves
            owned by this MPI rank.
        rank: The MPI rank of the current process.
    """

    def __init__(
        self,
        domain_manager: DomainManager,
        problem: Problem,
        local_leaf_indices: list[int],
        rank: int | None = None,
    ) -> None:
        """Initialize the Monitor.

        Args:
            domain_manager: The manager for the domain decomposition.
            problem: The problem definition.
            local_leaf_indices: List of global indices for leaves on this rank.
            rank: The MPI rank of this process. Defaults to the global MPI rank.
        """
        # These are always locally stored variables
        self.sol: list[list[solver.Solution]] = []
        self.time: list[float] = []
        self.ranks: list[list[np.ndarray]] = []

        # These are always global
        self.domain_manager = domain_manager
        self.problem = problem

        self.local_leaf_indices = local_leaf_indices
        self.rank = rank if rank is not None else global_rank

    def update_topology(
        self, domain_manager: DomainManager, local_leaf_indices: list[int]
    ) -> None:
        """Updates the monitor with a new domain topology.

        Args:
            domain_manager: The new domain manager.
            local_leaf_indices: The new list of local leaf indices.
        """
        self.domain_manager = domain_manager
        self.local_leaf_indices = local_leaf_indices

    def get_last_sol(self) -> list[solver.Solution]:
        """Retrieves the solution objects for the most recent time step.

        Returns:
            A list of `solver.Solution` objects corresponding to the local
            leaves managed by this rank at the current simulation time.
        """
        return self.sol[-1]

    def del_prev_sol(self) -> None:
        """Prunes heavy data from older solutions to conserve memory.

        This method removes the dense `intensity` tensor networks and spatial
        arrays from the solution objects at index -2 (the step before the
        current one). This ensures that the simulation does not run out of
        memory while still keeping the solution metadata and structure alive
        for history tracking.
        """
        if len(self.sol) < 2:
            return
        for ii in range(len(self.sol[-2])):
            del self.sol[-2][ii].intensity
            del self.sol[-2][ii].space

    def add_solution(self, sol: list[solver.Solution], time: float) -> None:
        """Records a new solution step.

        This appends the current solution and time to the history and extracts
        tensor ranks for compression analysis.

        Args:
            sol: A list of `solver.Solution` objects representing the state
                of the local leaves at the current time step.
            time: The current simulation time.
        """
        self.sol.append(sol)
        self.time.append(time)
        self.add_ranks(sol)

    def add_ranks(self, sol: list[solver.Solution]) -> None:
        """Extracts and stores Tensor Train ranks for compression analysis.

        Args:
            sol: A list of `solver.Solution` objects from which to extract
                the ranks of the intensity tensor networks.
        """
        new_ranks = []
        for sol_item in sol:
            new_ranks.append(sol_item.intensity.ranks())
        self.ranks.append(new_ranks)

    def compute_aux_last_sol(self) -> None:
        """Computes derived quantities for the current solution state.

        This method calculates auxiliary data, such as the mean intensity
        (scalar flux), for the most recent solution if it has not already
        been computed. This is typically called before saving data or plotting.
        """
        # self.sol[-1] is now the list of solution objects for this rank
        latest_local_sol = self.sol[-1]
        for ii, _global_idx in enumerate(self.local_leaf_indices):
            # Get the i-th solution object for this rank
            sol_item = latest_local_sol[ii]
            if "mean_intensity" not in sol_item.aux:
                sol_item.aux["mean_intensity"] = solver.mean_intensity(
                    self.problem.indices,
                    self.domain_manager.domain_angles,
                    sol_item.intensity,
                )

    def save_checkpoint(self, save_dir: pathlib.Path, iteration: int) -> None:
        """Saves the current simulation state to disk for potential restart.

        This creates a `checkpoint_files` subdirectory within `save_dir`.
        Rank 0 saves the global `DomainManager` configuration. All ranks save
        their local solution objects as pickled files.

        Args:
            save_dir: The base directory where checkpoint files will be stored.
            iteration: The current time step iteration number, used in filenames.
        """
        latest_sol = self.sol[-1]
        time = self.time[-1]

        # Ensure directories exist
        (save_dir / "checkpoint_files").mkdir(parents=True, exist_ok=True)

        if self.rank == 0:
            with open(
                save_dir
                / "checkpoint_files"
                / f"checkpoint_{iteration}_domain_manager_{time:.2f}.pkl",
                "wb",
            ) as f:
                pickle.dump(self.domain_manager, f)

        # for kk, leaf in enumerate(self.domain_manager.leaves):
        for ii, global_idx in enumerate(self.local_leaf_indices):
            sol_item = latest_sol[ii]
            sol_item.save(
                save_dir
                / "checkpoint_files"
                / f"checkpoint_{iteration}_domain_{global_idx}_{time:.2f}.pkl"
            )

    def save_datafiles(self, save_dir: pathlib.Path, iteration: int) -> None:
        """Exports spatial fields and grid data to NumPy (.npz) files.

        This creates a `data_files` subdirectory. It saves the spatial variables
        (e.g., temperature, opacity) and the computed mean intensity for each
        local leaf. It also saves the discretization grid information.

        Args:
            save_dir: The base directory where data files will be stored.
            iteration: The current time step iteration number.
        """
        self.compute_aux_last_sol()
        latest_sol = self.sol[-1]

        # Ensure directories exist
        (save_dir / "data_files").mkdir(parents=True, exist_ok=True)

        for ii, global_idx in enumerate(self.local_leaf_indices):
            sol_item = latest_sol[ii]
            leaf = self.domain_manager.leaves[global_idx]
            np.savez(
                save_dir
                / "data_files"
                / f"space_vars_{iteration}_domain_{global_idx}_{sol_item.time:.2f}.npz",
                mean_intensity=sol_item.aux["mean_intensity"],
                **(sol_item.space if sol_item.space is not None else {}),
            )

            filename = (
                save_dir
                / "data_files"
                / (
                    f"discretization_{iteration}_domain_{global_idx}_"
                    f"{sol_item.time:.2f}.npz"
                )
            )
            np.savez(
                filename,
                cell_centers=leaf.disc.grid.cell_centers,
                cell_edges=leaf.disc.grid.cell_edges,
                dx=leaf.disc.grid.dx,
                num_cells=leaf.disc.grid.num_cells,
                num_ghost=leaf.disc.grid.num_ghost,
            )

    def plot_last_sol(
        self,
        global_plot_data: list,
        time: float,
        save_dir: pathlib.Path,
        iteration: int,
        fig_overlay: Figure | None = None,
    ) -> Figure | None:
        """Generates plots for the current simulation step.

        This method delegates the actual plotting logic to the `Problem` instance,
        allowing for problem-specific visualizations. It handles both per-step
        plots and cumulative overlay plots.

        Args:
            global_plot_data: A list of data gathered from all MPI ranks,
                typically containing spatial fields or reduced quantities.
            time: The current simulation time.
            save_dir: The directory where plot files (PDFs) will be saved.
            iteration: The current iteration number.
            fig_overlay: An optional matplotlib Figure object to draw on top of,
                used for creating time-evolution plots in a single frame.

        Returns:
            The matplotlib Figure object used for the overlay plot, or None if
            no overlay plot was generated.
        """
        # plot_data = [{'mean_intensity': mi} for mi in gathered_mean_intensities]

        fig_o = self.problem.plot_per_step_overlay(
            global_plot_data,
            self.domain_manager,
            time,
            iteration,
            fig=fig_overlay,
            save_filename=save_dir / ("overlay.pdf"),
        )

        self.problem.plot_per_step(
            global_plot_data,
            self.domain_manager,
            time,
            iteration,
            save_filename=save_dir / f"{iteration}_{time:2.6f}.pdf",
        )
        return fig_o

    def plot_ranks_compressions(
        self, global_ranks_history: list, filename: pathlib.Path, logger: logging.Logger
    ) -> Figure:
        """Visualizes the evolution of Tensor Train ranks and compression efficiency.

        This generates a figure with two subplots:
        1. **TT Ranks vs. Time**: Shows the mean and maximum tensor ranks
           aggregated across all domains over the simulation history.
        2. **Storage vs. Time**: Displays the Total Uncompressed Size and
           Total Compressed Size on a log scale, with Compression Ratio on a
           secondary axis.

        Args:
            global_ranks_history: A list of lists. `global_ranks_history[t]`
                contains a list of rank arrays for all domains present at time `t`.
            filename: The full path (including extension) where the plot image
                will be saved.
            logger: A logger instance to report saving status.

        Returns:
            The matplotlib Figure object containing the generated plots.
        """
        num_timesteps = len(global_ranks_history)
        if num_timesteps == 0:
            logger.warning("No rank history to plot.")
            return plt.figure()

        fig, axs = plt.subplots(1, 2, figsize=(12, 5))
        assert isinstance(axs, np.ndarray)

        # --- Plot 1: Aggregate Mean and Max Ranks Over Time ---
        global_mean_ranks = []
        global_max_ranks = []
        scatter_t = []
        scatter_r = []

        for t in range(num_timesteps):
            ranks_at_t = global_ranks_history[t]
            if not ranks_at_t:
                global_mean_ranks.append(0)
                global_max_ranks.append(0)
                continue

            all_ranks_flat = []
            for r_arr in ranks_at_t:
                all_ranks_flat.extend(r_arr)
                # Collect max rank per domain for scatter plot
                scatter_t.append(t)
                scatter_r.append(np.max(r_arr))

            if all_ranks_flat:
                global_mean_ranks.append(np.mean(all_ranks_flat))
                global_max_ranks.append(np.max(all_ranks_flat))
            else:
                global_mean_ranks.append(0)
                global_max_ranks.append(0)

        # Plot scatter of individual domain max ranks
        axs[0].scatter(
            scatter_t,
            scatter_r,
            s=10,
            color="gray",
            alpha=0.3,
            label="Individual Domains",
        )

        # Plot aggregate lines
        axs[0].plot(global_mean_ranks, "-", label="Global Mean Rank")
        axs[0].plot(global_max_ranks, "--", label="Global Max Rank")

        axs[0].set_xlabel("Time Step")
        axs[0].set_ylabel("Tensor Train Rank")
        axs[0].set_title("Aggregate TT Ranks vs. Time")
        axs[0].legend(fontsize="small")
        axs[0].grid(True, linestyle="--", alpha=0.6)

        # --- Plot 2: Storage Size and Compression Ratio ---
        # Get representative leaf size (Constant N assumption)
        if self.domain_manager.leaves:
            leaf0 = self.domain_manager.leaves[0]
            nspace = float(np.prod(leaf0.disc.grid.num_cells))
        else:
            nspace = 0.0

        ntheta = float(self.domain_manager.domain_angles.theta.shape[0])
        nphi = float(self.domain_manager.domain_angles.phi.shape[0])

        dim_map = {
            # `x` denotes the grouped spatial core used by TT operators.
            # It therefore matches the flattened spatial size, not nx only.
            "x": nspace,
            "theta": ntheta,
            "phi": nphi,
        }

        # Dimensions corresponding to the cores
        try:
            core_dims = [dim_map[k] for k in self.problem.config.solver.order]
        except KeyError as exc:
            raise ValueError(
                "Unsupported axis in solver.order for compression accounting. "
                "Supported axes are ['x', 'theta', 'phi']."
            ) from exc
        unknowns_per_leaf = nspace * ntheta * nphi

        storage_per_step = np.zeros(num_timesteps, dtype=float)
        uncompressed_per_step = np.zeros(num_timesteps, dtype=float)

        for t in range(num_timesteps):
            ranks_at_t = global_ranks_history[t]
            num_domains_at_t = len(ranks_at_t)
            uncompressed_per_step[t] = num_domains_at_t * unknowns_per_leaf

            storage_this_step = 0.0
            for rank_list in ranks_at_t:
                assert len(rank_list) + 1 == len(
                    core_dims
                ), "rank list not matching number of cores"
                if len(rank_list) == 2:
                    storage_this_step += (
                        rank_list[0] * core_dims[0]
                        + rank_list[0] * rank_list[1] * core_dims[1]
                        + rank_list[1] * core_dims[2]
                    )
                elif len(rank_list) == 3:
                    storage_this_step += (
                        rank_list[0] * core_dims[0]
                        + rank_list[0] * rank_list[1] * core_dims[1]
                        + rank_list[1] * core_dims[2] * rank_list[2]
                        + rank_list[2] * core_dims[3]
                    )
                else:
                    raise ValueError(
                        "Only 3 core and 4 core tensor trains are supported"
                        "for ranks computation"
                    )

            storage_per_step[t] = storage_this_step

        if np.all(storage_per_step == 0) and np.any(uncompressed_per_step > 0):
            logger.warning(
                "Compressed storage size is 0 for all steps, but uncompressed "
                "size is > 0. Check rank list structure."
            )

        # Avoid division by zero
        # If storage is 0 (e.g. no domains), ratio is 0.
        compression_ratio = np.zeros_like(storage_per_step)
        valid_mask = storage_per_step > 0
        compression_ratio[valid_mask] = (
            uncompressed_per_step[valid_mask] / storage_per_step[valid_mask]
        )

        # Primary Y-Axis: Compression Ratio
        color_ratio = "tab:blue"
        axs[1].set_xlabel("Time Step")
        axs[1].set_ylabel("Compression Ratio", color=color_ratio)

        if np.any(compression_ratio > 0):
            axs[1].semilogy(
                compression_ratio,
                "-",
                color=color_ratio,
                label="Compression Ratio",
                linewidth=1.5,
            )
        else:
            axs[1].plot(
                compression_ratio,
                "-",
                color=color_ratio,
                label="Compression Ratio",
                linewidth=1.5,
            )

        axs[1].tick_params(axis="y", labelcolor=color_ratio)
        axs[1].grid(True, linestyle="--", alpha=0.6)

        # Secondary Y-Axis: Storage Size (Log Scale)
        ax2 = axs[1].twinx()
        color_unc = "tab:orange"
        color_comp = "tab:green"
        ax2.set_ylabel("Total Storage (Parameters)", color="black")

        # Plot Uncompressed Size
        ax2.semilogy(
            uncompressed_per_step,
            "--",
            color=color_unc,
            label="Uncompressed (Total)",
            alpha=0.7,
        )
        # Plot Compressed Size
        # Mask zeros for log plot to avoid plotting issues
        mask_comp = storage_per_step > 0
        if np.any(mask_comp):
            ax2.semilogy(
                np.arange(num_timesteps)[mask_comp],
                storage_per_step[mask_comp],
                "-.",
                color=color_comp,
                label="Compressed (Total)",
                linewidth=1.5,
            )
        else:
            # Fallback if all zeros (e.g. empty history or error)
            ax2.plot(
                storage_per_step,
                "-.",
                color=color_comp,
                label="Compressed (Total)",
                linewidth=1.5,
            )

        ax2.tick_params(axis="y", labelcolor="black")

        axs[1].set_title("Storage & Compression vs. Time")

        # Combine legends
        lines1, labels1 = axs[1].get_legend_handles_labels()
        lines2, labels2 = ax2.get_legend_handles_labels()
        axs[1].legend(lines1 + lines2, labels1 + labels2, loc="best", fontsize="small")

        fig.tight_layout()
        plt.savefig(filename)
        logger.info(f"Saved rank and compression plot to {filename}")

        return fig
