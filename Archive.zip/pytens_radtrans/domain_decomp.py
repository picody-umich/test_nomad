"""Domain decomposition utilities.

This module provides classes and functions for decomposing the simulation domain
into a tree of subdomains, managing neighbor relationships, and handling the
overall domain configuration.

Note on Neighbor Finding:
    The current neighbor-finding and halo-exchange logic is designed for
    first-order, compact stencil numerical schemes. It correctly identifies
    face-adjacent domains, which is sufficient for these methods. If higher-order
    schemes with wider stencils are implemented in the future, this logic may
    need to be extended to find neighbors beyond the immediate face-sharing
    layer.
"""

import copy
import enum
import glob
import logging
import os
import pickle
from collections.abc import Callable
from dataclasses import dataclass
from typing import TYPE_CHECKING, Any, cast

import numpy as np
import pytens
from mpi4py import MPI

from . import bcs, utils
from .discretization import AngleDiscretization, Discretization, Indices
from .load_config import Config
from .types import Direction

if TYPE_CHECKING:
    from .problems import Problem


rank = MPI.COMM_WORLD.Get_rank()


def intervals_overlap(
    a0: float, a1: float, b0: float, b1: float, tol: float = 1e-13
) -> bool:
    """Check if two intervals [a0, a1] and [b0, b1] overlap.

    The check is exclusive at the endpoints, controlled by a tolerance.

    Args:
        a0: The lower bound of the first interval.
        a1: The upper bound of the first interval.
        b0: The lower bound of the second interval.
        b1: The upper bound of the second interval.
        tol: The tolerance for the overlap check.

    Returns:
        True if the intervals overlap, False otherwise.
    """
    return max(a0, b0) < min(a1, b1) - tol


def point_match(a: float, b: float, tol: float = 1e-13) -> bool:
    """Check if two floating-point numbers are equal within a tolerance.

    Args:
        a: The first number.
        b: The second number.
        tol: The tolerance for the comparison.

    Returns:
        True if the numbers are within the tolerance, False otherwise.
    """
    return abs(a - b) < tol


class NeighborRelationship(enum.Enum):
    """Enumeration for the geometric relationship between neighboring domains."""

    MATCHED = 1
    COARSE_TO_FINE = 2
    FINE_TO_COARSE = 3


@dataclass
class NeighborInfo:
    """Contains information about a single neighbor of a domain leaf.

    Attributes:
        neighbor: The index of the neighboring leaf. -1 indicates a boundary.
        direction: The direction of the neighbor relative to the leaf.
        disc: The discretization of the neighbor, or None for a boundary.
        relationship: The geometric grid relationship with the neighbor.
    """

    neighbor: int
    direction: Direction
    disc: Discretization | None
    relationship: NeighborRelationship | None

    def __str__(self) -> str:
        rel_str = ""
        if self.relationship:
            rel_str = f", relationship={self.relationship.name}"
        return f"neighbor={self.neighbor}, direction={self.direction}{rel_str}"


@dataclass
class LeafNeighbor:
    """Holds a list of all neighbors for a single domain leaf.

    Attributes:
        neighbors: A list of NeighborInfo objects detailing each neighbor.
    """

    neighbors: list[NeighborInfo]


@dataclass
class CommPlan:
    """Defines the communication plan between two leaves.

    This contains the pre-calculated information needed to transfer boundary
    data from a sender leaf to a receiver leaf's ghost cells. It supports
    matched, coarse-to-fine, and fine-to-coarse grid interfaces.

    Attributes:
        sender_leaf_idx: The global index of the leaf sending data.
        receiver_leaf_idx: The global index of the leaf receiving the data.
        sender_indices: Array of 1D indices into the flattened sender data
            array that specifies which cells to send.
        receiver_indices: Array of 1D indices into the flattened receiver ghost
            array that specifies where to place the received data. In the
            fine-to-coarse case, this array will contain duplicate indices.
        weights: Interpolation weights to be applied to the sender data. For
            fine-to-coarse, these are averaging weights (e.g., 1/N).
        num_sender_indices: The number of elements to be sent. This defines
            the size of the small, dense communication buffer.
    """

    sender_leaf_idx: int
    receiver_leaf_idx: int
    sender_indices: np.ndarray
    receiver_indices: np.ndarray
    weights: np.ndarray
    num_sender_indices: int
    flux_correction_plan: "FluxCorrectionPlan | None" = None


@dataclass
class FluxCorrectionPlan:
    """Stores static information for a flux correction at a coarse-fine interface.

    This plan is defined for a single pair of a coarse leaf and a fine leaf.

    Attributes:
        direction: The direction of the interface from the coarse perspective.
        temporary_fine_disc: A Discretization for the virtual 2-cell-wide
            grid used for high-fidelity flux calculation for this pair.
        coarse_cell_indices: The 1D flattened indices of the coarse cells
            at the interface that are adjacent to this specific fine neighbor.
        fine_face_indices_in_buffer: Indices into the F2C communication buffer
            that correspond to the fine cells directly at the interface.
    """

    direction: Direction
    temporary_fine_disc: Discretization
    coarse_cell_indices: np.ndarray
    fine_face_indices_in_buffer: np.ndarray


def create_pack_executor(plan: CommPlan) -> Callable[[np.ndarray], np.ndarray]:
    """Creates a function that extracts raw data from a sender's spatial core.

    This is the "pack" part of the "pack-send-reconstruct" communication
    pattern. The returned function takes a full spatial core array (e.g., from
    an opacity field or a solution tensor core) and uses the pre-computed
    `plan.sender_indices` to efficiently gather only the required boundary
    data into a small, dense NumPy array suitable for MPI transfer.

    Args:
        plan: The communication plan containing the sender indices.

    Returns:
        A function that takes a sender's spatial core array and returns a
        dense array of the data to be sent.
    """

    def pack_executor(sender_core: np.ndarray) -> np.ndarray:
        """Extracts data using pre-computed indices."""
        return cast(np.ndarray, sender_core[plan.sender_indices])

    return pack_executor


def create_reconstruct_executor(
    plan: CommPlan, receiver_flat_dim_with_ghosts: int
) -> Callable[[np.ndarray], np.ndarray]:
    """Creates a function that reconstructs a ghost cell contribution.

    This is the "reconstruct" part of the "pack-send-reconstruct" pattern.
    The returned function acts as the inverse to the `pack_executor`. It takes a
    small, dense buffer of raw data (as received via MPI) and reconstructs the
    large, sparse array representing the weighted contribution to the
    receiver's ghost cells.

    The process involves:
    1. Applying the pre-computed interpolation `plan.weights` to the buffer.
    2. Scattering the weighted data into a zero-filled array of the full
       receiver grid size using `plan.receiver_indices`.
    The use of `np.add.at` is crucial for the fine-to-coarse case, as it
    correctly handles summing contributions from multiple fine cells that map
    to the same coarse ghost cell index.

    Args:
        plan: The communication plan containing weights and receiver indices.
        receiver_flat_dim_with_ghosts: The flattened size of the receiver's
            spatial grid, including its ghost cells.

    Returns:
        A function that takes a dense buffer and returns the corresponding
        receiver's ghost cell data in a zero-filled array.
    """

    def reconstruct_executor(buffer: np.ndarray) -> np.ndarray:
        """Applies weights and scatters a dense buffer into a sparse core."""
        # buffer has shape (num_sender_indices, rank)
        rank = buffer.shape[1]

        # Create the zero-filled output array for the receiver's ghost data.
        output_core = np.zeros((receiver_flat_dim_with_ghosts, rank))

        # 1. Apply interpolation weights to the received buffer
        weighted_data = buffer * plan.weights[:, np.newaxis]

        # 2. Scatter (add) into the correct locations in the output core.
        # np.add.at correctly handles the summation for duplicate indices that
        # occur in the fine-to-coarse averaging case.
        np.add.at(output_core, plan.receiver_indices, weighted_data)

        return output_core

    return reconstruct_executor


def transfer_boundaries(
    func: Callable,
    indices_in: Indices,
    indices_out: Indices,
    permut: list[int],
    inv_permute: list[int],
) -> Callable:
    """Wraps a spatial function into a full tensor network operator.

    This utility takes a Python function (`func`) that operates on the spatial
    dimension of a tensor and wraps it into a `TTop` (Tensor Train Operator).
    The resulting callable, `run_op`, can be applied directly to a full solution
    `TensorNetwork`, transforming its spatial core while leaving the angular
    dimensions unchanged.

    This is used to create the tensor-based versions of the "pack" and
    "reconstruct" operators for the halo exchange.

    Args:
        func: The function to apply to the spatial core (e.g., a packer or
            reconstructor).
        indices_in: The `Indices` object describing the input tensor network.
        indices_out: The `Indices` object describing the output tensor network.
        permut: The permutation order for tensor dimensions.
        inv_permute: The inverse permutation order.

    Returns:
        A callable that takes a `TensorNetwork` and returns the transformed
        `TensorNetwork`.
    """

    # The function `f` is applied to the spatial core. The angular cores
    # are passed through with an identity function `lambda x: x`.
    fs = [func, lambda x: x, lambda x: x]
    fs_permuted = utils.reorder_list(fs, permut)

    ops = [
        [
            utils.apply_func_to_core(f, ii)  # type: ignore[arg-type]
            for ii, f in enumerate(fs_permuted)
        ]
    ]

    ind = utils.reorder_list(
        [indices_in.space, indices_in.theta, indices_in.phi], permut
    )
    ind_out = utils.reorder_list(
        [indices_out.space, indices_out.theta, indices_out.phi], permut
    )
    ind_out = [pytens.Index(f"{i.name}p", i.size) for i in ind_out]

    def run_op(tn: pytens.TensorNetwork) -> pytens.TensorNetwork:
        op = utils.TTop(tn, ind, ind_out, [tuple(ops[0])], 1.0)
        return op.evaluate()

    return run_op


class Tree:
    """A tree structure representing the spatial domain decomposition."""

    def __init__(self, discretization: Discretization, parent: "Tree | None") -> None:
        """Initialize a Tree node.

        Args:
            discretization: The discretization of the domain for this node.
            parent: The parent node in the tree, or None for the root.
        """
        self.disc = discretization
        self.parent = parent
        self.children: list[Tree] | None = None

    def split(self) -> list["Tree"]:
        """Split the current node's domain into children.

        Returns:
            A list of the newly created child Tree nodes.
        """
        self.children = [Tree(c, self) for c in self.disc.split()]
        return self.children

    @property
    def depth(self) -> int:
        """Return the depth of this node in the tree (Root is 0)."""
        d = 0
        node = self
        while node.parent:
            d += 1
            node = node.parent
        return d

    def merge(self) -> None:
        """Merge the children of this node back into the parent.

        This operation makes the current node a leaf node by removing its
        children.
        """
        self.children = None

    def split_recursive(self, levels: int) -> None:
        """Recursively split the tree by a number of levels.

        Args:
            levels: The number of levels to split.
        """
        if levels <= 0:
            return
        self.split()
        if self.children:
            for child in self.children:
                child.split_recursive(levels - 1)

    def split_on_list(self, lst: Any) -> "Tree":
        """Recursively split the tree based on a nested list specification.

        Args:
            lst: The nested list defining the split operations.

        Returns:
            The current Tree node after applying the splits.
        """
        if lst == 0:
            return self
        else:
            children = self.split()
            for ii in range(len(children)):
                children[ii].split_on_list(lst[1][ii])
        return self

    def get_leaves(self) -> list["Tree"]:
        """Recursively find all leaf nodes in the tree.

        Returns:
            A list of all leaf nodes that are descendants of the current node.
        """
        if self.children is None:
            return [self]

        leaves = []
        for child in self.children:
            leaves.extend(child.get_leaves())
        return leaves

    @staticmethod
    def _map_leaves_1d(
        leaves: list["Tree"], root: "Tree"
    ) -> list[tuple[LeafNeighbor, list[Direction]] | None]:
        """Helper to map neighbors for a 1D domain.

        Args:
            leaves: A list of all leaf nodes.
            root: The root of the domain tree.

        Returns:
            A list containing neighbor and boundary information for each leaf.
        """
        neighbors: list[tuple[LeafNeighbor, list[Direction]] | None] = [None] * len(
            leaves
        )
        neighbors_dict: dict[int, list[NeighborInfo]] = {
            i: [] for i in range(len(leaves))
        }
        boundary_dict: dict[int, list[Direction]] = {i: [] for i in range(len(leaves))}
        root_lb, root_ub = root.disc.grid.cell_edges[0][[0, -1]]

        # First, find all boundaries
        for ii, leaf in enumerate(leaves):
            lb, ub = leaf.disc.grid.cell_edges[0][[0, -1]]
            if point_match(ub, root_ub):
                neighbors_dict[ii].append(NeighborInfo(-1, Direction.EAST, None, None))
                boundary_dict[ii].append(Direction.EAST)
            if point_match(lb, root_lb):
                neighbors_dict[ii].append(NeighborInfo(-1, Direction.WEST, None, None))
                boundary_dict[ii].append(Direction.WEST)

        # Next, find all internal neighbors
        for ii, leaf1 in enumerate(leaves):
            for jj, leaf2 in enumerate(leaves):
                if ii == jj:
                    continue
                lb1, ub1 = leaf1.disc.grid.cell_edges[0][[0, -1]]
                lb2, ub2 = leaf2.disc.grid.cell_edges[0][[0, -1]]
                if point_match(ub1, lb2):
                    if np.isclose(leaf1.disc.grid.dx[0], leaf2.disc.grid.dx[0]):
                        rel = NeighborRelationship.MATCHED
                    elif leaf1.disc.grid.dx[0] > leaf2.disc.grid.dx[0]:
                        rel = NeighborRelationship.COARSE_TO_FINE
                    else:
                        rel = NeighborRelationship.FINE_TO_COARSE
                    neighbors_dict[ii].append(
                        NeighborInfo(jj, Direction.EAST, leaf2.disc, rel)
                    )
                if point_match(lb1, ub2):
                    if np.isclose(leaf1.disc.grid.dx[0], leaf2.disc.grid.dx[0]):
                        rel = NeighborRelationship.MATCHED
                    elif leaf1.disc.grid.dx[0] > leaf2.disc.grid.dx[0]:
                        rel = NeighborRelationship.COARSE_TO_FINE
                    else:
                        rel = NeighborRelationship.FINE_TO_COARSE
                    neighbors_dict[ii].append(
                        NeighborInfo(jj, Direction.WEST, leaf2.disc, rel)
                    )

        # Assemble the final results
        for ii, _ in enumerate(leaves):
            neighbors[ii] = (LeafNeighbor(neighbors_dict[ii]), boundary_dict[ii])
        return neighbors

    @staticmethod
    def _map_leaves_2d(
        leaves: list["Tree"], root: "Tree"
    ) -> list[tuple[LeafNeighbor, list[Direction]] | None]:
        """Helper to map neighbors for a 2D domain.

        Args:
            leaves: A list of all leaf nodes.
            root: The root of the domain tree.

        Returns:
            A list containing neighbor and boundary information for each leaf.
        """
        neighbors: list[tuple[LeafNeighbor, list[Direction]] | None] = [None] * len(
            leaves
        )
        neighbors_dict: dict[int, list[NeighborInfo]] = {
            i: [] for i in range(len(leaves))
        }
        boundary_dict: dict[int, list[Direction]] = {i: [] for i in range(len(leaves))}

        root_lb_x, root_ub_x = root.disc.grid.cell_edges[0][[0, -1]]
        root_lb_y, root_ub_y = root.disc.grid.cell_edges[1][[0, -1]]

        for ii, leaf in enumerate(leaves):
            lb_x, ub_x = leaf.disc.grid.cell_edges[0][[0, -1]]
            lb_y, ub_y = leaf.disc.grid.cell_edges[1][[0, -1]]

            if point_match(ub_x, root_ub_x):
                neighbors_dict[ii].append(NeighborInfo(-1, Direction.EAST, None, None))
                boundary_dict[ii].append(Direction.EAST)
            if point_match(lb_x, root_lb_x):
                neighbors_dict[ii].append(NeighborInfo(-1, Direction.WEST, None, None))
                boundary_dict[ii].append(Direction.WEST)
            if point_match(ub_y, root_ub_y):
                neighbors_dict[ii].append(NeighborInfo(-1, Direction.NORTH, None, None))
                boundary_dict[ii].append(Direction.NORTH)
            if point_match(lb_y, root_lb_y):
                neighbors_dict[ii].append(NeighborInfo(-1, Direction.SOUTH, None, None))
                boundary_dict[ii].append(Direction.SOUTH)

        for ii, leaf1 in enumerate(leaves):
            for jj, leaf2 in enumerate(leaves):
                if ii == jj:
                    continue
                l1_lb_x, l1_ub_x = leaf1.disc.grid.cell_edges[0][[0, -1]]
                l1_lb_y, l1_ub_y = leaf1.disc.grid.cell_edges[1][[0, -1]]
                l2_lb_x, l2_ub_x = leaf2.disc.grid.cell_edges[0][[0, -1]]
                l2_lb_y, l2_ub_y = leaf2.disc.grid.cell_edges[1][[0, -1]]

                y_overlap = intervals_overlap(l1_lb_y, l1_ub_y, l2_lb_y, l2_ub_y)
                x_overlap = intervals_overlap(l1_lb_x, l1_ub_x, l2_lb_x, l2_ub_x)

                if point_match(l1_ub_x, l2_lb_x) and y_overlap:
                    if np.isclose(leaf1.disc.grid.dx[1], leaf2.disc.grid.dx[1]):
                        rel = NeighborRelationship.MATCHED
                    elif leaf1.disc.grid.dx[1] > leaf2.disc.grid.dx[1]:
                        rel = NeighborRelationship.COARSE_TO_FINE
                    else:
                        rel = NeighborRelationship.FINE_TO_COARSE
                    neighbors_dict[ii].append(
                        NeighborInfo(jj, Direction.EAST, leaf2.disc, rel)
                    )
                if point_match(l1_lb_x, l2_ub_x) and y_overlap:
                    if np.isclose(leaf1.disc.grid.dx[1], leaf2.disc.grid.dx[1]):
                        rel = NeighborRelationship.MATCHED
                    elif leaf1.disc.grid.dx[1] > leaf2.disc.grid.dx[1]:
                        rel = NeighborRelationship.COARSE_TO_FINE
                    else:
                        rel = NeighborRelationship.FINE_TO_COARSE
                    neighbors_dict[ii].append(
                        NeighborInfo(jj, Direction.WEST, leaf2.disc, rel)
                    )
                if point_match(l1_ub_y, l2_lb_y) and x_overlap:
                    if np.isclose(leaf1.disc.grid.dx[0], leaf2.disc.grid.dx[0]):
                        rel = NeighborRelationship.MATCHED
                    elif leaf1.disc.grid.dx[0] > leaf2.disc.grid.dx[0]:
                        rel = NeighborRelationship.COARSE_TO_FINE
                    else:
                        rel = NeighborRelationship.FINE_TO_COARSE
                    neighbors_dict[ii].append(
                        NeighborInfo(jj, Direction.NORTH, leaf2.disc, rel)
                    )
                if point_match(l1_lb_y, l2_ub_y) and x_overlap:
                    if np.isclose(leaf1.disc.grid.dx[0], leaf2.disc.grid.dx[0]):
                        rel = NeighborRelationship.MATCHED
                    elif leaf1.disc.grid.dx[0] > leaf2.disc.grid.dx[0]:
                        rel = NeighborRelationship.COARSE_TO_FINE
                    else:
                        rel = NeighborRelationship.FINE_TO_COARSE
                    neighbors_dict[ii].append(
                        NeighborInfo(jj, Direction.SOUTH, leaf2.disc, rel)
                    )

        for ii, _ in enumerate(leaves):
            neighbors[ii] = (LeafNeighbor(neighbors_dict[ii]), boundary_dict[ii])
        return neighbors

    @staticmethod
    def map_leaves(
        leaves: list["Tree"], root: "Tree"
    ) -> list[tuple[LeafNeighbor, list[Direction]] | None]:
        """Get a mapping between leaves.

        Note: This is a slow O(N^2) algorithm and could be improved
        by searching the tree structure.

        Args:
            leaves: A list of all leaf nodes in the tree.
            root: The root node of the tree.

        Returns:
            A list where each element corresponds to a leaf, containing its
            neighbor information and a list of its boundary directions.
        """
        dim = leaves[0].disc.dimension
        if dim == 1:
            return Tree._map_leaves_1d(leaves, root)
        return Tree._map_leaves_2d(leaves, root)


def print_leaf_neighbor_map(
    leaf_neighbor_map: dict[int, tuple[LeafNeighbor, list[Direction]]],
) -> None:
    """A debugging utility to print the neighbor map for all leaves.

    Args:
        leaf_neighbor_map: The neighbor map to print.
    """
    for leaf, (leaf_neighbors, boundary_dirs) in leaf_neighbor_map.items():
        print(f"Leaf {leaf}:")
        for neighbor in leaf_neighbors.neighbors:
            if neighbor.neighbor >= 0:
                print(
                    f"  Neighbor: {neighbor.neighbor} "
                    f"Direction: {neighbor.direction.name}"
                )
            else:
                print(f"  Boundary in Direction: {neighbor.direction.name}")
        # Optionally, also print which directions are boundaries
        print(f"  Boundaries: {[b.name for b in boundary_dirs]}")
        print()


class DomainManager:
    """Manages the decomposed domain, including leaves and neighbor info."""

    def __init__(
        self,
        domain_tree: Tree,
        leaves: list[Tree],
        leaf_neighbor_map: list[tuple[LeafNeighbor, list[Direction]] | None],
        domain_angles: AngleDiscretization,
    ) -> None:
        """Initialize the DomainManager.

        Args:
            domain_tree: The root of the domain decomposition tree.
            leaves: A list of all leaf nodes in the tree.
            leaf_neighbor_map: A mapping of neighbors for each leaf.
            domain_angles: The angular discretization for the domain.
        """
        self.domain_tree = domain_tree
        self.leaves = leaves
        self.leaf_neighbor_map = leaf_neighbor_map
        self.domain_angles = domain_angles
        # Comm plans are built in from_config after periodic connections are added
        self.comm_plans: list[CommPlan] = []

    def _build_communication_plans(
        self,
    ) -> list[CommPlan]:
        """Pre-calculate communication plans.

        This method iterates through all leaf-neighbor pairs to generate:
        `CommPlan` objects for all internal interfaces for halo exchange. For
        fine-to-coarse interfaces, these plans will also contain a
        `FluxCorrectionPlan`.
        """
        comm_plans = []

        for sender_idx, map_item in enumerate(self.leaf_neighbor_map):
            if map_item is None:
                continue
            neighbor_info, _ = map_item
            for neighbor in neighbor_info.neighbors:
                if neighbor.neighbor == -1:
                    continue  # Skip physical boundaries

                plan = self._create_plan_for_neighbor(sender_idx, neighbor)
                if plan:
                    comm_plans.append(plan)

        return comm_plans

    def _create_plan_for_neighbor(
        self, sender_idx: int, neighbor: NeighborInfo
    ) -> CommPlan | None:
        """Create a single CommPlan for a specific neighbor relationship.

        This is a dispatcher method that calls the appropriate plan creation
        function based on the domain's dimension.

        Args:
            sender_idx: The global index of the leaf sending data.
            neighbor: The `NeighborInfo` object for the receiving leaf.

        Returns:
            A `CommPlan` object if a plan is created, or None.
        """
        dim = self.dimension()
        if dim == 1:
            return self._create_plan_1d(sender_idx, neighbor)
        if dim == 2:
            return self._create_plan_2d(sender_idx, neighbor)
        raise NotImplementedError("Only 1D and 2D domains are supported.")

    def _create_plan_2d(
        self, sender_idx: int, neighbor: NeighborInfo
    ) -> CommPlan | None:
        """Create a CommPlan for a 2D neighbor interface.

        This handles the geometric calculations for transferring boundary data
        between two 2D leaves. It supports three types of grid relationships:

        - `MATCHED`: A direct 1-to-1 copy of values from sender boundary
          cells to receiver ghost cells in their overlapping region.
        - `COARSE_TO_FINE`: A nearest-neighbor fill where each fine-grid
          receiver ghost cell takes its value from the coarse-grid sender
          cell that contains it.
        - `FINE_TO_COARSE`: An averaging process where each coarse-grid
          receiver ghost cell's value is the mean of all fine-grid sender
          cells whose centers are located within the coarse cell's boundaries.

        Args:
            sender_idx: The global index of the leaf sending data.
            neighbor: The `NeighborInfo` object for the receiving leaf.

        Returns:
            A `CommPlan` object if a plan is created, or None.
        """
        sender_leaf = self.leaves[sender_idx]
        receiver_idx = neighbor.neighbor
        receiver_leaf = self.leaves[receiver_idx]

        sender_disc = sender_leaf.disc
        receiver_disc = receiver_leaf.disc

        # --- Virtual shift for periodic BCs ---
        is_periodic = False
        if neighbor.direction == Direction.EAST and not point_match(
            sender_disc.grid.cell_edges[0][-1], receiver_disc.grid.cell_edges[0][0]
        ):
            is_periodic = True
        elif neighbor.direction == Direction.WEST and not point_match(
            sender_disc.grid.cell_edges[0][0], receiver_disc.grid.cell_edges[0][-1]
        ):
            is_periodic = True
        elif neighbor.direction == Direction.NORTH and not point_match(
            sender_disc.grid.cell_edges[1][-1], receiver_disc.grid.cell_edges[1][0]
        ):
            is_periodic = True
        elif neighbor.direction == Direction.SOUTH and not point_match(
            sender_disc.grid.cell_edges[1][0], receiver_disc.grid.cell_edges[1][-1]
        ):
            is_periodic = True

        if is_periodic:
            shift_vec = [0.0] * self.dimension()
            if neighbor.direction == Direction.EAST:
                shift_vec[0] = -(self.ub_x() - self.lb_x())
            elif neighbor.direction == Direction.WEST:
                shift_vec[0] = self.ub_x() - self.lb_x()
            elif neighbor.direction == Direction.NORTH:
                shift_vec[1] = -(self.ub_y() - self.lb_y())
            elif neighbor.direction == Direction.SOUTH:
                shift_vec[1] = self.ub_y() - self.lb_y()
            sender_disc = sender_disc.shift(shift_vec)

        # Determine primary (p) and transverse (t) axes for communication
        if neighbor.direction in [Direction.EAST, Direction.WEST]:
            p_ax, t_ax = 0, 1
        elif neighbor.direction in [Direction.NORTH, Direction.SOUTH]:
            p_ax, t_ax = 1, 0
        else:
            return None

        sender_indices: list[int] = []
        receiver_indices: list[int] = []
        weights: list[float] = []
        flux_plan: FluxCorrectionPlan | None = None

        if neighbor.relationship == NeighborRelationship.MATCHED:
            # Find overlap in the transverse dimension
            sender_edges_t = sender_disc.grid.cell_edges[t_ax]
            receiver_centers_t = receiver_disc.grid.cell_centers[t_ax]
            tol = 1e-13
            overlap_mask = (receiver_centers_t >= sender_edges_t[0] - tol) & (
                receiver_centers_t < sender_edges_t[-1] + tol
            )
            receiver_overlap_indices_t = np.where(overlap_mask)[0]
            if receiver_overlap_indices_t.size == 0:
                return None

            # Get sender indices in the primary dimension (boundary cells)
            sender_n_cells_p = sender_disc.grid.num_cells[p_ax]
            receiver_n_ghost_p = receiver_disc.grid.num_ghost[p_ax] // 2
            if neighbor.direction in [Direction.EAST, Direction.NORTH]:
                sender_indices_p = np.arange(
                    sender_n_cells_p - receiver_n_ghost_p, sender_n_cells_p
                )
            else:
                sender_indices_p = np.arange(receiver_n_ghost_p)

            # Create 2D index grids for sender (column-major: x*ny + y)
            sender_ny = sender_disc.grid.num_cells[1]
            if p_ax == 0:  # EAST/WEST: p=x, t=y
                x_coords = sender_indices_p
                y_coords = receiver_overlap_indices_t
            else:  # NORTH/SOUTH: p=y, t=x
                x_coords = receiver_overlap_indices_t
                y_coords = sender_indices_p
            s_x_idx, s_y_idx = np.meshgrid(x_coords, y_coords)
            sender_flat_indices = (s_x_idx * sender_ny + s_y_idx).flatten(order="C")
            sender_indices.extend(sender_flat_indices)

            # Get receiver indices
            rec_n_cells = receiver_leaf.disc.grid.num_cells
            rec_n_ghost = receiver_leaf.disc.grid.num_ghost
            rec_ghost_x = rec_n_ghost[0] // 2
            rec_ghost_y = rec_n_ghost[1] // 2
            rec_nx_full = rec_n_cells[0] + rec_n_ghost[0]
            rec_ny_full = rec_n_cells[1] + rec_n_ghost[1]
            rec_ny_full = rec_n_cells[1] + rec_n_ghost[1]

            if neighbor.direction == Direction.EAST:  # Receiver ghost is left
                x_coords_r = np.arange(rec_ghost_x)
                y_coords_r = receiver_overlap_indices_t + rec_ghost_y
            elif neighbor.direction == Direction.WEST:  # Receiver ghost is right
                x_coords_r = np.arange(rec_n_cells[0] + rec_ghost_x, rec_nx_full)
                y_coords_r = receiver_overlap_indices_t + rec_ghost_y
            elif neighbor.direction == Direction.NORTH:  # Receiver ghost is bottom
                y_coords_r = np.arange(rec_ghost_y)
                x_coords_r = receiver_overlap_indices_t + rec_ghost_x
            else:  # SOUTH: Receiver ghost is top
                y_coords_r = np.arange(
                    rec_n_cells[1] + rec_ghost_y, rec_n_cells[1] + rec_n_ghost[1]
                )
                x_coords_r = receiver_overlap_indices_t + rec_ghost_x

            # Create 2D index grids for receiver (column-major: x*ny + y)
            r_x_idx, r_y_idx = np.meshgrid(x_coords_r, y_coords_r)
            receiver_flat_indices = (r_x_idx * rec_ny_full + r_y_idx).flatten(order="C")
            receiver_indices.extend(receiver_flat_indices)
            weights.extend(np.ones(sender_flat_indices.size, dtype=float))

        elif neighbor.relationship == NeighborRelationship.COARSE_TO_FINE:
            # --- Coarse-to-Fine: Nearest Neighbor Interpolation ---
            # Each fine receiver ghost cell finds the coarse sender cell that
            # contains its center point and takes its value directly.

            # Get sender grid info
            sender_edges_p = sender_disc.grid.cell_edges[p_ax]
            sender_edges_t = sender_disc.grid.cell_edges[t_ax]

            # Calculate receiver's ghost cell centers in 2D
            rec_n_ghost_p = receiver_leaf.disc.grid.num_ghost[p_ax] // 2
            rec_dx_p = receiver_leaf.disc.grid.dx[p_ax]
            if neighbor.direction in [Direction.EAST, Direction.NORTH]:
                offset_p = np.arange(rec_n_ghost_p, 0, -1)
                rec_ghost_centers_p = (
                    receiver_leaf.disc.grid.cell_centers[p_ax][0] - offset_p * rec_dx_p
                )
            else:
                offset_p = np.arange(1, rec_n_ghost_p + 1)
                rec_ghost_centers_p = (
                    receiver_leaf.disc.grid.cell_centers[p_ax][-1] + offset_p * rec_dx_p
                )

            rec_centers_t = receiver_leaf.disc.grid.cell_centers[t_ax]
            tol = 1e-13
            overlap_mask_t = (rec_centers_t >= sender_edges_t[0] - tol) & (
                rec_centers_t < sender_edges_t[-1] + tol
            )
            rec_overlap_indices_t = np.where(overlap_mask_t)[0]
            rec_overlap_centers_t = rec_centers_t[rec_overlap_indices_t]

            if p_ax == 0:  # East-West: p=x, t=y
                rec_coords_p, rec_coords_t = np.meshgrid(
                    rec_ghost_centers_p, rec_overlap_centers_t
                )
            else:  # North-South: p=y, t=x
                rec_coords_t, rec_coords_p = np.meshgrid(
                    rec_overlap_centers_t, rec_ghost_centers_p
                )

            # Find containing sender cell for each fine ghost cell
            sender_indices_p = (
                np.searchsorted(sender_edges_p, rec_coords_p, side="right") - 1
            )
            sender_indices_t = (
                np.searchsorted(sender_edges_t, rec_coords_t, side="right") - 1
            )
            # Clip indices to ensure they are within the valid sender cell range,
            # mirroring the robust implementation in the 1D case.
            sender_indices_p = np.clip(
                sender_indices_p, 0, sender_disc.grid.num_cells[p_ax] - 1
            )
            sender_indices_t = np.clip(
                sender_indices_t, 0, sender_disc.grid.num_cells[t_ax] - 1
            )
            s_x_idx, s_y_idx = (
                (sender_indices_p, sender_indices_t)
                if p_ax == 0
                else (sender_indices_t, sender_indices_p)
            )
            sender_ny = sender_disc.grid.num_cells[1]
            sender_flat_indices = (s_x_idx * sender_ny + s_y_idx).flatten(order="C")

            # Calculate receiver flat indices
            rec_n_cells = receiver_leaf.disc.grid.num_cells
            rec_n_ghost = receiver_leaf.disc.grid.num_ghost
            rec_ghost_x = rec_n_ghost[0] // 2
            rec_ghost_y = rec_n_ghost[1] // 2
            rec_nx_full = rec_n_cells[0] + rec_n_ghost[0]
            rec_ny_full = rec_n_cells[1] + rec_n_ghost[1]

            if neighbor.direction == Direction.EAST:
                x_coords_r = np.arange(rec_ghost_x)
                y_coords_r = rec_overlap_indices_t + rec_ghost_y
                r_x, r_y = np.meshgrid(x_coords_r, y_coords_r)
            elif neighbor.direction == Direction.WEST:
                x_coords_r = np.arange(rec_n_cells[0] + rec_ghost_x, rec_nx_full)
                y_coords_r = rec_overlap_indices_t + rec_ghost_y
                r_x, r_y = np.meshgrid(x_coords_r, y_coords_r)
            elif neighbor.direction == Direction.NORTH:
                y_coords_r = np.arange(rec_ghost_y)
                x_coords_r = rec_overlap_indices_t + rec_ghost_x
                r_x, r_y = np.meshgrid(x_coords_r, y_coords_r)
            else:  # SOUTH
                y_coords_r = np.arange(
                    rec_n_cells[1] + rec_ghost_y, rec_n_cells[1] + rec_n_ghost[1]
                )
                x_coords_r = rec_overlap_indices_t + rec_ghost_x
                r_x, r_y = np.meshgrid(x_coords_r, y_coords_r)
            receiver_flat_indices = (r_x * rec_ny_full + r_y).flatten(order="C")

            sender_indices.extend(sender_flat_indices)
            receiver_indices.extend(receiver_flat_indices)
            weights.extend(np.ones_like(sender_flat_indices, dtype=float))

        elif neighbor.relationship == NeighborRelationship.FINE_TO_COARSE:
            # --- Fine-to-Coarse: Averaging ---
            # For each coarse receiver ghost cell, we find all fine sender cell
            # centers that lie within its boundaries. The ghost cell's value
            # becomes the average of these fine cell values.

            sender_centers_x = sender_disc.grid.cell_centers[0]
            sender_centers_y = sender_disc.grid.cell_centers[1]
            sender_ny = sender_disc.grid.num_cells[1]

            # Calculate receiver ghost cell edges and indices
            rec_n_cells = receiver_leaf.disc.grid.num_cells
            rec_n_ghost = receiver_leaf.disc.grid.num_ghost
            rec_nx_full = rec_n_cells[0] + rec_n_ghost[0]
            rec_ny_full = rec_n_cells[1] + rec_n_ghost[1]
            rec_dx = receiver_leaf.disc.grid.dx
            rec_edges = receiver_leaf.disc.grid.cell_edges

            rec_n_ghost_p = rec_n_ghost[p_ax] // 2
            if neighbor.direction in [Direction.EAST, Direction.NORTH]:
                offset_p = np.arange(rec_n_ghost_p, 0, -1)
                lower_p = rec_edges[p_ax][0] - offset_p * rec_dx[p_ax]
                upper_p = rec_edges[p_ax][0] - (offset_p - 1) * rec_dx[p_ax]
                rec_indices_p = np.arange(rec_n_ghost_p)
            else:
                offset_p = np.arange(1, rec_n_ghost_p + 1)
                lower_p = rec_edges[p_ax][-1] + (offset_p - 1) * rec_dx[p_ax]
                upper_p = rec_edges[p_ax][-1] + offset_p * rec_dx[p_ax]
                rec_indices_p = np.arange(
                    rec_n_cells[p_ax] + rec_n_ghost_p,
                    rec_n_cells[p_ax] + 2 * rec_n_ghost_p,
                )
            lower_t = rec_edges[t_ax][:-1]
            upper_t = rec_edges[t_ax][1:]
            rec_indices_t = np.arange(
                rec_n_ghost[t_ax] // 2, rec_n_cells[t_ax] + rec_n_ghost[t_ax] // 2
            )

            # Loop over each coarse receiver ghost cell
            for i_p, rec_idx_p in enumerate(rec_indices_p):
                for i_t, rec_idx_t in enumerate(rec_indices_t):
                    # Find fine sender cells within coarse ghost cell boundaries
                    lower_x = lower_p[i_p] if p_ax == 0 else lower_t[i_t]
                    upper_x = upper_p[i_p] if p_ax == 0 else upper_t[i_t]
                    tol = 1e-13
                    mask_x = (sender_centers_x >= lower_x - tol) & (
                        sender_centers_x < upper_x + tol
                    )
                    lower_y = lower_t[i_t] if p_ax == 0 else lower_p[i_p]
                    upper_y = upper_t[i_t] if p_ax == 0 else upper_p[i_p]
                    mask_y = (sender_centers_y >= lower_y - tol) & (
                        sender_centers_y < upper_y + tol
                    )
                    fine_indices_x = np.where(mask_x)[0]
                    fine_indices_y = np.where(mask_y)[0]

                    if fine_indices_x.size > 0 and fine_indices_y.size > 0:
                        num_fine = fine_indices_x.size * fine_indices_y.size
                        s_x, s_y = np.meshgrid(fine_indices_x, fine_indices_y)
                        s_flat = (s_x * sender_ny + s_y).flatten(order="C")
                        sender_indices.extend(s_flat)

                        r_x, r_y = (
                            (rec_idx_p, rec_idx_t)
                            if p_ax == 0
                            else (rec_idx_t, rec_idx_p)
                        )
                        r_flat = r_x * rec_ny_full + r_y
                        receiver_indices.extend([r_flat] * num_fine)
                        weights.extend([1.0 / num_fine] * num_fine)
            if sender_indices:
                s_indices_for_flux = np.array(sender_indices, dtype=int)
                coarse_leaf = receiver_leaf
                fine_leaf = sender_leaf
                # The direction of the interface from the coarse cell's perspective
                # is the direction TO the fine cell. Look this up directly from the
                # coarse cell's neighbor map to be robust.
                receiver_map_item = self.leaf_neighbor_map[receiver_idx]
                assert receiver_map_item is not None
                coarse_neighbor_info = next(
                    n
                    for n in receiver_map_item[0].neighbors
                    if n.neighbor == sender_idx
                )
                direction = coarse_neighbor_info.direction

                # 1. For each fine cell on the interface, find the index of the
                #    corresponding coarse cell. This creates an array of coarse
                #    indices that is the same size as the number of fine cells
                #    on the interface, suitable for a nearest-neighbor fill.

                # Find the centers of the fine cells along the interface.
                fine_centers_t = fine_leaf.disc.grid.cell_centers[t_ax]
                coarse_edges_t = coarse_leaf.disc.grid.cell_edges[t_ax]
                coarse_min_t, coarse_max_t = coarse_edges_t[0], coarse_edges_t[-1]
                tol = 1e-13
                fine_overlap_mask_t = (fine_centers_t >= coarse_min_t - tol) & (
                    fine_centers_t < coarse_max_t + tol
                )
                fine_overlap_centers_t = fine_centers_t[fine_overlap_mask_t]

                # Map each fine center to a coarse cell index in the transverse dim.
                coarse_indices_t = (
                    np.searchsorted(
                        coarse_leaf.disc.grid.cell_edges[t_ax],
                        fine_overlap_centers_t,
                        side="right",
                    )
                    - 1
                )
                coarse_indices_t = np.clip(
                    coarse_indices_t,
                    0,
                    coarse_leaf.disc.grid.num_cells[t_ax] - 1,
                )

                # Get the single coarse cell index in the primary dimension.
                cnx, cny = coarse_leaf.disc.grid.num_cells

                if p_ax == 0:  # East/West
                    coarse_idx_p = cnx - 1 if direction == Direction.EAST else 0
                    coarse_x_indices = np.repeat(
                        coarse_idx_p, len(fine_overlap_centers_t)
                    )
                    # coarse_indices_t is already mapped to the fine grid size
                    overlapped_coarse_indices = (
                        coarse_x_indices * cny + coarse_indices_t
                    )
                else:  # North/South
                    coarse_idx_p = cny - 1 if direction == Direction.NORTH else 0
                    coarse_y_indices = np.repeat(
                        coarse_idx_p, len(fine_overlap_centers_t)
                    )
                    # coarse_indices_t is already mapped to the fine grid size
                    overlapped_coarse_indices = (
                        coarse_indices_t * cny + coarse_y_indices
                    )

                # 2. Calculate the temporary_fine_disc for this specific fine_leaf.
                fine_edges_t = fine_leaf.disc.grid.cell_edges[t_ax]
                fine_min_t, fine_max_t = fine_edges_t[0], fine_edges_t[-1]
                fine_dx = fine_leaf.disc.grid.dx
                coarse_edge = (
                    coarse_leaf.disc.grid.cell_edges[p_ax][-1]
                    if direction in [Direction.EAST, Direction.NORTH]
                    else coarse_leaf.disc.grid.cell_edges[p_ax][0]
                )

                dim = self.dimension()
                lb, ub, n = [0.0] * dim, [0.0] * dim, [0] * dim
                n[p_ax] = 2
                lb[p_ax] = coarse_edge - fine_dx[p_ax]
                ub[p_ax] = coarse_edge + fine_dx[p_ax]
                lb[t_ax], ub[t_ax] = fine_min_t, fine_max_t
                n[t_ax] = fine_leaf.disc.grid.num_cells[t_ax]

                temp_disc = Discretization.from_geom(lb, ub, n, [0] * self.dimension())

                # 3. Find which indices in the comm buffer correspond to face cells.
                buffer_to_fine_grid_map = s_indices_for_flux

                fine_interface_direction = neighbor.direction
                fnx, fny = fine_leaf.disc.grid.num_cells
                if fine_interface_direction == Direction.EAST:
                    fine_face_indices = (fnx - 1) * fny + np.arange(fny)
                elif fine_interface_direction == Direction.WEST:
                    fine_face_indices = np.arange(fny)
                elif fine_interface_direction == Direction.NORTH:
                    fine_face_indices = np.arange(fnx) * fny + (fny - 1)
                else:  # SOUTH
                    fine_face_indices = np.arange(fnx) * fny

                is_face_cell = np.isin(buffer_to_fine_grid_map, fine_face_indices)
                fine_face_indices_in_buffer = np.where(is_face_cell)[0]

                flux_plan = FluxCorrectionPlan(
                    direction=direction,
                    temporary_fine_disc=temp_disc,
                    coarse_cell_indices=overlapped_coarse_indices,
                    fine_face_indices_in_buffer=fine_face_indices_in_buffer,
                )

        if not sender_indices:
            return None

        s_indices = np.array(sender_indices, dtype=int)

        return CommPlan(
            sender_leaf_idx=sender_idx,
            receiver_leaf_idx=receiver_idx,
            sender_indices=s_indices,
            receiver_indices=np.array(receiver_indices, dtype=int),
            weights=np.array(weights, dtype=float),
            num_sender_indices=len(s_indices),
            flux_correction_plan=flux_plan,
        )

    def _add_periodic_connections(self, config: Config, problem: "Problem") -> None:
        """Finds and adds periodic neighbor relationships between leaves.

        This method modifies the domain topology by:
        1. Checking the global boundary conditions of the problem.
        2. If an axis is periodic, it finds the leaves on the opposite edges
           of the global domain.
        3. It removes their physical boundary designations (e.g., WEST, EAST).
        4. It adds new neighbor information, linking these edge leaves to each
           other, effectively "wrapping" the domain.
        This ensures that periodic boundaries are handled by the standard halo
        exchange mechanism rather than the local BC module.
        """
        if self.num_domains() <= 1:
            return

        # Create BCs for the entire global domain to check for periodic axes
        global_disc = self.domain_tree.disc
        all_bounds = [
            Direction.EAST,
            Direction.WEST,
            Direction.NORTH,
            Direction.SOUTH,
        ][: self.dimension() * 2]
        global_bcs = problem.get_bc(global_disc, config, all_bounds)

        is_periodic_x = isinstance(
            global_bcs.conditions.get(Direction.WEST), bcs.Periodic
        )
        is_periodic_y = self.dimension() > 1 and isinstance(
            global_bcs.conditions.get(Direction.SOUTH), bcs.Periodic
        )

        if is_periodic_x:
            west_boundary = global_disc.grid.cell_edges[0][0]
            east_boundary = global_disc.grid.cell_edges[0][-1]
            west_leaves = {
                i
                for i, leaf in enumerate(self.leaves)
                if point_match(leaf.disc.grid.cell_edges[0][0], west_boundary)
            }
            east_leaves = {
                i
                for i, leaf in enumerate(self.leaves)
                if point_match(leaf.disc.grid.cell_edges[0][-1], east_boundary)
            }

            new_neighbors_to_add_x: dict[int, list[NeighborInfo]] = {
                i: [] for i in range(self.num_domains())
            }

            for w_idx in west_leaves:
                for e_idx in east_leaves:
                    w_leaf = self.leaves[w_idx]
                    e_leaf = self.leaves[e_idx]

                    if self.dimension() > 1:
                        l1_lb_y, l1_ub_y = w_leaf.disc.grid.cell_edges[1][[0, -1]]
                        l2_lb_y, l2_ub_y = e_leaf.disc.grid.cell_edges[1][[0, -1]]
                        if not intervals_overlap(l1_lb_y, l1_ub_y, l2_lb_y, l2_ub_y):
                            continue

                    dx_idx = 1 if self.dimension() > 1 else 0
                    if np.isclose(
                        w_leaf.disc.grid.dx[dx_idx], e_leaf.disc.grid.dx[dx_idx]
                    ):
                        rel_w_to_e = NeighborRelationship.MATCHED
                    elif w_leaf.disc.grid.dx[dx_idx] > e_leaf.disc.grid.dx[dx_idx]:
                        rel_w_to_e = NeighborRelationship.COARSE_TO_FINE
                    else:
                        rel_w_to_e = NeighborRelationship.FINE_TO_COARSE

                    if np.isclose(
                        e_leaf.disc.grid.dx[dx_idx], w_leaf.disc.grid.dx[dx_idx]
                    ):
                        rel_e_to_w = NeighborRelationship.MATCHED
                    elif e_leaf.disc.grid.dx[dx_idx] > w_leaf.disc.grid.dx[dx_idx]:
                        rel_e_to_w = NeighborRelationship.COARSE_TO_FINE
                    else:
                        rel_e_to_w = NeighborRelationship.FINE_TO_COARSE

                    new_neighbors_to_add_x[w_idx].append(
                        NeighborInfo(e_idx, Direction.WEST, e_leaf.disc, rel_w_to_e)
                    )
                    new_neighbors_to_add_x[e_idx].append(
                        NeighborInfo(w_idx, Direction.EAST, w_leaf.disc, rel_e_to_w)
                    )

            for leaf_idx in west_leaves | east_leaves:
                map_item = self.leaf_neighbor_map[leaf_idx]
                if map_item is None:
                    continue
                map_item = cast(tuple[LeafNeighbor, list[Direction]], map_item)
                direction = (
                    Direction.WEST if leaf_idx in west_leaves else Direction.EAST
                )
                map_item[0].neighbors = [
                    n for n in map_item[0].neighbors if n.direction != direction
                ]
                map_item[0].neighbors.extend(new_neighbors_to_add_x[leaf_idx])
                if direction in map_item[1]:
                    map_item[1].remove(direction)
        if is_periodic_y:
            south_boundary = global_disc.grid.cell_edges[1][0]
            north_boundary = global_disc.grid.cell_edges[1][-1]
            south_leaves = {
                i
                for i, leaf in enumerate(self.leaves)
                if point_match(leaf.disc.grid.cell_edges[1][0], south_boundary)
            }
            north_leaves = {
                i
                for i, leaf in enumerate(self.leaves)
                if point_match(leaf.disc.grid.cell_edges[1][-1], north_boundary)
            }

            new_neighbors_to_add_y: dict[int, list[NeighborInfo]] = {
                i: [] for i in range(self.num_domains())
            }

            for s_idx in south_leaves:
                for n_idx in north_leaves:
                    s_leaf = self.leaves[s_idx]
                    n_leaf = self.leaves[n_idx]

                    l1_lb_x, l1_ub_x = s_leaf.disc.grid.cell_edges[0][[0, -1]]
                    l2_lb_x, l2_ub_x = n_leaf.disc.grid.cell_edges[0][[0, -1]]
                    if not intervals_overlap(l1_lb_x, l1_ub_x, l2_lb_x, l2_ub_x):
                        continue

                    dx_idx = 0
                    if np.isclose(
                        s_leaf.disc.grid.dx[dx_idx], n_leaf.disc.grid.dx[dx_idx]
                    ):
                        rel_s_to_n = NeighborRelationship.MATCHED
                    elif s_leaf.disc.grid.dx[dx_idx] > n_leaf.disc.grid.dx[dx_idx]:
                        rel_s_to_n = NeighborRelationship.COARSE_TO_FINE
                    else:
                        rel_s_to_n = NeighborRelationship.FINE_TO_COARSE

                    if np.isclose(
                        n_leaf.disc.grid.dx[dx_idx], s_leaf.disc.grid.dx[dx_idx]
                    ):
                        rel_n_to_s = NeighborRelationship.MATCHED
                    elif n_leaf.disc.grid.dx[dx_idx] > s_leaf.disc.grid.dx[dx_idx]:
                        rel_n_to_s = NeighborRelationship.COARSE_TO_FINE
                    else:
                        rel_n_to_s = NeighborRelationship.FINE_TO_COARSE

                    new_neighbors_to_add_y[s_idx].append(
                        NeighborInfo(n_idx, Direction.SOUTH, n_leaf.disc, rel_s_to_n)
                    )
                    new_neighbors_to_add_y[n_idx].append(
                        NeighborInfo(s_idx, Direction.NORTH, s_leaf.disc, rel_n_to_s)
                    )

            for leaf_idx in south_leaves | north_leaves:
                map_item = self.leaf_neighbor_map[leaf_idx]
                if map_item is None:
                    continue
                map_item = cast(tuple[LeafNeighbor, list[Direction]], map_item)
                direction = (
                    Direction.SOUTH if leaf_idx in south_leaves else Direction.NORTH
                )
                map_item[0].neighbors = [
                    n for n in map_item[0].neighbors if n.direction != direction
                ]
                map_item[0].neighbors.extend(new_neighbors_to_add_y[leaf_idx])
                if direction in map_item[1]:
                    map_item[1].remove(direction)

    def _create_plan_1d(
        self, sender_idx: int, neighbor: NeighborInfo
    ) -> CommPlan | None:
        """Create a CommPlan for a 1D neighbor interface.

        This handles the geometric calculations for transferring boundary data
        between two 1D leaves, supporting matched, coarse-to-fine, and
        fine-to-coarse grid relationships.

        Args:
            sender_idx: The global index of the leaf sending data.
            neighbor: The `NeighborInfo` object for the receiving leaf.

        Returns:
            A `CommPlan` object if a plan is created, or None.
        """
        sender_leaf = self.leaves[sender_idx]
        receiver_idx = neighbor.neighbor
        receiver_leaf = self.leaves[receiver_idx]

        sender_disc = sender_leaf.disc
        receiver_disc = receiver_leaf.disc

        # For periodic BCs, create a temporary "virtual" sender discretization
        # to make it appear geometrically adjacent to the receiver.
        is_periodic = False
        if neighbor.direction == Direction.EAST and not point_match(
            sender_disc.grid.cell_edges[0][-1], receiver_disc.grid.cell_edges[0][0]
        ):
            is_periodic = True
        elif neighbor.direction == Direction.WEST and not point_match(
            sender_disc.grid.cell_edges[0][0], receiver_disc.grid.cell_edges[0][-1]
        ):
            is_periodic = True

        if is_periodic:
            domain_width = self.ub_x() - self.lb_x()
            # If sender connects via its EAST face, it's on the right of the domain
            # and must be shifted LEFT to wrap around.
            if neighbor.direction == Direction.EAST:
                sender_disc = sender_disc.shift([-domain_width])
            # If sender connects via its WEST face, it's on the left of the domain
            # and must be shifted RIGHT to wrap around.
            else:
                sender_disc = sender_disc.shift([domain_width])

        # Get sender's physical grid info (data source)
        sender_centers = sender_disc.grid.cell_centers[0]
        sender_edges = sender_disc.grid.cell_edges[0]

        # Get receiver's grid info
        receiver_edges = receiver_leaf.disc.grid.cell_edges[0]
        receiver_dx = receiver_leaf.disc.grid.dx[0]
        receiver_n_interior = receiver_leaf.disc.grid.num_cells[0]
        receiver_n_ghost_half = receiver_leaf.disc.grid.num_ghost[0] // 2

        # Calculate coordinates and indices for the receiver's ghost cells
        if neighbor.direction == Direction.EAST:  # Sender is WEST of receiver
            # Ghost cells are to the LEFT of the receiver's physical domain
            offset = np.arange(receiver_n_ghost_half, 0, -1)
            receiver_ghost_centers = (
                receiver_leaf.disc.grid.cell_centers[0][0] - offset * receiver_dx
            )
            receiver_ghost_edges_lower = receiver_edges[0] - offset * receiver_dx
            receiver_ghost_edges_upper = receiver_edges[0] - (offset - 1) * receiver_dx
            receiver_indices_base = np.arange(receiver_n_ghost_half)

        elif neighbor.direction == Direction.WEST:  # Sender is EAST of receiver
            # Ghost cells are to the RIGHT of the receiver's physical domain
            offset = np.arange(1, receiver_n_ghost_half + 1)
            receiver_ghost_centers = (
                receiver_leaf.disc.grid.cell_centers[0][-1] + offset * receiver_dx
            )
            receiver_ghost_edges_lower = receiver_edges[-1] + (offset - 1) * receiver_dx
            receiver_ghost_edges_upper = receiver_edges[-1] + offset * receiver_dx
            receiver_indices_base = np.arange(
                receiver_n_interior + receiver_n_ghost_half,
                receiver_n_interior + 2 * receiver_n_ghost_half,
            )
        else:
            return None  # Should not happen in 1D

        sender_indices: list[int] = []
        receiver_indices: list[int] = []
        weights: list[float] = []

        if neighbor.relationship == NeighborRelationship.MATCHED:
            if neighbor.direction == Direction.EAST:  # sender is WEST
                s_inds = np.arange(
                    len(sender_centers) - receiver_n_ghost_half, len(sender_centers)
                )
            else:  # sender is EAST
                s_inds = np.arange(receiver_n_ghost_half)
            sender_indices.extend(s_inds)
            receiver_indices.extend(receiver_indices_base)
            weights.extend(np.ones_like(receiver_indices_base, dtype=float))

        elif neighbor.relationship == NeighborRelationship.COARSE_TO_FINE:
            # For each fine receiver ghost center, find which coarse sender
            # cell contains it
            s_inds = (
                np.searchsorted(sender_edges, receiver_ghost_centers, side="right") - 1
            )
            s_inds = np.clip(s_inds, 0, len(sender_centers) - 1)
            sender_indices.extend(s_inds)
            receiver_indices.extend(receiver_indices_base)
            weights.extend(np.ones_like(receiver_indices_base, dtype=float))

        elif neighbor.relationship == NeighborRelationship.FINE_TO_COARSE:
            # For each coarse receiver ghost cell, average all fine sender cells
            # within it
            for i, rec_idx in enumerate(receiver_indices_base):
                rec_edge_lower = receiver_ghost_edges_lower[i]
                rec_edge_upper = receiver_ghost_edges_upper[i]

                # Find sender centers that fall within the coarse ghost cell boundaries
                mask = (sender_centers >= rec_edge_lower) & (
                    sender_centers < rec_edge_upper
                )
                fine_indices = np.where(mask)[0]

                if fine_indices.size > 0:
                    num_fine = fine_indices.size
                    sender_indices.extend(fine_indices)
                    receiver_indices.extend([rec_idx] * num_fine)
                    weights.extend([1.0 / num_fine] * num_fine)

        if not sender_indices:
            return None

        s_indices = np.array(sender_indices, dtype=int)
        flux_plan = None

        if neighbor.relationship == NeighborRelationship.FINE_TO_COARSE:
            # Create FluxCorrectionPlan for 1D interface
            # Look up the direction from the coarse (receiver) perspective
            receiver_map_item = self.leaf_neighbor_map[receiver_idx]
            assert receiver_map_item is not None
            coarse_neighbor_info = next(
                n for n in receiver_map_item[0].neighbors if n.neighbor == sender_idx
            )
            direction = coarse_neighbor_info.direction

            coarse_nx = receiver_leaf.disc.grid.num_cells[0]

            # 1. Identify coarse cell index at interface
            if direction == Direction.EAST:
                coarse_idx = coarse_nx - 1
                interface_pos = receiver_leaf.disc.grid.cell_edges[0][-1]
            else:
                coarse_idx = 0
                interface_pos = receiver_leaf.disc.grid.cell_edges[0][0]

            # 2. Create temporary fine discretization (2 cells wide)
            fine_dx = sender_leaf.disc.grid.dx[0]
            lb = [interface_pos - fine_dx]
            ub = [interface_pos + fine_dx]
            n = [2]
            temp_disc = Discretization.from_geom(lb, ub, n, [0])

            # 3. Find fine face index in buffer
            # If Coarse is West (Direction.EAST), Fine is East. Interface is Fine's 0.
            # If Coarse is East (Direction.WEST), Fine is West. Interface is Fine's -1.
            if direction == Direction.EAST:
                target_fine_idx = 0
            else:
                target_fine_idx = sender_leaf.disc.grid.num_cells[0] - 1

            # s_indices contains global indices of fine cells sent to coarse ghost.
            # Find which index in the buffer corresponds to the face cell.
            matches = np.where(s_indices == target_fine_idx)[0]

            if matches.size > 0:
                flux_plan = FluxCorrectionPlan(
                    direction=direction,
                    temporary_fine_disc=temp_disc,
                    coarse_cell_indices=np.array([coarse_idx]),
                    fine_face_indices_in_buffer=matches,
                )

        return CommPlan(
            sender_leaf_idx=sender_idx,
            receiver_leaf_idx=receiver_idx,
            sender_indices=s_indices,
            receiver_indices=np.array(receiver_indices, dtype=int),
            weights=np.array(weights, dtype=float),
            num_sender_indices=len(s_indices),
            flux_correction_plan=flux_plan,
        )

    def get_max_level_diff(self, proper_nesting: bool) -> int:
        """Calculate the maximum allowed level difference between neighbors.

        Args:
            proper_nesting: If True, forces the max difference to be 1.

        Returns:
            The maximum allowed level difference.
        """
        if proper_nesting:
            return 1

        # Use the first leaf as representative (assuming uniform N and ghost)
        leaf = self.leaves[0]
        ratios = []
        for i in range(leaf.disc.dimension):
            n = leaf.disc.grid.num_cells[i]
            ng = leaf.disc.grid.num_ghost[i]
            ratios.append(2 * n / ng)
        return int(np.floor(np.log2(min(ratios))))

    @property
    def max_level_diff(self) -> int:
        """Calculate the maximum allowed level difference between neighbors.

        This enforces that a coarse cell's ghost region does not extend beyond
        its immediate neighbor's physical domain.
        """
        return self.get_max_level_diff(False)

    def propose_refinement(
        self,
        leaf_indices: list[int],
        config: Config,
        problem: "Problem",
    ) -> tuple["DomainManager", dict[int, list[int]]]:
        """Propose a new domain decomposition with requested refinements.

        This method enforces the generalized level balance constraint by
        propagating refinements to neighbors if necessary.

        Args:
            leaf_indices: Indices of the leaves requested for refinement.
            config: The simulation configuration.
            problem: The problem definition.

        Returns:
            A tuple containing:
                - A new DomainManager instance with the updated topology.
                - A dictionary mapping old leaf indices to a list of new leaf indices.
        """
        # 1. Deep copy the tree to avoid modifying the current one
        new_tree = copy.deepcopy(self.domain_tree)

        # Re-map leaves in the new tree to match indices
        new_leaves = new_tree.get_leaves()

        # 2. Initialize target levels
        current_levels = np.array([leaf.depth for leaf in new_leaves])
        target_levels = current_levels.copy()

        # Mark requested leaves for refinement
        max_allowed_level = config.refinement.max_level
        for idx in leaf_indices:
            if current_levels[idx] < max_allowed_level:
                target_levels[idx] += 1

        # 3. Iterative Balancing
        max_diff = self.get_max_level_diff(config.refinement.proper_nesting)

        while True:
            violation = False
            for i, map_item in enumerate(self.leaf_neighbor_map):
                if map_item is None:
                    continue
                neighbor_info, _ = map_item

                for neighbor in neighbor_info.neighbors:
                    if neighbor.neighbor == -1:
                        continue  # Boundary

                    j = neighbor.neighbor
                    # Constraint: Level(i) - Level(j) <= max_diff
                    if target_levels[i] - target_levels[j] > max_diff:
                        target_levels[j] = target_levels[i] - max_diff
                        violation = True

            if not violation:
                break

        # 4. Apply splits and build lineage map
        old_to_new_map = {}
        current_new_idx = 0
        dim = self.dimension()

        for i, leaf in enumerate(new_leaves):
            splits_needed = target_levels[i] - current_levels[i]
            if splits_needed > 0:
                leaf.split_recursive(splits_needed)
                num_generated = (2**dim) ** splits_needed
                old_to_new_map[i] = list(
                    range(current_new_idx, current_new_idx + num_generated)
                )
                current_new_idx += num_generated
            else:
                old_to_new_map[i] = [current_new_idx]
                current_new_idx += 1

        # 5. Rebuild DomainManager
        final_leaves = new_tree.get_leaves()
        final_map = Tree.map_leaves(final_leaves, new_tree)

        new_manager = DomainManager(
            new_tree, final_leaves, final_map, self.domain_angles
        )
        new_manager._add_periodic_connections(config, problem)
        new_manager.comm_plans = new_manager._build_communication_plans()

        return new_manager, old_to_new_map

    def propose_coarsening(
        self,
        leaf_indices: list[int],
        config: Config,
        problem: "Problem",
    ) -> tuple["DomainManager", dict[int, int]]:
        """Propose a new domain decomposition with requested coarsenings.

        This method checks that all siblings are present and that coarsening
        does not violate the level balance constraint with neighbors.

        Args:
            leaf_indices: Indices of the leaves requested for coarsening.
            config: The simulation configuration.
            problem: The problem definition.

        Returns:
            A tuple containing:
                - A new DomainManager instance with the updated topology.
                - A dictionary mapping old leaf indices to their new leaf index.
        """
        new_tree = copy.deepcopy(self.domain_tree)
        new_leaves = new_tree.get_leaves()

        # Map indices to nodes
        nodes_to_coarsen = {new_leaves[i] for i in leaf_indices}

        # Group by parent
        parents_to_check: dict[Tree, list[Tree]] = {}
        for node in nodes_to_coarsen:
            if node.parent:
                if node.parent not in parents_to_check:
                    parents_to_check[node.parent] = []
                parents_to_check[node.parent].append(node)

        # Filter: All children must be present
        candidates = []
        for parent, children in parents_to_check.items():
            if parent.children and len(children) == len(parent.children):
                candidates.append(parent)

        # Check Balance
        node_to_index = {node: i for i, node in enumerate(new_leaves)}
        final_candidates = []
        max_diff = self.get_max_level_diff(config.refinement.proper_nesting)

        for parent in candidates:
            parent_level = parent.depth
            valid = True
            # Check all children's neighbors
            if parent.children:
                for child in parent.children:
                    idx = node_to_index[child]
                    map_item = self.leaf_neighbor_map[idx]
                    if map_item is None:
                        continue

                    for neighbor in map_item[0].neighbors:
                        if neighbor.neighbor == -1:
                            continue

                        # Neighbor index in current leaves
                        neigh_idx = neighbor.neighbor
                        neigh_level = new_leaves[neigh_idx].depth

                        # Constraint: NeighborLevel - ParentLevel <= max_diff
                        if neigh_level - parent_level > max_diff:
                            valid = False
                            break
                    if not valid:
                        break

            if valid:
                final_candidates.append(parent)

        # Build lineage map preparation
        # Map: leaf_node -> old_index
        leaf_to_old_idx = {leaf: i for i, leaf in enumerate(new_leaves)}
        parent_to_old_indices = {}

        for p in final_candidates:
            children = p.get_leaves()
            indices = [leaf_to_old_idx[c] for c in children]
            parent_to_old_indices[p] = indices
            p.merge()

        # Rebuild Manager
        final_leaves = new_tree.get_leaves()
        final_map = Tree.map_leaves(final_leaves, new_tree)

        new_manager = DomainManager(
            new_tree, final_leaves, final_map, self.domain_angles
        )
        new_manager._add_periodic_connections(config, problem)
        new_manager.comm_plans = new_manager._build_communication_plans()

        # Construct final map
        old_to_new_map = {}
        for new_idx, leaf in enumerate(final_leaves):
            if leaf in leaf_to_old_idx:
                old_idx = leaf_to_old_idx[leaf]
                old_to_new_map[old_idx] = new_idx
            elif leaf in parent_to_old_indices:
                indices = parent_to_old_indices[leaf]
                for old_idx in indices:
                    old_to_new_map[old_idx] = new_idx

        return new_manager, old_to_new_map

    def dimension(self) -> int:
        """Return the spatial dimension of the domain.

        Returns:
            The spatial dimension.
        """
        return self.leaves[0].disc.dimension

    def num_domains(self) -> int:
        """Return the total number of leaf domains.

        Returns:
            The total number of leaf domains.
        """
        return len(self.leaves)

    def min_dx(self) -> float:
        """Return the minimum cell spacing across all leaf domains.

        Returns:
            The minimum cell spacing.
        """
        return float(np.min([min(ll.disc.grid.dx) for ll in self.leaves]))

    def ub_x(self) -> float:
        """Return the global upper bound in the x-direction.

        Returns:
            The global upper bound in x.
        """
        return float(self.domain_tree.disc.grid.cell_edges[0][-1])

    def lb_x(self) -> float:
        """Return the global lower bound in the x-direction.

        Returns:
            The global lower bound in x.
        """
        return float(self.domain_tree.disc.grid.cell_edges[0][0])

    def ub_y(self) -> float:
        """Return the global upper bound in the y-direction.

        Returns:
            The global upper bound in y.
        """
        return float(self.domain_tree.disc.grid.cell_edges[1][-1])

    def lb_y(self) -> float:
        """Return the global lower bound in the y-direction.

        Returns:
            The global lower bound in y.
        """
        return float(self.domain_tree.disc.grid.cell_edges[1][0])

    @staticmethod
    def split_solution(sol: Any, domain_geometries: Any) -> Any:
        """Split the solution into multiple tensors.

        Args:
            sol: The solution to split.
            domain_geometries: The geometries of the domains.

        Raises:
            NotImplementedError: This method is not yet implemented.
        """
        raise NotImplementedError("TODO")

    @classmethod
    def from_split(cls, domain_geometries: Any) -> Any:
        """Create a DomainManager from a split solution.

        Args:
            domain_geometries: The geometries of the domains.

        Raises:
            NotImplementedError: This method is not yet implemented.
        """
        # out = cls(domain_geometries)
        # out.solutions = split_solution(sol, self.domain_geometries)
        raise NotImplementedError("TODO")

    @classmethod
    def from_config(cls, config: Config, problem: "Problem") -> "DomainManager":
        """Create a DomainManager from a configuration object.

        Args:
            config: The simulation configuration object.
            problem: The problem specification.

        Returns:
            A new DomainManager instance.
        """
        domain_angles = AngleDiscretization.from_config(config)

        lb = config.geometry.lb
        ub = config.geometry.ub
        n = config.geometry.n

        tree = Tree(Discretization.from_geom(lb, ub, n, config.geometry.n_ghost), None)
        tree.split_on_list(config.geometry.domain_decomp)

        leaves = tree.get_leaves()

        leaf_neighbor_map = Tree.map_leaves(leaves, tree)

        manager = cls(tree, leaves, leaf_neighbor_map, domain_angles)
        manager._add_periodic_connections(config, problem)
        manager.comm_plans = manager._build_communication_plans()

        return manager


def create_domain_manager(
    config: Config, problem: "Problem", logger: logging.Logger
) -> DomainManager:
    """Create a DomainManager from config or load from a checkpoint.

    This function should only be called by Rank 0.

    Args:
        config: The simulation configuration.
        problem: The problem specification.
        logger: The logger instance.

    Returns:
        The created or loaded DomainManager.

    Raises:
        FileNotFoundError: If a checkpoint is specified but no file is found.
        OSError: If multiple checkpoint files are found.
    """
    # Check if a checkpoint directory is specified in the config
    if config.checkpoint_directory:
        logger.info("Attempting to load DomainManager from checkpoint...")

        # --- Logic to find and load the checkpoint file ---
        dirname = config.checkpoint_directory
        search_pattern = os.path.join(dirname, "*domain_manager*.pkl")
        domain_manager_files = glob.glob(search_pattern)

        if len(domain_manager_files) == 1:
            filepath = domain_manager_files[0]
            logger.info("Found DomainManager file: %s", filepath)
            with open(filepath, "rb") as f:
                domain_manager = pickle.load(f)
            assert isinstance(domain_manager, DomainManager)
            return domain_manager

        elif len(domain_manager_files) == 0:
            raise FileNotFoundError(
                f"No DomainManager file found in checkpoint directory: {dirname}"
            )
        else:
            raise OSError(
                f"Found multiple DomainManager files in checkpoint directory: {dirname}"
            )

    else:
        # --- Logic to create from scratch using the existing classmethod ---
        logger.info("Creating new DomainManager from config.")
        return DomainManager.from_config(config, problem)
