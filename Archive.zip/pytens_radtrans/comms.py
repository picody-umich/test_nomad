"""Module for handling communication between domain leaves.

This module contains functions for both MPI-based communication and the
geometric transformations required to prepare data for transfer between
potentially non-matching grids.
"""

import os
import sys
from typing import TYPE_CHECKING, Any

import numpy as np
import pytens
from mpi4py import MPI

from . import contracts, solver

# --- Robust MPI Tag Generation ---
# A safe upper bound on the number of sub-arrays within a single data package
# channel. This applies independently to TensorNetwork arrays and user arrays.
MAX_SUB_ARRAYS = 100

# Define non-overlapping offset ranges for different data types ("channels").
# This prevents tag collisions for different arrays within the same package.
TAG_CHANNEL_TT_OFFSET = 10
TAG_CHANNEL_ARRAY_OFFSET = TAG_CHANNEL_TT_OFFSET + MAX_SUB_ARRAYS

# Define a multiplier for the unique (sender, receiver) pair ID.
# This multiplier must be larger than the largest possible channel offset to
# prevent tag collisions between different packages.
TAG_MULTIPLIER = TAG_CHANNEL_ARRAY_OFFSET + MAX_SUB_ARRAYS

if TYPE_CHECKING:
    from logging import Logger

    from .main_loop_utils import InitializationData


comm = MPI.COMM_WORLD
rank = comm.Get_rank()


def _get_tag_upper_bound(comm: MPI.Comm) -> int | None:
    """Returns MPI tag upper bound when available."""
    tag_ub_key = getattr(MPI, "TAG_UB", None)
    if tag_ub_key is None or not hasattr(comm, "Get_attr"):
        return None

    try:
        tag_ub = comm.Get_attr(tag_ub_key)
    except Exception:  # pragma: no cover - backend-specific MPI failure paths
        return None

    if isinstance(tag_ub, int):
        return tag_ub
    return None


def _make_tag_base(unique_id: int, comm: MPI.Comm) -> int:
    """Builds a tag base and validates it against MPI tag bounds."""
    if unique_id < 0:
        raise ValueError(f"Tag unique_id must be non-negative, got {unique_id}")

    tag_base = unique_id * TAG_MULTIPLIER
    max_tag = tag_base + TAG_CHANNEL_ARRAY_OFFSET + MAX_SUB_ARRAYS
    tag_ub = _get_tag_upper_bound(comm)
    if tag_ub is not None and max_tag > tag_ub:
        raise RuntimeError(
            "MPI tag overflow risk: "
            f"max tag {max_tag} exceeds tag upper bound {tag_ub}."
        )
    return tag_base


def _epoch_tags_enabled() -> bool:
    """Returns True when per-iteration MPI tag namespacing is enabled."""
    raw = os.environ.get("PYTENS_MPI_EPOCH_TAGS", "")
    return raw.lower() in {"1", "true", "yes", "on"}


def _halo_pair_uid(
    receiver_idx: int,
    sender_idx: int,
    num_domains: int,
    iteration: int | None,
) -> int:
    """Builds a unique communication ID for a (receiver, sender) halo pair."""
    base_uid = receiver_idx * num_domains + sender_idx
    if not _epoch_tags_enabled():
        return base_uid
    if iteration is None:
        raise RuntimeError(
            "PYTENS_MPI_EPOCH_TAGS is enabled but no halo iteration was provided."
        )
    if iteration < 0:
        raise RuntimeError(f"Invalid halo iteration {iteration}. Must be non-negative.")
    return iteration * (num_domains * num_domains) + base_uid


def _transfer_data_payloads(
    outgoing_payloads: dict[tuple[int, int], dict],
    incoming_expectations: list[tuple[int, Any, int]],
    comm: MPI.Comm,
    logger: "Logger",
) -> dict[tuple[int, Any], dict]:
    """Transfers generic data payloads between ranks using a two-phase protocol.

    This function handles the raw MPI mechanics for moving complex data structures
    composed of TensorNetworks and NumPy arrays. It abstracts the Metadata ->
    Raw Buffer pattern.

    Args:
        outgoing_payloads: Dict mapping (target_rank, tag_base) to a payload dict.
            Payload format: {"tn": TensorNetwork, "arrays": {name: ndarray}}
        incoming_expectations: List of (source_rank, unique_id, tag_base) tuples
            identifying expected messages.
            - unique_id: A unique identifier for the message content (e.g., global_idx).
            - tag_base: The base MPI tag to use for this message channel.
        comm: MPI communicator.
        logger: Logger instance.

    Returns:
        A dictionary mapping (source_rank, unique_id) to the received payload.
    """
    # Phase 1: Post receives for METADATA
    recv_meta_reqs = {}
    for source_rank, unique_id, tag_base in incoming_expectations:
        if source_rank != rank:
            req = comm.irecv(source=source_rank, tag=tag_base)
            recv_meta_reqs[(source_rank, unique_id)] = req

    # Prepare and send METADATA
    send_meta_reqs = []
    # Store separated arrays for Phase 2 to prevent GC
    outgoing_storage = {}

    for (target_rank, tag_base), payload in outgoing_payloads.items():
        if target_rank == rank:
            continue  # Skip local transfers in this low-level function

        # Deconstruct TensorNetwork.
        tn_meta, tn_arrays = payload["tn"].to_separated_dict()
        tn_items = list(tn_arrays.items())
        if len(tn_items) > MAX_SUB_ARRAYS:
            raise RuntimeError(
                "Tensor payload exceeds supported MPI sub-array channel count: "
                f"{len(tn_items)} > MAX_SUB_ARRAYS={MAX_SUB_ARRAYS}."
            )

        array_items = list(payload["arrays"].items())
        if len(array_items) > MAX_SUB_ARRAYS:
            raise RuntimeError(
                "Array payload exceeds supported MPI sub-array channel count: "
                f"{len(array_items)} > MAX_SUB_ARRAYS={MAX_SUB_ARRAYS}."
            )

        # Collect array info
        array_info = {
            name: {"shape": list(arr.shape), "dtype": arr.dtype.name}
            for name, arr in array_items
        }

        metadata = {
            "tn_meta": tn_meta,
            # Channel order must be explicit and dense; node IDs are not
            # guaranteed to be small contiguous integers.
            "tn_channel_node_ids": [node_id for node_id, _ in tn_items],
            "array_info": array_info,
            "array_channel_names": [name for name, _ in array_items],
            # Pass through extra metadata
            "extra": payload.get("extra", {}),
        }

        req = comm.isend(metadata, dest=target_rank, tag=tag_base)
        send_meta_reqs.append(req)

        outgoing_storage[(target_rank, tag_base)] = {
            "tn_items": tn_items,
            "array_items": array_items,
        }

    # Wait for Metadata
    received_metadata = {}
    for key, req in recv_meta_reqs.items():
        data = req.wait()
        if data is None:
            logger.critical("Rank %d: Failed to receive metadata for %s", rank, key)
            comm.Abort(1)
        received_metadata[key] = data

    if send_meta_reqs:
        MPI.Request.Waitall(send_meta_reqs)

    # Phase 2: Exchange Raw Arrays
    recv_array_reqs = []
    received_raw_arrays: dict[tuple[int, Any], dict[str, Any]] = {}

    for (source_rank, unique_id), meta in received_metadata.items():
        # unique_id here is the tag_base passed in incoming_expectations
        tag_base = next(
            t
            for s, u, t in incoming_expectations
            if s == source_rank and u == unique_id
        )
        received_raw_arrays[(source_rank, unique_id)] = {}

        tn_channel_node_ids = meta.get("tn_channel_node_ids")
        if not isinstance(tn_channel_node_ids, list):
            raise RuntimeError("Received metadata missing tn_channel_node_ids list.")
        if len(tn_channel_node_ids) > MAX_SUB_ARRAYS:
            raise RuntimeError(
                "Received Tensor payload exceeds supported channel count: "
                f"{len(tn_channel_node_ids)} > MAX_SUB_ARRAYS={MAX_SUB_ARRAYS}."
            )

        # TN Arrays. Use dense channel indices, not raw node IDs, for tags.
        for i, node_id in enumerate(tn_channel_node_ids):
            info = meta["tn_meta"]["numpy_arrays_info"].get(node_id)
            if info is None:
                info = meta["tn_meta"]["numpy_arrays_info"].get(str(node_id))
            if info is None:
                raise RuntimeError(
                    "Received metadata references unknown Tensor node ID " f"{node_id}."
                )
            buf = np.empty(tuple(info["shape"]), dtype=np.dtype(info["dtype"]))
            tag = tag_base + TAG_CHANNEL_TT_OFFSET + i
            req = comm.Irecv(buf, source=source_rank, tag=tag)
            recv_array_reqs.append(req)
            received_raw_arrays[(source_rank, unique_id)][node_id] = buf

        array_channel_names = meta.get("array_channel_names")
        if not isinstance(array_channel_names, list):
            raise RuntimeError("Received metadata missing array_channel_names list.")
        if len(array_channel_names) > MAX_SUB_ARRAYS:
            raise RuntimeError(
                "Received array payload exceeds supported channel count: "
                f"{len(array_channel_names)} > MAX_SUB_ARRAYS={MAX_SUB_ARRAYS}."
            )

        # User Arrays
        for i, name in enumerate(array_channel_names):
            info = meta["array_info"].get(name)
            if info is None:
                raise RuntimeError(
                    "Received metadata references unknown array channel " f"'{name}'."
                )
            buf = np.empty(tuple(info["shape"]), dtype=np.dtype(info["dtype"]))
            tag = tag_base + TAG_CHANNEL_ARRAY_OFFSET + i
            req = comm.Irecv(buf, source=source_rank, tag=tag)
            recv_array_reqs.append(req)
            received_raw_arrays[(source_rank, unique_id)][name] = buf

    # Send Raw Arrays
    send_array_reqs = []
    for (target_rank, tag_base), data in outgoing_storage.items():
        # TN Arrays
        for i, (_node_id, arr) in enumerate(data["tn_items"]):
            tag = tag_base + TAG_CHANNEL_TT_OFFSET + i
            req = comm.Isend(arr, dest=target_rank, tag=tag)
            send_array_reqs.append(req)

        # User Arrays
        for i, (_name, arr) in enumerate(data["array_items"]):
            tag = tag_base + TAG_CHANNEL_ARRAY_OFFSET + i
            req = comm.Isend(arr, dest=target_rank, tag=tag)
            send_array_reqs.append(req)

    # Wait for Arrays
    if recv_array_reqs:
        statuses = [MPI.Status() for _ in recv_array_reqs]
        try:
            MPI.Request.Waitall(recv_array_reqs, statuses)
        except MPI.Exception as e:
            print(
                f"Rank {rank}: MPI.Request.Waitall failed. Inspecting statuses...",
                file=sys.stderr,
            )
            for i, status in enumerate(statuses):
                error_code = status.Get_error()
                if error_code != MPI.SUCCESS:
                    source = status.Get_source()
                    tag = status.Get_tag()
                    print(
                        f"  - Rank {rank}: Request {i} (source={source}, tag={tag}) "
                        f"failed with MPI error code {error_code}.",
                        file=sys.stderr,
                    )
            sys.stderr.flush()
            raise e

    if send_array_reqs:
        MPI.Request.Waitall(send_array_reqs)

    # Reconstruct Payloads
    received_payloads = {}
    for key, meta in received_metadata.items():
        raw = received_raw_arrays[key]

        # Reconstruct TN
        tn_arrays = {nid: raw[nid] for nid in meta["tn_channel_node_ids"]}
        tn = pytens.TensorNetwork.from_separated_dict(meta["tn_meta"], tn_arrays)

        # Reconstruct User Arrays
        arrays = {name: raw[name] for name in meta["array_channel_names"]}

        received_payloads[key] = {
            "tn": tn,
            "arrays": arrays,
            "extra": meta.get("extra", {}),
        }

    return received_payloads


def transfer_solutions(
    outgoing_sols: dict[int, list[tuple[int, "solver.Solution"]]],
    incoming_expectations: list[tuple[int, int]],
    comm: MPI.Comm,
    logger: "Logger",
) -> list[tuple[int, "solver.Solution"]]:
    """Transfers full Solution objects between ranks.

    Args:
        outgoing_sols: Dict mapping target_rank -> list of (global_idx, Solution).
        incoming_expectations: List of (source_rank, global_idx) expected.
        comm: MPI communicator.
        logger: Logger instance.

    Returns:
        A list of received (global_idx, Solution) tuples.
    """
    # Prepare Outgoing Payloads
    outgoing_payloads = {}
    for target_rank, items in outgoing_sols.items():
        for global_idx, sol in items:
            # Flatten space and aux into a single arrays dict
            arrays = {}
            if sol.space:
                for k, v in sol.space.items():
                    arrays[f"space:{k}"] = np.ascontiguousarray(v)
            if sol.aux:
                for k, v in sol.aux.items():
                    arrays[f"aux:{k}"] = np.ascontiguousarray(v)

            tag_base = _make_tag_base(global_idx, comm)
            payload_key = (target_rank, tag_base)
            if payload_key in outgoing_payloads:
                raise RuntimeError(
                    "Duplicate transfer payload key for "
                    f"target_rank={target_rank}, global_idx={global_idx}."
                )
            outgoing_payloads[payload_key] = {
                "tn": sol.intensity,
                "arrays": arrays,
                "extra": {"time": sol.time},
            }

    # Prepare Incoming Expectations
    # Format: (source_rank, unique_id=global_idx, tag_base)
    expectations = [
        (src, idx, _make_tag_base(idx, comm)) for src, idx in incoming_expectations
    ]

    # Execute Transfer
    received_data = _transfer_data_payloads(
        outgoing_payloads, expectations, comm, logger
    )

    # Reconstruct Solutions
    received_solutions = []
    for (_source_rank, global_idx), payload in received_data.items():
        space = {}
        aux = {}
        for arr_key, arr in payload["arrays"].items():
            prefix, name = arr_key.split(":", 1)
            if prefix == "space":
                space[name] = arr
            elif prefix == "aux":
                aux[name] = arr

        sol = solver.Solution(
            time=payload["extra"]["time"],
            intensity=payload["tn"],
            space=space,
            aux=aux,
        )
        received_solutions.append((global_idx, sol))

    return received_solutions


def exchange_packages_mpi(
    all_outgoing_packages: dict[tuple[int, int], dict],
    init_data: "InitializationData",
    comm: MPI.Comm,
    logger: "Logger",
    iteration: int | None = None,
) -> dict[int, dict[int, dict]]:
    """Execute a generic, robust MPI exchange of data packages.

    Args:
        all_outgoing_packages: A dictionary mapping `(sender_idx, receiver_idx)`
            to a data package.
        init_data: The main simulation initialization data container.
        comm: The MPI communicator.
        logger: The logger instance.
        iteration: Current timestep iteration, used for optional epoch-tagging
            and payload-identity checks.

    Returns:
        A dictionary where keys are the local indices of receiving leaves and
        values are dictionaries mapping global sender indices to the received,
        reconstructed data package.
    """
    # 1. Identify Intra-rank vs Inter-rank transfers
    intra_rank_packages = {}
    inter_rank_payloads = {}
    incoming_expectations = []
    num_domains = init_data.domain_manager.num_domains()
    local_index_to_pos = contracts.build_local_index_to_pos(
        init_data.local_indices, rank
    )
    contracts.validate_receive_plans_local(
        init_data.receive_plans_by_leaf, local_index_to_pos, rank
    )

    # Prepare Outgoing
    for (sender_idx, receiver_idx), package in all_outgoing_packages.items():
        dest_rank, receiver_is_local = contracts.classify_halo_route(
            sender_idx,
            receiver_idx,
            leaf_to_rank_map=init_data.leaf_to_rank_map,
            local_index_to_pos=local_index_to_pos,
            rank=rank,
        )
        if dest_rank == rank:
            intra_rank_packages[(sender_idx, receiver_idx)] = package
        else:
            # Unique ID for halo exchange pair (receiver, sender). Using
            # num_domains avoids collisions from fixed-base encodings.
            pair_uid = _halo_pair_uid(receiver_idx, sender_idx, num_domains, iteration)
            tag_base = _make_tag_base(pair_uid, comm)
            payload_key = (dest_rank, tag_base)
            if payload_key in inter_rank_payloads:
                raise RuntimeError(
                    "Tag collision detected while preparing halo payloads for "
                    f"(sender={sender_idx}, receiver={receiver_idx})."
                )
            payload_extra = dict(package.get("extra", {}))
            payload_extra.update(
                {
                    "sender_leaf_idx": int(sender_idx),
                    "receiver_leaf_idx": int(receiver_idx),
                    "halo_iteration": (
                        int(iteration) if iteration is not None else None
                    ),
                }
            )
            inter_rank_payloads[payload_key] = {
                "tn": package["tn"],
                "arrays": package["arrays"],
                "extra": payload_extra,
            }

    # Prepare Incoming Expectations
    for rec_leaf_idx, plans in init_data.receive_plans_by_leaf.items():
        unique_senders = sorted({plan.sender_leaf_idx for plan in plans})
        for sender_idx in unique_senders:
            sender_rank = contracts.require_leaf_owner(
                sender_idx,
                init_data.leaf_to_rank_map,
                "Receive-plan map is invalid: sender leaf "
                f"{sender_idx} has no owner in leaf_to_rank_map.",
            )
            if sender_rank != rank:
                # Unique ID: tuple (rec_leaf_idx, sender_idx)
                uid = (rec_leaf_idx, sender_idx)
                pair_uid = _halo_pair_uid(
                    rec_leaf_idx, sender_idx, num_domains, iteration
                )
                tag_base = _make_tag_base(pair_uid, comm)
                incoming_expectations.append((sender_rank, uid, tag_base))

    # 2. Execute Inter-rank Transfer
    received_inter_rank = _transfer_data_payloads(
        inter_rank_payloads, incoming_expectations, comm, logger
    )

    # 3. Bundle Results
    received_packages_by_leaf: dict[int, dict[int, dict]] = {
        local_index_to_pos[leaf_idx]: {} for leaf_idx in init_data.receive_plans_by_leaf
    }

    # Bundle Inter-rank
    for (_source_rank, uid), payload in sorted(
        received_inter_rank.items(), key=lambda item: item[0][1]
    ):
        rec_leaf_idx, sender_idx = uid
        contracts.validate_halo_payload_identity(
            payload.get("extra"),
            expected_receiver_idx=rec_leaf_idx,
            expected_sender_idx=sender_idx,
            expected_iteration=iteration,
            expected_sender_rank=init_data.leaf_to_rank_map.get(sender_idx),
            source_rank=_source_rank,
        )
        rec_local_idx = local_index_to_pos[rec_leaf_idx]
        received_packages_by_leaf[rec_local_idx][sender_idx] = payload

    # Bundle Intra-rank
    for (sender_idx, receiver_idx), package in sorted(
        intra_rank_packages.items(), key=lambda item: (item[0][1], item[0][0])
    ):
        rec_local_idx_opt = local_index_to_pos.get(receiver_idx)
        if rec_local_idx_opt is not None:
            received_packages_by_leaf[rec_local_idx_opt][sender_idx] = package

    # Validate that each local receiver leaf got exactly the packages expected by
    # its communication plans. This catches stale or inconsistent rank maps
    # before transport silently diverges.
    for rec_leaf_idx, plans in init_data.receive_plans_by_leaf.items():
        rec_local_idx = local_index_to_pos[rec_leaf_idx]
        contracts.validate_sender_set(
            rec_leaf_idx,
            contracts.expected_sender_set(plans),
            set(received_packages_by_leaf[rec_local_idx].keys()),
            rank=rank,
        )

    return received_packages_by_leaf
