"""Implements the flux correction logic for coarse-fine AMR interfaces.

This module provides the FluxCorrector class, which is responsible for
calculating the difference between the high-fidelity flux (computed from the
fine side of an interface) and the low-fidelity flux (computed from the coarse
side) and creating a correction tensor to enforce conservation.
"""

from collections.abc import Callable

import numpy as np
import pytens

from . import domain_decomp, solver, utils
from .discretization import AngleDiscretization, Discretization, Indices
from .load_config import Config
from .stencil import Stencil
from .types import Direction


def create_flux_mask(
    disc: Discretization, plans: list[domain_decomp.CommPlan]
) -> dict[str, np.ndarray]:
    """Creates flux masks for a discretization based on communication plans.

    Args:
        disc: The discretization of the domain.
        plans: A list of communication plans involving this domain as a receiver
            of flux corrections.

    Returns:
        A dictionary with keys "x" and "y" containing the flux masks.
    """
    if disc.dimension == 1:
        nx = disc.grid.num_cells[0]
        mask_x = np.ones(nx + 1)
        for plan in plans:
            fcp = plan.flux_correction_plan
            if fcp is None:
                continue
            # In 1D, coarse_cell_indices has size 1
            c_idx = fcp.coarse_cell_indices[0]
            if fcp.direction == Direction.EAST:
                mask_x[c_idx + 1] = 0.0
            elif fcp.direction == Direction.WEST:
                mask_x[c_idx] = 0.0
        return {"x": mask_x}

    nx, ny = disc.grid.num_cells
    ngx = disc.grid.num_ghost[0] // 2
    ngy = disc.grid.num_ghost[1] // 2
    nx_g = nx + 2 * ngx
    # ny_g = ny + 2 * ngy

    # Create 2D interface-based masks sized for the full grid
    # including transverse ghost cells.
    mask_x = np.ones((nx + 1, ny + 2 * ngy))
    mask_y = np.ones((nx_g, ny + 1))

    for plan in plans:
        fcp = plan.flux_correction_plan
        if fcp is None:
            continue

        unique_coarse_indices = np.unique(fcp.coarse_cell_indices)
        coarse_y = unique_coarse_indices % ny
        coarse_x = unique_coarse_indices // ny

        if fcp.direction == Direction.EAST:
            # East face of cell `coarse_x` is interface `coarse_x + 1`
            mask_x[coarse_x + 1, coarse_y + ngy] = 0.0
        elif fcp.direction == Direction.WEST:
            # West face of cell `coarse_x` is interface `coarse_x`
            mask_x[coarse_x, coarse_y + ngy] = 0.0
        elif fcp.direction == Direction.NORTH:
            # North face of cell `coarse_y` is interface `coarse_y + 1`
            mask_y[coarse_x + ngx, coarse_y + 1] = 0.0
        elif fcp.direction == Direction.SOUTH:
            # South face of cell `coarse_y` is interface `coarse_y`
            mask_y[coarse_x + ngx, coarse_y] = 0.0

    return {"x": mask_x, "y": mask_y}


class FluxCalculator:
    """A class that computes high-fidelity flux at a coarse-fine interface."""

    def __init__(
        self,
        plan: domain_decomp.FluxCorrectionPlan,
        config: Config,
        domain_angles: AngleDiscretization,
        permut: list[int],
        inv_permute: list[int],
        num_sender_indices: int,
    ):
        """Pre-computes and stores objects for flux calculation.

        Args:
            plan: The flux correction plan containing interface indices.
            config: The global configuration object.
            domain_angles: The angular discretization.
            permut: The permutation order for tensor dimensions.
            inv_permute: The inverse permutation order.
            num_sender_indices: The size of the spatial index from the sender.
        """
        self.plan = plan
        self.permut = permut
        self.inv_permute = inv_permute
        self.num_sender_indices = num_sender_indices
        self.fine_stencil: Stencil = solver.create_stencil(
            config, plan.temporary_fine_disc, domain_angles
        )
        self._embed_coarse, self._embed_fine = self._create_embedder_pair()

    def _create_embedder(
        self,
        source_indices: np.ndarray,
        target_slice_idx: int,
        is_primary_axis_x: bool,
    ) -> Callable[[np.ndarray], np.ndarray]:
        """Creates a function to embed spatial data into one slice of a 2D grid.

        Args:
            source_indices: The indices of the cells to extract from the source array.
            target_slice_idx: The index (0 or 1) of the slice in the temporary grid.
            is_primary_axis_x: True if the interface is East/West.

        Returns:
            A function that performs the embedding operation on a NumPy array.
        """
        if target_slice_idx not in [0, 1]:
            raise ValueError("Target slice index must be 0 or 1.")

        nx_temp = self.plan.temporary_fine_disc.grid.num_cells[0]
        is_1d = self.plan.temporary_fine_disc.dimension == 1
        ny_temp = 1 if is_1d else self.plan.temporary_fine_disc.grid.num_cells[1]

        def embedder(source_core: np.ndarray) -> np.ndarray:
            """Extracts data and places it in the target slice of a new array."""
            rank = source_core.shape[1]
            output_core = np.zeros((nx_temp * ny_temp, rank))

            if is_1d:
                # In 1D, grid is size 2. target_slice_idx is 0 or 1.
                output_core[target_slice_idx, :] = source_core[source_indices, :]
            else:
                # Determine the target indices for the slice in the flattened 2D grid
                if is_primary_axis_x:  # E/W interface, grid is (2, ny_temp)
                    # target_slice_idx is the x-index (0 or 1)
                    target_indices = target_slice_idx * ny_temp + np.arange(ny_temp)
                else:  # N/S interface, grid is (nx_temp, 2)
                    # target_slice_idx is the y-index (0 or 1)
                    target_indices = np.arange(nx_temp) * 2 + target_slice_idx

                output_core[target_indices, :] = source_core[source_indices, :]
            return output_core

        return embedder

    def _create_embedder_pair(
        self,
    ) -> tuple[Callable[[np.ndarray], np.ndarray], Callable[[np.ndarray], np.ndarray]]:
        """Creates the pair of embedder functions for a coarse-fine interface.

        Returns:
            A tuple containing (embed_coarse, embed_fine).
        """
        is_primary_axis_x = self.plan.direction in [Direction.EAST, Direction.WEST]
        if self.plan.direction in [Direction.EAST, Direction.NORTH]:
            # Coarse domain is on the "left" (0), fine is on the "right" (1)
            coarse_slice_idx, fine_slice_idx = 0, 1
        else:  # WEST, SOUTH
            # Coarse domain is on the "right" (1), fine is on the "left" (0)
            coarse_slice_idx, fine_slice_idx = 1, 0

        embed_coarse = self._create_embedder(
            source_indices=self.plan.coarse_cell_indices,
            target_slice_idx=coarse_slice_idx,
            is_primary_axis_x=is_primary_axis_x,
        )
        embed_fine = self._create_embedder(
            source_indices=self.plan.fine_face_indices_in_buffer,
            target_slice_idx=fine_slice_idx,
            is_primary_axis_x=is_primary_axis_x,
        )
        return embed_coarse, embed_fine

    def _assemble_state(
        self,
        coarse_sol: solver.Solution,
        fine_ghost_tn: pytens.TensorNetwork,
        fine_spatial_data: dict[str, np.ndarray],
        coarse_indices: Indices,
    ) -> tuple[pytens.TensorNetwork, dict[str, np.ndarray], Indices]:
        """Assembles the solution state on the temporary fine grid.

        Args:
            coarse_sol: The solution from the coarse domain.
            fine_ghost_tn: The TensorNetwork of raw data from the fine neighbor.
            fine_spatial_data: The dictionary of raw spatial data from the fine buffer.
            coarse_indices: The indices describing the coarse domain's tensor.

        Returns:
            A tuple containing:
            - The combined intensity `TensorNetwork` on the temporary grid.
            - The combined dictionary of spatial data on the temporary grid.
            - The `Indices` object describing the temporary grid tensor.
        """
        # Output: a tensor on the temporary fine grid
        nx_temp = self.plan.temporary_fine_disc.grid.num_cells[0]
        is_1d = self.plan.temporary_fine_disc.dimension == 1
        ny_temp = 1 if is_1d else self.plan.temporary_fine_disc.grid.num_cells[1]

        space_out = pytens.Index("x", nx_temp * ny_temp)
        indices_out = Indices(
            space=space_out,
            theta=coarse_indices.theta,
            phi=coarse_indices.phi,
            dimension=self.plan.temporary_fine_disc.dimension,
        )
        # Input 1: The coarse solution tensor
        indices_in_coarse = coarse_indices
        # Input 2: The fine ghost data tensor
        space_in_fine = pytens.Index("x", self.num_sender_indices)
        indices_in_fine = Indices(
            space=space_in_fine,
            theta=coarse_indices.theta,
            phi=coarse_indices.phi,
            dimension=self.plan.temporary_fine_disc.dimension,
        )

        # --- Create and apply embedding operators ---
        op_coarse = domain_decomp.transfer_boundaries(
            self._embed_coarse,
            indices_in_coarse,
            indices_out,
            self.permut,
            self.inv_permute,
        )
        tn_coarse_embedded = op_coarse(coarse_sol.intensity)
        op_fine = domain_decomp.transfer_boundaries(
            self._embed_fine,
            indices_in_fine,
            indices_out,
            self.permut,
            self.inv_permute,
        )
        tn_fine_embedded = op_fine(fine_ghost_tn)

        # Combine to form the full state on the temporary grid
        temp_grid_tn = tn_coarse_embedded + tn_fine_embedded

        # --- Assemble spatial data on the temporary grid ---
        temp_grid_space: dict[str, np.ndarray] = {}
        assert coarse_sol.space is not None
        for key in coarse_sol.space:
            # Reshape 1D spatial arrays to 2D column vectors (rank-1 tensor core)
            # before passing to the embedder, then flatten the result.
            coarse_data = coarse_sol.space[key]
            coarse_embedded = self._embed_coarse(coarse_data.reshape(-1, 1))
            fine_data = fine_spatial_data[key]
            fine_embedded = self._embed_fine(fine_data.reshape(-1, 1))
            temp_grid_space[key] = (coarse_embedded + fine_embedded).flatten()

        return temp_grid_tn, temp_grid_space, indices_out

    def _calculate_high_fidelity_flux(
        self,
        coarse_sol: solver.Solution,
        fine_ghost_tn: pytens.TensorNetwork,
        fine_spatial_data: dict[str, np.ndarray],
        coarse_indices: Indices,
    ) -> tuple[pytens.TensorNetwork, Indices]:
        """Computes the high-fidelity flux from the fine side for one neighbor.

        Args:
            coarse_sol: The solution from the coarse domain.
            fine_ghost_tn: The TensorNetwork of raw data from the fine neighbor.
            fine_spatial_data: The dictionary of raw spatial data from the fine buffer.
            coarse_indices: The indices describing the coarse domain's tensor.

        Returns:
            A tuple containing:
            - The flux `TensorNetwork` computed on the fine interface grid.
            - The `Indices` object describing the flux tensor.
        """
        temp_grid_tn, temp_grid_space, indices_out = self._assemble_state(
            coarse_sol,
            fine_ghost_tn,
            fine_spatial_data,
            coarse_indices,
        )
        assert temp_grid_space is not None

        is_primary_axis_x = self.plan.direction in [Direction.EAST, Direction.WEST]
        is_1d = self.plan.temporary_fine_disc.dimension == 1

        if is_1d:
            # get_flux_cores_1d returns raw cores (apply=False). We must wrap them
            # to ensure 'afc' is applied and they are permuted correctly.
            raw_cores = self.fine_stencil.get_flux_cores_1d()
            flux_op_cores = self.fine_stencil.cores_class(
                raw_cores.cores, self.fine_stencil.order, apply=True
            )
            flux_space_size = 1
        else:
            flux_info_list = self.fine_stencil.get_flux_cores_2d()

            primary_direction = "x" if is_primary_axis_x else "y"
            flux_cores_for_direction = []
            for flux_1d_func, direction, other_cores in flux_info_list:
                if direction == primary_direction:
                    nx_temp, ny_temp = self.fine_stencil.disc.grid.num_cells
                    output_size = ny_temp if direction == "x" else nx_temp
                    spatial_2d_func = self.fine_stencil.create_2d_spatial_core_func(
                        flux_1d_func, direction, output_size
                    )
                    full_core = (spatial_2d_func,) + other_cores
                    flux_cores_for_direction.append(full_core)

            flux_op_cores = self.fine_stencil.cores_class(
                flux_cores_for_direction, self.fine_stencil.order
            )
            nx_temp, ny_temp = self.plan.temporary_fine_disc.grid.num_cells
            flux_space_size = ny_temp if is_primary_axis_x else nx_temp

        # Define indices for the operator.
        ind_in_list = utils.reorder_list(
            [indices_out.space, indices_out.theta, indices_out.phi], self.permut
        )

        # The flux operator reduces the spatial dimension from the 2-cell wide
        # grid to the 1-cell wide interface. Define the output indices for this.
        flux_space_out = pytens.Index("x", flux_space_size)
        flux_indices_out = Indices(
            space=flux_space_out,
            theta=indices_out.theta,
            phi=indices_out.phi,
            dimension=indices_out.dimension,
        )
        ind_out_unprimed = utils.reorder_list(
            [flux_space_out, indices_out.theta, indices_out.phi], self.permut
        )
        ind_out_list_p = [pytens.Index(f"{i.name}p", i.size) for i in ind_out_unprimed]

        # Build and apply the operator.
        op_func = flux_op_cores.get_op(ind_in_list, ind_out_list_p, 1.0)
        nx_temp = self.plan.temporary_fine_disc.grid.num_cells[0]
        if is_1d:
            reshaped_space = temp_grid_space
        else:
            ny_temp = self.plan.temporary_fine_disc.grid.num_cells[1]
            reshaped_space = {
                key: val.reshape(nx_temp, ny_temp)
                for key, val in temp_grid_space.items()
            }
        tn_op_list = op_func([temp_grid_tn], reshaped_space)
        flux_tn = tn_op_list.evaluate()
        rename_map = dict(zip(ind_out_list_p, ind_out_unprimed, strict=False))
        flux_tn.rename_indices(rename_map)

        return flux_tn, flux_indices_out

    def _scale_flux(
        self,
        flux_tn: pytens.TensorNetwork,
        coarse_disc: Discretization,
        dt: float,
    ) -> pytens.TensorNetwork:
        """Scales a flux tensor to create a contribution for the RHS update.

        Args:
            flux_tn: The `TensorNetwork` representing the physical flux.
            coarse_disc: The discretization of the coarse domain receiving the flux.
            dt: The time step size.

        Returns:
            The scaled `TensorNetwork` ready to be added to the RHS.
        """
        p_ax = 0 if self.plan.direction in [Direction.EAST, Direction.WEST] else 1
        h_p = coarse_disc.grid.dx[p_ax]

        if coarse_disc.dimension == 1:
            transverse_ratio = 1.0
        else:
            t_ax = 1 - p_ax
            H_t = coarse_disc.grid.dx[t_ax]
            h_t = self.plan.temporary_fine_disc.grid.dx[t_ax]
            # We must scale by the ratio of the fine face area to the coarse face area
            # to correctly integrate the flux density over the coarse face.
            transverse_ratio = h_t / H_t

        if self.plan.direction in [Direction.EAST, Direction.NORTH]:
            scale = -dt / h_p
        else:
            scale = +dt / h_p

        return flux_tn.scale(scale * transverse_ratio)

    def _scale_and_scatter_flux_contribution(
        self,
        flux_tn: pytens.TensorNetwork,
        flux_indices: Indices,
        coarse_indices: Indices,
        coarse_disc: Discretization,
        dt: float,
    ) -> pytens.TensorNetwork:
        """Scales and scatters the flux into a corrective RHS term.

        Args:
            flux_tn: The high-fidelity flux on the fine interface grid.
            flux_indices: The indices describing the `flux_tn`.
            coarse_indices: The indices describing the coarse domain's tensor.
            coarse_disc: The discretization of the coarse domain receiving the flux.
            dt: The time step size.

        Returns:
            A TensorNetwork representing the final corrective term, ready to be
            added to the coarse domain's RHS.
        """
        # 1. Define the spatial core function for aggregation and scattering
        coarse_space_size = coarse_indices.space.size
        coarse_map = self.plan.coarse_cell_indices

        def scatter_op(core: np.ndarray) -> np.ndarray:
            """Performs a grouped sum based on the coarse cell map."""
            output_core = np.zeros((coarse_space_size, core.shape[1]))
            np.add.at(output_core, coarse_map, core)
            return output_core

        # 2. Wrap the core function into a full tensor operator
        scatter_tn_op = domain_decomp.transfer_boundaries(
            scatter_op, flux_indices, coarse_indices, self.permut, self.inv_permute
        )
        scattered_flux = scatter_tn_op(flux_tn)

        # 3. Apply the physical scaling
        scaled_flux = self._scale_flux(scattered_flux, coarse_disc, dt)
        return scaled_flux

    def __call__(
        self,
        coarse_sol: solver.Solution,
        fine_ghost_tn: pytens.TensorNetwork,
        fine_spatial_data: dict[str, np.ndarray],
        coarse_disc: Discretization,
        dt: float,
        coarse_indices: Indices,
    ) -> pytens.TensorNetwork:
        """Computes the final, scaled flux correction term for the interface.

        Args:
            coarse_sol: The solution object for the coarse domain.
            fine_ghost_tn: The `TensorNetwork` of raw intensity data received from
                the fine neighbor's buffer.
            fine_spatial_data: A dictionary of raw spatial data arrays (e.g.,
                opacities) received from the fine neighbor's buffer.
            coarse_disc: The discretization of the coarse domain receiving the flux.
            dt: The time step size, used for scaling the flux.
            coarse_indices: The indices describing the coarse domain's tensor.

        Returns:
            A `TensorNetwork` representing the final corrective term, ready to be
            added to the coarse domain's RHS.
        """
        flux_at_interface, indices = self._calculate_high_fidelity_flux(
            coarse_sol, fine_ghost_tn, fine_spatial_data, coarse_indices
        )
        correction_term = self._scale_and_scatter_flux_contribution(
            flux_at_interface, indices, coarse_indices, coarse_disc, dt
        )
        return correction_term


def create_flux_calculator(
    plan: domain_decomp.FluxCorrectionPlan,
    config: Config,
    domain_angles: AngleDiscretization,
    permut: list[int],
    inv_permute: list[int],
    num_sender_indices: int,
) -> FluxCalculator:
    """Instantiates and returns a FluxCalculator object for an interface.

    Args:
        plan: The flux correction plan containing interface indices.
        config: The global configuration object.
        domain_angles: The angular discretization.
        permut: The permutation order for tensor dimensions.
        inv_permute: The inverse permutation order.
        num_sender_indices: The size of the spatial index from the sender.

    Returns:
        A configured FluxCalculator instance.
    """
    return FluxCalculator(
        plan, config, domain_angles, permut, inv_permute, num_sender_indices
    )
