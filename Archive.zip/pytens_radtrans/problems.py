"""Physics/Problem Specifications and utilities."""  # pylint: disable=C0302

import abc
from pathlib import Path
from typing import Any

import matplotlib
import matplotlib.pyplot as plt
import numpy as np
import pytens
import scipy
import scipy.optimize as sciopt
from matplotlib.figure import Figure

from . import bcs, solver
from .discretization import AngleDiscretization, Discretization
from .domain_decomp import DomainManager
from .load_config import (
    Config,
    IdealGas,
)
from .load_config import (
    CrookedPipe as CrookedPipeConfig,
)
from .load_config import (
    GaussianDiffusion as GaussianDiffusionConfig,
)
from .load_config import (
    Hohlraum as HohlraumConfig,
)
from .load_config import (
    LineSource as LineSourceConfig,
)
from .load_config import (
    ThermalRelaxation as ThermalRelaxationConfig,
)
from .types import Direction, NDArrayF

matplotlib.rcParams["mathtext.fontset"] = "stix"
matplotlib.rcParams["font.family"] = "STIXGeneral"
matplotlib.rcParams["font.size"] = 14


def collect_amr_points(
    gathered_data_arrays: list, domain_manager: DomainManager, field: str
) -> tuple[np.ndarray, np.ndarray, np.ndarray]:
    """
    Collects all cell centers and corresponding data values from a list of data arrays
    representing the leaves of a domain manager.

    Args:
        gathered_data_arrays: A list of NumPy arrays, one for each leaf in the domain,
                              ordered by the global leaf index.
        domain_manager: The global DomainManager object.

    Returns:
        A tuple of three 1D arrays: (x_points, y_points, values).
    """
    all_x_pts = []
    all_y_pts = []
    all_vals = []

    for i, leaf in enumerate(domain_manager.leaves):
        # The data for this leaf is the i-th element of the gathered list
        data_arr = gathered_data_arrays[i][field]

        # Ensure the data array is 2D for meshing
        if data_arr.ndim == 1:
            nx, ny = leaf.disc.grid.num_cells
            data_arr = data_arr.reshape((nx, ny))

        # Get the cell center coordinates for this leaf
        xc = leaf.disc.grid.cell_centers[0]
        yc = leaf.disc.grid.cell_centers[1]

        # Create a mesh of coordinates
        X, Y = np.meshgrid(xc, yc, indexing="ij")

        # Flatten the arrays and append them to our master lists
        all_x_pts.append(X.ravel())
        all_y_pts.append(Y.ravel())
        all_vals.append(data_arr.ravel())

    # Concatenate the lists from all leaves into single 1D arrays
    return (
        np.concatenate(all_x_pts),
        np.concatenate(all_y_pts),
        np.concatenate(all_vals),
    )


def collect_leaf_boundaries(
    domain_manager: DomainManager,
) -> list[tuple[list[float], list[float]]]:
    """Collects the boundary lines of all leaves for plotting.

    This is useful for visualizing the domain decomposition in plots.

    Args:
        domain_manager: The global DomainManager object.

    Returns:
        A list of lines, where each line is a tuple of two lists:
        ([x0, x1], [y0, y1]). Each leaf is represented by four such lines,
        forming a rectangle.
    """
    lines = []
    for leaf in domain_manager.leaves:
        xe = leaf.disc.grid.cell_edges[0]
        ye = leaf.disc.grid.cell_edges[1]
        x0, x1 = float(xe[0]), float(xe[-1])
        y0, y1 = float(ye[0]), float(ye[-1])
        # Four edges of the rectangle (each as (xs, ys)):
        lines.append(([x0, x1], [y0, y0]))  # bottom
        lines.append(([x0, x1], [y1, y1]))  # top
        lines.append(([x0, x0], [y0, y1]))  # left
        lines.append(([x1, x1], [y0, y1]))  # right
    return lines


def interpolate_leaf_data_to_grid(
    plot_data: list,
    domain_manager: DomainManager,
    field: str,
    num_grid_pts: int = 500,
) -> tuple[np.ndarray, np.ndarray, np.ndarray, np.ndarray, np.ndarray]:
    """
    Collects, grids, and interpolates data from domain leaves for plotting.

    Args:
        plot_data: A list of dictionaries, one for each leaf.
        domain_manager: The global DomainManager.
        field: The key for the data field to be processed.
        num_grid_pts: The resolution of the output grid.

    Returns:
        A tuple (Xg, Yg, x_grid, y_grid, grid_vals) containing the meshgrid
        coordinates, the 1D grid arrays, and the interpolated data on that grid.
    """
    x_pts, y_pts, vals = collect_amr_points(plot_data, domain_manager, field)

    x_grid = np.linspace(x_pts.min(), x_pts.max(), num_grid_pts)
    y_grid = np.linspace(y_pts.min(), y_pts.max(), num_grid_pts)
    Xg, Yg = np.meshgrid(x_grid, y_grid)

    grid_vals = scipy.interpolate.griddata(
        (x_pts, y_pts), vals, (Xg, Yg), method="linear"
    )
    return Xg, Yg, x_grid, y_grid, grid_vals


class Problem(abc.ABC):
    """Abstract base class for defining a new physics problem.

    A developer implementing a new problem should subclass `Problem` and implement
    the abstract methods to define the initial conditions, boundary conditions,
    and optionally, custom plotting routines.

    Key Methods to Implement:
    - `ic_intensity`: Define the initial state of the radiation intensity field.
    - `ic_space`: Define the initial state of spatial fields like temperature and
      density. The base implementation handles density and opacities based on
      the config file, but this can be extended.
    - `get_bc`: Define the global boundary conditions for the problem.

    Boundary Condition Implementation (`get_bc`):
    The `get_bc` method is called by the framework for each individual subdomain
    (or "leaf") in a decomposed domain, not just once for the global domain.
    The `bounds` argument passed to this method is a list of directions
    indicating which faces of that specific subdomain lie on the global physical
    boundary.

    Therefore, the standard implementation pattern is to check if a direction is
    in the `bounds` list before applying a global boundary condition rule:

    ```python
    def get_bc(self, disc, config, bounds):
        bc_manager = bcs.BoundaryConditions(disc, config, bounds)
        if Direction.WEST in bc_manager.bounds:
            bc_manager.add_condition(Direction.WEST, bcs.MyWestBC())
        # ... other boundaries ...
        return bc_manager
    ```

    This design decouples the global physics definition from the domain
    decomposition and allows for complex boundary conditions that may depend on
    the local discretization (`disc`) of the subdomain.

    Plotting Methods (Optional):
    - `plot_per_step`: Generate a plot for a single time step.
    - `plot_per_step_overlay`: Add data from the current step to a persistent
      figure.
    - `plot_all_sols`: Generate a summary plot at the end of the simulation
      using the complete history.
    """

    def __init__(self, config: Config) -> None:
        """Initializes the Problem.

        Args:
            config: The global configuration object.
        """
        self.config = config
        self.indices = solver.Indices.from_config(config)

    def _create_isotropic_intensity(
        self, spatial_dist: NDArrayF
    ) -> pytens.TensorNetwork:
        """Helper to create an isotropic intensity field."""
        theta = np.ones(self.config.angles.n_theta)
        phi = np.ones(self.config.angles.n_phi)
        ind = [self.indices.space, self.indices.theta, self.indices.phi]
        return ind, [spatial_dist, theta, phi]

    @abc.abstractmethod
    def ic_intensity(self, disc: solver.Discretization) -> pytens.TensorNetwork:
        """Initial conditions for intensity."""

    def ic_space(self, disc: solver.Discretization) -> dict[str, NDArrayF]:
        """Generates initial conditions for spatial variables.

        This base implementation computes density and opacities based on the
        global configuration. Problem subclasses can override this to add or
        modify fields like temperature.

        Args:
            disc: The discretization for the local domain.

        Returns:
            A dictionary containing the initial spatial fields.
        """
        assert self.config.equations.density is not None
        density = disc.to_field(self.config.equations.density)
        spec_absorption_opacity = self.config.equations.specific_absorption_opacity
        spec_scattering_opacity = self.config.equations.specific_scattering_opacity

        absorption_opacity = disc.to_field(spec_absorption_opacity * density)
        scattering_opacity = disc.to_field(spec_scattering_opacity * density)

        return {
            "density": density,
            "absorption_opacity": absorption_opacity,
            "scattering_opacity": scattering_opacity,
        }

    @abc.abstractmethod
    def get_bc(
        self, disc: solver.Discretization, config: Config, bounds: list[Direction]
    ) -> bcs.BoundaryConditions:
        """Gets the boundary conditions for the problem.

        Args:
            disc: The discretization for the local domain.
            config: The global configuration object.
            bounds: A list of directions where this domain has external boundaries.

        Returns:
            A BoundaryConditions object configured for this problem.
        """

    def plot_per_step_overlay(self, *args: Any, **kwargs: Any) -> Figure | None:
        """Generates an overlay plot, adding data from each step to a single figure.

        The base implementation does nothing. Subclasses can override this to provide
        specific overlay plotting behavior.
        """
        return None

    def plot_per_step(
        self,
        _plot_data: list,
        _domain_manager: DomainManager,
        _time: float,
        _iteration: int,
        save_filename: Path | None = None,
    ) -> None:
        """Generates a new plot for each time step.

        The base implementation does nothing. Subclasses can override this to provide
        specific per-step plotting behavior.
        """
        return None

    def plot_all_sols(
        self,
        plot_history: list,
        time_history: list,
        domain_manager: DomainManager,
        **kwargs: Any,
    ) -> Figure | None:
        """Generates a plot using a history of all solutions over time.

        The base implementation does nothing. Subclasses can override this to provide
        a final summary plot at the end of a simulation.
        """
        return None


class GaussianDiffusion1D(Problem):
    """A 1D Gaussian diffusion problem for verification."""

    def __init__(self, config: Config) -> None:
        """Initializes the 1D Gaussian Diffusion problem.

        Args:
            config: The global configuration object.
        """
        super().__init__(config)
        assert config.equations.density is not None

        self.D = config.equations.speed_of_light / (
            3.0
            * config.equations.density
            * config.equations.specific_scattering_opacity
        )

    def get_bc(
        self, disc: Discretization, config: Config, bounds: list[Direction]
    ) -> bcs.BoundaryConditions:
        """Gets the boundary conditions for the problem (outflow on all sides).

        Args:
            disc: The discretization for the local domain.
            config: The global configuration object.
            bounds: A list of directions where this domain has external boundaries.

        Returns:
            A BoundaryConditions object configured with outflow conditions.
        """
        bc_manager = bcs.BoundaryConditions(disc, config, bounds)
        if Direction.WEST in bc_manager.bounds:
            bc_manager.add_condition(Direction.WEST, bcs.Outflow())
        if Direction.EAST in bc_manager.bounds:
            bc_manager.add_condition(Direction.EAST, bcs.Outflow())
        return bc_manager

    def energy_density(self, time: float, disc: Discretization) -> NDArrayF:
        """Computes the analytical energy density at a given time.

        Args:
            time: The simulation time.
            disc: The discretization of the domain.

        Returns:
            An array containing the analytical energy density on the cell centers.
        """
        assert isinstance(self.config.problem, GaussianDiffusionConfig)
        spread = 4 * self.D * (self.config.problem.t0 + time)
        pre = self.config.problem.A / np.sqrt(np.pi * spread)
        exp = np.exp(-(disc.grid.cell_centers[0] ** 2) / spread)
        E: NDArrayF = pre * exp
        return E

    def ic_intensity(self, disc: Discretization) -> pytens.TensorNetwork:
        """Sets the initial conditions for intensity based on the analytical solution.

        Args:
            disc: The discretization of the domain.

        Returns:
            A TensorNetwork representing the initial intensity.
        """
        assert isinstance(self.config.problem, GaussianDiffusionConfig)

        spatial_dist = (
            self.energy_density(0.0, disc)
            * self.config.equations.speed_of_light
            / (4 * np.pi)
        )
        return self._create_isotropic_intensity(spatial_dist)

    def plot_per_step_overlay(
        self,
        plot_data: list,
        domain_manager: DomainManager,
        time: float,
        iteration: int,
        fig: plt.Figure | None = None,
        save_filename: Path | None = None,
    ) -> plt.Figure | None:
        """
        Generates an overlay plot, adding the current time step's data to an
        existing figure.
        """
        initial_fig = False
        if fig is None:
            fig, ax = plt.subplots(1, 1, figsize=(8, 6))
            initial_fig = True
        else:
            # Get the single axis from the existing figure
            ax = fig.get_axes()[0]

        # Loop through each leaf in the domain
        for i, leaf in enumerate(domain_manager.leaves):
            leaf_disc = leaf.disc
            cell_centers = leaf_disc.grid.cell_centers[0]

            mean_intensity = plot_data[i]["mean_intensity"]

            e_numerical = (
                4 * np.pi / self.config.equations.speed_of_light * mean_intensity
            )
            e_analytical = self.energy_density(time, leaf_disc)

            # Draw vertical lines for the boundaries of this leaf domain
            ax.axvline(x=leaf_disc.grid.cell_edges[0][0], color="red")
            ax.axvline(x=leaf_disc.grid.cell_edges[0][-1], color="red")

            # to avoid cluttering the legend with an entry for every single leaf.
            label_analytical = "Analytical" if i == 0 else None
            label_numerical = (
                f"Numerical t={time:.2e}"  # Label numerical solution with time
            )

            # Plot the analytical solution for this leaf
            ax.plot(
                cell_centers,
                e_analytical,
                "--",
                color="black",
                alpha=0.5,
                label=label_analytical,
            )
            # Plot the numerical solution for this leaf
            ax.plot(
                cell_centers,
                e_numerical,
                "-",
                alpha=0.6,
                label=label_numerical,
            )

        # This should only be done once when the figure is first created.
        if initial_fig:
            ax.set_xlabel(r"Space $x$")
            ax.set_ylabel(r"Energy Density $E$")
            ax.set_title("Solution Overlay")
            ax.legend()
            ax.grid(True, linestyle="--", alpha=0.5)

        if save_filename is not None:
            plt.savefig(save_filename)

        return fig


class GaussianDiffusion2D(Problem):
    """A 2D Gaussian diffusion problem for verification."""

    def __init__(self, config: Config) -> None:
        """Initializes the 2D Gaussian Diffusion problem.

        Args:
            config: The global configuration object.
        """
        super().__init__(config)
        assert config.equations.density is not None

        self.D = config.equations.speed_of_light / (
            3.0
            * config.equations.density
            * config.equations.specific_scattering_opacity
        )

    def get_bc(
        self, disc: Discretization, config: Config, bounds: list[Direction]
    ) -> bcs.BoundaryConditions:
        """Gets the boundary conditions for the problem (outflow on all sides).

        Args:
            disc: The discretization for the local domain.
            config: The global configuration object.
            bounds: A list of directions where this domain has external boundaries.

        Returns:
            A BoundaryConditions object configured with outflow conditions.
        """
        bc_manager = bcs.BoundaryConditions(disc, config, bounds)
        if Direction.WEST in bc_manager.bounds:
            bc_manager.add_condition(Direction.WEST, bcs.Outflow())
        if Direction.EAST in bc_manager.bounds:
            bc_manager.add_condition(Direction.EAST, bcs.Outflow())
        if Direction.SOUTH in bc_manager.bounds:
            bc_manager.add_condition(Direction.SOUTH, bcs.Outflow())
        if Direction.NORTH in bc_manager.bounds:
            bc_manager.add_condition(Direction.NORTH, bcs.Outflow())
        return bc_manager

    def edens_meshgrid(self, time: float, xx: NDArrayF, yy: NDArrayF) -> NDArrayF:
        """Computes the analytical energy density on a given meshgrid.

        Args:
            time: The simulation time.
            xx: The x-coordinates of the meshgrid.
            yy: The y-coordinates of the meshgrid.

        Returns:
            An array containing the analytical energy density on the meshgrid.
        """
        assert isinstance(self.config.problem, GaussianDiffusionConfig)
        spread = 4 * self.D * (self.config.problem.t0 + time)
        pre = self.config.problem.A / np.sqrt(np.pi * spread) ** 2
        exp = np.exp(-(xx**2 + yy**2) / spread).T
        E: NDArrayF = pre * exp
        return E

    def energy_density(self, time: float, disc: Discretization) -> NDArrayF:
        """Computes the analytical energy density at a given time.

        Args:
            time: The simulation time.
            disc: The discretization of the domain.

        Returns:
            An array containing the analytical energy density on the cell centers.
        """

        xx, yy = np.meshgrid(disc.grid.cell_centers[0], disc.grid.cell_centers[1])
        return self.edens_meshgrid(time, xx, yy)

    def ic_intensity(self, disc: Discretization) -> pytens.TensorNetwork:
        """Sets the initial conditions for intensity based on the analytical solution.

        Args:
            disc: The discretization of the domain.

        Returns:
            A TensorNetwork representing the initial intensity.
        """
        assert isinstance(self.config.problem, GaussianDiffusionConfig)

        spatial_dist = (
            self.energy_density(0.0, disc).flatten()
            * self.config.equations.speed_of_light
            / (4 * np.pi)
        )
        return self._create_isotropic_intensity(spatial_dist)

    def plot_per_step_overlay(
        self,
        plot_data: list,
        domain_manager: DomainManager,
        time: float,
        iteration: int,
        fig: plt.Figure | None = None,
        save_filename: Path | None = None,
    ) -> plt.Figure | None:
        """Generates an overlay plot of a 1D slice of the 2D domain."""
        initial_fig = False
        if fig is None:
            fig, ax = plt.subplots(1, 1, figsize=(8, 6))
            initial_fig = True
        else:
            ax = fig.get_axes()[0]

        Xg, Yg, x_grid, y_grid, grid_vals = interpolate_leaf_data_to_grid(
            plot_data, domain_manager, "mean_intensity", num_grid_pts=200
        )

        # 5. Calculate numerical and analytical solutions
        epredict = 4 * np.pi / self.config.equations.speed_of_light * grid_vals
        eanalytic = self.edens_meshgrid(time, Xg, Yg).T

        # 6. Plot a slice of the 2D data (e.g., near y=0)
        yloc = 0.0
        # Find the grid index closest to yloc
        index = np.argmin(np.abs(y_grid - yloc))

        # Use different colors to distinguish plots at different times
        normalized_step = iteration / self.config.solver.num_steps
        color = plt.get_cmap("viridis")(normalized_step)

        ax.plot(
            x_grid,
            eanalytic[index, :],
            "--",
            color=color,
            alpha=0.5,
            label="Analytical",
        )
        ax.plot(
            x_grid, epredict[index, :], "-", color=color, alpha=0.8, label="Numerical"
        )

        ax.set_title(f"Solution Overlay up to time t={time:.2e}")

        if initial_fig:
            ax.set_xlabel(r"Space $x$")
            ax.set_ylabel(r"Energy Density $E$ (slice at y $\approx$ 0)")
            ax.set_title("Solution Overlay")
            # ax.legend(loc="center left", bbox_to_anchor=(1, 0.5))
            ax.legend()
            ax.grid(True, linestyle="--", alpha=0.5)

        if save_filename is not None:
            plt.savefig(save_filename, bbox_inches="tight")

        return fig

    def plot_per_step(
        self,
        plot_data: list,
        domain_manager: DomainManager,
        time: float,  # Add time as a direct argument
        iteration: int,
        save_filename: Path | None = None,
    ) -> None:
        """Generates a 2D plot of the solution at a single time step."""
        fig, axs = plt.subplot_mosaic(
            [["numerical", "analytical", "color"], ["error", "error", "color2"]],
            width_ratios=[0.45, 0.45, 0.1],
            layout="constrained",
            figsize=(12, 8),
        )

        Xg, Yg, _, _, grid_vals = interpolate_leaf_data_to_grid(
            plot_data, domain_manager, "mean_intensity"
        )

        # 4. Calculate numerical and analytical solutions
        epredict = 4 * np.pi / self.config.equations.speed_of_light * grid_vals
        eanalytic = self.edens_meshgrid(time, Xg, Yg).T
        err = np.abs(epredict - eanalytic) + 1e-16

        # --- Plotting logic remains the same ---
        pos_n = axs["numerical"].contourf(Xg, Yg, epredict)
        axs["analytical"].contourf(Xg, Yg, eanalytic)
        pos_e = axs["error"].contourf(Xg, Yg, err, cmap="bone")

        lines = collect_leaf_boundaries(domain_manager)
        for ax_key in ["numerical", "analytical", "error"]:
            for xs, ys in lines:
                axs[ax_key].plot(xs, ys, color="r", linewidth=1.0, alpha=0.8)
            axs[ax_key].set(xlabel=r"$x$", ylabel=r"$y$", aspect="equal")

        axs["numerical"].set_title("Numerical")
        axs["analytical"].set_title("Analytical")
        axs["error"].set_title("Error")

        fig.colorbar(pos_n, cax=axs["color"])
        fig.colorbar(pos_e, cax=axs["color2"])

        if save_filename is not None:
            plt.savefig(save_filename)
        plt.close(fig)


class LineSource2D(Problem):
    """A 2D line source problem, which models radiation expanding from a center."""

    def get_bc(
        self, disc: Discretization, config: Config, bounds: list[Direction]
    ) -> bcs.BoundaryConditions:
        """Gets the boundary conditions for the problem (outflow on all sides).

        Args:
            disc: The discretization for the local domain.
            config: The global configuration object.
            bounds: A list of directions where this domain has external boundaries.

        Returns:
            A BoundaryConditions object configured with outflow conditions.
        """
        bc_manager = bcs.BoundaryConditions(disc, config, bounds)
        if Direction.WEST in bc_manager.bounds:
            bc_manager.add_condition(Direction.WEST, bcs.Outflow())
        if Direction.EAST in bc_manager.bounds:
            bc_manager.add_condition(Direction.EAST, bcs.Outflow())
        if Direction.SOUTH in bc_manager.bounds:
            bc_manager.add_condition(Direction.SOUTH, bcs.Outflow())
        if Direction.NORTH in bc_manager.bounds:
            bc_manager.add_condition(Direction.NORTH, bcs.Outflow())
        return bc_manager

    def ic_space(self, disc: solver.Discretization) -> dict[str, NDArrayF]:
        """Sets the initial spatial conditions for a vacuum.

        Args:
            disc: The discretization of the domain.

        Returns:
            A dictionary with all spatial fields set to zero.
        """
        return {
            "density": disc.to_field(0.0),
            "absorption_opacity": disc.to_field(0.0),
            "scattering_opacity": disc.to_field(0.0),
        }

    def energy_density(self, _time: float, disc: Discretization) -> NDArrayF:
        """Computes the initial energy density profile.

        Note: This represents the initial condition, not a time-evolving
        analytical solution.

        Args:
            _time: The simulation time (unused).
            disc: The discretization of the domain.

        Returns:
            An array containing the initial energy density on the cell centers.
        """
        assert isinstance(self.config.problem, LineSourceConfig)

        spread = self.config.problem.omega**2
        u0 = self.config.problem.u0

        pre = u0 / (2 * np.pi * spread)
        xx, yy = np.meshgrid(disc.grid.cell_centers[0], disc.grid.cell_centers[1])
        exp = np.exp(-(xx**2 + yy**2) / (2 * spread))
        E: NDArrayF = pre * exp + 1e-10
        return E

    def ic_intensity(self, disc: Discretization) -> pytens.TensorNetwork:
        """Sets the initial conditions for intensity based on the energy profile.

        Args:
            disc: The discretization of the domain.

        Returns:
            A TensorNetwork representing the initial intensity.
        """
        assert isinstance(self.config.problem, LineSourceConfig)

        spatial_dist = (
            self.energy_density(0.0, disc).transpose().flatten()
            * self.config.equations.speed_of_light
            / (4 * np.pi)
        )
        return self._create_isotropic_intensity(spatial_dist)

    def plot_per_step(
        self,
        plot_data: list,
        domain_manager: DomainManager,
        time: float,
        iteration: int,
        save_filename: Path | None = None,
    ) -> None:
        """Generates a 2D plot of the solution at a single time step."""
        fig, axs = plt.subplot_mosaic(
            [["numerical", "color"]],
            width_ratios=[0.9, 0.1],
            layout="constrained",
            figsize=(8, 6),
        )

        Xg, Yg, x_grid, y_grid, grid_vals = interpolate_leaf_data_to_grid(
            plot_data, domain_manager, "mean_intensity"
        )
        grid_vals *= 4 * np.pi / self.config.equations.speed_of_light

        # 5. Create the plot
        pos_num = axs["numerical"].pcolormesh(
            x_grid, y_grid, grid_vals, rasterized=True, shading="auto"
        )

        # Draw leaf boundaries for context
        lines = collect_leaf_boundaries(domain_manager)
        for xs, ys in lines:
            axs["numerical"].plot(xs, ys, color="r", linewidth=1.0, alpha=0.8)

        fig.colorbar(pos_num, cax=axs["color"])
        axs["numerical"].set_xlabel(r"$x$")
        axs["numerical"].set_ylabel(r"$y$")
        axs["numerical"].set_title(f"Numerical Solution at t={time:.2e}")
        axs["numerical"].set_aspect("equal", "box")

        if save_filename is not None:
            plt.savefig(save_filename)
        plt.close(fig)

    def plot_per_step_overlay(
        self,
        plot_data: list,
        domain_manager: DomainManager,
        time: float,
        iteration: int,
        fig: plt.Figure | None = None,
        save_filename: Path | None = None,
    ) -> plt.Figure | None:
        """
        Calculates the total integrated energy and adds it as a point to an
        overlay plot.
        """
        initial_fig = False
        if fig is None:
            fig, ax = plt.subplots(1, 1, figsize=(8, 6))
            initial_fig = True
        else:
            ax = fig.get_axes()[0]

        # --- FIX: Calculate the TOTAL integral across all leaves ---
        total_integral = 0.0
        for i, leaf in enumerate(domain_manager.leaves):
            # 1. Access the mean_intensity data for this leaf correctly
            mean_intensity = plot_data[i]["mean_intensity"]

            # 2. Reshape and calculate energy density
            epredict = 4 * np.pi / self.config.equations.speed_of_light * mean_intensity
            epredict = epredict.reshape(leaf.disc.grid.num_cells)

            # 3. Calculate the integral for this leaf and add to the total
            leaf_integral = (
                np.sum(epredict) * leaf.disc.grid.dx[0] * leaf.disc.grid.dx[1]
            )
            total_integral += leaf_integral

        # --- FIX: Plot the single, total value against time ---
        ax.plot([time], [total_integral], "ko")

        if initial_fig:
            ax.set_xlabel(r"Time")
            ax.set_ylabel("Total Integrated Energy")
            ax.set_title("Energy Evolution")
            ax.grid(True, linestyle="--")

        if save_filename is not None:
            plt.savefig(save_filename)

        return fig


class ThermalRelaxation(Problem):
    """Base class for thermal relaxation problems."""

    def __init__(self, config: Config) -> None:
        """Initializes the ThermalRelaxation problem and computes the analytic solution.

        Args:
            config: The global configuration object.
        """
        super().__init__(config)
        self.angle_disc = AngleDiscretization.from_config(config)
        assert isinstance(self.config.problem, ThermalRelaxationConfig)

        # Assign complex attributes to local variables first
        density = self.config.equations.density
        source = self.config.equations.source

        # Perform checks and assertions on the simple local variables
        assert isinstance(source, IdealGas)
        shc = source.specific_heat_capacity

        first_term = self.config.equations.radiation_constant
        second_term = 0.0
        if density is not None and shc is not None:
            second_term = density * shc
        third_term = (
            second_term * self.config.problem.Ti
            + self.config.equations.radiation_constant * self.config.problem.Tri**4
        )
        self.analytic_temp = sciopt.fsolve(
            lambda T: first_term * T**4 + second_term * T - third_term,
            self.config.problem.Tri,
            fprime=lambda T: 4 * first_term * T**3 + second_term,
        )

    def plot_all_sols(
        self,
        plot_history: list,
        time_history: list,
        domain_manager: DomainManager,
        **kwargs: Any,
    ) -> Figure | None:
        """Plots the evolution of average matter and radiation temperatures over time.

        Args:
            plot_history: A list (per time step) of lists (per leaf) of plot data dicts.
            time_history: A list of the time for each step.
            domain_manager: The domain manager for the simulation.
            **kwargs: Additional keyword arguments (unused).

        Returns:
            A matplotlib Figure object showing the temperature evolution.
        """
        num_steps = len(time_history)
        ti_arr = np.zeros(num_steps)
        tr_arr = np.zeros(num_steps)

        for t_idx, data_at_time_t in enumerate(plot_history):
            # To get a global average, we need to average across all leaves
            leaf_temperatures = []
            leaf_rad_temperatures = []

            for _leaf_idx, leaf_data in enumerate(data_at_time_t):
                if leaf_data and leaf_data["temperature"] is not None:
                    leaf_temperatures.append(np.mean(leaf_data["temperature"]))
                if leaf_data and leaf_data["mean_intensity"] is not None:
                    J = np.mean(leaf_data["mean_intensity"])
                    E = 4 * np.pi / self.config.equations.speed_of_light * J
                    Tr = (E / self.config.equations.radiation_constant) ** 0.25
                    leaf_rad_temperatures.append(Tr)

            if leaf_temperatures:
                ti_arr[t_idx] = np.mean(leaf_temperatures)
            if leaf_rad_temperatures:
                tr_arr[t_idx] = np.mean(leaf_rad_temperatures)

        times = np.array(time_history)

        assert self.config.equations.density is not None
        norm = (
            self.config.equations.speed_of_light
            * self.config.equations.specific_absorption_opacity
            * self.config.equations.density
        )
        times = times * norm
        fig = plt.figure()
        plt.plot(times, ti_arr, "-k", label="Avg Temp")
        plt.plot(times, tr_arr, "-c", label="Radiation Temp")
        plt.plot(times, self.analytic_temp + 0 * ti_arr, "-r", label="Teq, analytic")
        plt.ylabel("Temperature")
        plt.xlabel(r"$t  [c \alpha_a]$")
        plt.legend()
        return fig


class ThermalRelaxation1D(ThermalRelaxation):
    """A 1D thermal relaxation problem where matter and radiation equilibrate."""

    def get_bc(
        self, disc: Discretization, config: Config, bounds: list[Direction]
    ) -> bcs.BoundaryConditions:
        """Gets the boundary conditions for the problem (periodic on all sides).

        Args:
            disc: The discretization for the local domain.
            config: The global configuration object.
            bounds: A list of directions where this domain has external boundaries.

        Returns:
            A BoundaryConditions object configured with periodic conditions.
        """
        bc_manager = bcs.BoundaryConditions(disc, config, bounds)

        # Periodic BCs
        if Direction.WEST in bc_manager.bounds:
            # bc_manager.add_condition(Direction.WEST, bcs.Outflow())
            bc_manager.add_condition(Direction.WEST, bcs.Periodic())
        if Direction.EAST in bc_manager.bounds:
            # bc_manager.add_condition(Direction.EAST, bcs.Outflow())
            bc_manager.add_condition(Direction.EAST, bcs.Periodic())

        return bc_manager

    def ic_space(self, disc: Discretization) -> dict[str, NDArrayF]:
        """Sets the initial spatial conditions, including matter temperature.

        Args:
            disc: The discretization of the domain.

        Returns:
            A dictionary containing the initial spatial fields.
        """
        assert isinstance(self.config.problem, ThermalRelaxationConfig)
        space_ics = super().ic_space(disc)

        To = self.config.problem.Ti
        space_ics["temperature"] = np.ones(disc.grid.num_cells[0]) * To
        return space_ics

    def ic_intensity(self, disc: Discretization) -> pytens.TensorNetwork:
        """Sets the initial radiation intensity based on an initial radiation
        temperature.

        Args:
            disc: The discretization of the domain.

        Returns:
            A TensorNetwork representing the initial intensity.
        """
        assert isinstance(self.config.problem, ThermalRelaxationConfig)
        To = self.config.problem.Tri
        E = self.config.equations.radiation_constant * To**4
        ic = self.config.equations.speed_of_light * E / 4.0 / np.pi

        x = np.ones(disc.grid.num_cells[0]) * ic
        theta = np.ones(self.config.angles.n_theta)
        phi = np.ones(self.config.angles.n_phi)
        ind = [self.indices.space, self.indices.theta, self.indices.phi]
        f = (ind, [x, theta, phi])

        return f

    def plot_per_step_overlay(
        self,
        plot_data: list,
        domain_manager: DomainManager,
        time: float,
        iteration: int,
        fig: Figure | None = None,
        save_filename: Path | None = None,
    ) -> Figure | None:
        """Generates an overlay plot of matter and radiation temperature profiles.

        This method adds the current time step's temperature profiles to an
        existing figure, allowing visualization of the relaxation process over time.
        """
        initial_fig = False
        if fig is None:
            initial_fig = True
            fig, ax = plt.subplots(1, 1)
        else:
            ax = fig.get_axes()[0]

        for i, leaf in enumerate(domain_manager.leaves):
            leaf_disc = leaf.disc
            cell_centers = leaf_disc.grid.cell_centers[0]

            mean_intensity = plot_data[i]["mean_intensity"]
            temperature = plot_data[i]["temperature"]

            E = 4 * np.pi / self.config.equations.speed_of_light * mean_intensity
            Tr = (E / self.config.equations.radiation_constant) ** 0.25

            if initial_fig:
                ax.plot(
                    cell_centers,
                    temperature,
                    "-k",
                    alpha=0.2,
                    label="T" if i == 0 else None,
                )
                ax.plot(
                    cell_centers, Tr, "-c", alpha=0.2, label="Tr" if i == 0 else None
                )
                ax.plot(
                    cell_centers,
                    0 * cell_centers + self.analytic_temp,
                    "-r",
                    label="analytic" if i == 0 else None,
                )
            else:
                ax.plot(cell_centers, temperature, "--k", alpha=0.2)
                ax.plot(cell_centers, Tr, "--c", alpha=0.8)

        if initial_fig:
            ax.set_xlabel(r"Space $x$")
            ax.set_ylabel(r"Temp")
            ax.legend()

        if save_filename is not None:
            plt.savefig(save_filename)

        return fig


class ThermalRelaxation2D(ThermalRelaxation):
    """A 2D thermal relaxation problem where matter and radiation equilibrate."""

    def get_bc(
        self, disc: Discretization, config: Config, bounds: list[Direction]
    ) -> bcs.BoundaryConditions:
        """Gets the boundary conditions for the problem (periodic on all sides).

        Args:
            disc: The discretization for the local domain.
            config: The global configuration object.
            bounds: A list of directions where this domain has external boundaries.

        Returns:
            A BoundaryConditions object configured with periodic conditions.
        """
        bc_manager = bcs.BoundaryConditions(disc, config, bounds)

        # Periodic BCs
        if Direction.WEST in bc_manager.bounds:
            bc_manager.add_condition(Direction.WEST, bcs.Periodic())
        if Direction.EAST in bc_manager.bounds:
            bc_manager.add_condition(Direction.EAST, bcs.Periodic())
        if Direction.SOUTH in bc_manager.bounds:
            bc_manager.add_condition(Direction.SOUTH, bcs.Periodic())
        if Direction.NORTH in bc_manager.bounds:
            bc_manager.add_condition(Direction.NORTH, bcs.Periodic())

        return bc_manager

    def ic_space(self, disc: Discretization) -> dict[str, NDArrayF]:
        """Sets the initial spatial conditions, including matter temperature.

        Args:
            disc: The discretization of the domain.

        Returns:
            A dictionary containing the initial spatial fields.
        """
        assert isinstance(self.config.problem, ThermalRelaxationConfig)
        space_ics = super().ic_space(disc)

        To = self.config.problem.Ti
        space_ics["temperature"] = np.ones(disc.grid.num_cells) * To
        return space_ics

    def ic_intensity(self, disc: Discretization) -> pytens.TensorNetwork:
        """Sets the initial radiation intensity based on an initial radiation
        temperature.

        Args:
            disc: The discretization of the domain.

        Returns:
            A TensorNetwork representing the initial intensity.
        """
        assert isinstance(self.config.problem, ThermalRelaxationConfig)
        To = self.config.problem.Tri
        E = self.config.equations.radiation_constant * To**4
        ic = self.config.equations.speed_of_light * E / 4.0 / np.pi

        xy = np.ones(disc.grid.num_cells) * ic

        xy = xy.flatten()
        theta = np.ones(self.config.angles.n_theta)
        phi = np.ones(self.config.angles.n_phi)
        ind = [self.indices.space, self.indices.theta, self.indices.phi]
        f = (ind, [xy, theta, phi])

        return f


class Hohlraum1D(Problem):
    """A 1D Hohlraum problem, modeling a radiation wave entering a cold vacuum."""

    def get_bc(
        self, disc: Discretization, config: Config, bounds: list[Direction]
    ) -> bcs.BoundaryConditions:
        """Gets boundary conditions: Dirichlet on the left, outflow on the right.

        Args:
            disc: The discretization for the local domain.
            config: The global configuration object.
            bounds: A list of directions where this domain has external boundaries.

        Returns:
            A BoundaryConditions object configured for the Hohlraum problem.
        """
        bc_manager = bcs.BoundaryConditions(disc, config, bounds)

        # Dirichlet (fill=1.0) on WEST, outflow on EAST.
        if Direction.WEST in bc_manager.bounds:
            bc_manager.add_condition(Direction.WEST, bcs.Dirichlet(1.0))
        if Direction.EAST in bc_manager.bounds:
            bc_manager.add_condition(Direction.EAST, bcs.Outflow())

        return bc_manager

    def ic_space(self, disc: solver.Discretization) -> dict[str, NDArrayF]:
        """Sets the initial spatial conditions for a vacuum.

        Args:
            disc: The discretization of the domain.

        Returns:
            A dictionary with all spatial fields set to zero.
        """
        return {
            "density": disc.to_field(0.0),
            "absorption_opacity": disc.to_field(0.0),
            "scattering_opacity": disc.to_field(0.0),
        }

    def ic_intensity(self, disc: Discretization) -> pytens.TensorNetwork:
        """Sets the initial intensity to zero everywhere.

        Args:
            disc: The discretization of the domain.

        Returns:
            A TensorNetwork representing zero initial intensity.
        """
        spatial_dist = np.zeros(disc.grid.num_cells[0])
        return self._create_isotropic_intensity(spatial_dist)

    def plot_all_sols(
        self,
        plot_history: list,
        time_history: list,
        domain_manager: DomainManager,
        **kwargs: Any,
    ) -> plt.Figure | None:
        """
        Plots a 1D summary of the solution's evolution over time, stitching
        together all domains.
        """
        # --- 1. Extract mean intensity history from the plot data ---
        if not plot_history or not plot_history[0]:
            return None

        # Check for AMR (variable number of domains)
        num_leaves_final = len(domain_manager.leaves)
        if len(plot_history[0]) != num_leaves_final:
            # If the number of domains at t=0 differs from t=final, we assume AMR
            # and skip this static-grid summary plot.
            return None

        mean_intensity_history = [
            [leaf_data["mean_intensity"] for leaf_data in data_at_time_t]
            for data_at_time_t in plot_history
        ]

        # --- 2. Stitch the data from all leaves into a single, continuous domain ---
        num_times = len(time_history)

        # Create the stitched spatial grid by concatenating the cell centers
        # from each leaf
        stitched_cell_centers = np.concatenate(
            [leaf.disc.grid.cell_centers[0] for leaf in domain_manager.leaves]
        )

        # Create the stitched data array for mean intensity (space vs. time)
        stitched_mean_intensity_data = np.zeros((len(stitched_cell_centers), num_times))

        for t in range(num_times):
            # Check consistency at each step
            if len(mean_intensity_history[t]) != num_leaves_final:
                return None

            # Collect the mean intensity array from each leaf at the current time step
            means_at_t = [
                mean_intensity_history[t][leaf_idx].flatten()
                for leaf_idx in range(num_leaves_final)
            ]
            # Concatenate them into a single column for this time step
            stitched_mean_intensity_data[:, t] = np.concatenate(means_at_t)

        # --- 3. Create the plots using the stitched data ---
        fig, axs = plt.subplot_mosaic(
            [["numerical", "analytical", "color"], ["error", "error", "color2"]],
            width_ratios=[0.45, 0.45, 0.1],
            figsize=(12, 8),
            layout="constrained",
        )

        tt, xx = np.meshgrid(time_history, stitched_cell_centers)
        levels = np.linspace(
            np.min(stitched_mean_intensity_data),
            np.max(stitched_mean_intensity_data),
            10,
        )

        # -- Numerical Solution Plot --
        pos1 = axs["numerical"].contourf(
            tt, xx, stitched_mean_intensity_data, levels=levels
        )
        axs["numerical"].set(xlabel="Time", ylabel="Space", title="Numerical Solution")
        fig.colorbar(pos1, cax=axs["color"])

        # -- Analytical Solution Plot --
        analytical_data = np.zeros_like(stitched_mean_intensity_data)
        for t_idx, time_val in enumerate(time_history):
            ct = self.config.equations.speed_of_light * time_val
            analytic = 0.5 * (1 - stitched_cell_centers / (ct + 1e-16))
            analytic[stitched_cell_centers > ct] = 0.0  # Set to 0 for clarity
            analytical_data[:, t_idx] = analytic

        axs["analytical"].contourf(tt, xx, analytical_data, levels=levels)
        axs["analytical"].set(
            xlabel="Time", ylabel="Space", title="Analytical Solution"
        )

        # -- Error Plot --
        # Add a small epsilon to avoid log(0) issues
        err = np.abs(stitched_mean_intensity_data - analytical_data) + 1e-16
        pos2 = axs["error"].contourf(tt, xx, err, cmap="bone")
        axs["error"].set(xlabel="Time", ylabel="Space", title="Absolute Error")
        fig.colorbar(pos2, cax=axs["color2"])

        return fig

    def plot_per_step_overlay(
        self,
        plot_data: list,
        domain_manager: DomainManager,
        time: float,
        iteration: int,
        fig: Figure | None = None,
        save_filename: Path | None = None,
    ) -> Figure | None:
        """Generates an overlay plot of the mean intensity profile.

        This method adds the current time step's intensity profile to an
        existing figure.
        """
        if fig is None:
            fig, ax = plt.subplots(1, 1)
        else:
            axes = fig.get_axes()
            assert len(axes) == 1
            ax = axes[0]

        for ii, leaf in enumerate(domain_manager.leaves):
            y = plot_data[ii]["mean_intensity"]
            ax.plot(leaf.disc.grid.cell_centers[0], y, "-", color="black", alpha=0.2)
            # Use low alpha so persistent boundaries get darker, while
            # coarsened (removed) boundaries stay faint.
            ax.axvline(x=leaf.disc.grid.cell_edges[0][0], color="red", alpha=0.1)
            ax.axvline(x=leaf.disc.grid.cell_edges[0][-1], color="red", alpha=0.1)

        ax.set_xlabel(r"Space $x$")
        ax.set_ylabel(r"Mean intensity $J$")

        if save_filename:
            plt.savefig(save_filename)

        return fig

    def plot_per_step(
        self,
        plot_data: list,
        domain_manager: DomainManager,
        time: float,
        iteration: int,
        save_filename: Path | None = None,
    ) -> None:
        """Generates a snapshot plot of the solution and grid for the current step."""
        fig, ax = plt.subplots(1, 1, figsize=(8, 6))

        for ii, leaf in enumerate(domain_manager.leaves):
            y = plot_data[ii]["mean_intensity"]
            # Plot solution
            ax.plot(
                leaf.disc.grid.cell_centers[0],
                y,
                "o-",
                markersize=2,
                label=f"Domain {ii}",
            )
            # Plot domain boundaries clearly
            ax.axvline(
                x=leaf.disc.grid.cell_edges[0][0],
                color="red",
                linestyle="--",
                alpha=0.5,
            )
            ax.axvline(
                x=leaf.disc.grid.cell_edges[0][-1],
                color="red",
                linestyle="--",
                alpha=0.5,
            )

        ax.set_xlabel(r"Space $x$")
        ax.set_ylabel(r"Mean intensity $J$")
        ax.set_title(
            f"Step {iteration}, Time {time:.2e} (Domains: {len(domain_manager.leaves)})"
        )
        ax.grid(True, alpha=0.3)

        if save_filename:
            plt.savefig(save_filename)
        plt.close(fig)


class Hohlraum2D(Problem):
    """A 2D Hohlraum problem, modeling radiation entering from a corner."""

    def get_bc(
        self, disc: Discretization, config: Config, bounds: list[Direction]
    ) -> bcs.BoundaryConditions:
        """Gets boundary conditions: Dirichlet on left/bottom, outflow on right/top.

        Args:
            disc: The discretization for the local domain.
            config: The global configuration object.
            bounds: A list of directions where this domain has external boundaries.

        Returns:
            A BoundaryConditions object configured for the 2D Hohlraum problem.
        """
        bc_manager = bcs.BoundaryConditions(disc, config, bounds)

        if Direction.WEST in bc_manager.bounds:
            bc_manager.add_condition(Direction.WEST, bcs.Dirichlet(1.0))
        if Direction.SOUTH in bc_manager.bounds:
            bc_manager.add_condition(Direction.SOUTH, bcs.Dirichlet(1.0))
        if Direction.EAST in bc_manager.bounds:
            bc_manager.add_condition(Direction.EAST, bcs.Outflow())
        if Direction.NORTH in bc_manager.bounds:
            bc_manager.add_condition(Direction.NORTH, bcs.Outflow())

        return bc_manager

    def ic_space(self, disc: solver.Discretization) -> dict[str, NDArrayF]:
        """Sets the initial spatial conditions for a vacuum.

        Args:
            disc: The discretization of the domain.

        Returns:
            A dictionary with all spatial fields set to zero.
        """
        return {
            "density": disc.to_field(0.0),
            "absorption_opacity": disc.to_field(0.0),
            "scattering_opacity": disc.to_field(0.0),
        }

    def ic_intensity(self, disc: Discretization) -> pytens.TensorNetwork:
        """Sets the initial intensity to zero everywhere.

        Args:
            disc: The discretization of the domain.

        Returns:
            A TensorNetwork representing zero initial intensity.
        """
        spatial_dist = np.zeros(disc.grid.num_cells).flatten()
        return self._create_isotropic_intensity(spatial_dist)

    def analytic_sol_on_mesh(
        self,
        time: float,
        cell_x: NDArrayF,
        cell_y: NDArrayF,
        xx: NDArrayF,
        yy: NDArrayF,
    ) -> NDArrayF:
        """Computes the analytical solution on a given meshgrid.

        Args:
            time: The simulation time.
            cell_x: The 1D array of x-coordinates for the grid.
            cell_y: The 1D array of y-coordinates for the grid.
            xx: The 2D meshgrid of x-coordinates.
            yy: The 2D meshgrid of y-coordinates.

        Returns:
            An array containing the analytical mean intensity on the meshgrid.
        """
        jleft = np.zeros(xx.shape)
        jbottom = np.zeros(xx.shape)

        ct = self.config.equations.speed_of_light * time
        ind_x = cell_x < ct
        xx_eta_x = xx[:, ind_x]
        yy_eta_x = yy[:, ind_x]
        term1 = yy_eta_x / np.sqrt(ct**2 - xx_eta_x**2)
        term1[term1 > 1] = 1
        eta_x = np.arccos(term1)
        jleft[:, ind_x] = (
            0.5
            - (np.pi - eta_x) * xx_eta_x / (2 * np.pi * ct)
            - 0.5
            / np.pi
            * np.arcsin(
                xx_eta_x * np.sin(eta_x) / np.sqrt(xx_eta_x**2 + yy_eta_x**2 + 1e-16)
            )
        )

        ind_y = cell_y < ct
        xx_eta_y = xx[ind_y, :]
        yy_eta_y = yy[ind_y, :]
        term2 = xx_eta_y / np.sqrt(ct**2 - yy_eta_y**2)
        term2[term2 > 1] = 1
        eta_y = np.arccos(term2)
        jbottom[ind_y, :] = (
            0.5
            - (np.pi - eta_y) * yy_eta_y / (2 * np.pi * ct)
            - 0.5
            / np.pi
            * np.arcsin(
                yy_eta_y * np.sin(eta_y) / np.sqrt(xx_eta_y**2 + yy_eta_y**2 + 1e-16)
            )
        )

        j = jleft + jbottom
        return j

    def analytic_sol(  # pylint: disable=R0914
        self, time: float, disc: Discretization
    ) -> np.ndarray:
        """Computes the analytical solution on the domain's cell centers.

        Args:
            time: The simulation time.
            disc: The discretization of the domain.

        Returns:
            An array containing the analytical mean intensity on the cell centers.
        """
        xx, yy = np.meshgrid(disc.grid.cell_centers[0], disc.grid.cell_centers[1])
        return self.analytic_sol_on_mesh(
            time, disc.grid.cell_centers[0], disc.grid.cell_centers[1], xx, yy
        )

    def plot_per_step(
        self,
        plot_data: list,
        domain_manager: DomainManager,
        time: float,
        iteration: int,
        save_filename: Path | None = None,
    ) -> None:
        """
        Generates a 2D plot of the solution at a single time step.
        """
        fig, axs = plt.subplot_mosaic(
            [["numerical", "analytical", "color"], ["error", "error", "color2"]],
            width_ratios=[0.45, 0.45, 0.1],
            layout="constrained",
            figsize=(12, 8),
        )

        # Interpolate numerical data and get analytical solution on the same grid
        Xg, Yg, x_grid, y_grid, grid_vals = interpolate_leaf_data_to_grid(
            plot_data, domain_manager, "mean_intensity"
        )
        analytical_vals = self.analytic_sol_on_mesh(time, x_grid, y_grid, Xg, Yg)
        err = np.abs(grid_vals - analytical_vals) + 1e-16

        pos_num = axs["numerical"].pcolormesh(
            x_grid, y_grid, grid_vals, vmin=0.0, vmax=1.0, rasterized=True
        )
        axs["analytical"].pcolormesh(
            x_grid, y_grid, analytical_vals, vmin=0.0, vmax=1.0, rasterized=True
        )
        pos_e = axs["error"].pcolormesh(
            x_grid, y_grid, err, cmap="bone", rasterized=True
        )

        # Draw leaf boundaries for context (assuming this helper exists)
        lines = collect_leaf_boundaries(domain_manager)
        for ax_key in ["numerical", "analytical", "error"]:
            for xs, ys in lines:
                axs[ax_key].plot(xs, ys, color="r", linewidth=1.0, alpha=0.8)
            axs[ax_key].set(xlabel=r"$x$", ylabel=r"$y$", aspect="equal")

        axs["numerical"].set_title("Numerical")
        axs["analytical"].set_title("Analytical")
        axs["error"].set_title("Error")

        fig.colorbar(pos_num, cax=axs["color"])
        fig.colorbar(pos_e, cax=axs["color2"])

        if save_filename is not None:
            plt.savefig(save_filename)
        plt.close(fig)


class CrookedPipe(Problem):  # pylint: disable=R0902
    """A 2D problem modeling radiation flow through a bent pipe."""

    def __init__(self, config: Config) -> None:
        """Initializes the Crooked Pipe problem.

        Args:
            config: The global configuration object.
        """
        super().__init__(config)
        assert isinstance(config.problem, CrookedPipeConfig)

        self.rho_wall = config.problem.wall_density
        self.specific_absorption_opacity_wall = (
            config.problem.wall_specific_absorption_opacity
        )

        self.rho_pipe = config.problem.pipe_density
        self.specific_absorption_opacity_pipe = (
            config.problem.pipe_specific_absorption_opacity
        )

        self.specific_scattering_opacity = 0.0

        self.temp_rad_background = config.problem.background_temperature
        self.temp_source = config.problem.source_temperature

        self.intensity_source = (
            self.config.equations.speed_of_light
            * self.config.equations.radiation_constant
            * self.temp_source**4
            / (4 * np.pi)
        )

    def ic_intensity(self, disc: Discretization) -> pytens.TensorNetwork:
        """Sets the initial intensity based on a background temperature.

        Args:
            disc: The discretization of the domain.

        Returns:
            A TensorNetwork representing the initial intensity.
        """

        intensity_val = (
            self.config.equations.speed_of_light
            * self.config.equations.radiation_constant
            * self.temp_rad_background**4
            / (4 * np.pi)
        )
        spatial_dist = np.ones(disc.grid.num_cells).flatten() * intensity_val
        return self._create_isotropic_intensity(spatial_dist)

    def _get_pipe_mask(self, disc: Discretization) -> np.ndarray:
        """Returns a boolean mask where True indicates a cell is inside the pipe."""
        pipe_mask = np.zeros(disc.grid.num_cells, dtype=bool)
        x_centers = disc.grid.cell_centers[0]
        y_centers = disc.grid.cell_centers[1]

        # pipe part 1
        ind_x = x_centers < -1.0
        ind_y = (y_centers > -0.5) & (y_centers < 0.5)
        pipe_mask[np.ix_(ind_x, ind_y)] = True

        # pipe part 2
        ind_x = (x_centers > -1.0) & (x_centers <= -0.5)
        ind_y = (y_centers > -1.5) & (y_centers <= 1.5)
        pipe_mask[np.ix_(ind_x, ind_y)] = True

        # pipe part 3a
        ind_x = (x_centers > -0.5) & (x_centers <= 0.5)
        ind_y = (y_centers > -1.5) & (y_centers <= -1.0)
        pipe_mask[np.ix_(ind_x, ind_y)] = True

        # pipe part 3b
        ind_x = (x_centers > -0.5) & (x_centers <= 0.5)
        ind_y = (y_centers > 1.0) & (y_centers <= 1.5)
        pipe_mask[np.ix_(ind_x, ind_y)] = True

        # pipe part 4
        ind_x = (x_centers > 0.5) & (x_centers <= 1.0)
        ind_y = (y_centers > -1.5) & (y_centers <= 1.5)
        pipe_mask[np.ix_(ind_x, ind_y)] = True

        # pipe part 5
        ind_x = x_centers > 1.0
        ind_y = (y_centers > -0.5) & (y_centers < 0.5)
        pipe_mask[np.ix_(ind_x, ind_y)] = True

        return pipe_mask

    def ic_space(self, disc: Discretization) -> dict[str, NDArrayF]:
        """Sets the initial spatial conditions based on the pipe geometry.

        Args:
            disc: The discretization of the domain.

        Returns:
            A dictionary containing the initial spatial fields, with different
            properties inside and outside the pipe.
        """
        pipe_mask = self._get_pipe_mask(disc)

        density = np.where(pipe_mask, self.rho_pipe, self.rho_wall)
        spec_absorption_opacity = np.where(
            pipe_mask,
            self.specific_absorption_opacity_pipe,
            self.specific_absorption_opacity_wall,
        )

        spec_scattering_opacity = np.zeros(disc.grid.num_cells)
        temp = np.ones(disc.grid.num_cells) * self.temp_rad_background

        absorption_opacity = spec_absorption_opacity * density
        scattering_opacity = spec_scattering_opacity * density

        return {
            "temperature": temp,
            "density": density,
            "absorption_opacity": absorption_opacity,
            "scattering_opacity": scattering_opacity,
        }

    def get_bc(
        self, disc: Discretization, config: Config, bounds: list[Direction]
    ) -> bcs.BoundaryConditions:
        """Gets the boundary conditions for the pipe.

        This includes a mixed Dirichlet condition on the left boundary (source
        and wall) and outflow on all other sides.

        Args:
            disc: The discretization for the local domain.
            config: The global configuration object.
            bounds: A list of directions where this domain has external boundaries.

        Returns:
            A BoundaryConditions object configured for the Crooked Pipe problem.
        """
        bc_manager = bcs.BoundaryConditions(disc, config, bounds)

        # Construct the special Dirichlet array for the WEST boundary,
        # which is a mix of a source inlet and a zero-value wall.
        y_centers = disc.grid.cell_centers[1]
        inlet_y_min = -0.5
        inlet_y_max = 0.5
        left_bc_array = np.zeros_like(y_centers)
        inlet_indices = np.where((y_centers > inlet_y_min) & (y_centers < inlet_y_max))
        left_bc_array[inlet_indices] = self.intensity_source

        if Direction.WEST in bc_manager.bounds:
            bc_manager.add_condition(Direction.WEST, bcs.Dirichlet(left_bc_array))
        if Direction.EAST in bc_manager.bounds:
            bc_manager.add_condition(Direction.EAST, bcs.Outflow())
        if Direction.SOUTH in bc_manager.bounds:
            bc_manager.add_condition(Direction.SOUTH, bcs.Outflow())
        if Direction.NORTH in bc_manager.bounds:
            bc_manager.add_condition(Direction.NORTH, bcs.Outflow())

        return bc_manager

    def _plot_pipe_outline(self, ax: plt.Axes) -> None:
        """Helper to draw the crooked pipe outline on a matplotlib axis."""
        linecolor = "red"
        # Define pipe segments as lists of (x_coords, y_coords) tuples
        segments = [
            # Bottom outline
            ([-3.5, -1.0], [-0.5, -0.5]),
            ([-1.0, -1.0], [-0.5, -1.5]),
            ([-1.0, 1.0], [-1.5, -1.5]),
            ([1.0, 1.0], [-1.5, -0.5]),
            ([1.0, 3.5], [-0.5, -0.5]),
            # Top outline
            ([-3.5, -1.0], [0.5, 0.5]),
            ([-1.0, -1.0], [0.5, 1.5]),
            ([-1.0, 1.0], [1.5, 1.5]),
            ([1.0, 1.0], [1.5, 0.5]),
            ([1.0, 3.5], [0.5, 0.5]),
            # Inner box
            ([-0.5, -0.5], [-1.0, 1.0]),
            ([-0.5, 0.5], [1.0, 1.0]),
            ([0.5, 0.5], [1.0, -1.0]),
            ([0.5, -0.5], [-1.0, -1.0]),
        ]
        for x_coords, y_coords in segments:
            ax.plot(x_coords, y_coords, color=linecolor)

    def plot_per_step(
        self,
        plot_data: list,
        domain_manager: DomainManager,
        time: float,
        iteration: int,
        save_filename: Path | None = None,
    ) -> None:
        """Generates a 2D plot of mean intensity and temperature.

        This method creates a two-panel plot showing the state of the radiation
        and matter fields at a single time step, with the pipe geometry and
        domain decomposition overlaid.
        """
        fig, axs = plt.subplot_mosaic(
            # [["intensity", "colorJ"], ["temperature", "colorT"]],
            # width_ratios=[0.9, 0.1],
            [["intensity"], ["temperature"]],
            width_ratios=[1.0],
            layout="constrained",
            sharex=True,
        )

        # --- Collect and Interpolate Intensity Data ---
        Xg, Yg, _, _, intensity_grid = interpolate_leaf_data_to_grid(
            plot_data, domain_manager, "mean_intensity"
        )

        # --- Collect and Interpolate Temperature Data ---
        # Interpolate temperature data onto the same grid
        x_pts_t, y_pts_t, tvals = collect_amr_points(
            plot_data, domain_manager, "temperature"
        )
        temperature_grid = scipy.interpolate.griddata(
            (x_pts_t, y_pts_t), tvals, (Xg, Yg), method="linear"
        )

        # --- Plotting ---
        c = self.config.equations.speed_of_light
        a = self.config.equations.radiation_constant
        vmin_J = (c * a * self.temp_rad_background**4) / (4 * np.pi)
        vmax_J = (c * a * self.temp_source**4) / (4 * np.pi)

        axs["intensity"].pcolormesh(
            Xg,
            Yg,
            # intensity_grid,
            np.log10(intensity_grid),
            rasterized=True,
            # vmin=vmin_J,
            # vmax=vmax_J,
            vmin=np.log10(vmin_J),
            vmax=np.log10(vmax_J),
            cmap="plasma",
            shading="auto",
        )
        axs["intensity"].set_ylabel("y")
        axs["intensity"].set_title(f"Mean Intensity at t={time:.2e}")

        axs["temperature"].pcolormesh(
            Xg,
            Yg,
            # temperature_grid,
            np.log10(temperature_grid),
            rasterized=True,
            # vmin=self.temp_rad_background,
            # vmax=self.temp_source,
            vmin=np.log10(self.temp_rad_background),
            vmax=np.log10(self.temp_source),
            cmap="inferno",
            shading="auto",
        )
        axs["temperature"].set_xlabel("x")
        axs["temperature"].set_ylabel("y")
        axs["temperature"].set_title("Temperature")

        # Draw the pipe outline on both plots
        self._plot_pipe_outline(axs["intensity"])
        self._plot_pipe_outline(axs["temperature"])

        # Draw leaf boundaries on both plots
        lines = collect_leaf_boundaries(domain_manager)
        for xs, ys in lines:
            axs["intensity"].plot(
                xs, ys, color="white", linestyle="--", linewidth=1.0, alpha=0.8
            )
            axs["temperature"].plot(
                xs, ys, color="white", linestyle="--", linewidth=1.0, alpha=0.8
            )

        if save_filename is not None:
            plt.savefig(save_filename)
        # exit(1)
        plt.close(fig)


def load_problem(config: Config) -> Problem:
    """Load a problem."""
    prob: Problem | None = None
    if isinstance(config.problem, HohlraumConfig):
        if config.geometry.dimension == 1:
            prob = Hohlraum1D(config)
        else:
            prob = Hohlraum2D(config)
    elif isinstance(config.problem, ThermalRelaxationConfig):
        if config.geometry.dimension == 1:
            prob = ThermalRelaxation1D(config)
        else:
            prob = ThermalRelaxation2D(config)
    elif isinstance(config.problem, GaussianDiffusionConfig):
        if config.geometry.dimension == 1:
            prob = GaussianDiffusion1D(config)
        else:
            prob = GaussianDiffusion2D(config)
    elif isinstance(config.problem, LineSourceConfig):
        prob = LineSource2D(config)
    elif isinstance(config.problem, CrookedPipeConfig):
        prob = CrookedPipe(config)
    else:
        raise NotImplementedError(f"Problem name: {config.problem.name}")

    assert prob is not None
    return prob
