"""Centralized runtime contracts for distributed ownership and load balancing.

These helpers enforce invariants that static typing cannot prove in MPI runs:
leaf ownership, sender/receiver consistency, and migration-map validity.
"""

from collections.abc import Mapping, Sequence
from typing import Any

import numpy as np


def build_local_index_to_pos(local_indices: Sequence[int], rank: int) -> dict[int, int]:
    """Builds a local leaf-index lookup and rejects duplicate ownership."""
    index_to_pos = {idx: i for i, idx in enumerate(local_indices)}
    if len(index_to_pos) != len(local_indices):
        raise RuntimeError(
            "Local index map is invalid: duplicate leaf index on one rank."
        )
    return index_to_pos


def validate_receive_plans_local(
    receive_plans_by_leaf: Mapping[int, Sequence[Any]],
    local_index_to_pos: Mapping[int, int],
    rank: int,
) -> None:
    """Ensures receive plans only refer to leaves local to this rank."""
    for leaf_idx in receive_plans_by_leaf:
        if leaf_idx not in local_index_to_pos:
            raise RuntimeError(
                "Receive-plan map is invalid: non-local receiver leaf "
                f"{leaf_idx} appears on rank {rank}."
            )


def require_leaf_owner(
    leaf_idx: int, leaf_to_rank_map: Mapping[int, int], missing_message: str
) -> int:
    """Returns owner rank for `leaf_idx`, or raises with caller-defined message."""
    if leaf_idx not in leaf_to_rank_map:
        raise RuntimeError(missing_message)
    return leaf_to_rank_map[leaf_idx]


def classify_halo_route(
    sender_idx: int,
    receiver_idx: int,
    *,
    leaf_to_rank_map: Mapping[int, int],
    local_index_to_pos: Mapping[int, int],
    rank: int,
) -> tuple[int, bool]:
    """Validates sender/receiver ownership and returns route metadata."""
    if sender_idx not in local_index_to_pos:
        raise RuntimeError(
            "Outgoing package map is invalid: sender leaf "
            f"{sender_idx} is not local on rank {rank}."
        )
    dest_rank = require_leaf_owner(
        receiver_idx,
        leaf_to_rank_map,
        "Outgoing package map is invalid: receiver leaf "
        f"{receiver_idx} has no owner in leaf_to_rank_map.",
    )
    receiver_is_local = receiver_idx in local_index_to_pos
    if dest_rank == rank and not receiver_is_local:
        raise RuntimeError(
            "Leaf ownership mismatch detected for halo exchange: receiver "
            f"leaf {receiver_idx} is mapped to local rank {rank} but is "
            "not present in local_indices."
        )
    if dest_rank != rank and receiver_is_local:
        raise RuntimeError(
            "Leaf ownership mismatch detected for halo exchange: receiver "
            f"leaf {receiver_idx} is local on rank {rank} but mapped to "
            f"remote rank {dest_rank}."
        )
    return dest_rank, receiver_is_local


def validate_halo_payload_identity(
    payload_extra: Any,
    *,
    expected_receiver_idx: int,
    expected_sender_idx: int,
    expected_iteration: int | None,
    expected_sender_rank: int | None,
    source_rank: int,
) -> None:
    """Validates metadata identity fields on a received halo payload."""
    if not isinstance(payload_extra, dict):
        raise RuntimeError(
            "Received halo payload without metadata identity fields for "
            f"receiver={expected_receiver_idx}, sender={expected_sender_idx}."
        )

    sender_meta = payload_extra.get("sender_leaf_idx")
    receiver_meta = payload_extra.get("receiver_leaf_idx")
    iteration_meta = payload_extra.get("halo_iteration")
    if sender_meta != expected_sender_idx or receiver_meta != expected_receiver_idx:
        raise RuntimeError(
            "Received halo payload identity mismatch: expected "
            f"(receiver={expected_receiver_idx}, sender={expected_sender_idx}), got "
            f"(receiver={receiver_meta}, sender={sender_meta})."
        )

    if expected_iteration is not None and iteration_meta != int(expected_iteration):
        raise RuntimeError(
            "Received halo payload iteration mismatch: expected "
            f"{expected_iteration}, got {iteration_meta} "
            f"for receiver={expected_receiver_idx}, sender={expected_sender_idx}."
        )

    if expected_sender_rank is not None and expected_sender_rank != source_rank:
        raise RuntimeError(
            "Received halo payload from unexpected rank for sender leaf "
            f"{expected_sender_idx}: expected rank {expected_sender_rank}, "
            f"got rank {source_rank}."
        )


def expected_sender_set(plans: Sequence[Any]) -> set[int]:
    """Builds expected sender set from communication plans."""
    return {int(plan.sender_leaf_idx) for plan in plans}


def validate_sender_set(
    receiver_leaf_idx: int,
    expected_senders: set[int],
    received_senders: set[int],
    *,
    rank: int,
) -> None:
    """Ensures each receiver gets exactly the senders required by comm plans."""
    missing = sorted(expected_senders - received_senders)
    extra = sorted(received_senders - expected_senders)
    if missing or extra:
        raise RuntimeError(
            "Halo package mismatch for receiver leaf "
            f"{receiver_leaf_idx} on rank {rank}. "
            f"Missing senders: {missing}, extra senders: {extra}."
        )


def assign_unique_leaf_owner(
    leaf_to_rank_map: dict[int, int], leaf_idx: int, owner_rank: int
) -> None:
    """Assigns a leaf owner while rejecting duplicate claims."""
    if leaf_idx in leaf_to_rank_map:
        raise RuntimeError(f"Duplicate ownership of leaf {leaf_idx}")
    leaf_to_rank_map[leaf_idx] = owner_rank


def validate_leaf_coverage(
    leaf_to_rank_map: Mapping[int, int], num_domains: int, *, context: str
) -> None:
    """Ensures ownership map covers exactly all leaves [0, num_domains)."""
    expected_keys = set(range(num_domains))
    observed_keys = set(leaf_to_rank_map.keys())
    missing = sorted(expected_keys - observed_keys)
    extra = sorted(observed_keys - expected_keys)
    if missing or extra:
        raise RuntimeError(
            f"{context} does not match domain leaves. "
            f"Missing leaves: {missing}, extra leaves: {extra}."
        )


def validate_rank_bounds(
    leaf_to_rank_map: Mapping[int, int], num_ranks: int, *, context: str
) -> None:
    """Ensures rank IDs are valid for all mapped leaves."""
    for leaf_idx, owner_rank in leaf_to_rank_map.items():
        if owner_rank < 0 or owner_rank >= num_ranks:
            raise RuntimeError(
                f"{context} has out-of-range owner rank {owner_rank} "
                f"for leaf {leaf_idx}."
            )


def validate_weight_coverage(weights: Mapping[int, float], num_domains: int) -> None:
    """Ensures weight map covers exactly all leaves [0, num_domains)."""
    expected_keys = set(range(num_domains))
    observed_keys = set(weights.keys())
    missing = sorted(expected_keys - observed_keys)
    extra = sorted(observed_keys - expected_keys)
    if missing or extra:
        raise RuntimeError(
            "Global load weights do not match domain leaves. "
            f"Missing leaves: {missing}, extra leaves: {extra}."
        )


def validate_positive_weight(weight: float, leaf_idx: int, *, context: str) -> None:
    """Ensures load-balancing weights are finite and positive."""
    if not np.isfinite(weight) or weight <= 0.0:
        raise RuntimeError(
            f"{context} invalid weight {weight} for leaf {leaf_idx}. "
            "Weights must be finite and positive."
        )


def build_global_weight_and_rank_maps(
    all_indices_nested: Sequence[Sequence[int]],
    all_weights_nested: Sequence[Sequence[float]],
    *,
    num_domains: int,
    num_ranks: int,
) -> tuple[dict[int, float], dict[int, int]]:
    """Reconstructs and validates global LB maps from gathered rank-local data."""
    global_weights: dict[int, float] = {}
    current_rank_map: dict[int, int] = {}
    for r_id in range(num_ranks):
        r_indices = all_indices_nested[r_id]
        r_weights = all_weights_nested[r_id]
        if len(r_indices) != len(r_weights):
            raise RuntimeError(
                "Load balancing gather mismatch: indices/weights length differs."
            )
        for idx, weight in zip(r_indices, r_weights, strict=True):
            if idx < 0 or idx >= num_domains:
                raise RuntimeError(
                    "Load balancing gather invalid: out-of-range leaf index."
                )
            validate_positive_weight(weight, idx, context="Load balancing gather")
            assign_unique_leaf_owner(current_rank_map, idx, r_id)
            global_weights[idx] = weight

    validate_leaf_coverage(
        current_rank_map,
        num_domains,
        context="Load balancing rank map",
    )
    return global_weights, current_rank_map


def validate_lb_migration_map(
    migration_map: Mapping[int, int],
    *,
    current_rank_map: Mapping[int, int],
    num_ranks: int,
) -> None:
    """Validates a proposed LB migration map before data migration starts."""
    for leaf_idx, target_rank in migration_map.items():
        if leaf_idx not in current_rank_map:
            raise RuntimeError(
                "Load balancing produced migration for unknown leaf " f"{leaf_idx}."
            )
        if target_rank < 0 or target_rank >= num_ranks:
            raise RuntimeError(
                "Load balancing produced out-of-range target rank "
                f"{target_rank} for leaf {leaf_idx}."
            )
        if target_rank == current_rank_map[leaf_idx]:
            raise RuntimeError(
                "Load balancing produced no-op migration for leaf "
                f"{leaf_idx} on rank {target_rank}."
            )


def validate_post_lb_rank_map(
    actual_rank_map: Mapping[int, int],
    expected_rank_map: Mapping[int, int],
) -> None:
    """Ensures actual ownership after migration matches planned ownership."""
    if actual_rank_map != expected_rank_map:
        raise RuntimeError(
            "Load-balancing migration verification failed: reconstructed ownership "
            "does not match the expected post-migration rank map."
        )
