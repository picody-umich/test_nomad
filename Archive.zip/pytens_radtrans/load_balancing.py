"""Load balancing logic for domain decomposition."""

import numpy as np

from . import contracts, domain_decomp, solver, utils


def compute_local_weights(
    solutions: list[solver.Solution], strategy: str
) -> list[float]:
    """Computes the computational weight of each local solution.

    Args:
        solutions: List of local Solution objects.
        strategy: The weighting strategy ('count' or 'parameters').

    Returns:
        A list of float weights corresponding to the input solutions.
    """
    if strategy not in {"count", "parameters"}:
        raise ValueError(
            f"Unknown load-balancing strategy '{strategy}'. "
            "Expected 'count' or 'parameters'."
        )

    weights: list[float] = []
    for sol in solutions:
        if strategy == "count":
            weights.append(1.0)
        else:  # strategy == "parameters"
            weights.append(float(utils.num_parameters(sol.intensity)))
    return weights


def propose_partition(
    domain_manager: domain_decomp.DomainManager,
    num_ranks: int,
    current_rank_map: dict[int, int],
    global_weights: dict[int, float],
    threshold: float = 1.1,
) -> dict[int, int] | None:
    """Proposes a new distribution of leaves to balance load.

    This function uses a 1D partitioning of the Z-order curve (the list of leaves)
    to balance the accumulated weights.

    Args:
        domain_manager: The global domain manager.
        num_ranks: Total number of MPI ranks.
        current_rank_map: Dictionary mapping global leaf index to current rank.
        global_weights: Dictionary mapping global leaf index to its weight.
        threshold: The imbalance threshold required to trigger a migration.

    Returns:
        A dictionary mapping {leaf_idx: target_rank} for leaves that must move.
        Returns None if the current imbalance is below the threshold.
    """
    leaves = domain_manager.leaves
    num_leaves = len(leaves)

    if num_ranks <= 0:
        raise ValueError(f"num_ranks must be positive, got {num_ranks}.")

    if num_leaves == 0:
        return None

    contracts.validate_leaf_coverage(
        current_rank_map, num_leaves, context="Current rank map"
    )
    contracts.validate_rank_bounds(
        current_rank_map, num_ranks, context="Current rank map"
    )
    contracts.validate_weight_coverage(global_weights, num_leaves)

    # 1. Check current imbalance
    current_loads = np.zeros(num_ranks)
    for leaf_idx, r_id in current_rank_map.items():
        w = float(global_weights[leaf_idx])
        contracts.validate_positive_weight(w, leaf_idx, context="Current rank map has")
        current_loads[r_id] += w

    total_weight = np.sum(current_loads)
    avg_load = total_weight / num_ranks
    max_load = np.max(current_loads)

    # Avoid silently proceeding on invalid/degenerate loads.
    if avg_load <= 1e-12:
        raise RuntimeError(
            "Average load is non-positive; cannot compute imbalance ratio."
        )

    imbalance = max_load / avg_load

    # If balanced enough, do nothing
    if imbalance < threshold:
        return None

    # 2. Partition based on Z-order (linear list of leaves)
    new_map = {}
    target_load_per_rank = total_weight / num_ranks

    current_rank = 0
    current_rank_load = 0.0

    for i, _ in enumerate(leaves):
        leaf_idx = i
        w = float(global_weights[leaf_idx])

        # If we are not the last rank, check if we should advance
        if current_rank < num_ranks - 1:
            # If adding this weight exceeds target significantly, consider switching.
            if current_rank_load + w > target_load_per_rank:
                # If current rank is empty, we MUST take it
                if current_rank_load == 0:
                    pass
                else:
                    # Compare imbalance:
                    # Option A: Add to current (Load = current + w)
                    # Option B: Start new rank (Current Load = current,
                    #           Next Load starts with w)
                    # We choose the option that keeps the split point closer to
                    # the target
                    diff_include = abs((current_rank_load + w) - target_load_per_rank)
                    diff_exclude = abs(current_rank_load - target_load_per_rank)

                    if diff_exclude < diff_include:
                        # Better to leave it for next rank
                        current_rank += 1
                        current_rank_load = 0.0

        if current_rank_map.get(leaf_idx) != current_rank:
            new_map[leaf_idx] = current_rank

        current_rank_load += w

    return new_map
