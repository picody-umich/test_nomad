"""Main Loop."""

import logging
import pathlib
from typing import Any

import matplotlib.pyplot as plt
from mpi4py import MPI
from tqdm import tqdm

from . import main_loop_utils
from .load_config import Config
from .main_loop_utils import InitializationData

comm = MPI.COMM_WORLD
rank = comm.Get_rank()


def plot_initial_state(
    init_data: InitializationData, logger: logging.Logger, save_dir: pathlib.Path
) -> Any:
    """Gathers and plots the initial state of the simulation.

    This function computes auxiliary quantities (like mean intensity) for the
    initial solution, gathers data from all MPI ranks to the root rank, and
    generates an initial plot.

    Args:
        init_data: The initialization data containing the current state and
            domain information.
        logger: The logger instance for status updates.
        save_dir: The directory where the plot should be saved.

    Returns:
        The matplotlib figure object for the overlay plot if on rank 0,
        otherwise None.
    """
    init_data.monitor.compute_aux_last_sol()

    local_plot_data = []
    if init_data.local_sol:
        for s in init_data.local_sol:
            data_dict = {
                "mean_intensity": s.aux.get("mean_intensity"),
                "temperature": s.space.get("temperature", None) if s.space else None,
            }
            local_plot_data.append(data_dict)

    all_plot_data_chunked = comm.gather(local_plot_data, root=0)

    fig_overlay = None
    if rank == 0:
        logger.info("Plotting initial results.")
        num_domains = init_data.domain_manager.num_domains()
        global_plot_data = [None] * num_domains

        if init_data.local_indices_chunked:
            assert all_plot_data_chunked is not None
            for rank_id, chunk_indices in enumerate(init_data.local_indices_chunked):
                for ind, global_idx in enumerate(chunk_indices):
                    global_plot_data[global_idx] = all_plot_data_chunked[rank_id][ind]

        fig_overlay = init_data.monitor.plot_last_sol(
            global_plot_data, init_data.time, save_dir, 0, fig_overlay
        )

    return fig_overlay


def plot_final_ranks(
    init_data: InitializationData, logger: logging.Logger, save_dir: pathlib.Path
) -> None:
    """Gathers and plots the history of tensor ranks and compression ratios.

    This function collects the rank history from all domains across all MPI
    processes and generates a plot showing how the tensor ranks evolved over
    time. It handles variable numbers of domains (due to AMR) by flattening
    the list of ranks at each time step.

    Args:
        init_data: The initialization data containing the monitor with rank history.
        logger: The logger instance for status updates.
        save_dir: The directory where the plot should be saved.
    """
    local_ranks_history = init_data.monitor.ranks
    all_ranks_chunked = comm.gather(local_ranks_history, root=0)

    if rank == 0:
        logger.info("Gathering and plotting final rank/compression data.")
        num_steps = len(local_ranks_history)

        # Reconstruct global history as a list of lists (one list of ranks per step)
        # The inner list length varies with time due to AMR.
        global_ranks_history = []

        if all_ranks_chunked:
            for t in range(num_steps):
                ranks_at_t = []
                for rank_id in range(len(all_ranks_chunked)):
                    # Append all ranks from this MPI process for time step t
                    ranks_at_t.extend(all_ranks_chunked[rank_id][t])
                global_ranks_history.append(ranks_at_t)

        init_data.monitor.plot_ranks_compressions(
            global_ranks_history, save_dir / "ranks_compression.pdf", logger
        )
        logger.info("Rank plots saved.")


def plot_final_summary(
    init_data: InitializationData, logger: logging.Logger, save_dir: pathlib.Path
) -> None:
    """Gathers and plots a summary of the solution evolution.

    This function collects the full history of solution fields (e.g., mean
    intensity, temperature) from all MPI ranks and generates a comprehensive
    summary plot.

    Args:
        init_data: The initialization data containing the monitor with solution history.
        logger: The logger instance for status updates.
        save_dir: The directory where the plot should be saved.
    """
    local_plot_history = []
    for sol_at_time_t in init_data.monitor.sol:
        data_at_t = []
        for s in sol_at_time_t:
            data_dict = {
                "mean_intensity": s.aux.get("mean_intensity", None),
                "temperature": s.space.get("temperature", None) if s.space else None,
            }
            data_at_t.append(data_dict)
        local_plot_history.append(data_at_t)

    all_plot_data_chunked = comm.gather(local_plot_history, root=0)

    if rank == 0:
        logger.info("Gathering and plotting summary of all solutions.")
        num_steps = len(init_data.monitor.time)

        # Reconstruct global history as a list of lists
        # (one list of domain data per step)
        # The inner list length varies with time due to AMR.
        global_plot_history = []

        if all_plot_data_chunked:
            for t in range(num_steps):
                data_at_t = []
                for rank_id in range(len(all_plot_data_chunked)):
                    # Append all domain data from this rank at time t
                    # all_plot_data_chunked[rank_id] is a list of steps
                    # all_plot_data_chunked[rank_id][t] is a list of domain dicts
                    data_at_t.extend(all_plot_data_chunked[rank_id][t])
                global_plot_history.append(data_at_t)

        fig = init_data.problem.plot_all_sols(
            global_plot_history,
            init_data.monitor.time,
            init_data.domain_manager,
        )
        if fig is not None:
            fig.savefig(save_dir / "summary_sol_plot.pdf")
        plt.close("all")

        logger.info("Final plots saved")


def main_loop(config: Config, logger: logging.Logger, save_dir: pathlib.Path) -> None:
    """Orchestrates the main simulation loop.

    This function handles the initialization, time-stepping, halo exchanges,
    I/O operations, and final result plotting. It coordinates the parallel
    execution across MPI ranks.

    Args:
        config: The configuration object defining simulation parameters.
        logger: The logger instance for status updates.
        save_dir: The directory where output files and plots will be saved.
    """
    init_data = main_loop_utils.initialize_simulation(config, logger)

    fig_overlay = plot_initial_state(init_data, logger, save_dir)

    comm.Barrier()
    logger.info("Ready to begin time loop")

    pbar = None
    if rank == 0:
        pbar = tqdm(range(1, config.solver.num_steps + 1), desc="Time Steps")

    for ii in range(1, config.solver.num_steps + 1):
        if rank == 0:
            assert pbar is not None
            pbar.update(1)
            pbar.set_postfix({"time": f"{init_data.time:.2e}"})

        if ii % 1 == 0:
            logger.info("Step %d, Time = %3.2E", ii - 1, init_data.time)

        updates = main_loop_utils.perform_halo_exchange(
            init_data,
            comm,
            logger,
            iteration=ii,
        )
        new_local_sol = main_loop_utils.advance_local_solutions(
            config, updates, init_data, ii, logger
        )

        init_data, fig_overlay = main_loop_utils.handle_post_step_io(
            new_local_sol, init_data, config, save_dir, ii, fig_overlay, comm, logger
        )

        # Handle Adaptive Mesh Refinement and Load Balancing
        init_data = main_loop_utils.handle_adaptation(init_data, config, logger, ii)

        comm.Barrier()

    comm.Barrier()

    plot_final_ranks(init_data, logger, save_dir)

    if config.saving.keep_all is True:
        plot_final_summary(init_data, logger, save_dir)
