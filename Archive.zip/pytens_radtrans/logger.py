import logging
import pathlib


def setup_logger(filename: pathlib.Path, name: str, rank: int) -> logging.Logger:
    """
    Configures a logger that behaves differently for Rank 0 and other ranks.

    - Rank 0: Logs INFO level and above to both a file ('simulation.log') and
      the console.
    - Other Ranks: Log WARNING level and above only to the console.
    - All log messages are prefixed with the rank ID.

    Args:
        name: The name of the logger (e.g., __name__).
        rank: The MPI rank of the current process.

    Returns:
        A configured logger instance.
    """
    # Create a custom formatter that includes the rank
    formatter = logging.Formatter(
        f"[%(asctime)s] [Rank {rank}] [%(levelname)s] - %(message)s"
    )

    # Create a base logger
    logging.captureWarnings(True)
    logger = logging.getLogger(name)
    logger.setLevel(logging.INFO)  # Set the lowest level to capture all messages

    # Rank 0 is our main logger
    if rank == 0:
        # Create a handler to write to a log file
        file_handler = logging.FileHandler(filename, mode="w")
        file_handler.setLevel(logging.INFO)
        file_handler.setFormatter(formatter)
        logger.addHandler(file_handler)

        # Also create a handler to print to the console
        # stream_handler = logging.StreamHandler(sys.stdout)
        # stream_handler.setLevel(logging.INFO)
        # stream_handler.setFormatter(formatter)
        # logger.addHandler(stream_handler)

    # Other ranks only log warnings and errors to the console
    else:
        # We only want to see important messages from workers
        file_handler = logging.FileHandler(filename, mode="w")
        file_handler.setLevel(logging.WARNING)
        file_handler.setFormatter(formatter)
        logger.addHandler(file_handler)

        # stream_handler = logging.StreamHandler(sys.stdout)
        # stream_handler.setLevel(logging.WARNING)
        # stream_handler.setFormatter(formatter)
        # logger.addHandler(stream_handler)

    return logger
