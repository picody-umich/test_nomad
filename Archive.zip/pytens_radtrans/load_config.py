"""Defines Pydantic models for loading and validating simulation configurations."""

import pathlib
from typing import Annotated, Any, Literal

import pydantic as pd
import yaml


class Geometry(pd.BaseModel):
    """Defines the spatial geometry of the simulation domain."""

    dimension: int = pd.Field(
        gt=0, le=2, description="Number of spatial dimensions (1 or 2)."
    )
    lb: list[float] = pd.Field(description="Lower bounds of the spatial domain.")
    ub: list[float] = pd.Field(description="Upper bounds of the spatial domain.")
    n: list[int] = pd.Field(description="Number of cells in each spatial dimension.")
    n_ghost: list[int] = pd.Field(
        description="Number of ghost cells on each side of each dimension."
    )
    domain_decomp: Any = pd.Field(
        description="MPI domain decomposition structure. 0 for a single domain.",
        default=0,
    )

    def _validate_decomp_recursive(
        self, decomp_spec: Any, dimension: int, num_cells: list[int]
    ) -> None:
        """Recursively validate the domain decomposition structure."""
        if decomp_spec == 0:
            return  # This is a valid leaf node

        if not isinstance(decomp_spec, list):
            raise ValueError(
                f"Invalid domain_decomp specifier: {decomp_spec}. "
                "Must be 0 or a list."
            )

        if (
            len(decomp_spec) != 2
            or decomp_spec[0] != 1
            or not isinstance(decomp_spec[1], list)
        ):
            raise ValueError(
                f"Invalid domain_decomp split specifier: {decomp_spec}. "
                "Must be of the form [1, [...]]."
            )

        sub_specs = decomp_spec[1]
        num_children = 2**dimension

        if len(sub_specs) != num_children:
            raise ValueError(
                f"Invalid number of sub-decompositions. "
                f"Expected {num_children} for dimension {dimension}, "
                f"but got {len(sub_specs)}."
            )

        # In the current implementation (Constant N), splitting a domain
        # preserves the number of cells per domain (increasing resolution).
        # Therefore, we do not divide num_cells by 2, nor do we check for parity.
        for sub in sub_specs:
            self._validate_decomp_recursive(sub, dimension, num_cells)

    # runs through the inputs 1 by 1
    @pd.field_validator("lb", "ub", "n")
    @classmethod
    def bounds(
        cls, field_value: list[float] | list[int], info: pd.ValidationInfo
    ) -> list[float] | list[int]:
        """Check that the length of bounds lists matches the dimension."""
        if "dimension" not in info.data:
            return field_value  # validation will fail on dimension anyway

        if len(field_value) != info.data["dimension"]:
            raise ValueError(
                "Bounds must be a list with a number"
                " of elements equal to the dimension"
            )

        return field_value

    @pd.field_validator("n_ghost")
    @classmethod
    def ghost_cells(cls, field_value: list[int], info: pd.ValidationInfo) -> list[int]:
        """Check that ghost cell specifications are valid."""
        if "dimension" not in info.data:
            return field_value  # validation will fail on dimension anyway

        if len(field_value) != info.data["dimension"]:
            raise ValueError(
                "Length of number of ghost cells must be equal to the dimension."
            )
        for n in field_value:
            if n % 2 != 0:
                raise ValueError("Number of ghost cells must be even.")
            if n < 2:
                raise ValueError("Must be 2 or more ghost cells per dimension.")
        return field_value

    @pd.model_validator(mode="after")
    def check_consistency(self) -> "Geometry":
        """Perform cross-field validation for geometry."""
        # Check bounds order
        for i, ub_val in enumerate(self.ub):
            if ub_val <= self.lb[i]:
                raise ValueError("Upper bound is not larger than lower bound.")

        # Validate domain decomposition
        self._validate_decomp_recursive(self.domain_decomp, self.dimension, self.n)
        return self


class Angles(pd.BaseModel):
    """Defines the angular discretization."""

    n_theta: int = pd.Field(gt=0, description="Number of polar angles (theta).")
    n_phi: int = pd.Field(gt=0, description="Number of azimuthal angles (phi).")


class UpwindStencil(pd.BaseModel):
    """Configuration for the Upwind stencil."""

    name: Literal["upwind"] = pd.Field(description="Selects the upwind stencil.")


class RusanovStencil(pd.BaseModel):
    """Configuration for the Rusanov stencil."""

    name: Literal["rusanov"] = pd.Field(description="Selects the Rusanov stencil.")
    wave_speed: float = pd.Field(
        ge=0.0,
        description=(
            "Extremal Wave Speed. For vacuum transport can choose same as speed of"
            " light.If it is too small, then scheme can be numerically unstable"
        ),
    )


class APFStencil(pd.BaseModel):
    """Configuration for the Asymptotic Preserving (Jiang) stencil."""

    name: Literal["jiang"] = pd.Field(
        description="Selects the Asymptotic Preserving (Jiang) stencil."
    )
    beta: float = pd.Field(
        ge=0.0, default=4.0, description="Parameter for the Jiang flux limiter."
    )
    tau_threshold: float = pd.Field(
        ge=0.0,
        default=1e-3,
        description="Threshold for switching between transport and diffusion regimes.",
    )
    alpha_threshold: float = pd.Field(
        ge=0.0,
        default=1e-6,
        description=(
            "The absorption coefficient is set to this value when it's close to zero"
        ),
    )


class Rounding(pd.BaseModel):
    """Defines parameters for tensor rounding operations."""

    method: Literal["svd", "gram", "randomized"] = pd.Field(
        description="Algorithm used for tensor train rounding."
    )
    tt_sum: bool = pd.Field(
        description="exploit sum specific rounding if available", default=True
    )
    rank_increase_bound: int = pd.Field(
        description="rank increase bound for randomized rounding", default=10000
    )
    tol: float = pd.Field(gt=0.0, description="Rounding Tolerance")
    freq: int = pd.Field(description="Frequency of rounding")


class Solver(pd.BaseModel):
    """Defines solver-specific parameters."""

    cfl: float = pd.Field(gt=0.0, description="CFL number for time step calculation.")
    stencil: Annotated[
        UpwindStencil | RusanovStencil | APFStencil, pd.Discriminator("name")
    ] = pd.Field(description="The finite volume stencil to use for spatial flux.")
    method: Literal["forward euler"] = pd.Field(description="Time integration method.")
    num_steps: int = pd.Field(gt=0, description="Total number of time steps to run.")
    rounding: Rounding = pd.Field(description="Parameters for TT rounding/compression.")
    order: list[str] = pd.Field(description="Order of variables in the tensor network.")


class NoSource(pd.BaseModel):
    """Specifies that no source term is used."""

    name: Literal["none"] = pd.Field(
        description="Specifies no source term is used in the equations."
    )


class ScatterOnly(pd.BaseModel):
    """Specifies a scatter-only source term."""

    name: Literal["scatter only"] = pd.Field(
        description="Specifies a scatter-only source term."
    )


class IdealGas(pd.BaseModel):
    """Configuration for the ideal gas source term."""

    name: Literal["ideal gas"] = pd.Field(
        description="Selects the ideal gas source term for energy exchange."
    )
    specific_heat_capacity: float | None = pd.Field(
        description=(
            "Specific heat capacity (Cv) of the material. Required for temperature"
            " updates."
        ),
        default=None,
    )


class Equations(pd.BaseModel):
    """Defines the physical parameters of the transport equations."""

    speed_of_light: float = pd.Field(description="Speed of light in simulation units.")
    density: float | None = pd.Field(
        gt=0,
        description="Global material density. Not needed if problem defines it.",
        default=None,
    )
    specific_scattering_opacity: float = pd.Field(
        ge=0, description="Specific scattering opacity (sigma_s).", default=0.0
    )
    radiation_constant: float = pd.Field(
        ge=0, description="Radiation constant (a_r).", default=0.0
    )
    specific_absorption_opacity: float = pd.Field(
        ge=0.0,
        description="Specific absorption opacity (sigma_a).",
        default=0.0,
    )
    source: NoSource | IdealGas | ScatterOnly = pd.Field(
        description="The source term model for radiation-matter interaction.",
        discriminator="name",
    )


class Saving(pd.BaseModel):
    """Defines parameters for saving simulation results."""

    directory: str = pd.Field(description="Location to save results.")
    plot_freq: int = pd.Field(description="How often to generate plots.", default=1)
    spatial_save_freq: int = pd.Field(
        description="How often to save spatial quantities.", default=100000
    )
    keep_all: bool = pd.Field(
        description="Whether or not to keep all solutions in memory.", default=True
    )
    checkpoint_freq: int = pd.Field(
        description="How often to save a checkpoint file.", default=100000000, gt=0
    )


class Problem(pd.BaseModel):
    """Base class for configuring problems."""


class Hohlraum(Problem):
    """Hohlraum problem configuration."""

    name: Literal["hohlraum"]


class ThermalRelaxation(Problem):
    """Thermal Relaxation problem configuration."""

    name: Literal["thermal relaxation"]
    Ti: float = pd.Field(description="Initial constant temperature of the material.")
    Tri: float = pd.Field(
        description="Initial radiation temperature for the intensity field."
    )


class GaussianDiffusion(Problem):
    """Gaussian Diffusion problem configuration."""

    name: Literal["gaussian diffusion"]
    A: float = pd.Field(gt=0.0, description="Amplitude of the initial Gaussian pulse.")
    t0: float = pd.Field(
        gt=0.0, description="Effective initial time for the analytical solution."
    )


class LineSource(Problem):
    """Line Source problem configuration."""

    name: Literal["line source"]
    u0: float = pd.Field(gt=0.0, description="Amplitude of the initial pulse.")
    omega: float = pd.Field(gt=0.0, description="Initial spread of the pulse.")


class CrookedPipe(Problem):
    """Crooked Pipe problem configuration."""

    name: Literal["crooked pipe"]
    background_temperature: float = pd.Field(
        gt=0.0, description="Initial temperature of the pipe and walls."
    )
    source_temperature: float = pd.Field(
        gt=0.0, description="Temperature of the radiation source at the inlet."
    )
    wall_density: float = pd.Field(gt=0.0, description="Density of the pipe walls.")
    pipe_density: float = pd.Field(
        gt=0.0, description="Density of the medium inside the pipe."
    )
    wall_specific_absorption_opacity: float = pd.Field(
        gt=0.0, description="Specific absorption opacity of the pipe walls."
    )
    pipe_specific_absorption_opacity: float = pd.Field(
        gt=0.0, description="Specific absorption opacity of the medium in the pipe."
    )


def problem_get_discriminator_value(v: Any) -> str | None:
    """Get the discriminator value for the problem type.

    This function is used by Pydantic to determine which problem model to use
    when parsing the configuration.

    Args:
        v: The input value, which can be a dictionary or a model instance.

    Returns:
        The value of the 'name' field, or None if not found.
    """
    if isinstance(v, dict):
        name = v.get("name")
        if isinstance(name, str):
            return name
        return None
    if hasattr(v, "name") and isinstance(v.name, str):
        return v.name
    return None


class BaseRefinementConfig(pd.BaseModel):
    """Base configuration for Adaptive Mesh Refinement."""

    enabled: bool = pd.Field(
        default=False, description="Whether to enable adaptive mesh refinement."
    )
    proper_nesting: bool = pd.Field(
        default=False,
        description="If True, enforces a strict 2:1 size ratio between neighbors.",
    )
    max_level: int = pd.Field(
        default=10, ge=0, description="Maximum refinement level allowed."
    )
    frequency: int = pd.Field(
        default=1, ge=1, description="Frequency of adaptation steps."
    )
    refine_neighbors: bool = pd.Field(
        default=False,
        description="If True, neighbors of refined cells are also refined.",
    )


class RankRefinementConfig(BaseRefinementConfig):
    """Refinement strategy based on Tensor Train ranks."""

    strategy: Literal["rank"] = pd.Field(
        default="rank", description="The strategy used to trigger refinement."
    )
    max_rank: int = pd.Field(
        default=20, gt=0, description="Maximum tensor rank allowed before refining."
    )
    min_rank: int = pd.Field(
        default=5,
        ge=0,
        description=(
            "Minimum tensor rank required to keep a fine grid (coarsen if lower)."
        ),
    )

    @pd.model_validator(mode="after")
    def check_ranks(self) -> "RankRefinementConfig":
        """Ensure max_rank is greater than min_rank."""
        if self.max_rank <= self.min_rank:
            raise ValueError(
                f"max_rank ({self.max_rank}) must be greater than "
                f"min_rank ({self.min_rank})."
            )
        return self


class IntensityRefinementConfig(BaseRefinementConfig):
    """Refinement strategy based on global Mean Intensity percentiles."""

    strategy: Literal["mean_intensity"] = pd.Field(
        default="mean_intensity",
        description="Refinement based on global intensity percentile.",
    )
    refine_fraction: float = pd.Field(
        default=0.2,
        gt=0.0,
        lt=1.0,
        description="Top fraction of global max to refine (e.g. 0.2 = top 20%).",
    )
    coarsen_fraction: float = pd.Field(
        default=0.5,
        gt=0.0,
        lt=1.0,
        description="Bottom fraction of global max to coarsen (e.g. 0.5 = bottom 50%).",
    )

    @pd.model_validator(mode="after")
    def check_fractions(self) -> "IntensityRefinementConfig":
        """Ensure hysteresis (refine threshold > coarsen threshold)."""
        # Refine Threshold = (1 - refine) * Max
        # Coarsen Threshold = (1 - coarsen) * Max
        # We need Refine > Coarsen => (1-r) > (1-c) => r < c
        if self.refine_fraction >= self.coarsen_fraction:
            raise ValueError(
                "refine_fraction must be smaller than coarsen_fraction to ensure "
                "hysteresis."
            )
        return self


RefinementConfig = Annotated[
    RankRefinementConfig | IntensityRefinementConfig, pd.Discriminator("strategy")
]


class LoadBalancing(pd.BaseModel):
    """Configuration for load balancing."""

    enabled: bool = pd.Field(
        default=False, description="Whether to enable dynamic load balancing."
    )
    imbalance_threshold: float = pd.Field(
        default=1.1,
        gt=1.0,
        description=(
            "Ratio of max load to average load required to trigger rebalancing."
        ),
    )
    strategy: Literal["count", "parameters"] = pd.Field(
        default="parameters",
        description=(
            "Metric for load balancing: 'count' (leaves) or 'parameters' (tensor size)."
        ),
    )
    frequency: int = pd.Field(
        default=10,
        ge=1,
        description="Frequency (in time steps) to check for load balancing.",
    )


class Config(pd.BaseModel):
    """The main configuration model for the entire simulation."""

    problem: Annotated[
        (
            Annotated[Hohlraum, pd.Tag("hohlraum")]
            | Annotated[ThermalRelaxation, pd.Tag("thermal relaxation")]
            | Annotated[GaussianDiffusion, pd.Tag("gaussian diffusion")]
            | Annotated[LineSource, pd.Tag("line source")]
            | Annotated[CrookedPipe, pd.Tag("crooked pipe")]
        ),
        pd.Discriminator(problem_get_discriminator_value),
    ] = pd.Field(description="Problem-specific physical setup and parameters.")

    geometry: Geometry = pd.Field(description="Spatial domain and grid configuration.")
    angles: Angles = pd.Field(description="Angular discretization configuration.")
    solver: Solver = pd.Field(description="Numerical solver parameters.")
    equations: Equations = pd.Field(
        description="Physical constants and equation terms."
    )
    saving: Saving = pd.Field(description="Output and data saving configuration.")
    checkpoint_directory: None | pd.DirectoryPath = pd.Field(
        description="Checkpoint directory", default=None
    )
    refinement: RefinementConfig = pd.Field(
        default_factory=RankRefinementConfig,
        description="Adaptive Mesh Refinement configuration.",
    )
    load_balancing: LoadBalancing = pd.Field(
        default_factory=LoadBalancing,
        description="Load balancing configuration.",
    )

    @pd.model_validator(mode="after")
    def check_density_requirement(self) -> "Config":
        """Validate density is provided where required."""
        # Problems that define their own density and do not need a global one.
        problems_with_internal_density = (CrookedPipe,)

        # Check if a source is defined and if a global density is missing.
        if not isinstance(self.equations.source, NoSource):
            if self.equations.density is None:
                # If density is missing, it's only allowed for specific problems.
                if not isinstance(self.problem, problems_with_internal_density):
                    raise ValueError(
                        "Density must be provided for a non-empty source term "
                        f"with the '{self.problem.name}' problem."
                    )
        return self


def load_yml_config(path: pathlib.Path) -> Any:
    """Load a configuration from a YAML file.

    Args:
        path: The path to the YAML configuration file.

    Returns:
        The loaded configuration as a dictionary.

    Raises:
        FileNotFoundError: If the specified file does not exist.
    """
    try:
        return yaml.safe_load(path.read_text())
    except FileNotFoundError as error:
        message = "Error.yml config file not found."
        raise FileNotFoundError(error, message) from error
