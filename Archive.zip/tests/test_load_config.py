"""Tests for the configuration loading and validation."""

from pathlib import Path

import pydantic as pd
import pytest
import yaml

from pytens_radtrans import load_config


@pytest.fixture
def base_config() -> dict:
    """Return a minimal, valid configuration dictionary."""
    return {
        "problem": {"name": "hohlraum"},
        "geometry": {
            "dimension": 1,
            "lb": [0.0],
            "ub": [1.0],
            "n": [10],
            "n_ghost": [2],
        },
        "angles": {"n_theta": 4, "n_phi": 4},
        "solver": {
            "cfl": 0.5,
            "stencil": {"name": "upwind"},
            "method": "forward euler",
            "num_steps": 10,
            "rounding": {"method": "svd", "tol": 1e-8, "freq": 1},
            "order": ["x", "theta", "phi"],
        },
        "equations": {
            "speed_of_light": 1.0,
            "density": 1.0,
            "specific_scattering_opacity": 1.0,
            "radiation_constant": 1.0,
            "specific_absorption_opacity": 1.0,
            "source": {"name": "none"},
        },
        "saving": {"directory": "results"},
    }


def test_load_yml_config_success(tmp_path: Path) -> None:
    """Test that load_yml_config successfully loads a valid YAML file."""
    config_path = tmp_path / "config.yml"
    config_dict = {"key": "value"}
    config_path.write_text(yaml.dump(config_dict))

    loaded_config = load_config.load_yml_config(config_path)
    assert loaded_config == config_dict


def test_load_yml_config_not_found() -> None:
    """Test that load_yml_config raises FileNotFoundError for a non-existent file."""
    with pytest.raises(FileNotFoundError):
        load_config.load_yml_config(Path("non_existent_file.yml"))


class TestGeometryValidation:
    """Tests for the Geometry model validators."""

    @pytest.mark.parametrize(
        "field_to_modify, value",
        [("lb", [0.0, 0.0]), ("ub", [1.0, 1.0]), ("n", [10, 10])],
    )
    def test_bounds_length_mismatch(
        self, base_config: dict, field_to_modify: str, value: list
    ) -> None:
        """Test that mismatched dimension for lb, ub, n raises ValueError."""
        base_config["geometry"]["dimension"] = 1
        base_config["geometry"][field_to_modify] = value
        with pytest.raises(pd.ValidationError, match="equal to the dimension"):
            load_config.Config(**base_config)

    def test_bounds_order_invalid(self, base_config: dict) -> None:
        """Test that ub <= lb raises a validation error."""
        base_config["geometry"]["ub"] = base_config["geometry"]["lb"]
        with pytest.raises(pd.ValidationError, match="not larger than lower bound"):
            load_config.Config(**base_config)

    @pytest.mark.parametrize(
        "n_ghost, error_msg",
        [
            ([2, 2], "equal to the dimension"),  # Mismatched length
            ([3], "must be even"),  # Odd number of cells
            ([0], "more ghost cells"),  # Insufficient ghost cells
        ],
    )
    def test_ghost_cells_invalid(
        self, base_config: dict, n_ghost: list[int], error_msg: str
    ) -> None:
        """Test validation rules for n_ghost."""
        base_config["geometry"]["n_ghost"] = n_ghost
        with pytest.raises(pd.ValidationError, match=error_msg):
            load_config.Config(**base_config)


class TestGeometryConstraints:
    """Tests for constraints on top-level Geometry fields."""

    @pytest.mark.parametrize(
        "dimension, error_match",
        [
            (0, "Input should be greater than 0"),
            (3, "Input should be less than or equal to 2"),
        ],
    )
    def test_dimension_constraints(
        self, base_config: dict, dimension: int, error_match: str
    ) -> None:
        """Test that dimension constraints (gt=0, le=3) are enforced."""
        base_config["geometry"]["dimension"] = dimension
        # Adjust other fields to match the invalid dimension to isolate the error
        base_config["geometry"]["lb"] = [0.0] * dimension
        base_config["geometry"]["ub"] = [1.0] * dimension
        base_config["geometry"]["n"] = [10] * dimension
        base_config["geometry"]["n_ghost"] = [2] * dimension

        with pytest.raises(pd.ValidationError, match=error_match):
            load_config.Config(**base_config)


class TestDomainDecompValidation:
    """Tests for the domain_decomp validator."""

    @pytest.mark.parametrize(
        "geom_update",
        [
            # Default (0)
            {},
            # 1D, no split
            {"n": [10], "domain_decomp": 0},
            # 1D, one split
            {"n": [10], "domain_decomp": [1, [0, 0]]},
            # 2D, one split
            {
                "dimension": 2,
                "lb": [0, 0],
                "ub": [1, 1],
                "n": [10, 20],
                "n_ghost": [2, 2],
                "domain_decomp": [1, [0, 0, 0, 0]],
            },
            # 2D, nested split
            {
                "dimension": 2,
                "lb": [0, 0],
                "ub": [1, 1],
                "n": [16, 20],
                "n_ghost": [2, 2],
                "domain_decomp": [1, [[1, [0, 0, 0, 0]], 0, 0, 0]],
            },
        ],
    )
    def test_domain_decomp_success(self, base_config: dict, geom_update: dict) -> None:
        """Test valid domain decomposition configurations."""
        base_config["geometry"].update(geom_update)
        # Should not raise any validation error
        load_config.Config(**base_config)

    @pytest.mark.parametrize(
        "geom_update, error_match",
        [
            (
                {"n": [10], "domain_decomp": [1, [0]]},
                "Invalid number of sub-decompositions",
            ),
            (
                {"n": [10], "domain_decomp": [0, [0, 0]]},
                "Invalid domain_decomp split specifier",
            ),
            (
                {"n": [10], "domain_decomp": "invalid"},
                "Invalid domain_decomp specifier",
            ),
            (
                {
                    "dimension": 2,
                    "lb": [0, 0],
                    "ub": [1, 1],
                    "n": [10, 10],
                    "n_ghost": [2, 2],
                    "domain_decomp": [1, [0, 0]],
                },
                "Invalid number of sub-decompositions",
            ),
        ],
    )
    def test_domain_decomp_invalid(
        self, base_config: dict, geom_update: dict, error_match: str
    ) -> None:
        """Test invalid domain decomposition configurations."""
        base_config["geometry"].update(geom_update)
        with pytest.raises(pd.ValidationError, match=error_match):
            load_config.Config(**base_config)


class TestEquationsValidation:
    """Tests for the Equations model validators."""

    def test_source_check_fails_with_invalid_density(self, base_config: dict) -> None:
        """Test that source check fails if density is invalid for a source."""
        base_config["equations"]["source"] = {"name": "ideal gas"}
        # Set an invalid density that violates the gt=0 constraint.
        base_config["equations"]["density"] = 0.0
        with pytest.raises(pd.ValidationError, match="Input should be greater than 0"):
            load_config.Config(**base_config)

    def test_density_required_for_generic_source(self, base_config: dict) -> None:
        """Test that density is required for a source with a generic problem."""
        # The default 'hohlraum' problem is not a special case.
        base_config["equations"]["source"] = {"name": "ideal gas"}
        del base_config["equations"]["density"]
        with pytest.raises(
            pd.ValidationError,
            match=(
                "Density must be provided for a non-empty source term "
                "with the 'hohlraum' problem."
            ),
        ):
            load_config.Config(**base_config)

    def test_density_not_required_for_crooked_pipe(self, base_config: dict) -> None:
        """Test that density is not required for the CrookedPipe problem."""
        base_config["problem"] = {
            "name": "crooked pipe",
            "background_temperature": 1.0,
            "source_temperature": 2.0,
            "wall_density": 1.0,
            "pipe_density": 0.1,
            "wall_specific_absorption_opacity": 1.0,
            "pipe_specific_absorption_opacity": 0.1,
        }
        base_config["equations"]["source"] = {"name": "ideal gas"}
        # Omit global density
        del base_config["equations"]["density"]

        # This should now pass validation without raising an error.
        load_config.Config(**base_config)


class TestProblemParsing:
    """Tests for the Problem discriminated union."""

    @pytest.mark.parametrize(
        "problem_config, expected_class",
        [
            ({"name": "hohlraum"}, load_config.Hohlraum),
            (
                {"name": "thermal relaxation", "Ti": 1.0, "Tri": 1.0},
                load_config.ThermalRelaxation,
            ),
            (
                {"name": "gaussian diffusion", "A": 1.0, "t0": 1.0},
                load_config.GaussianDiffusion,
            ),
            ({"name": "line source", "u0": 1.0, "omega": 1.0}, load_config.LineSource),
            (
                {
                    "name": "crooked pipe",
                    "background_temperature": 1.0,
                    "source_temperature": 2.0,
                    "wall_density": 1.0,
                    "pipe_density": 0.1,
                    "wall_specific_absorption_opacity": 1.0,
                    "pipe_specific_absorption_opacity": 0.1,
                },
                load_config.CrookedPipe,
            ),
        ],
    )
    def test_problem_parsing_success(
        self, base_config: dict, problem_config: dict, expected_class: type
    ) -> None:
        """Test that different problem configurations parse correctly."""
        base_config["problem"] = problem_config
        config = load_config.Config(**base_config)
        assert isinstance(config.problem, expected_class)

    def test_problem_parsing_invalid_name(self, base_config: dict) -> None:
        """Test that an invalid problem name fails parsing."""
        base_config["problem"] = {"name": "invalid problem"}
        with pytest.raises(
            pd.ValidationError, match="does not match any of the expected tags"
        ):
            load_config.Config(**base_config)


class TestFieldConstraints:
    """Tests for various numeric field constraints."""

    @pytest.mark.parametrize(
        "model, path, value, error_match, setup_config",
        [
            # Solver constraints
            ("solver", "cfl", -0.1, "Input should be greater than 0", None),
            ("solver", "num_steps", 0, "Input should be greater than 0", None),
            ("rounding", "tol", 0.0, "Input should be greater than 0", None),
            # Angles constraints
            ("angles", "n_theta", 0, "Input should be greater than 0", None),
            ("angles", "n_phi", 0, "Input should be greater than 0", None),
            # Equations constraints
            (
                "equations",
                "specific_scattering_opacity",
                -1.0,
                "Input should be greater than or equal to 0",
                None,
            ),
            (
                "equations",
                "radiation_constant",
                -1.0,
                "Input should be greater than or equal to 0",
                None,
            ),
            (
                "equations",
                "specific_absorption_opacity",
                -1.0,
                "Input should be greater than or equal to 0",
                None,
            ),
            # Saving constraints
            ("saving", "checkpoint_freq", 0, "Input should be greater than 0", None),
            # Stencil constraints
            (
                "stencil",
                "wave_speed",
                -1.0,
                "Input should be greater than or equal to 0",
                {"name": "rusanov", "wave_speed": 1.0},
            ),
            (
                "stencil",
                "beta",
                -1.0,
                "Input should be greater than or equal to 0",
                {"name": "jiang"},
            ),
            # Problem constraints
            (
                "problem",
                "A",
                -1.0,
                "Input should be greater than 0",
                {"name": "gaussian diffusion", "A": 1.0, "t0": 1.0},
            ),
            (
                "problem",
                "t0",
                0.0,
                "Input should be greater than 0",
                {"name": "gaussian diffusion", "A": 1.0, "t0": 1.0},
            ),
            (
                "problem",
                "u0",
                0.0,
                "Input should be greater than 0",
                {"name": "line source", "u0": 1.0, "omega": 1.0},
            ),
            (
                "problem",
                "background_temperature",
                0.0,
                "Input should be greater than 0",
                {
                    "name": "crooked pipe",
                    "background_temperature": 1.0,
                    "source_temperature": 1.0,
                    "wall_density": 1.0,
                    "pipe_density": 1.0,
                    "wall_specific_absorption_opacity": 1.0,
                    "pipe_specific_absorption_opacity": 1.0,
                },
            ),
        ],
    )
    def test_numeric_field_constraints(
        self,
        base_config: dict,
        model: str,
        path: str,
        value: float,
        error_match: str,
        setup_config: dict | None,
    ) -> None:
        """Test various numeric constraints (gt, ge, le)."""
        if model == "problem":
            base_config["problem"] = setup_config
            base_config["problem"][path] = value
        elif model == "stencil":
            base_config["solver"]["stencil"] = setup_config
            base_config["solver"]["stencil"][path] = value
        elif model == "rounding":
            base_config["solver"]["rounding"][path] = value
        else:
            base_config[model][path] = value

        with pytest.raises(pd.ValidationError, match=error_match):
            load_config.Config(**base_config)
