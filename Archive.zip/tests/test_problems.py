from types import SimpleNamespace

import pytest
from pydantic import BaseModel

from pytens_radtrans import problems
from pytens_radtrans.load_config import (
    Angles,
    Config,
    CrookedPipe,
    Equations,
    GaussianDiffusion,
    Geometry,
    Hohlraum,
    IdealGas,
    LineSource,
    NoSource,
    Rounding,
    Saving,
    Solver,
    ThermalRelaxation,
    UpwindStencil,
)


def create_base_config(problem_config: BaseModel, dimension: int) -> Config:
    """Creates a minimal, valid config object for testing."""
    return Config(
        geometry=Geometry(
            dimension=dimension,
            lb=[0.0] * dimension,
            ub=[1.0] * dimension,
            n=[10] * dimension,
            n_ghost=[2] * dimension,
        ),
        angles=Angles(n_theta=2, n_phi=2),
        solver=Solver(
            num_steps=1,
            cfl=0.5,
            method="forward euler",
            stencil=UpwindStencil(name="upwind"),
            rounding=Rounding(method="svd", tol=1e-8, freq=1),
            order=["space", "theta", "phi"],
        ),
        equations=Equations(
            speed_of_light=1.0,
            specific_absorption_opacity=0.0,
            specific_scattering_opacity=1.0,
            density=1.0,
            source=NoSource(name="none"),
        ),
        problem=problem_config,
        saving=Saving(directory="."),
    )


@pytest.mark.parametrize(
    "dimension, expected_class",
    [
        (1, problems.Hohlraum1D),
        (2, problems.Hohlraum2D),
    ],
)
def test_load_problem_hohlraum(dimension, expected_class):
    """Tests loading 1D and 2D Hohlraum problems."""
    config = create_base_config(Hohlraum(name="hohlraum"), dimension)
    problem = problems.load_problem(config)
    assert isinstance(problem, expected_class)


@pytest.mark.parametrize(
    "dimension, expected_class",
    [
        (1, problems.ThermalRelaxation1D),
        (2, problems.ThermalRelaxation2D),
    ],
)
def test_load_problem_thermal_relaxation(dimension, expected_class):
    """Tests loading 1D and 2D ThermalRelaxation problems."""
    problem_config = ThermalRelaxation(name="thermal relaxation", Ti=1.0, Tri=1.0)
    config = create_base_config(problem_config, dimension)
    config.equations.source = IdealGas(name="ideal gas", specific_heat_capacity=1.0)

    problem = problems.load_problem(config)
    assert isinstance(problem, expected_class)


@pytest.mark.parametrize(
    "dimension, expected_class",
    [
        (1, problems.GaussianDiffusion1D),
        (2, problems.GaussianDiffusion2D),
    ],
)
def test_load_problem_gaussian_diffusion(dimension, expected_class):
    """Tests loading 1D and 2D GaussianDiffusion problems."""
    problem_config = GaussianDiffusion(name="gaussian diffusion", A=1.0, t0=0.1)
    config = create_base_config(problem_config, dimension)
    problem = problems.load_problem(config)
    assert isinstance(problem, expected_class)


def test_load_problem_line_source():
    """Tests loading a 2D LineSource problem."""
    problem_config = LineSource(name="line source", u0=1.0, omega=0.1)
    config = create_base_config(problem_config, 2)
    problem = problems.load_problem(config)
    assert isinstance(problem, problems.LineSource2D)


def test_load_problem_crooked_pipe():
    """Tests loading a 2D CrookedPipe problem."""
    problem_config = CrookedPipe(
        name="crooked pipe",
        background_temperature=1.0,
        source_temperature=10.0,
        wall_density=1.0,
        pipe_density=0.1,
        wall_specific_absorption_opacity=100.0,
        pipe_specific_absorption_opacity=0.1,
    )
    config = create_base_config(problem_config, 2)
    problem = problems.load_problem(config)
    assert isinstance(problem, problems.CrookedPipe)


def test_load_problem_not_implemented():
    """Tests that an unknown problem raises NotImplementedError."""

    class UnknownProblem:
        """A mock problem config class that is not in the discriminated union."""

        name: str = "Unknown"

    # Create a mock config object that bypasses Pydantic validation.
    # The `load_problem` function only needs the `.problem` attribute to
    # reach the `NotImplementedError` branch.
    mock_config = SimpleNamespace(problem=UnknownProblem())

    with pytest.raises(NotImplementedError):
        problems.load_problem(mock_config)  # type: ignore
