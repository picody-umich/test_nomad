import logging
from unittest.mock import ANY, MagicMock, call, patch

import numpy as np
import pytest

from pytens_radtrans import domain_loop, solver
from pytens_radtrans.load_config import (
    Config,
    Equations,
    NoSource,
    Rounding,
    Solver,
)

# A simplified mock for pytens.TensorNetwork
MockTensorNetwork = MagicMock


@pytest.fixture
def mock_config():
    """Provides a mock Config object for testing."""
    config = MagicMock(spec=Config)
    config.solver = MagicMock(spec=Solver)
    config.solver.method = "forward euler"
    config.solver.rounding = MagicMock(spec=Rounding)
    config.solver.rounding.freq = 2
    config.equations = MagicMock(spec=Equations)
    config.equations.source = MagicMock(spec=NoSource)
    config.equations.source.name = "none"
    return config


@pytest.fixture
def mock_solution():
    """Provides a mock Solution object for testing."""
    solution = MagicMock(spec=solver.Solution)
    solution.time = 0.0
    solution.intensity = MockTensorNetwork()
    solution.intensity.ranks.return_value = [2, 2, 2]
    solution.space = {
        "temperature": np.ones(10),
        "absorption_opacity": np.ones(10),
        "scattering_opacity": np.ones(10),
        "density": np.ones(10),
    }
    return solution


@pytest.fixture
def mock_rhs():
    """Provides a mock rhs callable that returns a mock TNOPList."""
    # This mock will stand in for the `utils.TNOPList` that `rhs` returns
    mock_sum_update = MagicMock()
    mock_sum_update.evaluate.return_value = MockTensorNetwork(name="evaluated")
    mock_sum_update.evaluate_round.return_value = MockTensorNetwork(name="rounded")

    rhs_callable = MagicMock(return_value=mock_sum_update)
    return rhs_callable


@patch("pytens_radtrans.domain_loop.utils.TT")
def test_domain_step_forward_euler_no_rounding(
    mock_tt_class, mock_config, mock_solution, mock_rhs
):
    """
    Tests the domain_step function with forward euler, no rounding, and no source term.
    """
    # Arrange
    mock_config.solver.rounding.freq = 100  # Ensure no rounding
    mock_config.equations.source.name = "none"
    ii = 1  # Step that does not trigger rounding
    dt = 0.1
    absorption_opacity = np.ones(12)
    scattering_opacity = np.ones(12)

    # Act
    new_sol = domain_loop.domain_step(
        prev_sol=mock_solution,
        ii=ii,
        dt=dt,
        absorption_opacity_with_ghost=absorption_opacity,
        scattering_opacity_with_ghost=scattering_opacity,
        additive_tensors=[],
        rhs=mock_rhs,
        config=mock_config,
        disc=MagicMock(),
        indices=MagicMock(),
        logger=logging.getLogger(),
    )

    # Assert
    # Check that rhs was called correctly
    mock_rhs.assert_called_once_with(
        [],
        {
            "absorption_opacity": absorption_opacity,
            "scattering_opacity": scattering_opacity,
        },
    )

    # Check that the previous solution's intensity was added to the update
    sum_update_obj = mock_rhs.return_value
    sum_update_obj.append.assert_called_once()
    mock_tt_class.assert_called_once_with(mock_solution.intensity)

    # Check that rounding was NOT called and evaluate was
    sum_update_obj.evaluate.assert_called_once()
    sum_update_obj.evaluate_round.assert_not_called()

    # Check the new solution object
    assert isinstance(new_sol, solver.Solution)
    assert new_sol.time == mock_solution.time + dt
    assert new_sol.intensity is sum_update_obj.evaluate.return_value
    assert "temperature" in new_sol.space
    np.testing.assert_array_equal(
        new_sol.space["temperature"], mock_solution.space["temperature"]
    )


@patch("pytens_radtrans.domain_loop.utils.TT")
def test_domain_step_with_rounding(mock_tt_class, mock_config, mock_solution, mock_rhs):
    """
    Tests that rounding is applied correctly when ii % freq == 0.
    """
    # Arrange
    mock_config.solver.rounding.freq = 5
    mock_config.equations.source.name = "none"
    ii = 10  # Step that DOES trigger rounding

    # Act
    domain_loop.domain_step(
        prev_sol=mock_solution,
        ii=ii,
        dt=0.1,
        absorption_opacity_with_ghost=np.ones(12),
        scattering_opacity_with_ghost=np.ones(12),
        additive_tensors=[],
        rhs=mock_rhs,
        config=mock_config,
        disc=MagicMock(),
        indices=MagicMock(),
        logger=logging.getLogger(),
    )

    # Assert
    sum_update_obj = mock_rhs.return_value
    sum_update_obj.evaluate.assert_not_called()
    sum_update_obj.evaluate_round.assert_called_once_with(
        mock_config.solver.rounding, mock_solution.intensity.ranks.return_value
    )


@patch("pytens_radtrans.domain_loop.solver.temp_equation_ideal_gas")
@patch("pytens_radtrans.domain_loop.utils.TT")
def test_domain_step_source_ideal_gas(
    mock_tt_class, mock_temp_eq, mock_config, mock_solution, mock_rhs
):
    """
    Tests the logic for the 'ideal gas' source term with rounding.
    """
    # Arrange
    mock_config.equations.source.name = "ideal gas"
    mock_config.solver.rounding.freq = 1  # Round every step
    ii = 1
    dt = 0.1

    mock_next_intensity = MockTensorNetwork(name="next_intensity")
    mock_next_intensity.evaluate_round.return_value = MockTensorNetwork(
        name="next_intensity_rounded"
    )
    mock_next_temp = np.full(10, 1.5)
    mock_temp_eq.return_value = (mock_next_intensity, mock_next_temp)

    # Act
    new_sol = domain_loop.domain_step(
        prev_sol=mock_solution,
        ii=ii,
        dt=dt,
        absorption_opacity_with_ghost=np.ones(12),
        scattering_opacity_with_ghost=np.ones(12),
        additive_tensors=[],
        rhs=mock_rhs,
        config=mock_config,
        disc=MagicMock(),
        indices=MagicMock(),
        logger=logging.getLogger(),
    )

    # Assert
    mock_temp_eq.assert_called_once_with(ANY, ANY, dt, ANY, mock_config)
    assert new_sol.intensity is mock_next_intensity.evaluate_round.return_value
    np.testing.assert_array_equal(new_sol.space["temperature"], mock_next_temp)


@patch("pytens_radtrans.domain_loop.solver.scatter_source")
@patch("pytens_radtrans.domain_loop.utils.TT")
def test_domain_step_source_scatter_only_no_rounding(
    mock_tt_class, mock_scatter_source, mock_config, mock_solution, mock_rhs
):
    """
    Tests the logic for the 'scatter only' source term without rounding.
    """
    # Arrange
    mock_config.equations.source.name = "scatter only"
    mock_config.solver.rounding.freq = 2  # Don't round on this step
    ii = 1
    dt = 0.1

    mock_next_intensity = MockTensorNetwork(name="next_intensity")
    mock_next_intensity.evaluate.return_value = MockTensorNetwork(
        name="next_intensity_evaluated"
    )
    mock_scatter_source.return_value = mock_next_intensity

    # Act
    new_sol = domain_loop.domain_step(
        prev_sol=mock_solution,
        ii=ii,
        dt=dt,
        absorption_opacity_with_ghost=np.ones(12),
        scattering_opacity_with_ghost=np.ones(12),
        additive_tensors=[],
        rhs=mock_rhs,
        config=mock_config,
        disc=MagicMock(),
        indices=MagicMock(),
        logger=logging.getLogger(),
    )

    # Assert
    mock_scatter_source.assert_called_once_with(ANY, ANY, dt, ANY, mock_config)
    # Check that rounding was NOT called on the source result
    mock_next_intensity.evaluate_round.assert_not_called()
    mock_next_intensity.evaluate.assert_called_once()
    assert new_sol.intensity is mock_next_intensity.evaluate.return_value


def test_domain_step_unsupported_solver(mock_config, mock_solution, mock_rhs):
    """
    Tests that NotImplementedError is raised for an unsupported solver method.
    """
    # Arrange
    mock_config.solver.method = "unsupported method"

    # Act & Assert
    with pytest.raises(NotImplementedError, match="This solver not implemented"):
        domain_loop.domain_step(
            prev_sol=mock_solution,
            ii=1,
            dt=0.1,
            absorption_opacity_with_ghost=np.ones(12),
            scattering_opacity_with_ghost=np.ones(12),
            additive_tensors=[],
            rhs=mock_rhs,
            config=mock_config,
            disc=MagicMock(),
            indices=MagicMock(),
            logger=logging.getLogger(),
        )


@patch("pytens_radtrans.domain_loop.utils.TT")
def test_domain_step_with_flux_corrections(
    mock_tt_class, mock_config, mock_solution, mock_rhs
):
    """
    Tests that flux correction tensors are correctly added to the RHS update.
    """
    # Arrange
    mock_config.solver.rounding.freq = 100  # Ensure no rounding
    mock_correction_1 = MockTensorNetwork(name="correction1")
    mock_correction_2 = MockTensorNetwork(name="correction2")
    flux_corrections = [mock_correction_1, mock_correction_2]

    # Act
    domain_loop.domain_step(
        prev_sol=mock_solution,
        ii=1,
        dt=0.1,
        absorption_opacity_with_ghost=np.ones(12),
        scattering_opacity_with_ghost=np.ones(12),
        additive_tensors=[],
        rhs=mock_rhs,
        config=mock_config,
        disc=MagicMock(),
        indices=MagicMock(),
        logger=logging.getLogger(),
        flux_corrections=flux_corrections,
    )

    # Assert
    # Check that TT was instantiated for the solution and each correction
    tt_calls = [
        call(mock_solution.intensity),
        call(mock_correction_1),
        call(mock_correction_2),
    ]
    mock_tt_class.assert_has_calls(tt_calls, any_order=True)

    # Check that each TT object was appended to the RHS sum
    sum_update_obj = mock_rhs.return_value
    assert sum_update_obj.append.call_count == 3
