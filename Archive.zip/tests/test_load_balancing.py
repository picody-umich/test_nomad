"""Unit tests for the load balancing module."""

from unittest.mock import MagicMock

from pytens_radtrans import load_balancing
from pytens_radtrans.domain_decomp import DomainManager


class IntensityWithCost:
    def __init__(self, cost: float):
        self._cost = cost

    def cost(self) -> float:
        return self._cost


def create_mock_manager(num_leaves: int) -> DomainManager:
    """Creates a mock DomainManager with a flat list of leaves."""
    manager = MagicMock(spec=DomainManager)
    # Create mock leaves with an 'index' attribute
    leaves = []
    for i in range(num_leaves):
        leaf = MagicMock()
        leaf.index = i
        leaves.append(leaf)
    manager.leaves = leaves
    return manager


def test_compute_local_weights() -> None:
    """Test weight computation strategies."""
    # Mock solutions
    sol1 = MagicMock()
    sol1.intensity = IntensityWithCost(300)

    sol2 = MagicMock()
    sol2.intensity = IntensityWithCost(50)

    solutions = [sol1, sol2]

    # Test 'count' strategy
    weights_count = load_balancing.compute_local_weights(solutions, "count")
    assert weights_count == [1.0, 1.0]

    # Test 'parameters' strategy
    weights_param = load_balancing.compute_local_weights(solutions, "parameters")
    assert weights_param == [300.0, 50.0]


def test_compute_local_weights_prefers_numeric_cost() -> None:
    """A numeric intensity.cost() should be used directly."""
    sol = MagicMock()
    sol.intensity = IntensityWithCost(321)
    weights = load_balancing.compute_local_weights([sol], "parameters")
    assert weights == [321.0]


def test_compute_local_weights_unknown_strategy_raises() -> None:
    """Unknown weighting strategies must fail fast."""
    sol = MagicMock()
    sol.intensity = IntensityWithCost(1)
    try:
        load_balancing.compute_local_weights([sol], "mystery")
    except ValueError as exc:
        assert "Unknown load-balancing strategy" in str(exc)
    else:
        raise AssertionError("Expected ValueError for unknown strategy.")


def test_compute_local_weights_missing_cost_raises() -> None:
    """Parameter strategy must require intensity.cost()."""
    sol = MagicMock()
    sol.intensity = object()  # no `cost` method
    try:
        load_balancing.compute_local_weights([sol], "parameters")
    except AttributeError:
        pass
    else:
        raise AssertionError("Expected AttributeError when intensity cost is missing.")


def test_propose_partition_balanced() -> None:
    """Test that balanced loads do not trigger migration."""
    num_ranks = 2
    num_leaves = 4
    manager = create_mock_manager(num_leaves)

    # Perfectly balanced: Rank 0 has [0, 1], Rank 1 has [2, 3]
    current_rank_map = {0: 0, 1: 0, 2: 1, 3: 1}
    global_weights = {i: 1.0 for i in range(num_leaves)}

    migration = load_balancing.propose_partition(
        manager, num_ranks, current_rank_map, global_weights, threshold=1.1
    )

    assert migration is None


def test_propose_partition_imbalanced() -> None:
    """Test that imbalance triggers migration."""
    num_ranks = 2
    num_leaves = 4
    manager = create_mock_manager(num_leaves)

    # Imbalanced: Rank 0 has [0, 1, 2], Rank 1 has [3]
    # Loads: Rank 0 = 3.0, Rank 1 = 1.0. Avg = 2.0. Max/Avg = 1.5 > 1.1
    current_rank_map = {0: 0, 1: 0, 2: 0, 3: 1}
    global_weights = {i: 1.0 for i in range(num_leaves)}

    migration = load_balancing.propose_partition(
        manager, num_ranks, current_rank_map, global_weights, threshold=1.1
    )

    assert migration is not None
    # Expect leaf 2 to move to Rank 1 to balance (2 vs 2)
    # New map should be: Rank 0: [0, 1], Rank 1: [2, 3]
    assert 2 in migration
    assert migration[2] == 1
    # Leaves 0 and 1 stay on 0 (not in map or map to 0)
    if 0 in migration:
        assert migration[0] == 0
    if 1 in migration:
        assert migration[1] == 0


def test_propose_partition_weighted() -> None:
    """Test balancing based on weights, not just counts."""
    num_ranks = 2
    num_leaves = 3
    manager = create_mock_manager(num_leaves)

    # Leaf 0 is heavy (weight 10), Leaves 1 & 2 are light (weight 5)
    # Total = 20. Target per rank = 10.
    global_weights = {0: 10.0, 1: 5.0, 2: 5.0}

    # Currently: Rank 0 has [0, 1] (Load 15), Rank 1 has [2] (Load 5)
    # Avg = 10. Max/Avg = 1.5 > 1.1
    current_rank_map = {0: 0, 1: 0, 2: 1}

    migration = load_balancing.propose_partition(
        manager, num_ranks, current_rank_map, global_weights, threshold=1.1
    )

    assert migration is not None
    # To balance, Rank 0 should keep Leaf 0 (10). Rank 1 should take 1 & 2 (5+5=10).
    # So Leaf 1 must move to Rank 1.
    assert 1 in migration
    assert migration[1] == 1


def test_propose_partition_rejects_missing_weights() -> None:
    """Missing weights must fail instead of falling back silently."""
    manager = create_mock_manager(3)
    current_rank_map = {0: 0, 1: 0, 2: 1}
    global_weights = {0: 1.0, 1: 1.0}

    try:
        load_balancing.propose_partition(
            manager, 2, current_rank_map, global_weights, threshold=1.1
        )
    except RuntimeError as exc:
        assert "Global load weights do not match domain leaves" in str(exc)
    else:
        raise AssertionError("Expected RuntimeError for missing global weights.")
