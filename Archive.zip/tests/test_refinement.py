"""Unit tests for AMR configuration, triggers, and spatial data adapters."""

import logging
from unittest.mock import MagicMock, patch

import numpy as np
import pydantic
import pytens
import pytest
from mpi4py import MPI

from pytens_radtrans import load_config, refinement, solver
from pytens_radtrans.discretization import AngleDiscretization, Discretization
from pytens_radtrans.refinement import (
    merge_solution,
    merge_spatial_data,
    split_solution,
    split_spatial_data,
)


def test_refinement_config_defaults():
    """Test default values for RefinementConfig."""
    # Default should be RankRefinementConfig
    cfg = load_config.RankRefinementConfig()
    assert not cfg.enabled
    assert cfg.strategy == "rank"
    assert cfg.max_rank > cfg.min_rank


def test_refinement_config_validation():
    """Test validation logic for RefinementConfig."""
    with pytest.raises(pydantic.ValidationError):
        load_config.RankRefinementConfig(max_rank=5, min_rank=10)


def test_intensity_refinement_config_validation():
    """Test validation logic for IntensityRefinementConfig."""
    # Valid config
    cfg = load_config.IntensityRefinementConfig(
        refine_fraction=0.2, coarsen_fraction=0.5
    )
    assert cfg.strategy == "mean_intensity"

    # Invalid: refine >= coarsen (no hysteresis)
    with pytest.raises(pydantic.ValidationError):
        load_config.IntensityRefinementConfig(refine_fraction=0.5, coarsen_fraction=0.5)

    with pytest.raises(pydantic.ValidationError):
        load_config.IntensityRefinementConfig(refine_fraction=0.6, coarsen_fraction=0.5)


def test_max_rank_trigger_refine():
    """Test that MaxRankTrigger correctly identifies refinement needs."""
    trigger = refinement.MaxRankTrigger(max_rank=10, min_rank=5)

    # Mock a solution with high rank
    sol_high = MagicMock(spec=solver.Solution)
    sol_high.intensity = MagicMock()
    sol_high.intensity.ranks.return_value = [1, 15, 1]  # 15 > 10

    # Mock a solution with low rank
    sol_low = MagicMock(spec=solver.Solution)
    sol_low.intensity = MagicMock()
    sol_low.intensity.ranks.return_value = [1, 8, 1]  # 8 <= 10

    assert trigger.should_refine(sol_high)
    assert not trigger.should_refine(sol_low)


def test_max_rank_trigger_coarsen():
    """Test that MaxRankTrigger correctly identifies coarsening needs."""
    trigger = refinement.MaxRankTrigger(max_rank=10, min_rank=5)

    # Case 1: All siblings are low rank -> Coarsen
    sols_coarsen = []
    for _ in range(4):
        sol = MagicMock(spec=solver.Solution)
        sol.intensity = MagicMock()
        sol.intensity.ranks.return_value = [1, 2, 1]  # 2 < 5
        sols_coarsen.append(sol)

    assert trigger.should_coarsen(sols_coarsen)

    # Case 2: One sibling is high rank -> Do not coarsen
    sols_keep = []
    for i in range(4):
        sol = MagicMock(spec=solver.Solution)
        sol.intensity = MagicMock()
        if i == 0:
            sol.intensity.ranks.return_value = [1, 8, 1]  # 8 >= 5
        else:
            sol.intensity.ranks.return_value = [1, 2, 1]
        sols_keep.append(sol)

    assert not trigger.should_coarsen(sols_keep)


def test_mean_intensity_trigger():
    """Test MeanIntensityTrigger logic with mocked MPI."""
    # Refine top 20% (val > 0.8 * max), Coarsen bottom 50% (val < 0.5 * max)
    trigger = refinement.MeanIntensityTrigger(refine_fraction=0.2, coarsen_fraction=0.5)

    # Mock MPI communicator
    mock_comm = MagicMock(spec=MPI.Comm)
    # Simulate global max = 100.0
    mock_comm.allreduce.return_value = 100.0

    # Mock local solutions
    sol1 = MagicMock(spec=solver.Solution)
    sol1.aux = {"mean_intensity": np.array([50.0])}  # Local max 50
    sol2 = MagicMock(spec=solver.Solution)
    sol2.aux = {"mean_intensity": np.array([90.0])}  # Local max 90

    # 1. Update global stats
    trigger.update_global_stats(mock_comm, [sol1, sol2])
    assert trigger.global_max == 100.0
    mock_comm.allreduce.assert_called_once()

    # 2. Test Refinement
    # Threshold = (1 - 0.2) * 100 = 80.0
    sol_refine = MagicMock(spec=solver.Solution)
    sol_refine.aux = {"mean_intensity": np.array([85.0])}  # 85 > 80 -> Refine
    assert trigger.should_refine(sol_refine)

    sol_keep = MagicMock(spec=solver.Solution)
    sol_keep.aux = {"mean_intensity": np.array([75.0])}  # 75 < 80 -> Keep
    assert not trigger.should_refine(sol_keep)

    # 3. Test Coarsening
    # Threshold = (1 - 0.5) * 100 = 50.0
    # Case A: All below 50 -> Coarsen
    sols_coarsen = []
    for _ in range(4):
        s = MagicMock(spec=solver.Solution)
        s.aux = {"mean_intensity": np.array([40.0])}
        sols_coarsen.append(s)
    assert trigger.should_coarsen(sols_coarsen)

    # Case B: One above 50 -> Keep
    sols_keep_coarsen = []
    for i in range(4):
        s = MagicMock(spec=solver.Solution)
        if i == 0:
            s.aux = {"mean_intensity": np.array([60.0])}
        else:
            s.aux = {"mean_intensity": np.array([40.0])}
        sols_keep_coarsen.append(s)
    assert not trigger.should_coarsen(sols_keep_coarsen)

    # 4. Test Missing Data Error
    sol_error = MagicMock(spec=solver.Solution)
    sol_error.aux = {}  # Missing key
    with pytest.raises(ValueError, match="Mean intensity not found"):
        trigger.should_refine(sol_error)


def test_split_spatial_data_1d_linear():
    """Test splitting a linear function results in exact interpolation (order=1)."""
    # Parent: x in [0, 2], N=4. Centers: 0.25, 0.75, 1.25, 1.75
    parent_disc = Discretization.from_geom([0.0], [2.0], [4], [0])

    # Function f(x) = 2x + 1
    x_p = parent_disc.grid.cell_centers[0]
    parent_arr = 2.0 * x_p + 1.0
    # Add a dummy rank dimension (e.g., shape (4, 1))
    parent_arr = parent_arr[:, np.newaxis]

    # Split into children
    children_discs = parent_disc.split()
    left_disc, right_disc = children_discs[0], children_discs[1]

    # Interpolate
    left_arr = split_spatial_data(parent_arr, parent_disc, left_disc, order=1)
    right_arr = split_spatial_data(parent_arr, parent_disc, right_disc, order=1)

    # Check Left Child
    x_l = left_disc.grid.cell_centers[0]
    expected_l = 2.0 * x_l + 1.0
    np.testing.assert_allclose(
        left_arr.squeeze(), expected_l, err_msg="Left child interpolation failed"
    )

    # Check Right Child
    x_r = right_disc.grid.cell_centers[0]
    expected_r = 2.0 * x_r + 1.0
    np.testing.assert_allclose(
        right_arr.squeeze(), expected_r, err_msg="Right child interpolation failed"
    )


def test_merge_spatial_data_1d_conservation():
    """Test that merging conserves the volume average (restriction)."""
    parent_disc = Discretization.from_geom([0.0], [2.0], [4], [0])
    children_discs = parent_disc.split()

    # Left child has value 10, Right child has value 20
    # Shape (4, 1)
    left_arr = np.full((4, 1), 10.0)
    right_arr = np.full((4, 1), 20.0)

    merged = merge_spatial_data([left_arr, right_arr], children_discs, parent_disc)

    # Parent should be average of children in the respective regions.
    # Since parent N=4, first 2 cells cover left (10), last 2 cells cover right (20).
    # However, merge_spatial_data averages *fine* cells to *coarse* cells.
    # Left child (N=4) covers [0, 1]. Parent cells 0,1 cover [0, 1].
    # So Parent[0] averages Left[0], Left[1]. Parent[1] averages Left[2], Left[3].

    expected = np.array([10.0, 10.0, 20.0, 20.0]).reshape(4, 1)
    np.testing.assert_allclose(merged, expected, err_msg="1D Merge conservation failed")


def test_split_spatial_data_2d_linear():
    """Test 2D splitting with a linear plane f(x,y) = x + y."""
    # Parent: [0,2]x[0,2], 4x4 cells
    parent_disc = Discretization.from_geom([0.0, 0.0], [2.0, 2.0], [4, 4], [0, 0])

    x = parent_disc.grid.cell_centers[0]
    y = parent_disc.grid.cell_centers[1]
    # Create meshgrid (indexing='ij' for x,y order)
    X, Y = np.meshgrid(x, y, indexing="ij")
    parent_arr = X + Y

    children_discs = parent_disc.split()
    # 0: LL, 1: UL, 2: UR, 3: LR

    # Test Upper Right (UR) - Index 2
    ur_disc = children_discs[2]
    ur_arr = split_spatial_data(parent_arr, parent_disc, ur_disc, order=1)

    x_ur = ur_disc.grid.cell_centers[0]
    y_ur = ur_disc.grid.cell_centers[1]
    X_ur, Y_ur = np.meshgrid(x_ur, y_ur, indexing="ij")
    expected_ur = X_ur + Y_ur

    np.testing.assert_allclose(
        ur_arr, expected_ur, atol=1e-14, err_msg="2D Split (UR) failed"
    )


def test_merge_spatial_data_2d_checkerboard():
    """Test 2D merging with distinct values in each quadrant."""
    parent_disc = Discretization.from_geom([0.0, 0.0], [2.0, 2.0], [4, 4], [0, 0])
    children_discs = parent_disc.split()

    # N=4 per child
    shape = (4, 4)

    # LL=1, UL=2, UR=3, LR=4
    c0 = np.full(shape, 1.0)  # LL
    c1 = np.full(shape, 2.0)  # UL
    c2 = np.full(shape, 3.0)  # UR
    c3 = np.full(shape, 4.0)  # LR

    merged = merge_spatial_data([c0, c1, c2, c3], children_discs, parent_disc)

    # Parent is 4x4.
    # x in [0, 1] (indices 0,1) -> Left Strip (LL, UL)
    # x in [1, 2] (indices 2,3) -> Right Strip (LR, UR)
    # y in [0, 1] (indices 0,1) -> Bottom (LL, LR)
    # y in [1, 2] (indices 2,3) -> Top (UL, UR)

    # Parent[0:2, 0:2] should be 1.0 (LL)
    np.testing.assert_allclose(merged[0:2, 0:2], 1.0)
    # Parent[0:2, 2:4] should be 2.0 (UL)
    np.testing.assert_allclose(merged[0:2, 2:4], 2.0)
    # Parent[2:4, 2:4] should be 3.0 (UR)
    np.testing.assert_allclose(merged[2:4, 2:4], 3.0)
    # Parent[2:4, 0:2] should be 4.0 (LR)
    np.testing.assert_allclose(merged[2:4, 0:2], 4.0)


def test_split_accuracy_sine():
    """Check L2 error convergence or small error for sine wave."""
    # Use a denser grid to ensure linear interpolation is decent
    N = 20
    parent_disc = Discretization.from_geom([0.0], [np.pi], [N], [0])
    x_p = parent_disc.grid.cell_centers[0]
    parent_arr = np.sin(x_p)

    children_discs = parent_disc.split()
    left_disc = children_discs[0]

    # Interpolate
    left_arr = split_spatial_data(parent_arr, parent_disc, left_disc, order=1)

    # Exact
    x_l = left_disc.grid.cell_centers[0]
    exact_l = np.sin(x_l)

    # Error should be small (O(dx^2))
    error = np.linalg.norm(left_arr - exact_l) / np.sqrt(N)
    assert error < 1e-2, f"Interpolation error too high: {error}"


@patch("pytens_radtrans.refinement.domain_decomp.transfer_boundaries")
def test_split_solution_structure(mock_transfer_boundaries: MagicMock) -> None:
    """Test that split_solution correctly creates child Solution objects."""
    # Setup mocks
    mock_op = MagicMock()
    mock_op.return_value = MagicMock(spec=pytens.TensorNetwork)
    mock_transfer_boundaries.return_value = mock_op

    # Setup Parent
    parent_disc = Discretization.from_geom([0.0], [1.0], [4], [0])
    parent_sol = MagicMock(spec=solver.Solution)
    parent_sol.time = 0.5
    parent_sol.intensity = MagicMock(spec=pytens.TensorNetwork)
    parent_sol.space = {"temp": np.ones((4, 1))}

    # Setup Children
    child_discs = parent_disc.split()

    # Mock domain_angles
    mock_angles = MagicMock(spec=AngleDiscretization)
    mock_angles.theta = np.array([0.5, 1.5])
    mock_angles.phi = np.array([0.5, 1.5])
    mock_logger = MagicMock(spec=logging.Logger)

    # Execute
    permut = [0, 1, 2]  # Dummy permutation for the test
    rounding_opts = load_config.Rounding(method="svd", tol=1e-6, freq=1, tt_sum=False)
    child_sols = split_solution(
        parent_sol,
        parent_disc,
        child_discs,
        permut,
        mock_angles,
        rounding_opts,
        mock_logger,
    )

    # Assertions
    assert len(child_sols) == 2
    assert mock_transfer_boundaries.call_count == len(child_discs)
    assert mock_op.call_count == len(child_discs)

    for sol in child_sols:
        assert sol.time == 0.5
        np.testing.assert_array_equal(sol.space["temp"], np.ones((4, 1)))
        assert sol.intensity == mock_op.return_value


@patch("pytens_radtrans.refinement.domain_decomp.transfer_boundaries")
def test_split_solution_interpolation_1d(mock_transfer_boundaries: MagicMock) -> None:
    """Tests the 1D interpolation logic within split_solution via mocking."""
    # 1. Setup mocks
    mock_op = MagicMock()
    mock_op.return_value = MagicMock(spec=pytens.TensorNetwork)
    mock_transfer_boundaries.return_value = mock_op

    # 2. Setup Discretizations
    n_parent = 10
    parent_disc = Discretization.from_geom([0.0], [1.0], [n_parent], [0])
    child_discs = parent_disc.split()
    child_left, child_right = child_discs

    # 3. Setup parent solution and mock angles
    parent_sol = MagicMock(spec=solver.Solution)
    parent_sol.time = 0.5
    parent_sol.intensity = MagicMock(spec=pytens.TensorNetwork)
    parent_sol.intensity.ranks.return_value = [1, 2, 1]
    parent_sol.space = {}
    parent_sol.space = {}
    mock_angles = MagicMock(spec=AngleDiscretization)
    mock_angles.theta = np.array([0.5])
    mock_angles.phi = np.array([0.5])
    mock_logger = MagicMock(spec=logging.Logger)

    # 4. Execute the function to be tested
    rounding_opts = load_config.Rounding(method="svd", tol=1e-6, freq=1, tt_sum=False)
    split_solution(
        parent_sol,
        parent_disc,
        child_discs,
        [0, 1, 2],
        mock_angles,
        rounding_opts,
        mock_logger,
    )

    # 5. Capture the interpolation function passed to the mock
    assert mock_transfer_boundaries.call_count == 2
    interp_op_left = mock_transfer_boundaries.call_args_list[0].args[0]
    interp_op_right = mock_transfer_boundaries.call_args_list[1].args[0]

    # 6. Test the captured interpolation function directly
    x_parent = parent_disc.grid.cell_centers[0]
    parent_core_flat = x_parent.reshape(-1, 1)  # Simulate a rank-1 spatial core

    # Test left child
    child_core_left = interp_op_left(parent_core_flat)
    # split_solution uses order=1 (Linear interpolation).
    expected_left = split_spatial_data(
        parent_core_flat, parent_disc, child_left, order=0
    ).flatten()
    np.testing.assert_allclose(child_core_left.flatten(), expected_left)

    # Test right child
    child_core_right = interp_op_right(parent_core_flat)
    expected_right = split_spatial_data(
        parent_core_flat, parent_disc, child_right, order=0
    ).flatten()
    np.testing.assert_allclose(child_core_right.flatten(), expected_right)


@patch("pytens_radtrans.refinement.domain_decomp.transfer_boundaries")
def test_split_solution_interpolation_2d(mock_transfer_boundaries: MagicMock) -> None:
    """Tests the 2D interpolation logic within split_solution via mocking."""
    # 1. Setup mocks
    mock_op = MagicMock()
    mock_op.return_value = MagicMock(spec=pytens.TensorNetwork)
    mock_transfer_boundaries.return_value = mock_op

    # 2. Setup Discretizations
    n_parent = 10
    parent_disc = Discretization.from_geom(
        [0.0, 0.0], [1.0, 1.0], [n_parent, n_parent], [0, 0]
    )
    child_discs = parent_disc.split()
    child_ll = child_discs[0]

    # 3. Setup parent solution and mock angles
    parent_sol = MagicMock(spec=solver.Solution)
    parent_sol.time = 0.5
    parent_sol.intensity = MagicMock(spec=pytens.TensorNetwork)
    parent_sol.intensity.ranks.return_value = [1, 2, 1]
    parent_sol.space = {}
    mock_angles = MagicMock(spec=AngleDiscretization)
    mock_angles.theta = np.array([0.5])
    mock_angles.phi = np.array([0.5])
    mock_logger = MagicMock(spec=logging.Logger)

    # 4. Execute
    rounding_opts = load_config.Rounding(method="svd", tol=1e-6, freq=1, tt_sum=False)
    split_solution(
        parent_sol,
        parent_disc,
        child_discs,
        [0, 1, 2],
        mock_angles,
        rounding_opts,
        mock_logger,
    )

    # 5. Capture the interpolation function for the lower-left child
    assert mock_transfer_boundaries.call_count == 4
    interp_op_ll = mock_transfer_boundaries.call_args_list[0].args[0]

    # 6. Test the captured function
    x_p = parent_disc.grid.cell_centers[0]
    y_p = parent_disc.grid.cell_centers[1]
    X_p, Y_p = np.meshgrid(x_p, y_p, indexing="ij")
    parent_data = X_p + Y_p
    parent_core_flat = parent_data.reshape(-1, 1)

    child_core_ll = interp_op_ll(parent_core_flat)
    child_data_ll = child_core_ll.reshape(n_parent, n_parent)

    # split_solution uses order=0. Calculate expected result accordingly.
    expected_data_flat = split_spatial_data(
        parent_core_flat.reshape(n_parent, n_parent, 1),
        parent_disc,
        child_ll,
        order=0,
    )
    expected_data = expected_data_flat.reshape(n_parent, n_parent)

    np.testing.assert_allclose(child_data_ll, expected_data)


@patch("pytens_radtrans.refinement.utils.TNOPList")
@patch("pytens_radtrans.refinement.domain_decomp.transfer_boundaries")
def test_merge_solution_structure(
    mock_transfer_boundaries: MagicMock, mock_tnop_list: MagicMock
) -> None:
    """Test that merge_solution correctly aggregates child Solution objects."""
    # Setup Mocks
    mock_op = MagicMock()
    mock_op.return_value = MagicMock(spec=pytens.TensorNetwork)
    mock_transfer_boundaries.return_value = mock_op

    mock_tnop_instance = mock_tnop_list.return_value
    mock_tnop_instance.evaluate_round.return_value = MagicMock(
        spec=pytens.TensorNetwork
    )
    mock_tnop_instance.evaluate_round.return_value.ranks.return_value = [1, 2, 1]

    # Setup Parent
    parent_disc = Discretization.from_geom([0.0], [1.0], [4], [0])

    # Setup Children
    child_discs = parent_disc.split()
    child_sols = []
    for _ in range(2):
        sol = MagicMock(spec=solver.Solution)
        sol.time = 0.5
        sol.intensity = MagicMock()
        # Fix: lambda accepts 'memo' argument
        # B023: Bind loop variable 'sol' to default argument
        sol.intensity.__deepcopy__ = lambda memo, s=sol: s.intensity
        sol.space = {"temp": np.ones((4, 1))}
        child_sols.append(sol)

    # Execute
    permut = [0, 1, 2]
    mock_angles = MagicMock(spec=AngleDiscretization)
    mock_angles.theta = np.array([0.5])
    mock_angles.phi = np.array([0.5])
    rounding_opts = load_config.Rounding(method="svd", tol=1e-6, freq=1)
    logger = logging.getLogger("TestAMR")

    merged_sol = merge_solution(
        child_sols,
        child_discs,
        parent_disc,
        permut,
        mock_angles,
        rounding_opts,
        logger,
    )

    assert merged_sol.time == 0.5
    # Check spatial data merge (average of 1.0 is 1.0)
    np.testing.assert_array_equal(merged_sol.space["temp"], np.ones((4, 1)))
    assert merged_sol.intensity is not None


def test_split_merge_cycle_1d() -> None:
    """Test splitting and merging a random 1D solution."""
    logger = logging.getLogger("TestAMR")

    # 1. Setup Geometry
    # Parent: [0, 1], N=4
    lb = [0.0]
    ub = [1.0]
    n = [4]
    n_ghost = [0]
    parent_disc = Discretization.from_geom(lb, ub, n, n_ghost)

    # 2. Setup Angles
    theta = np.linspace(0, 1, 2)
    phi = np.linspace(0, 1, 2)
    delta_theta = np.ones_like(theta)
    delta_phi = np.ones_like(phi)
    angle_disc = AngleDiscretization(theta, phi, delta_theta, delta_phi)

    # 3. Create Linear Solution (Exact for order=1)
    permut = [0, 1, 2]
    # f(x) = x. Centers are [0.125, 0.375, 0.625, 0.875]
    x_data = parent_disc.grid.cell_centers[0]
    th_data = np.random.rand(2)
    ph_data = np.random.rand(2)

    idx_x = pytens.Index("x", 4)
    idx_th = pytens.Index("theta", 2)
    idx_ph = pytens.Index("phi", 2)

    tn = pytens.tt_rank1([idx_x, idx_th, idx_ph], [x_data, th_data, ph_data])
    sol = solver.Solution(time=0.0, intensity=tn, space={})

    # 4. Split
    child_discs = parent_disc.split()
    rounding = load_config.Rounding(method="svd", tol=1e-12, freq=1, tt_sum=False)

    child_sols = split_solution(
        sol, parent_disc, child_discs, permut, angle_disc, rounding, logger
    )

    assert len(child_sols) == 2

    # 5. Merge
    merged_sol = merge_solution(
        child_sols,
        child_discs,
        parent_disc,
        permut,
        angle_disc,
        rounding,
        logger,
    )

    # 6. Compare
    # Evaluate full tensors to numpy arrays for comparison
    orig_arr = sol.intensity.contract().value
    merged_arr = merged_sol.intensity.contract().value

    # Linear interpolation is exact for linear functions, so we expect high precision
    np.testing.assert_allclose(merged_arr, orig_arr, rtol=1e-10, atol=1e-10)


def test_split_merge_cycle_2d() -> None:
    """Test splitting and merging a random 2D solution."""
    logger = logging.getLogger("TestAMR")

    # 1. Setup Geometry 2D
    lb = [0.0, 0.0]
    ub = [1.0, 1.0]
    n = [4, 4]
    n_ghost = [0, 0]
    parent_disc = Discretization.from_geom(lb, ub, n, n_ghost)

    theta = np.linspace(0, 1, 2)
    phi = np.linspace(0, 1, 2)
    delta_theta = np.ones_like(theta)
    delta_phi = np.ones_like(phi)
    angle_disc = AngleDiscretization(theta, phi, delta_theta, delta_phi)

    permut = [0, 1, 2]

    # Linear data: f(x, y) = x + y
    # Flattened for TT rank-1 construction (which is separable)
    # Actually, x+y is rank-2. Let's use f(x,y) = x*y (rank-1) for simplicity
    # or just f(x,y) = x (rank-1).
    # Let's use f(x,y) = x + y. This requires rank 2.
    # But we are constructing a rank-1 TT.
    # Let's use f(x,y) = x * y. This is rank-1 and quadratic? No, bilinear.
    # Linear interpolation is exact for bilinear functions on rectangles.
    x_c = parent_disc.grid.cell_centers[0]
    y_c = parent_disc.grid.cell_centers[1]
    X, Y = np.meshgrid(x_c, y_c, indexing="ij")
    spatial_data = (X * Y).flatten()  # Bilinear

    th_data = np.random.rand(2)
    ph_data = np.random.rand(2)

    idx_x = pytens.Index("x", 16)
    idx_th = pytens.Index("theta", 2)
    idx_ph = pytens.Index("phi", 2)

    tn = pytens.tt_rank1([idx_x, idx_th, idx_ph], [spatial_data, th_data, ph_data])
    sol = solver.Solution(time=0.0, intensity=tn, space={})

    # Split
    child_discs = parent_disc.split()
    assert len(child_discs) == 4

    rounding = load_config.Rounding(method="svd", tol=1e-12, freq=1, tt_sum=False)

    child_sols = split_solution(
        sol, parent_disc, child_discs, permut, angle_disc, rounding, logger
    )

    # Merge
    merged_sol = merge_solution(
        child_sols,
        child_discs,
        parent_disc,
        permut,
        angle_disc,
        rounding,
        logger,
    )

    # Compare
    orig_arr = sol.intensity.contract().value
    merged_arr = merged_sol.intensity.contract().value

    np.testing.assert_allclose(merged_arr, orig_arr, rtol=1e-10, atol=1e-10)
