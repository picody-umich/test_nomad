"""Tests for flux_corrector.py."""

from unittest.mock import MagicMock

import numpy as np
import pytens
import pytest

from pytens_radtrans import domain_decomp, flux_corrector, solver
from pytens_radtrans.discretization import AngleDiscretization, Indices
from pytens_radtrans.load_config import (
    Angles,
    Config,
    Geometry,
    RusanovStencil,
    UpwindStencil,
)
from pytens_radtrans.stencil import UpwindStencil as UpwindStencilOp
from pytens_radtrans.types import Direction


@pytest.fixture
def mock_config() -> Config:
    """Creates a mock Config object for testing."""
    config = MagicMock(spec=Config)
    config.geometry = MagicMock(spec=Geometry)
    config.geometry.lb = [0.0, 0.0]
    config.geometry.ub = [2.0, 2.0]
    config.geometry.n = [8, 6]  # nx=8, ny=6 cells per leaf
    config.geometry.n_ghost = [2, 2]
    config.geometry.domain_decomp = [1, [0, 0, [1, [0, 0, 0, 0]], 0]]
    config.geometry.dimension = 2
    config.angles = MagicMock(spec=Angles)
    config.angles.n_theta = 4
    config.angles.n_phi = 1
    config.solver = MagicMock()
    config.solver.order = ["x", "theta", "phi"]
    config.equations = MagicMock()
    config.equations.speed_of_light = 1.0
    return config


@pytest.fixture
def dm_3c4f_tr(mock_config: Config) -> domain_decomp.DomainManager:
    """Creates a DomainManager with 3 coarse and 4 fine domains in the TR quadrant."""
    mock_problem = MagicMock()
    return domain_decomp.DomainManager.from_config(mock_config, mock_problem)


@pytest.fixture
def domain_angles(mock_config: Config) -> AngleDiscretization:
    """Creates a mock AngleDiscretization."""
    return AngleDiscretization.from_config(mock_config)


@pytest.fixture
def dm_4c3f_bl(mock_config: Config) -> domain_decomp.DomainManager:
    """Creates a DM with 4 coarse and 3 fine domains in the BL quadrant."""
    # Refine the bottom-left quadrant once
    mock_config.geometry.domain_decomp = [1, [[1, [0, 0, 0, 0]], 0, 0, 0]]
    mock_problem = MagicMock()
    return domain_decomp.DomainManager.from_config(mock_config, mock_problem)


@pytest.fixture
def test_data_bl(
    dm_4c3f_bl: domain_decomp.DomainManager, domain_angles: AngleDiscretization
) -> list[tuple[pytens.TensorNetwork, Indices]]:
    """Creates a list of unique, rank-1 intensities for the BL refined DM."""
    data = []
    for i, leaf in enumerate(dm_4c3f_bl.leaves):
        disc = leaf.disc
        nx, ny = disc.grid.num_cells
        x_coords = disc.grid.cell_centers[0]
        y_coords = disc.grid.cell_centers[1]
        xx, yy = np.meshgrid(x_coords, y_coords)  # Default "xy" indexing
        spatial_field = ((i + 1) * (xx + yy)).T.flatten()

        space_idx = pytens.Index("x", nx * ny)
        theta_idx = pytens.Index("theta", domain_angles.theta.size)
        phi_idx = pytens.Index("phi", domain_angles.phi.size)
        indices = Indices(
            space=space_idx,
            theta=theta_idx,
            phi=phi_idx,
            dimension=disc.dimension,
        )
        intensity_tn = pytens.tt_rank1(
            [indices.space, indices.theta, indices.phi],
            [
                spatial_field,
                np.ones(domain_angles.theta.size),
                np.ones(domain_angles.phi.size),
            ],
        )
        data.append((intensity_tn, indices))
    return data


@pytest.fixture
def test_data(
    dm_3c4f_tr: domain_decomp.DomainManager, domain_angles: AngleDiscretization
) -> list[tuple[pytens.TensorNetwork, Indices]]:
    """Creates a list of unique, rank-1 intensities and their indices."""
    data = []
    for i, leaf in enumerate(dm_3c4f_tr.leaves):
        disc = leaf.disc
        nx, ny = disc.grid.num_cells
        x_coords = disc.grid.cell_centers[0]
        y_coords = disc.grid.cell_centers[1]
        xx, yy = np.meshgrid(x_coords, y_coords)  # Default "xy" indexing
        spatial_field = ((i + 1) * (xx + yy)).T.flatten()

        space_idx = pytens.Index("x", nx * ny)
        theta_idx = pytens.Index("theta", domain_angles.theta.size)
        phi_idx = pytens.Index("phi", domain_angles.phi.size)
        indices = Indices(
            space=space_idx,
            theta=theta_idx,
            phi=phi_idx,
            dimension=disc.dimension,
        )

        # Create a rank-1 separable tensor I(x,y,mu) = f(x,y) * g(mu)
        # Here, g(mu) = 1.0 for all mu, and phi is a dummy dimension.
        intensity_tn = pytens.tt_rank1(
            [indices.space, indices.theta, indices.phi],
            [
                spatial_field,
                np.ones(domain_angles.theta.size),
                np.ones(domain_angles.phi.size),
            ],
        )
        data.append((intensity_tn, indices))
    return data


# --- 1D Fixtures ---


@pytest.fixture
def mock_config_1d() -> Config:
    """Creates a mock Config object for a 1D problem."""
    config = MagicMock(spec=Config)
    config.geometry = MagicMock(spec=Geometry)
    config.geometry.lb = [0.0]
    config.geometry.ub = [2.0]
    config.geometry.n = [10]  # 10 cells per leaf
    config.geometry.n_ghost = [2]
    # Split into 2, then refine the second half
    # Root -> [D0, D1] -> D0 is leaf, D1 splits -> [D1a, D1b]
    config.geometry.domain_decomp = [1, [0, [1, [0, 0]]]]
    config.geometry.dimension = 1
    config.angles = MagicMock(spec=Angles)
    config.angles.n_theta = 4
    config.angles.n_phi = 1
    config.solver = MagicMock()
    config.solver.order = ["x", "theta", "phi"]
    config.equations = MagicMock()
    config.equations.speed_of_light = 1.0
    return config


@pytest.fixture
def dm_1d_amr(mock_config_1d: Config) -> domain_decomp.DomainManager:
    """Creates a 1D DomainManager with 1 Coarse and 2 Fine domains.

    Leaves:
    0: [0.0, 1.0] (Coarse)
    1: [1.0, 1.5] (Fine)
    2: [1.5, 2.0] (Fine)
    """
    mock_problem = MagicMock()
    return domain_decomp.DomainManager.from_config(mock_config_1d, mock_problem)


@pytest.fixture
def domain_angles_1d(mock_config_1d: Config) -> AngleDiscretization:
    """Creates a mock AngleDiscretization for 1D."""
    return AngleDiscretization.from_config(mock_config_1d)


@pytest.fixture
def test_data_1d(
    dm_1d_amr: domain_decomp.DomainManager, domain_angles_1d: AngleDiscretization
) -> list[tuple[pytens.TensorNetwork, Indices]]:
    """Creates a list of unique, rank-1 intensities for the 1D AMR DM."""
    data = []
    for i, leaf in enumerate(dm_1d_amr.leaves):
        disc = leaf.disc
        nx = disc.grid.num_cells[0]
        x_coords = disc.grid.cell_centers[0]

        # Linear field: u(x) = (i+1) * x
        spatial_field = (i + 1) * x_coords

        space_idx = pytens.Index("x", nx)
        theta_idx = pytens.Index("theta", domain_angles_1d.theta.size)
        phi_idx = pytens.Index("phi", domain_angles_1d.phi.size)
        indices = Indices(
            space=space_idx,
            theta=theta_idx,
            phi=phi_idx,
            dimension=disc.dimension,
        )
        intensity_tn = pytens.tt_rank1(
            [indices.space, indices.theta, indices.phi],
            [
                spatial_field,
                np.ones(domain_angles_1d.theta.size),
                np.ones(domain_angles_1d.phi.size),
            ],
        )
        data.append((intensity_tn, indices))
    return data


class TestFluxCalculator:
    """Tests the flux calculation logic in flux_corrector.py."""

    @pytest.mark.parametrize(
        "coarse_idx, fine_idx",
        [
            pytest.param(1, 2, id="E-W_interface_1-2"),
            pytest.param(1, 3, id="E-W_interface-1-3"),
            pytest.param(6, 2, id="N-S_interface_6-2"),
            pytest.param(6, 5, id="N-S_interface_6-5"),
        ],
    )
    @pytest.mark.parametrize(
        "stencil_type",
        [
            pytest.param(UpwindStencil(name="upwind"), id="upwind"),
            pytest.param(RusanovStencil(name="rusanov", wave_speed=1.0), id="rusanov"),
        ],
    )
    def test_flux_calculation_all_interfaces(
        self,
        mock_config: Config,
        dm_3c4f_tr: domain_decomp.DomainManager,
        domain_angles: AngleDiscretization,
        test_data: list[tuple[pytens.TensorNetwork, Indices]],
        stencil_type: UpwindStencil | RusanovStencil,
        coarse_idx: int,
        fine_idx: int,
    ):
        """
        Verifies the flux calculation for all coarse-fine interfaces using
        different stencils.
        """
        mock_config.solver.stencil = stencil_type
        permut = [0, 1, 2]
        inv_permute = [0, 1, 2]

        coarse_intensity, coarse_indices = test_data[coarse_idx]
        fine_intensity, fine_indices = test_data[fine_idx]

        # Mock a Solution object for the calculator function signature
        coarse_sol = MagicMock(spec=solver.Solution)
        coarse_sol.intensity = coarse_intensity
        coarse_sol.indices = coarse_indices
        coarse_sol.space = {}
        # The coarse discretization is needed for scaling, passed in separately
        coarse_disc = dm_3c4f_tr.leaves[coarse_idx].disc

        f2c_comm_plan = next(
            p
            for p in dm_3c4f_tr.comm_plans
            if p.sender_leaf_idx == fine_idx and p.receiver_leaf_idx == coarse_idx
        )
        assert f2c_comm_plan.flux_correction_plan is not None
        flux_plan = f2c_comm_plan.flux_correction_plan

        calculator = flux_corrector.create_flux_calculator(
            flux_plan,
            mock_config,
            domain_angles,
            permut,
            inv_permute,
            f2c_comm_plan.num_sender_indices,
        )

        # Simulate data packaging for the fine neighbor's intensity tensor
        packer = domain_decomp.create_pack_executor(f2c_comm_plan)
        dummy_out_indices = MagicMock(spec=Indices)
        dummy_out_indices.space = pytens.Index(
            "dummy_space", f2c_comm_plan.num_sender_indices
        )
        dummy_out_indices.theta = fine_indices.theta
        dummy_out_indices.phi = fine_indices.phi
        pack_op = domain_decomp.transfer_boundaries(
            packer, fine_indices, dummy_out_indices, permut, inv_permute
        )
        fine_ghost_tn = pack_op(fine_intensity)
        fine_spatial_data = {}  # Empty for this test

        # Access private method for testing intermediate flux calculation
        # pylint: disable=protected-access
        flux_tn_result, _ = calculator._calculate_high_fidelity_flux(
            coarse_sol, fine_ghost_tn, fine_spatial_data, coarse_indices
        )

        # --- Manually compute the expected flux density ---
        # 1. Get the solution values on either side of the interface
        coarse_data = coarse_intensity.contract().value.reshape(
            coarse_indices.space.size, -1
        )
        fine_data = fine_intensity.contract().value.reshape(fine_indices.space.size, -1)

        fine_face_indices_global = f2c_comm_plan.sender_indices[
            flux_plan.fine_face_indices_in_buffer
        ]
        u_fine_at_interface = fine_data[fine_face_indices_global]

        # To manually compute the flux, we must replicate the coarse data onto the
        # fine grid at the interface.
        unique_coarse_indices = np.unique(flux_plan.coarse_cell_indices)
        u_coarse_unique = coarse_data[unique_coarse_indices]

        # 2. Replicate the unique coarse data to match fine grid resolution.
        num_fine_cells = u_fine_at_interface.shape[0]
        num_coarse_cells = u_coarse_unique.shape[0]
        assert num_fine_cells % num_coarse_cells == 0
        refinement_ratio = num_fine_cells // num_coarse_cells
        u_coarse_on_fine_grid = np.repeat(u_coarse_unique, refinement_ratio, axis=0)

        # Assign left/right states based on orientation, matching the embedder
        if flux_plan.direction in [Direction.EAST, Direction.NORTH]:
            u_left, u_right = u_coarse_on_fine_grid, u_fine_at_interface
        else:  # WEST, SOUTH
            u_left, u_right = u_fine_at_interface, u_coarse_on_fine_grid

        # 3. Apply the stencil's flux logic based on interface direction
        c = mock_config.equations.speed_of_light
        is_primary_axis_x = flux_plan.direction in [Direction.EAST, Direction.WEST]

        if is_primary_axis_x:
            # mu_x = c * sin(theta) * cos(phi)
            mu = (c * np.sin(domain_angles.theta) * np.cos(domain_angles.phi)).flatten()
        else:  # N-S interface
            # mu_y = c * sin(theta) * sin(phi)
            mu = (c * np.sin(domain_angles.theta) * np.sin(domain_angles.phi)).flatten()

        if isinstance(stencil_type, UpwindStencil):
            expected_flux_spatial = np.where(mu > 0, mu * u_left, mu * u_right)
        elif isinstance(stencil_type, RusanovStencil):
            alpha = stencil_type.wave_speed
            f_l = mu * u_left
            f_r = mu * u_right
            expected_flux_spatial = 0.5 * (f_l + f_r) - 0.5 * alpha * (u_right - u_left)
        else:
            raise TypeError("Unsupported stencil type for this test")

        nx_temp, ny_temp = flux_plan.temporary_fine_disc.grid.num_cells
        n_angles = domain_angles.theta.size * domain_angles.phi.size
        result_flux_spatial = flux_tn_result.contract().value.reshape(-1, n_angles)

        # Verify the shape of the resulting flux tensor's spatial part.
        if is_primary_axis_x:
            expected_shape = (ny_temp, n_angles)
        else:
            expected_shape = (nx_temp, n_angles)
        assert result_flux_spatial.shape == expected_shape

        np.testing.assert_allclose(
            result_flux_spatial, expected_flux_spatial, rtol=1e-12
        )

        # --- Verification for final scaled and scattered correction term ---
        dt = 0.1  # Dummy time step for scaling
        correction_tn = calculator(
            coarse_sol,
            fine_ghost_tn,
            fine_spatial_data,
            coarse_disc,
            dt,
            coarse_indices,
        )

        # Manually compute the final term from the already-computed expected flux
        coarse_space_size = coarse_indices.space.size
        coarse_map = flux_plan.coarse_cell_indices
        expected_scattered_flux = np.zeros((coarse_space_size, n_angles))
        np.add.at(expected_scattered_flux, coarse_map, expected_flux_spatial)

        p_ax = 0 if is_primary_axis_x else 1
        t_ax = 1 - p_ax
        h = coarse_disc.grid.dx[p_ax]

        # Calculate transverse ratio for scaling
        h_t = flux_plan.temporary_fine_disc.grid.dx[t_ax]
        H_t = coarse_disc.grid.dx[t_ax]
        transverse_ratio = h_t / H_t

        if flux_plan.direction in [Direction.EAST, Direction.NORTH]:
            scale = -dt / h
        else:
            scale = dt / h
        expected_correction_term = expected_scattered_flux * scale * transverse_ratio

        result_correction_term = correction_tn.contract().value.reshape(
            coarse_space_size, n_angles
        )

        np.testing.assert_allclose(
            result_correction_term, expected_correction_term, rtol=1e-12
        )


class TestFluxCalculatorBL:
    """Tests the flux calculation logic for a Bottom-Left refined grid."""

    @pytest.mark.parametrize(
        "coarse_idx, fine_idx",
        [
            pytest.param(4, 1, id="interface_4-1"),
            pytest.param(4, 2, id="interface_4-2"),
            pytest.param(6, 2, id="interface_6-2"),
            pytest.param(6, 3, id="interface_6-3"),
        ],
    )
    @pytest.mark.parametrize(
        "stencil_type",
        [
            pytest.param(UpwindStencil(name="upwind"), id="upwind"),
        ],
    )
    def test_flux_calculation_bl_interfaces(
        self,
        mock_config: Config,
        dm_4c3f_bl: domain_decomp.DomainManager,
        domain_angles: AngleDiscretization,
        test_data_bl: list[tuple[pytens.TensorNetwork, Indices]],
        stencil_type: UpwindStencil | RusanovStencil,
        coarse_idx: int,
        fine_idx: int,
    ):
        """
        Verifies the flux calculation for a BL-refined coarse-fine interface.
        """
        mock_config.solver.stencil = stencil_type
        permut = [0, 1, 2]
        inv_permute = [0, 1, 2]

        coarse_intensity, coarse_indices = test_data_bl[coarse_idx]
        fine_intensity, fine_indices = test_data_bl[fine_idx]

        coarse_sol = MagicMock(spec=solver.Solution)
        coarse_sol.intensity = coarse_intensity
        coarse_sol.indices = coarse_indices
        coarse_sol.space = {}

        f2c_comm_plan = next(
            p
            for p in dm_4c3f_bl.comm_plans
            if p.sender_leaf_idx == fine_idx and p.receiver_leaf_idx == coarse_idx
        )
        assert f2c_comm_plan.flux_correction_plan is not None
        flux_plan = f2c_comm_plan.flux_correction_plan

        # --- Verify that the coarse_cell_indices are on the CORRECT side ---
        if coarse_idx == 4 and fine_idx == 1:
            expected_indices = np.array([0, 0, 6, 6, 12, 12, 18, 18])
        elif coarse_idx == 4 and fine_idx == 2:
            expected_indices = np.array([24, 24, 30, 30, 36, 36, 42, 42])
        elif coarse_idx == 6 and fine_idx == 2:
            expected_indices = np.array([3, 3, 4, 4, 5, 5])
        elif coarse_idx == 6 and fine_idx == 3:
            expected_indices = np.array([0, 0, 1, 1, 2, 2])
        else:
            raise NotImplementedError("Unhandled coarse_cell_indices test case.")

        np.testing.assert_array_equal(flux_plan.coarse_cell_indices, expected_indices)

        calculator = flux_corrector.create_flux_calculator(
            flux_plan,
            mock_config,
            domain_angles,
            permut,
            inv_permute,
            f2c_comm_plan.num_sender_indices,
        )

        packer = domain_decomp.create_pack_executor(f2c_comm_plan)
        dummy_out_indices = MagicMock(spec=Indices)
        dummy_out_indices.space = pytens.Index(
            "dummy_space", f2c_comm_plan.num_sender_indices
        )
        dummy_out_indices.theta = fine_indices.theta
        dummy_out_indices.phi = fine_indices.phi
        pack_op = domain_decomp.transfer_boundaries(
            packer, fine_indices, dummy_out_indices, permut, inv_permute
        )
        fine_ghost_tn = pack_op(fine_intensity)
        fine_spatial_data = {}

        # pylint: disable=protected-access
        flux_tn_result, _ = calculator._calculate_high_fidelity_flux(
            coarse_sol, fine_ghost_tn, fine_spatial_data, coarse_indices
        )

        coarse_data = coarse_intensity.contract().value.reshape(
            coarse_indices.space.size, -1
        )
        fine_data = fine_intensity.contract().value.reshape(fine_indices.space.size, -1)

        fine_face_indices_global = f2c_comm_plan.sender_indices[
            flux_plan.fine_face_indices_in_buffer
        ]
        u_fine_at_interface = fine_data[fine_face_indices_global]

        unique_coarse_indices = np.unique(flux_plan.coarse_cell_indices)
        u_coarse_unique = coarse_data[unique_coarse_indices]

        num_fine_cells = u_fine_at_interface.shape[0]
        num_coarse_cells = u_coarse_unique.shape[0]
        assert num_fine_cells % num_coarse_cells == 0
        refinement_ratio = num_fine_cells // num_coarse_cells
        u_coarse_on_fine_grid = np.repeat(u_coarse_unique, refinement_ratio, axis=0)

        if flux_plan.direction in [Direction.EAST, Direction.NORTH]:
            u_left, u_right = u_coarse_on_fine_grid, u_fine_at_interface
        else:
            u_left, u_right = u_fine_at_interface, u_coarse_on_fine_grid

        c = mock_config.equations.speed_of_light
        is_primary_axis_x = flux_plan.direction in [Direction.EAST, Direction.WEST]

        if is_primary_axis_x:
            mu = (c * np.sin(domain_angles.theta) * np.cos(domain_angles.phi)).flatten()
        else:
            mu = (c * np.sin(domain_angles.theta) * np.sin(domain_angles.phi)).flatten()

        if isinstance(stencil_type, UpwindStencil):
            expected_flux_spatial = np.where(mu > 0, mu * u_left, mu * u_right)
        else:
            raise TypeError("Unsupported stencil type for this test")

        n_angles = domain_angles.theta.size * domain_angles.phi.size
        result_flux_spatial = flux_tn_result.contract().value.reshape(-1, n_angles)

        np.testing.assert_allclose(
            result_flux_spatial, expected_flux_spatial, rtol=1e-12
        )


class TestTemporaryGridAssembly:
    """Tests the assembly of the temporary grid state for flux calculation."""

    def test_assemble_temporary_grid_state_all_interfaces(
        self,
        mock_config: Config,
        domain_angles: AngleDiscretization,
        dm_3c4f_tr: domain_decomp.DomainManager,
        test_data: list[tuple[pytens.TensorNetwork, Indices]],
    ) -> None:
        """Verify assembly for all coarse-fine interfaces in the fixture."""
        # Ensure a stencil is configured so FluxCalculator init works
        mock_config.solver.stencil = UpwindStencil(name="upwind")

        cf_pairs = [
            (p.receiver_leaf_idx, p.sender_leaf_idx)
            for p in dm_3c4f_tr.comm_plans
            if p.flux_correction_plan is not None
        ]
        assert len(cf_pairs) == 4, "Expected 4 coarse-fine interfaces in the fixture"

        for coarse_idx, fine_idx in cf_pairs:
            self._verify_single_interface_assembly(
                mock_config,
                domain_angles,
                dm_3c4f_tr,
                test_data,
                coarse_idx,
                fine_idx,
            )

    def _verify_single_interface_assembly(
        self,
        mock_config: Config,
        domain_angles: AngleDiscretization,
        dm: domain_decomp.DomainManager,
        test_data: list[tuple[pytens.TensorNetwork, Indices]],
        coarse_idx: int,
        fine_idx: int,
    ) -> None:
        """Helper to verify grid assembly for a single coarse-fine pair."""
        permut = [0, 1, 2]
        inv_permute = [0, 1, 2]
        coarse_intensity, coarse_indices = test_data[coarse_idx]
        fine_intensity, fine_indices = test_data[fine_idx]

        # Re-create the unique spatial fields from the test_data fixture
        coarse_leaf = dm.leaves[coarse_idx]
        c_x, c_y = coarse_leaf.disc.grid.cell_centers
        c_xx, c_yy = np.meshgrid(c_x, c_y)  # Default "xy" indexing
        coarse_spatial_field = ((coarse_idx + 1) * (c_xx + c_yy)).T.flatten()

        fine_leaf = dm.leaves[fine_idx]
        f_x, f_y = fine_leaf.disc.grid.cell_centers
        f_xx, f_yy = np.meshgrid(f_x, f_y)  # Default "xy" indexing
        full_fine_spatial_field = ((fine_idx + 1) * (f_xx + f_yy)).T.flatten()

        coarse_sol = MagicMock(spec=solver.Solution)
        coarse_sol.intensity = coarse_intensity
        coarse_sol.indices = coarse_indices
        coarse_sol.space = {"test_field": coarse_spatial_field}

        f2c_comm_plan = next(
            p
            for p in dm.comm_plans
            if p.sender_leaf_idx == fine_idx and p.receiver_leaf_idx == coarse_idx
        )
        flux_plan = f2c_comm_plan.flux_correction_plan
        assert flux_plan is not None

        # Simulate the packed fine_ghost_tn
        packer = domain_decomp.create_pack_executor(f2c_comm_plan)
        dummy_out_indices = MagicMock(spec=Indices)
        dummy_out_indices.space = pytens.Index(
            "dummy_space", f2c_comm_plan.num_sender_indices
        )
        dummy_out_indices.theta = fine_indices.theta
        dummy_out_indices.phi = fine_indices.phi
        pack_op = domain_decomp.transfer_boundaries(
            packer, fine_indices, dummy_out_indices, permut, inv_permute
        )
        fine_ghost_tn = pack_op(fine_intensity)

        # Simulate packing for the spatial data (packer needs a column vector)
        packed_fine_field = packer(full_fine_spatial_field.reshape(-1, 1)).flatten()
        fine_spatial_data = {"test_field": packed_fine_field}

        # --- Manually create the calculator to access private methods ---
        calculator = flux_corrector.create_flux_calculator(
            flux_plan,
            mock_config,
            domain_angles,
            permut,
            inv_permute,
            f2c_comm_plan.num_sender_indices,
        )

        # --- Action: Call the function under test ---
        # pylint: disable=protected-access
        (
            temp_grid_tn,
            temp_grid_space,
            indices_out,
        ) = calculator._assemble_state(
            coarse_sol,
            fine_ghost_tn,
            fine_spatial_data,
            coarse_indices,
        )

        # --- Verification ---
        # 1. Contract all tensors to full NumPy arrays
        result_tensor_full = temp_grid_tn.contract().value
        coarse_tensor_full = coarse_intensity.contract().value
        fine_ghost_tensor_full = fine_ghost_tn.contract().value

        # 2. Reshape and get parameters for indexing
        nx_temp, ny_temp = flux_plan.temporary_fine_disc.grid.num_cells
        n_theta = coarse_indices.theta.size
        n_phi = coarse_indices.phi.size
        result_tensor = result_tensor_full.reshape((nx_temp, ny_temp, n_theta, n_phi))

        # 3. Determine which slice is coarse and which is fine
        is_primary_axis_x = flux_plan.direction in [Direction.EAST, Direction.WEST]
        if flux_plan.direction in [Direction.EAST, Direction.NORTH]:
            coarse_slice_idx, fine_slice_idx = 0, 1
        else:
            coarse_slice_idx, fine_slice_idx = 1, 0

        # 4. Extract expected data and compare slices
        if is_primary_axis_x:
            # Slices are along the x-axis (axis 0)
            actual_coarse_slice = result_tensor[coarse_slice_idx, :, :, :]
            actual_fine_slice = result_tensor[fine_slice_idx, :, :, :]
            # Get expected coarse data
            coarse_data_flat = coarse_tensor_full.reshape((-1, n_theta * n_phi))
            expected_coarse_data = coarse_data_flat[flux_plan.coarse_cell_indices]
            expected_coarse_slice = expected_coarse_data.reshape(
                (ny_temp, n_theta, n_phi)
            )
            # Get expected fine data from the packed buffer
            fine_ghost_flat = fine_ghost_tensor_full.reshape((-1, n_theta * n_phi))
            expected_fine_data = fine_ghost_flat[flux_plan.fine_face_indices_in_buffer]
            expected_fine_slice = expected_fine_data.reshape((ny_temp, n_theta, n_phi))
        else:  # Primary axis is y
            # Slices are along the y-axis (axis 1)
            actual_coarse_slice = result_tensor[:, coarse_slice_idx, :, :]
            actual_fine_slice = result_tensor[:, fine_slice_idx, :, :]
            # Get expected coarse data
            coarse_data_flat = coarse_tensor_full.reshape((-1, n_theta * n_phi))
            expected_coarse_data = coarse_data_flat[flux_plan.coarse_cell_indices]
            expected_coarse_slice = expected_coarse_data.reshape(
                (nx_temp, n_theta, n_phi)
            )
            # Get expected fine data
            fine_ghost_flat = fine_ghost_tensor_full.reshape((-1, n_theta * n_phi))
            expected_fine_data = fine_ghost_flat[flux_plan.fine_face_indices_in_buffer]
            expected_fine_slice = expected_fine_data.reshape((nx_temp, n_theta, n_phi))

        np.testing.assert_allclose(actual_coarse_slice, expected_coarse_slice)
        np.testing.assert_allclose(actual_fine_slice, expected_fine_slice)

        # --- Verification for spatial fields ---
        assert "test_field" in temp_grid_space
        result_array = temp_grid_space["test_field"]
        result_array_2d = result_array.reshape((nx_temp, ny_temp))

        if is_primary_axis_x:
            actual_coarse_slice_space = result_array_2d[coarse_slice_idx, :]
            actual_fine_slice_space = result_array_2d[fine_slice_idx, :]
        else:  # Primary axis is y
            actual_coarse_slice_space = result_array_2d[:, coarse_slice_idx]
            actual_fine_slice_space = result_array_2d[:, fine_slice_idx]

        expected_coarse_slice_space = coarse_spatial_field[
            flux_plan.coarse_cell_indices
        ]
        expected_fine_slice_space = packed_fine_field[
            flux_plan.fine_face_indices_in_buffer
        ]

        np.testing.assert_allclose(
            actual_coarse_slice_space, expected_coarse_slice_space
        )
        np.testing.assert_allclose(actual_fine_slice_space, expected_fine_slice_space)

        # --- Verification for indices_out ---
        assert indices_out.dimension == flux_plan.temporary_fine_disc.dimension
        assert indices_out.space.name == "x"
        assert indices_out.space.size == nx_temp * ny_temp
        assert indices_out.theta == coarse_indices.theta
        assert indices_out.phi == coarse_indices.phi

    def test_temporary_grid_ordering_ew_interface(
        self,
        mock_config: Config,
        domain_angles: AngleDiscretization,
        dm_3c4f_tr: domain_decomp.DomainManager,
        test_data: list[tuple[pytens.TensorNetwork, Indices]],
    ) -> None:
        """
        Verifies that _assemble_state constructs a temporary
        grid with the correct data and spatial ordering for a specific E-W interface.
        """
        # Ensure a stencil is configured so FluxCalculator init works
        mock_config.solver.stencil = UpwindStencil(name="upwind")

        # --- 1. Setup: Select a specific E-W coarse-fine interface ---
        # Coarse Leaf 1 (TL) borders Fine Leaf 2 (BL of the refined TR quadrant)
        coarse_idx, fine_idx = 1, 2
        coarse_intensity, coarse_indices = test_data[coarse_idx]
        fine_intensity, fine_indices = test_data[fine_idx]

        f2c_comm_plan = next(
            p
            for p in dm_3c4f_tr.comm_plans
            if p.sender_leaf_idx == fine_idx and p.receiver_leaf_idx == coarse_idx
        )
        flux_plan = f2c_comm_plan.flux_correction_plan
        assert flux_plan is not None
        assert flux_plan.direction == Direction.EAST

        # --- 2. Manually construct the expected "ground truth" grid ---
        # Re-create the full spatial fields from the test_data fixture
        coarse_leaf = dm_3c4f_tr.leaves[coarse_idx]
        c_x, c_y = coarse_leaf.disc.grid.cell_centers
        c_xx, c_yy = np.meshgrid(c_x, c_y)
        coarse_spatial_field = ((coarse_idx + 1) * (c_xx + c_yy)).T.flatten()

        fine_leaf = dm_3c4f_tr.leaves[fine_idx]
        f_x, f_y = fine_leaf.disc.grid.cell_centers
        f_xx, f_yy = np.meshgrid(f_x, f_y)
        fine_spatial_field = ((fine_idx + 1) * (f_xx + f_yy)).T.flatten()

        # Get the coarse data column for the interface
        unique_coarse_indices = np.unique(flux_plan.coarse_cell_indices)
        coarse_data_col = coarse_spatial_field[unique_coarse_indices]

        # Get the fine data column for the interface
        fine_face_indices_global = f2c_comm_plan.sender_indices[
            flux_plan.fine_face_indices_in_buffer
        ]
        fine_data_col = fine_spatial_field[fine_face_indices_global]

        # Replicate coarse data to match fine resolution
        refinement_ratio = len(fine_data_col) // len(coarse_data_col)
        coarse_data_on_fine_grid = np.repeat(coarse_data_col, refinement_ratio)

        # Assemble the 2D grid. For an EAST direction, coarse is left, fine is right.
        # This matches the column-major layout produced by the embedders.
        nx_temp, ny_temp = flux_plan.temporary_fine_disc.grid.num_cells
        assert nx_temp == 2
        expected_grid_2d = np.array([coarse_data_on_fine_grid, fine_data_col])

        # --- 3. Call the function under test with correctly packed inputs ---
        coarse_sol = MagicMock(spec=solver.Solution)
        coarse_sol.intensity = coarse_intensity
        coarse_sol.space = {"field": coarse_spatial_field}

        # Simulate the packed fine data (both intensity and spatial) by applying the
        # communication plan's packer.
        packer = domain_decomp.create_pack_executor(f2c_comm_plan)

        dummy_out_indices = MagicMock(spec=Indices)
        dummy_out_indices.space = pytens.Index(
            "dummy_space", f2c_comm_plan.num_sender_indices
        )
        dummy_out_indices.theta = fine_indices.theta
        dummy_out_indices.phi = fine_indices.phi
        pack_op = domain_decomp.transfer_boundaries(
            packer, fine_indices, dummy_out_indices, [0, 1, 2], [0, 1, 2]
        )
        fine_ghost_tn = pack_op(fine_intensity)

        # The packer expects a column vector, so reshape and then flatten the output.
        packed_fine_field = packer(fine_spatial_field.reshape(-1, 1)).flatten()
        fine_spatial_data = {"field": packed_fine_field}

        calculator = flux_corrector.create_flux_calculator(
            flux_plan,
            mock_config,
            domain_angles,
            [0, 1, 2],
            [0, 1, 2],
            f2c_comm_plan.num_sender_indices,
        )

        # pylint: disable=protected-access
        _, temp_grid_space, _ = calculator._assemble_state(
            coarse_sol,
            fine_ghost_tn,
            fine_spatial_data,
            coarse_indices,
        )

        # --- 4. Compare the results, respecting row-major ordering ---
        assembled_grid_flat = temp_grid_space["field"]
        assembled_grid_2d = assembled_grid_flat.reshape((nx_temp, ny_temp))
        np.testing.assert_allclose(assembled_grid_2d, expected_grid_2d)


def test_create_flux_mask(dm_3c4f_tr: domain_decomp.DomainManager) -> None:
    """Test the create_flux_mask function."""
    # Coarse leaf 1 (TL) has flux correction plans from fine leaves 2 and 3
    # on its East face.
    coarse_idx = 1
    coarse_leaf = dm_3c4f_tr.leaves[coarse_idx]
    plans = [
        p
        for p in dm_3c4f_tr.comm_plans
        if p.receiver_leaf_idx == coarse_idx and p.flux_correction_plan is not None
    ]

    masks = flux_corrector.create_flux_mask(coarse_leaf.disc, plans)

    nx, ny = coarse_leaf.disc.grid.num_cells
    ngx = coarse_leaf.disc.grid.num_ghost[0] // 2
    ngy = coarse_leaf.disc.grid.num_ghost[1] // 2
    ny_g = ny + 2 * ngy

    assert masks["x"].shape == (nx + 1, ny_g)
    assert masks["y"].shape == (nx + 2 * ngx, ny + 1)

    # Check that the mask is 0.0 at the interface
    # East face of coarse leaf 1 is at x=nx.
    # It should be masked for the y-indices corresponding to the fine neighbors.
    # Fine leaves 2 and 3 cover the whole y-range of coarse leaf 1.
    assert np.all(masks["x"][nx, ngy:-ngy] == 0.0)
    # Check that other places are 1.0
    assert np.all(masks["x"][:nx, :] == 1.0)


def test_flux_mask_integration_with_stencil(
    dm_3c4f_tr: domain_decomp.DomainManager,
    mock_config: Config,
    domain_angles: AngleDiscretization,
) -> None:
    """Verify that the generated flux mask works with a Stencil operator."""
    # 1. Setup: Coarse leaf 1 (TL)
    coarse_idx = 1
    coarse_leaf = dm_3c4f_tr.leaves[coarse_idx]
    plans = [
        p
        for p in dm_3c4f_tr.comm_plans
        if p.receiver_leaf_idx == coarse_idx and p.flux_correction_plan is not None
    ]

    # 2. Create mask
    masks = flux_corrector.create_flux_mask(coarse_leaf.disc, plans)

    # 3. Create Stencil
    sin_theta = np.sin(domain_angles.theta)
    cos_phi = np.cos(domain_angles.phi)
    sin_phi = np.sin(domain_angles.phi)

    stencil = UpwindStencilOp(
        mock_config.equations.speed_of_light,
        sin_theta,
        cos_phi,
        sin_phi,
        coarse_leaf.disc,
        mock_config,
    )

    # 4. Create Input TensorNetwork (with ghost cells)
    nx, ny = coarse_leaf.disc.grid.num_cells
    ngx = coarse_leaf.disc.grid.num_ghost[0] // 2
    ngy = coarse_leaf.disc.grid.num_ghost[1] // 2
    nx_g = nx + 2 * ngx
    ny_g = ny + 2 * ngy
    full_size = nx_g * ny_g

    space_ind = pytens.Index("x", full_size)
    theta_ind = pytens.Index("theta", domain_angles.theta.size)
    phi_ind = pytens.Index("phi", domain_angles.phi.size)

    # Use a constant field so we can predict the flux
    field_val = 1.0
    input_tn = pytens.tt_rank1(
        [space_ind, theta_ind, phi_ind],
        [
            np.full(full_size, field_val),
            np.ones(theta_ind.size),
            np.ones(phi_ind.size),
        ],
    )

    # 5. Get Operator with mask
    # The indices passed to get_ttop define the output size (interior)
    interior_size = nx * ny
    space_ind_interior = pytens.Index("x", interior_size)
    indices_interior = Indices(
        space=space_ind_interior,
        theta=theta_ind,
        phi=phi_ind,
        dimension=2,
    )

    op = stencil.get_ttop(indices_interior, scale=1.0, flux_mask=masks)

    # 6. Apply and Verify
    # This ensures that the mask shape is compatible with the stencil's internal
    # flux calculations and broadcasting logic.
    res = op([input_tn], {}).evaluate()
    res_val = res.contract().value
    assert res_val.size == interior_size * theta_ind.size * phi_ind.size

    # 7. Verify that the flux divergence is zero at the masked interface.
    # The mask zeros out the flux at the East face of the coarse domain (x=nx).
    # For a constant field, the unmasked flux divergence is zero everywhere.
    # However, if we mask one face but not the other, the divergence becomes non-zero.
    # Specifically, at the cell just left of the interface (x=nx-1), the flux
    # leaving to the right is masked to 0, while flux entering from left is non-zero.
    # So we expect a non-zero divergence at the boundary cells if the mask is working.

    # Reshape result to (nx, ny, n_theta, n_phi)
    res_reshaped = res_val.reshape(nx, ny, theta_ind.size, phi_ind.size)

    # Check cells at the East boundary (x=nx-1)
    # Flux in (from left) = c * cos_phi * u
    # Flux out (to right) = 0 (masked)
    # Divergence = (Flux_out - Flux_in) / h = -Flux_in / h
    # So we expect non-zero values here for angles with cos_phi != 0.
    east_boundary_cells = res_reshaped[-1, :, :, :]

    # Check for at least one non-zero value to confirm mask effect
    assert not np.allclose(east_boundary_cells, 0.0)

    # Check interior cells (away from the masked boundary)
    # Flux in = Flux out, so divergence should be zero.
    interior_cells = res_reshaped[:-1, :, :, :]
    np.testing.assert_allclose(interior_cells, 0.0, atol=1e-12)


class TestFluxCalculator1D:
    """Tests the flux calculation logic for 1D interfaces."""

    def test_flux_calculation_1d_interface(
        self,
        mock_config_1d: Config,
        dm_1d_amr: domain_decomp.DomainManager,
        domain_angles_1d: AngleDiscretization,
        test_data_1d: list[tuple[pytens.TensorNetwork, Indices]],
    ):
        """Verifies flux calculation for the 1D Coarse-Fine interface."""
        mock_config_1d.solver.stencil = UpwindStencil(name="upwind")
        permut = [0, 1, 2]
        inv_permute = [0, 1, 2]

        # Interface between Coarse (0) and Fine (1)
        coarse_idx = 0
        fine_idx = 1

        coarse_intensity, coarse_indices = test_data_1d[coarse_idx]
        fine_intensity, fine_indices = test_data_1d[fine_idx]

        coarse_sol = MagicMock(spec=solver.Solution)
        coarse_sol.intensity = coarse_intensity
        coarse_sol.indices = coarse_indices
        coarse_sol.space = {}
        coarse_disc = dm_1d_amr.leaves[coarse_idx].disc

        # Find the plan where Fine sends to Coarse (Fine-to-Coarse)
        f2c_comm_plan = next(
            p
            for p in dm_1d_amr.comm_plans
            if p.sender_leaf_idx == fine_idx and p.receiver_leaf_idx == coarse_idx
        )
        assert f2c_comm_plan.flux_correction_plan is not None
        flux_plan = f2c_comm_plan.flux_correction_plan

        # Verify plan details
        assert flux_plan.direction == Direction.EAST
        # Coarse cell index at interface is the last cell (nx-1 = 9)
        assert flux_plan.coarse_cell_indices[0] == 9

        calculator = flux_corrector.create_flux_calculator(
            flux_plan,
            mock_config_1d,
            domain_angles_1d,
            permut,
            inv_permute,
            f2c_comm_plan.num_sender_indices,
        )

        # Simulate data packaging
        packer = domain_decomp.create_pack_executor(f2c_comm_plan)
        dummy_out_indices = MagicMock(spec=Indices)
        dummy_out_indices.space = pytens.Index(
            "dummy_space", f2c_comm_plan.num_sender_indices
        )
        dummy_out_indices.theta = fine_indices.theta
        dummy_out_indices.phi = fine_indices.phi
        pack_op = domain_decomp.transfer_boundaries(
            packer, fine_indices, dummy_out_indices, permut, inv_permute
        )
        fine_ghost_tn = pack_op(fine_intensity)
        fine_spatial_data = {}

        # --- Calculate Flux ---
        # pylint: disable=protected-access
        flux_tn_result, _ = calculator._calculate_high_fidelity_flux(
            coarse_sol, fine_ghost_tn, fine_spatial_data, coarse_indices
        )

        # --- Verification ---
        # 1. Get values at interface
        coarse_data = coarse_intensity.contract().value.reshape(
            coarse_indices.space.size, -1
        )
        fine_data = fine_intensity.contract().value.reshape(fine_indices.space.size, -1)

        # Coarse value at interface (last cell)
        u_coarse = coarse_data[-1]

        # Fine value at interface (first cell, since Fine is East of Coarse)
        # The packer extracts the boundary cells. For 1D East neighbor, it's the
        # first ghost cells.
        # Wait, the packer extracts from the SENDER (Fine).
        # If Fine is East of Coarse, Coarse's ghost is Fine's physical boundary (West).
        # So Fine sends its first few cells.
        # The flux plan identifies the specific face cell index in the buffer.
        fine_face_indices_global = f2c_comm_plan.sender_indices[
            flux_plan.fine_face_indices_in_buffer
        ]
        u_fine = fine_data[fine_face_indices_global[0]]

        # 2. Compute Expected Flux (Upwind)
        # mu = c * sin(theta) * cos(phi)
        c = mock_config_1d.equations.speed_of_light
        mu = (
            c * np.sin(domain_angles_1d.theta) * np.cos(domain_angles_1d.phi)
        ).flatten()

        # Interface orientation: Coarse (Left) | Fine (Right)
        # Flux = mu * u
        # if mu > 0: flow from Left to Right -> use u_coarse
        # if mu < 0: flow from Right to Left -> use u_fine
        expected_flux_spatial = np.where(mu > 0, mu * u_coarse, mu * u_fine)

        # 3. Compare
        # Result shape should be (1, n_angles) because 1D flux lives on a point
        # (size 1 spatial)
        n_angles = domain_angles_1d.theta.size * domain_angles_1d.phi.size
        result_flux_spatial = flux_tn_result.contract().value.reshape(-1, n_angles)

        assert result_flux_spatial.shape == (1, n_angles)
        np.testing.assert_allclose(
            result_flux_spatial[0], expected_flux_spatial, rtol=1e-12
        )

        # --- Verify Scaling ---
        dt = 0.1
        correction_tn = calculator(
            coarse_sol,
            fine_ghost_tn,
            fine_spatial_data,
            coarse_disc,
            dt,
            coarse_indices,
        )

        # In 1D, transverse ratio is 1.0.
        # Direction is EAST (Coarse is West, Fine is East).
        # Flux is leaving Coarse domain at East face.
        # Update = - dt/dx * Flux
        dx = coarse_disc.grid.dx[0]
        scale = -dt / dx

        expected_correction = np.zeros((coarse_indices.space.size, n_angles))
        # Add to the last cell (index 9)
        expected_correction[9, :] = expected_flux_spatial * scale

        result_correction = correction_tn.contract().value.reshape(
            coarse_indices.space.size, n_angles
        )

        np.testing.assert_allclose(result_correction, expected_correction, rtol=1e-12)
