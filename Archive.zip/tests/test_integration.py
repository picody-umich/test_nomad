import logging
import pathlib
import tempfile

from pytens_radtrans import main_loop
from pytens_radtrans.load_config import Config

# Create a dummy logger
logger = logging.getLogger("test_integration")
logger.setLevel(logging.INFO)


def test_hohlraum_1d_integration():
    """Integration test for Hohlraum 1D pipeline (smoke test)."""
    with tempfile.TemporaryDirectory() as tmp_dir:
        tmp_path = pathlib.Path(tmp_dir)
        config_dict = {
            "problem": {"name": "hohlraum"},
            "geometry": {
                "dimension": 1,
                "n_ghost": [2],
                "lb": [0.0],
                "ub": [1.0],
                "n": [20],
                "domain_decomp": 0,  # Auto/Single domain
            },
            "angles": {"n_theta": 10, "n_phi": 10},
            "equations": {"speed_of_light": 2.0, "source": {"name": "none"}},
            "solver": {
                "cfl": 0.8,
                "stencil": {"name": "jiang", "beta": 4.0},
                "method": "forward euler",
                "num_steps": 2,
                "rounding": {"method": "gram", "tt_sum": True, "tol": 1e-8, "freq": 1},
                "order": ["x", "theta", "phi"],
            },
            "saving": {"directory": str(tmp_path), "plot_freq": 1, "keep_all": True},
        }

        config = Config(**config_dict)
        main_loop.main_loop(config, logger, tmp_path)

        assert (tmp_path / "summary_sol_plot.pdf").exists()
        assert (tmp_path / "ranks_compression.pdf").exists()


def test_hohlraum_2d_integration():
    """Integration test for Hohlraum 2D pipeline (smoke test)."""
    with tempfile.TemporaryDirectory() as tmp_dir:
        tmp_path = pathlib.Path(tmp_dir)
        config_dict = {
            "problem": {"name": "hohlraum"},
            "geometry": {
                "dimension": 2,
                "lb": [0.0, 0.0],
                "ub": [1.0, 1.0],
                "n_ghost": [2, 2],
                "n": [10, 10],
                "domain_decomp": 0,
            },
            "angles": {"n_theta": 10, "n_phi": 10},
            "equations": {"speed_of_light": 2.0, "source": {"name": "none"}},
            "solver": {
                "cfl": 0.5,
                "stencil": {"name": "jiang", "beta": 4},
                "method": "forward euler",
                "num_steps": 1,
                "rounding": {
                    "method": "randomized",
                    "rank_increase_bound": 4,
                    "tt_sum": True,
                    "tol": 1e-3,
                    "freq": 1,
                },
                "order": ["x", "theta", "phi"],
            },
            "saving": {"directory": str(tmp_path), "plot_freq": 1, "keep_all": False},
        }

        config = Config(**config_dict)
        main_loop.main_loop(config, logger, tmp_path)
        assert (tmp_path / "ranks_compression.pdf").exists()


def test_gaussian_diffusion_2d_integration():
    """Integration test for Gaussian Diffusion 2D pipeline (smoke test)."""
    with tempfile.TemporaryDirectory() as tmp_dir:
        tmp_path = pathlib.Path(tmp_dir)
        config_dict = {
            "problem": {"name": "gaussian diffusion", "A": 1.0, "t0": 10.0},
            "geometry": {
                "dimension": 2,
                "lb": [-5.0, -5.0],
                "ub": [5.0, 5.0],
                "n_ghost": [2, 2],
                "n": [10, 10],
                "domain_decomp": 0,
            },
            "angles": {"n_theta": 10, "n_phi": 10},
            "equations": {
                "speed_of_light": 1.0,
                "density": 1.0,
                "specific_scattering_opacity": 100.0,
                "source": {"name": "scatter only"},
            },
            "solver": {
                "cfl": 0.3,
                "stencil": {"name": "rusanov", "wave_speed": 0},
                "method": "forward euler",
                "num_steps": 1,
                "rounding": {"method": "gram", "tt_sum": True, "tol": 1e-8, "freq": 1},
                "order": ["x", "theta", "phi"],
            },
            "saving": {"directory": str(tmp_path), "plot_freq": 1, "keep_all": True},
        }

        config = Config(**config_dict)
        main_loop.main_loop(config, logger, tmp_path)

        # GaussianDiffusion2D does not implement plot_all_sols, so summary_sol_plot.pdf
        # is not created. We only check for ranks_compression.pdf.
        assert (tmp_path / "ranks_compression.pdf").exists()
