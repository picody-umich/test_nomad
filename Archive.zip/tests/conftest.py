"""Pytest configuration for environments without runnable MPI daemons.

This file installs a small fake ``mpi4py`` module before tests import the
package. The project code imports ``MPI.COMM_WORLD`` at module import time,
which triggers ``MPI_Init`` in environments where OpenMPI cannot launch local
daemons (like restricted sandboxes).

Set ``PYTENS_TEST_USE_REAL_MPI=1`` to disable this shim and use real mpi4py.
"""

from __future__ import annotations

import os
import sys
import types
from dataclasses import dataclass
from typing import Any

# Headless test environments should never use GUI backends.
os.environ.setdefault("MPLBACKEND", "Agg")


def _install_fake_mpi4py() -> None:
    if "mpi4py" in sys.modules:
        return

    class _FakeRequest:
        @staticmethod
        def Waitall(
            requests: list[_FakePending], statuses: list[_FakeStatus] | None = None
        ) -> None:
            if statuses is None:
                for req in requests:
                    req.wait()
                return

            for i, req in enumerate(requests):
                req.wait()
                if i < len(statuses):
                    statuses[i].error = 0

    @dataclass
    class _FakeStatus:
        error: int = 0
        source: int = 0
        tag: int = 0

        def Get_error(self) -> int:
            return self.error

        def Get_source(self) -> int:
            return self.source

        def Get_tag(self) -> int:
            return self.tag

    class _FakePending:
        def __init__(self, value: Any = None) -> None:
            self._value = value

        def wait(self) -> Any:
            return self._value

    class _FakeComm:
        def Get_rank(self) -> int:
            return 0

        def Get_size(self) -> int:
            return 1

        def bcast(self, value: Any, root: int = 0) -> Any:
            return value

        def gather(self, value: Any, root: int = 0) -> list[Any]:
            return [value]

        def allgather(self, value: Any) -> list[Any]:
            return [value]

        def scatter(self, values: Any, root: int = 0) -> Any:
            if isinstance(values, list | tuple):
                return values[0]
            return values

        def allreduce(self, value: Any, op: Any = None) -> Any:
            return value

        def Barrier(self) -> None:
            return None

        def Abort(self, code: int = 1) -> None:
            raise RuntimeError(f"Fake MPI Abort({code})")

        def irecv(self, source: int = 0, tag: int = 0) -> _FakePending:
            _ = source, tag
            return _FakePending(None)

        def isend(self, obj: Any, dest: int = 0, tag: int = 0) -> _FakePending:
            _ = obj, dest, tag
            return _FakePending(None)

        def Irecv(self, buf: Any, source: int = 0, tag: int = 0) -> _FakePending:
            _ = buf, source, tag
            return _FakePending(None)

        def Isend(self, buf: Any, dest: int = 0, tag: int = 0) -> _FakePending:
            _ = buf, dest, tag
            return _FakePending(None)

    class _FakeMPI:
        Comm = _FakeComm
        Request = _FakeRequest
        Status = _FakeStatus
        Exception = RuntimeError
        SUCCESS = 0
        MAX = "MAX"
        MIN = "MIN"
        SUM = "SUM"
        COMM_WORLD = _FakeComm()

    mpi4py_mod = types.ModuleType("mpi4py")
    mpi4py_mod.MPI = _FakeMPI

    sys.modules["mpi4py"] = mpi4py_mod
    sys.modules["mpi4py.MPI"] = _FakeMPI


if os.environ.get("PYTENS_TEST_USE_REAL_MPI", "0") != "1":
    _install_fake_mpi4py()
