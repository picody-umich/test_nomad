import itertools
from unittest.mock import MagicMock

import numpy as np
import pytens
import pytest

from pytens_radtrans.discretization import Discretization, Indices
from pytens_radtrans.load_config import Angles, Config, Geometry, Solver
from pytens_radtrans.stencil import (
    JiangStencil,
    RusanovStencil,
    Stencil,
    UpwindStencil,
)

# --- Fixtures for setting up test environments ---


@pytest.fixture
def mock_config_1d():
    """Provides a mock Config object for 1D simulations."""
    config = MagicMock(spec=Config)
    config.solver = MagicMock(spec=Solver)
    config.solver.order = ["x", "theta", "phi"]
    config.cfl_factor = 0.5
    config.speed_of_light = 1.0
    config.geometry = MagicMock(spec=Geometry)
    config.geometry.n = [4]
    config.geometry.dimension = 1
    config.angles = MagicMock(spec=Angles)
    config.angles.n_theta = 1
    config.angles.n_phi = 2
    return config


@pytest.fixture
def mock_config_2d():
    """Provides a mock Config object for 2D simulations."""
    config = MagicMock(spec=Config)
    config.solver = MagicMock(spec=Solver)
    config.solver.order = ["x", "theta", "phi"]
    config.cfl_factor = 0.5
    config.speed_of_light = 1.0
    config.geometry = MagicMock(spec=Geometry)
    config.geometry.n = [4, 4]
    config.geometry.dimension = 2
    config.angles = MagicMock(spec=Angles)
    config.angles.n_theta = 1
    config.angles.n_phi = 4
    return config


@pytest.fixture
def mock_config_2d_nonsquare():
    """Provides a mock Config object for non-square 2D simulations."""
    config = MagicMock(spec=Config)
    config.solver = MagicMock(spec=Solver)
    config.solver.order = ["x", "theta", "phi"]
    config.cfl_factor = 0.5
    config.speed_of_light = 1.0
    config.geometry = MagicMock(spec=Geometry)
    config.geometry.n = [8, 6]
    config.geometry.dimension = 2
    config.angles = MagicMock(spec=Angles)
    config.angles.n_theta = 1
    config.angles.n_phi = 4
    return config


@pytest.fixture
def mock_config_reordered():
    """Provides a 1D mock Config with a non-default tensor order."""
    config = MagicMock(spec=Config)
    config.solver = MagicMock(spec=Solver)
    config.solver.order = ["theta", "x", "phi"]
    config.cfl_factor = 0.5
    config.speed_of_light = 1.0
    config.geometry = MagicMock(spec=Geometry)
    config.geometry.n = [4]
    config.geometry.dimension = 1
    config.angles = MagicMock(spec=Angles)
    config.angles.n_theta = 1
    config.angles.n_phi = 2
    return config


@pytest.fixture
def disc_1d():
    """Provides a 1D Discretization object."""
    return Discretization.from_geom(
        lb=[0.0],
        ub=[1.0],
        n=[4],
        num_ghost=[2],
    )


@pytest.fixture
def disc_2d():
    """Provides a 2D Discretization object."""
    return Discretization.from_geom(
        lb=[0.0, 0.0],
        ub=[1.0, 1.0],
        n=[4, 4],
        num_ghost=[2, 2],
    )


@pytest.fixture
def disc_2d_nonsquare():
    """Provides a non-square 2D Discretization object."""
    return Discretization.from_geom(
        lb=[0.0, 0.0],
        ub=[1.0, 1.0],
        n=[8, 6],
        num_ghost=[2, 2],
    )


@pytest.fixture
def angle_params():
    """Provides common angular parameters."""
    sin_theta = np.array([1.0])
    # Angle 1: right-moving; Angle 2: left-moving
    cos_phi = np.array([1.0, -1.0])
    sin_phi = np.array([0.0, 0.0])  # for 1D, sin_phi can be zero
    return sin_theta, cos_phi, sin_phi


@pytest.fixture
def angle_params_2d():
    """Provides common angular parameters for 2D."""
    sin_theta = np.array([1.0])
    # Right, Up, Left, Down
    cos_phi = np.array([1.0, 0.0, -1.0, 0.0])
    sin_phi = np.array([0.0, 1.0, 0.0, -1.0])
    return sin_theta, cos_phi, sin_phi


# --- Test Classes ---


class TestStencilHelpers:
    """Tests for the helper methods in the base Stencil class."""

    def test_masks_minus_plus(self):
        """Verify that an array is correctly split into positive and negative parts."""
        arr = np.array([-2.0, -1.0, 0.0, 1.0, 2.0])
        mask_left, mask_right = Stencil.masks_minus_plus(None, arr)

        expected_left = np.array([-2.0, -1.0, 0.0, 0.0, 0.0])
        expected_right = np.array([0.0, 0.0, 0.0, 1.0, 2.0])

        np.testing.assert_array_equal(mask_left, expected_left)
        np.testing.assert_array_equal(mask_right, expected_right)

    def test_get_ul_dc_and_ur_dc(self, disc_1d, mock_config_1d):
        """Verify extraction of left and right states for flux calculation."""
        stencil = UpwindStencil(1.0, None, None, None, disc_1d, mock_config_1d)
        # Array with one ghost cell on each side: [g, c1, c2, c3, c4, g]
        core_vals = np.arange(6)  # [0, 1, 2, 3, 4, 5]

        ul = stencil.get_ul_dc(core_vals, dim=0)
        ur = stencil.get_ur_dc(core_vals, dim=0)

        np.testing.assert_array_equal(ul, [0, 1, 2, 3, 4])
        np.testing.assert_array_equal(ur, [1, 2, 3, 4, 5])

    def test_get_rhs(self, disc_1d, mock_config_1d):
        """Verify the calculation of the flux divergence."""
        stencil = UpwindStencil(1.0, None, None, None, disc_1d, mock_config_1d)
        # Fluxes at interfaces: F_1/2, F_3/2, F_5/2, F_7/2, F_9/2
        flux = np.array([1.0, 2.0, 4.0, 7.0, 11.0])
        h = disc_1d.grid.dx[0]  # 0.25

        rhs = stencil.get_rhs(flux, h)

        expected_rhs = (flux[1:] - flux[:-1]) / h
        np.testing.assert_allclose(rhs, expected_rhs)


class TestUpwindStencil:
    """Tests for the UpwindStencil implementation."""

    def test_stencil1d_operator(self, mock_config_1d, disc_1d, angle_params):
        """Verify the full 1D upwind TT operator on a simple linear field."""
        # 1. Setup problem: I(x) = x with outflow BCs.
        # The input tensor network must contain the ghost cells.
        # For a grid with centers [0.125, 0.375, 0.625, 0.875], I(x)=x with
        # outflow BCs gives the following field with one ghost on each side.
        field_vals = np.array([0.125, 0.125, 0.375, 0.625, 0.875, 0.875])
        n_space_total = field_vals.shape[0]

        # 2. Create input Tensor Network from factorized arrays
        n_theta = mock_config_1d.angles.n_theta
        n_phi = mock_config_1d.angles.n_phi

        space_ind = pytens.Index("x", n_space_total)
        theta_ind = pytens.Index("theta", n_theta)
        phi_ind = pytens.Index("phi", n_phi)

        # The field is isotropic (same spatial part for all angles)
        indices = [space_ind, theta_ind, phi_ind]
        arrays = [field_vals, np.ones(n_theta), np.ones(n_phi)]
        input_tn = pytens.tt_rank1(indices, arrays)

        # 3. Instantiate stencil and get operator
        sin_theta, cos_phi, sin_phi = angle_params
        stencil = UpwindStencil(
            mock_config_1d.speed_of_light,
            sin_theta,
            cos_phi,
            sin_phi,
            disc_1d,
            mock_config_1d,
        )

        # The output indices should match the interior grid dimensions
        out_indices = Indices.from_config(mock_config_1d)
        op = stencil.get_ttop(out_indices, scale=1.0)

        # 4. Apply operator and get result array
        tn_op_list = op([input_tn], spatial_vars={})
        result_tn = tn_op_list.evaluate()

        result_array = result_tn.contract().value

        # 5. Calculate expected result manually
        h = disc_1d.grid.dx[0]
        c = mock_config_1d.speed_of_light
        expected_array = np.zeros((out_indices.space.size, n_theta, n_phi))

        # Angle 1: right-moving, Omega_x = cos_phi[0] = 1.0
        omega_x_r = cos_phi[0]
        fluxes_r = c * omega_x_r * field_vals[:-1]  # upwind uses left value
        rhs_r = (fluxes_r[1:] - fluxes_r[:-1]) / h

        # Angle 2: left-moving, Omega_x = cos_phi[1] = -1.0
        omega_x_l = cos_phi[1]
        fluxes_l = c * omega_x_l * field_vals[1:]  # upwind uses right value
        rhs_l = (fluxes_l[1:] - fluxes_l[:-1]) / h

        # Populate expected array. Assumes n_theta = 1
        expected_array[:, 0, 0] = rhs_r
        expected_array[:, 0, 1] = rhs_l

        # 6. Assert
        np.testing.assert_allclose(result_array, expected_array)

    def test_stencil2d_operator(self, mock_config_2d, disc_2d, angle_params_2d):
        """Verify the full 2D upwind TT operator."""
        # 1. Setup problem: I(x,y) = x+y with outflow BCs.
        nx, ny = disc_2d.grid.num_cells
        ngx = int(disc_2d.grid.num_ghost[0] / 2)
        ngy = int(disc_2d.grid.num_ghost[1] / 2)

        xc = disc_2d.grid.cell_centers[0]
        yc = disc_2d.grid.cell_centers[1]
        xx, yy = np.meshgrid(xc, yc, indexing="ij")
        field_interior = xx + yy

        # Create full field with outflow ghost cells
        field_vals = np.zeros((nx + 2 * ngx, ny + 2 * ngy))
        field_vals[ngx:-ngx, ngy:-ngy] = field_interior
        field_vals[:ngx, ngy:-ngy] = field_interior[0, :]
        field_vals[-ngx:, ngy:-ngy] = field_interior[-1, :]
        field_vals[:, :ngy] = field_vals[:, ngy : ngy + 1]
        field_vals[:, -ngy:] = field_vals[:, -ngy - 1 : -ngy]

        # 2. Create input Tensor Network
        n_space_total = field_vals.size
        n_theta = mock_config_2d.angles.n_theta
        n_phi = mock_config_2d.angles.n_phi

        space_ind = pytens.Index("x", n_space_total)
        theta_ind = pytens.Index("theta", n_theta)
        phi_ind = pytens.Index("phi", n_phi)
        indices = [space_ind, theta_ind, phi_ind]
        arrays = [field_vals.flatten(), np.ones(n_theta), np.ones(n_phi)]
        input_tn = pytens.tt_rank1(indices, arrays)

        # 3. Instantiate stencil and get operator
        sin_theta, cos_phi, sin_phi = angle_params_2d
        stencil = UpwindStencil(
            mock_config_2d.speed_of_light,
            sin_theta,
            cos_phi,
            sin_phi,
            disc_2d,
            mock_config_2d,
        )
        out_indices = Indices.from_config(mock_config_2d)
        op = stencil.get_ttop(out_indices, scale=1.0)

        # 4. Apply operator and get result array
        tn_op_list = op([input_tn], spatial_vars={})
        result_tn = tn_op_list.evaluate()
        result_array = result_tn.contract().value.reshape(nx, ny, n_theta, n_phi)

        # 5. Calculate expected result manually
        hx, hy = disc_2d.grid.dx
        c = mock_config_2d.speed_of_light
        expected_array = np.zeros_like(result_array)

        for i in range(n_phi):
            omega_x = c * cos_phi[i]
            omega_y = c * sin_phi[i]
            rhs_x = np.zeros((nx, ny))
            rhs_y = np.zeros((nx, ny))

            # X-direction fluxes (vertical interfaces) and divergence
            if omega_x != 0:
                ul_x = field_vals[:-1, :]
                ur_x = field_vals[1:, :]
                flux_x = np.zeros_like(ul_x)
                if omega_x > 0:
                    flux_x = omega_x * ul_x
                else:  # omega_x < 0
                    flux_x = omega_x * ur_x
                divergence_x = (flux_x[1:, :] - flux_x[:-1, :]) / hx
                rhs_x = divergence_x[:, ngy:-ngy]

            # Y-direction fluxes (horizontal interfaces) and divergence
            if omega_y != 0:
                ul_y = field_vals[:, :-1]
                ur_y = field_vals[:, 1:]
                flux_y = np.zeros_like(ul_y)
                if omega_y > 0:
                    flux_y = omega_y * ul_y
                else:  # omega_y < 0
                    flux_y = omega_y * ur_y
                divergence_y = (flux_y[:, 1:] - flux_y[:, :-1]) / hy
                rhs_y = divergence_y[ngx:-ngx, :]

            expected_array[:, :, 0, i] = rhs_x + rhs_y

        # 6. Assert
        np.testing.assert_allclose(result_array, expected_array)

    def test_stencil1d_with_flux_mask(
        self, mock_config_1d, disc_1d, angle_params
    ) -> None:
        """Verify that the 1D flux mask correctly zeros out a flux."""
        # 1. Setup problem: I(x) = x, same as the base test.
        field_vals = np.array([0.125, 0.125, 0.375, 0.625, 0.875, 0.875])
        n_space_total = field_vals.shape[0]
        n_theta = mock_config_1d.angles.n_theta
        n_phi = mock_config_1d.angles.n_phi
        space_ind = pytens.Index("x", n_space_total)
        theta_ind = pytens.Index("theta", n_theta)
        phi_ind = pytens.Index("phi", n_phi)
        input_tn = pytens.tt_rank1(
            [space_ind, theta_ind, phi_ind],
            [field_vals, np.ones(n_theta), np.ones(n_phi)],
        )

        # 2. Create a flux mask that zeros out the flux at the middle interface (x=0.5)
        # There are 5 interfaces for 4 cells. Mask index 2 is the middle one.
        flux_mask_arr = np.ones(disc_1d.grid.num_cells[0] + 1)
        flux_mask_arr[2] = 0.0
        flux_mask = {"x": flux_mask_arr}

        # 3. Instantiate stencil and get operator with the mask
        stencil = UpwindStencil(1.0, *angle_params, disc_1d, mock_config_1d)
        out_indices = Indices.from_config(mock_config_1d)
        op = stencil.get_ttop(out_indices, scale=1.0, flux_mask=flux_mask)

        # 4. Apply operator and get result
        result_array = op([input_tn], {}).evaluate().contract().value

        # 5. Calculate expected result manually
        h = disc_1d.grid.dx[0]
        c = 1.0
        _, cos_phi, _ = angle_params
        expected_array = np.zeros((out_indices.space.size, 1, 2))

        # Angle 1 (right-moving): Fluxes are F_L * mask
        fluxes_r = c * cos_phi[0] * field_vals[:-1] * flux_mask_arr
        rhs_r = (fluxes_r[1:] - fluxes_r[:-1]) / h

        # Angle 2 (left-moving): Fluxes are F_R * mask
        fluxes_l = c * cos_phi[1] * field_vals[1:] * flux_mask_arr
        rhs_l = (fluxes_l[1:] - fluxes_l[:-1]) / h

        expected_array[:, 0, 0] = rhs_r
        expected_array[:, 0, 1] = rhs_l

        # 6. Assert
        np.testing.assert_allclose(result_array, expected_array)

    def test_stencil2d_with_flux_mask(
        self, mock_config_2d, disc_2d, angle_params_2d
    ) -> None:
        """Verify that the 2D flux mask correctly zeros out a flux."""
        # 1. Setup: I(x,y) = x+y, same as the base test.
        nx, ny = disc_2d.grid.num_cells
        ngx = int(disc_2d.grid.num_ghost[0] / 2)
        ngy = int(disc_2d.grid.num_ghost[1] / 2)
        xc, yc = disc_2d.grid.cell_centers
        xx, yy = np.meshgrid(xc, yc, indexing="ij")
        field_interior = xx + yy
        field_vals = np.zeros((nx + 2 * ngx, ny + 2 * ngy))
        field_vals[ngx:-ngx, ngy:-ngy] = field_interior
        # Apply outflow BCs
        field_vals[:ngx, ngy:-ngy] = field_interior[0, :]
        field_vals[-ngx:, ngy:-ngy] = field_interior[-1, :]
        field_vals[:, :ngy] = field_vals[:, ngy : ngy + 1]
        field_vals[:, -ngy:] = field_vals[:, -ngy - 1 : -ngy]
        n_theta = mock_config_2d.angles.n_theta
        n_phi = mock_config_2d.angles.n_phi
        space_ind = pytens.Index("x", field_vals.size)
        theta_ind = pytens.Index("theta", n_theta)
        phi_ind = pytens.Index("phi", n_phi)
        input_tn = pytens.tt_rank1(
            [space_ind, theta_ind, phi_ind],
            [field_vals.flatten(), np.ones(n_theta), np.ones(n_phi)],
        )

        # 2. Create a flux mask to zero out x-flux at x=0.5 (interface index 2)
        flux_mask_x = np.ones(disc_2d.grid.num_cells[0] + 1)
        flux_mask_x[2] = 0.0
        flux_mask = {"x": flux_mask_x, "y": None}

        # 3. Instantiate stencil and get operator
        stencil = UpwindStencil(1.0, *angle_params_2d, disc_2d, mock_config_2d)
        out_indices = Indices.from_config(mock_config_2d)
        op = stencil.get_ttop(out_indices, scale=1.0, flux_mask=flux_mask)

        # 4. Apply operator and get result
        result_array = (
            op([input_tn], {}).evaluate().contract().value.reshape(nx, ny, 1, 4)
        )

        # 5. Calculate expected result manually
        hx, hy = disc_2d.grid.dx
        c = 1.0
        _, cos_phi, sin_phi = angle_params_2d
        expected_array = np.zeros_like(result_array)

        for i in range(4):
            # Calculate full x-fluxes and apply mask
            ul_x, ur_x = field_vals[:-1, :], field_vals[1:, :]
            flux_x = c * cos_phi[i] * (ul_x if cos_phi[i] > 0 else ur_x)
            masked_flux_x = flux_x * flux_mask_x[:, np.newaxis]
            rhs_x = ((masked_flux_x[1:, :] - masked_flux_x[:-1, :]) / hx)[:, ngy:-ngy]

            # Calculate y-fluxes (unmasked)
            ul_y, ur_y = field_vals[:, :-1], field_vals[:, 1:]
            flux_y = c * sin_phi[i] * (ul_y if sin_phi[i] > 0 else ur_y)
            rhs_y = ((flux_y[:, 1:] - flux_y[:, :-1]) / hy)[ngx:-ngx, :]

            expected_array[:, :, 0, i] = rhs_x + rhs_y

        np.testing.assert_allclose(result_array, expected_array)

    def test_stencil2d_with_flux_mask_nonsquare(
        self, mock_config_2d_nonsquare, disc_2d_nonsquare, angle_params_2d
    ) -> None:
        """Verify 2D flux mask on a non-square grid."""
        # 1. Setup on a non-square grid
        disc_2d = disc_2d_nonsquare
        mock_config_2d = mock_config_2d_nonsquare
        nx, ny = disc_2d.grid.num_cells
        ngx = int(disc_2d.grid.num_ghost[0] / 2)
        ngy = int(disc_2d.grid.num_ghost[1] / 2)
        xc, yc = disc_2d.grid.cell_centers
        xx, yy = np.meshgrid(xc, yc, indexing="ij")
        field_interior = xx + yy
        field_vals = np.zeros((nx + 2 * ngx, ny + 2 * ngy))
        field_vals[ngx:-ngx, ngy:-ngy] = field_interior
        field_vals[:ngx, ngy:-ngy] = field_interior[0, :]
        field_vals[-ngx:, ngy:-ngy] = field_interior[-1, :]
        field_vals[:, :ngy] = field_vals[:, ngy : ngy + 1]
        field_vals[:, -ngy:] = field_vals[:, -ngy - 1 : -ngy]
        n_theta = mock_config_2d.angles.n_theta
        n_phi = mock_config_2d.angles.n_phi
        space_ind = pytens.Index("x", field_vals.size)
        theta_ind = pytens.Index("theta", n_theta)
        phi_ind = pytens.Index("phi", n_phi)
        input_tn = pytens.tt_rank1(
            [space_ind, theta_ind, phi_ind],
            [field_vals.flatten(), np.ones(n_theta), np.ones(n_phi)],
        )

        # 2. Create mask to zero out x-flux at an interface
        flux_mask_x = np.ones((nx + 1, ny + 2 * ngy))
        flux_mask_x[2, :] = 0.0  # Zero out all y-cells at x-interface 2
        flux_mask = {"x": flux_mask_x, "y": np.ones((nx + 2 * ngx, ny + 1))}

        # 3. Get operator with mask
        stencil = UpwindStencil(1.0, *angle_params_2d, disc_2d, mock_config_2d)
        out_indices = Indices.from_config(mock_config_2d)
        op = stencil.get_ttop(out_indices, scale=1.0, flux_mask=flux_mask)

        # 4. Apply operator
        result_array = (
            op([input_tn], {}).evaluate().contract().value.reshape(nx, ny, 1, 4)
        )

        # 5. Calculate expected result manually
        hx, hy = disc_2d.grid.dx
        c = 1.0
        _, cos_phi, sin_phi = angle_params_2d
        expected_array = np.zeros_like(result_array)

        for i in range(4):
            # Calculate full x-fluxes and apply mask
            ul_x, ur_x = field_vals[:-1, :], field_vals[1:, :]
            flux_x = c * cos_phi[i] * (ul_x if cos_phi[i] > 0 else ur_x)
            masked_flux_x = flux_x * flux_mask["x"]
            rhs_x = ((masked_flux_x[1:, :] - masked_flux_x[:-1, :]) / hx)[:, ngy:-ngy]

            # Calculate y-fluxes (unmasked in this test)
            ul_y, ur_y = field_vals[:, :-1], field_vals[:, 1:]
            flux_y = c * sin_phi[i] * (ul_y if sin_phi[i] > 0 else ur_y)
            rhs_y = ((flux_y[:, 1:] - flux_y[:, :-1]) / hy)[ngx:-ngx, :]

            expected_array[:, :, 0, i] = rhs_x + rhs_y

        np.testing.assert_allclose(result_array, expected_array)

    def test_stencil1d_operator_reordered(
        self, mock_config_reordered, disc_1d, angle_params
    ):
        """Verify the 1D upwind operator works with a non-default tensor order."""
        # 1. Setup problem: I(x) = x with outflow BCs.
        field_vals = np.array([0.125, 0.125, 0.375, 0.625, 0.875, 0.875])
        n_space_total = field_vals.shape[0]

        # 2. Create input Tensor Network
        n_theta = mock_config_reordered.angles.n_theta
        n_phi = mock_config_reordered.angles.n_phi
        n_space = mock_config_reordered.geometry.n[0]

        space_ind = pytens.Index("x", n_space_total)
        theta_ind = pytens.Index("theta", n_theta)
        phi_ind = pytens.Index("phi", n_phi)

        indices = [space_ind, theta_ind, phi_ind]
        arrays = [field_vals, np.ones(n_theta), np.ones(n_phi)]

        # Reorder indices and arrays according to the config
        from pytens_radtrans.utils import encode_order, reorder_list

        permut, _ = encode_order(mock_config_reordered.solver.order)
        reordered_indices = reorder_list(indices, permut)
        reordered_arrays = reorder_list(arrays, permut)
        input_tn = pytens.tt_rank1(reordered_indices, reordered_arrays)

        # 3. Instantiate stencil and get operator
        sin_theta, cos_phi, sin_phi = angle_params
        stencil = UpwindStencil(
            mock_config_reordered.speed_of_light,
            sin_theta,
            cos_phi,
            sin_phi,
            disc_1d,
            mock_config_reordered,
        )
        out_indices = Indices.from_config(mock_config_reordered)
        op = stencil.get_ttop(out_indices, scale=1.0)

        # 4. Apply operator and get result array
        tn_op_list = op([input_tn], spatial_vars={})
        result_tn = tn_op_list.evaluate()
        result_array = result_tn.contract().value

        # 5. Reshape and reorder result for comparison
        result_array = result_array.reshape((n_theta, n_space, n_phi))
        result_reordered = result_array.transpose((1, 0, 2))

        # 6. Calculate expected result manually (same as original test)
        h = disc_1d.grid.dx[0]
        c = mock_config_reordered.speed_of_light
        expected_array = np.zeros((n_space, n_theta, n_phi))

        omega_x_r = cos_phi[0]
        fluxes_r = c * omega_x_r * field_vals[:-1]
        rhs_r = (fluxes_r[1:] - fluxes_r[:-1]) / h

        omega_x_l = cos_phi[1]
        fluxes_l = c * omega_x_l * field_vals[1:]
        rhs_l = (fluxes_l[1:] - fluxes_l[:-1]) / h

        expected_array[:, 0, 0] = rhs_r
        expected_array[:, 0, 1] = rhs_l

        # 7. Assert
        np.testing.assert_allclose(result_reordered, expected_array)

    @pytest.mark.parametrize(
        "order",
        list(itertools.permutations(["x", "theta", "phi"])),
        ids=lambda o: "-".join(o),
    )
    def test_stencil1d_operator_any_order(self, order, disc_1d, angle_params):
        """Verify the 1D upwind operator works with any tensor order."""
        # 1. Setup config and problem: I(x) = x with outflow BCs.
        config = MagicMock(spec=Config)
        config.solver = MagicMock(spec=Solver)
        config.solver.order = list(order)
        config.cfl_factor = 0.5
        config.speed_of_light = 1.0
        config.geometry = MagicMock(spec=Geometry)
        config.geometry.n = [4]
        config.geometry.dimension = 1
        config.angles = MagicMock(spec=Angles)
        config.angles.n_theta = 1
        config.angles.n_phi = 2

        field_vals = np.array([0.125, 0.125, 0.375, 0.625, 0.875, 0.875])
        n_space_total = field_vals.shape[0]

        # 2. Create input Tensor Network
        n_theta = config.angles.n_theta
        n_phi = config.angles.n_phi
        n_space = config.geometry.n[0]

        space_ind = pytens.Index("x", n_space_total)
        theta_ind = pytens.Index("theta", n_theta)
        phi_ind = pytens.Index("phi", n_phi)

        indices = [space_ind, theta_ind, phi_ind]
        arrays = [field_vals, np.ones(n_theta), np.ones(n_phi)]

        # Reorder indices and arrays according to the config
        from pytens_radtrans.utils import encode_order, reorder_list

        permut, inv_permut = encode_order(config.solver.order)
        reordered_indices = reorder_list(indices, permut)
        reordered_arrays = reorder_list(arrays, permut)
        input_tn = pytens.tt_rank1(reordered_indices, reordered_arrays)

        # 3. Instantiate stencil and get operator
        sin_theta, cos_phi, sin_phi = angle_params
        stencil = UpwindStencil(
            config.speed_of_light,
            sin_theta,
            cos_phi,
            sin_phi,
            disc_1d,
            config,
        )
        out_indices = Indices.from_config(config)
        op = stencil.get_ttop(out_indices, scale=1.0)

        # 4. Apply operator and get result array
        tn_op_list = op([input_tn], spatial_vars={})
        result_tn = tn_op_list.evaluate()
        result_array = result_tn.contract().value

        # 5. Reshape and reorder result for comparison
        default_sizes = [n_space, n_theta, n_phi]
        reshaped = result_array.reshape(reorder_list(default_sizes, permut))
        result_reordered = reshaped.transpose(inv_permut)

        # 6. Calculate expected result manually (same as original test)
        h = disc_1d.grid.dx[0]
        c = config.speed_of_light
        expected_array = np.zeros((n_space, n_theta, n_phi))

        omega_x_r = cos_phi[0]
        fluxes_r = c * omega_x_r * field_vals[:-1]
        rhs_r = (fluxes_r[1:] - fluxes_r[:-1]) / h

        omega_x_l = cos_phi[1]
        fluxes_l = c * omega_x_l * field_vals[1:]
        rhs_l = (fluxes_l[1:] - fluxes_l[:-1]) / h

        expected_array[:, 0, 0] = rhs_r
        expected_array[:, 0, 1] = rhs_l

        # 7. Assert
        np.testing.assert_allclose(result_reordered, expected_array)

    @pytest.mark.parametrize(
        "order",
        list(itertools.permutations(["x", "theta", "phi"])),
        ids=lambda o: "-".join(o),
    )
    def test_rusanov_operator_any_order_matches_default(
        self, order, disc_1d, angle_params
    ):
        """Verify 1D Rusanov operator matches default ordering for any order."""
        # Default-order config
        config_default = MagicMock(spec=Config)
        config_default.solver = MagicMock(spec=Solver)
        config_default.solver.order = ["x", "theta", "phi"]
        config_default.cfl_factor = 0.5
        config_default.speed_of_light = 1.0
        config_default.geometry = MagicMock(spec=Geometry)
        config_default.geometry.n = [4]
        config_default.geometry.dimension = 1
        config_default.angles = MagicMock(spec=Angles)
        config_default.angles.n_theta = 1
        config_default.angles.n_phi = 2

        # Permuted-order config
        config_perm = MagicMock(spec=Config)
        config_perm.solver = MagicMock(spec=Solver)
        config_perm.solver.order = list(order)
        config_perm.cfl_factor = 0.5
        config_perm.speed_of_light = 1.0
        config_perm.geometry = MagicMock(spec=Geometry)
        config_perm.geometry.n = [4]
        config_perm.geometry.dimension = 1
        config_perm.angles = MagicMock(spec=Angles)
        config_perm.angles.n_theta = 1
        config_perm.angles.n_phi = 2

        field_vals = np.array([0.125, 0.125, 0.375, 0.625, 0.875, 0.875])
        n_space_total = field_vals.shape[0]

        n_theta = config_default.angles.n_theta
        n_phi = config_default.angles.n_phi
        n_space = config_default.geometry.n[0]

        space_ind = pytens.Index("x", n_space_total)
        theta_ind = pytens.Index("theta", n_theta)
        phi_ind = pytens.Index("phi", n_phi)
        indices = [space_ind, theta_ind, phi_ind]
        arrays = [field_vals, np.ones(n_theta), np.ones(n_phi)]

        # Default-order input
        input_default = pytens.tt_rank1(indices, arrays)

        # Permuted-order input
        from pytens_radtrans.utils import encode_order, reorder_list

        permut, inv_permut = encode_order(config_perm.solver.order)
        reordered_indices = reorder_list(indices, permut)
        reordered_arrays = reorder_list(arrays, permut)
        input_perm = pytens.tt_rank1(reordered_indices, reordered_arrays)

        # Build operators
        sin_theta, cos_phi, sin_phi = angle_params
        stencil_default = RusanovStencil(
            config_default.speed_of_light,  # wave_speed
            config_default.speed_of_light,
            sin_theta,
            cos_phi,
            sin_phi,
            disc_1d,
            config_default,
        )
        stencil_perm = RusanovStencil(
            config_perm.speed_of_light,  # wave_speed
            config_perm.speed_of_light,
            sin_theta,
            cos_phi,
            sin_phi,
            disc_1d,
            config_perm,
        )

        out_indices_default = Indices.from_config(config_default)
        out_indices_perm = Indices.from_config(config_perm)
        op_default = stencil_default.get_ttop(out_indices_default, scale=1.0)
        op_perm = stencil_perm.get_ttop(out_indices_perm, scale=1.0)

        # Apply operators
        result_default = op_default([input_default], spatial_vars={}).evaluate()
        result_perm = op_perm([input_perm], spatial_vars={}).evaluate()

        result_default_array = result_default.contract().value
        result_perm_array = result_perm.contract().value

        # Reorder permuted result back to canonical (x, theta, phi)
        default_sizes = [n_space, n_theta, n_phi]
        reshaped = result_perm_array.reshape(reorder_list(default_sizes, permut))
        result_perm_reordered = reshaped.transpose(inv_permut)

        # Compare to default ordering
        result_default_array = result_default_array.reshape(
            (n_space, n_theta, n_phi)
        )
        np.testing.assert_allclose(result_perm_reordered, result_default_array)

    def test_rhs_vs_manual_flux_divergence(
        self, mock_config_2d, disc_2d, angle_params_2d
    ):
        """
        Verifies that the direct RHS calculation from stencil2d is identical to
        manually computing the divergence of fluxes obtained from the same underlying
        helper function. This confirms the consistency of _create_2d_spatial_core_func.
        """
        # 1. --- Setup: Same as test_stencil2d_operator ---
        nx, ny = disc_2d.grid.num_cells
        ngx = int(disc_2d.grid.num_ghost[0] / 2)
        ngy = int(disc_2d.grid.num_ghost[1] / 2)
        xc, yc = disc_2d.grid.cell_centers
        xx, yy = np.meshgrid(xc, yc, indexing="ij")
        field_interior = xx + yy
        field_vals = np.zeros((nx + 2 * ngx, ny + 2 * ngy))
        field_vals[ngx:-ngx, ngy:-ngy] = field_interior
        field_vals[:ngx, ngy:-ngy] = field_interior[0, :]
        field_vals[-ngx:, ngy:-ngy] = field_interior[-1, :]
        field_vals[:, :ngy] = field_vals[:, ngy : ngy + 1]
        field_vals[:, -ngy:] = field_vals[:, -ngy - 1 : -ngy]

        n_theta = mock_config_2d.angles.n_theta
        n_phi = mock_config_2d.angles.n_phi
        space_ind = pytens.Index("x", field_vals.size)
        theta_ind = pytens.Index("theta", n_theta)
        phi_ind = pytens.Index("phi", n_phi)
        input_tn = pytens.tt_rank1(
            [space_ind, theta_ind, phi_ind],
            [field_vals.flatten(), np.ones(n_theta), np.ones(n_phi)],
        )

        stencil = UpwindStencil(1.0, *angle_params_2d, disc_2d, mock_config_2d)
        out_indices = Indices.from_config(mock_config_2d)

        # 2. --- Method 1: Direct RHS Calculation via get_ttop ---
        op_direct = stencil.get_ttop(out_indices, scale=1.0)
        result_direct_rhs_tn = op_direct([input_tn], {}).evaluate()
        result_direct_rhs = result_direct_rhs_tn.contract().value.reshape(
            nx, ny, n_theta, n_phi
        )

        # 3. --- Method 2: Manual Flux Divergence ---
        total_x_flux = np.zeros((nx + 1, ny, n_theta, n_phi))
        total_y_flux = np.zeros((nx, ny + 1, n_theta, n_phi))

        flux_info_list = stencil.get_flux_cores_2d()

        for flux_1d_func, direction, other_cores in flux_info_list:
            theta_func, phi_func = other_cores

            if direction == "x":
                output_size = (nx + 1) * ny
                spatial_op = stencil.create_2d_spatial_core_func(
                    flux_1d_func, direction, output_size
                )
                flux_spatial = spatial_op(field_vals.flatten()).reshape(nx + 1, ny)
            else:  # direction == 'y'
                output_size = nx * (ny + 1)
                spatial_op = stencil.create_2d_spatial_core_func(
                    flux_1d_func, direction, output_size
                )
                flux_spatial = spatial_op(field_vals.flatten()).reshape(nx, ny + 1)

            theta_core = theta_func(np.ones((1, 1))).flatten()
            phi_core = phi_func(np.ones((1, 1))).flatten()

            flux_component = (
                flux_spatial[..., np.newaxis, np.newaxis]
                * theta_core[np.newaxis, np.newaxis, :, np.newaxis]
                * phi_core[np.newaxis, np.newaxis, np.newaxis, :]
            )

            if direction == "x":
                total_x_flux += flux_component
            else:
                total_y_flux += flux_component

        hx, hy = disc_2d.grid.dx
        div_x = (total_x_flux[1:, :, :, :] - total_x_flux[:-1, :, :, :]) / hx
        div_y = (total_y_flux[:, 1:, :, :] - total_y_flux[:, :-1, :, :]) / hy
        result_manual_rhs = div_x + div_y

        # 4. --- Comparison ---
        np.testing.assert_allclose(result_direct_rhs, result_manual_rhs)

    def test_rhs_vs_manual_flux_divergence_nonsquare(
        self, mock_config_2d_nonsquare, disc_2d_nonsquare, angle_params_2d
    ):
        """
        Verifies RHS vs manual flux divergence on a NON-SQUARE grid to expose
        potential data layout bugs.
        """
        # 1. --- Setup ---
        disc_2d = disc_2d_nonsquare
        mock_config_2d = mock_config_2d_nonsquare

        nx, ny = disc_2d.grid.num_cells
        ngx = int(disc_2d.grid.num_ghost[0] / 2)
        ngy = int(disc_2d.grid.num_ghost[1] / 2)
        xc, yc = disc_2d.grid.cell_centers
        xx, yy = np.meshgrid(xc, yc, indexing="ij")
        field_interior = xx + yy
        field_vals = np.zeros((nx + 2 * ngx, ny + 2 * ngy))
        field_vals[ngx:-ngx, ngy:-ngy] = field_interior
        field_vals[:ngx, ngy:-ngy] = field_interior[0, :]
        field_vals[-ngx:, ngy:-ngy] = field_interior[-1, :]
        field_vals[:, :ngy] = field_vals[:, ngy : ngy + 1]
        field_vals[:, -ngy:] = field_vals[:, -ngy - 1 : -ngy]

        n_theta = mock_config_2d.angles.n_theta
        n_phi = mock_config_2d.angles.n_phi
        space_ind = pytens.Index("x", field_vals.size)
        theta_ind = pytens.Index("theta", n_theta)
        phi_ind = pytens.Index("phi", n_phi)
        input_tn = pytens.tt_rank1(
            [space_ind, theta_ind, phi_ind],
            [field_vals.flatten(), np.ones(n_theta), np.ones(n_phi)],
        )

        stencil = UpwindStencil(1.0, *angle_params_2d, disc_2d, mock_config_2d)
        out_indices = Indices.from_config(mock_config_2d)

        # --- 2. Method 1: Direct RHS Calculation ---
        op_direct = stencil.get_ttop(out_indices, scale=1.0)
        result_direct_rhs_tn = op_direct([input_tn], {}).evaluate()
        result_direct_rhs = result_direct_rhs_tn.contract().value.reshape(
            nx, ny, n_theta, n_phi
        )

        # --- 3. Method 2: Manual Flux Divergence ---
        total_x_flux = np.zeros((nx + 1, ny, n_theta, n_phi))
        total_y_flux = np.zeros((nx, ny + 1, n_theta, n_phi))

        flux_info_list = stencil.get_flux_cores_2d()

        for flux_1d_func, direction, other_cores in flux_info_list:
            theta_func, phi_func = other_cores

            if direction == "x":
                output_size = (nx + 1) * ny
                spatial_op = stencil.create_2d_spatial_core_func(
                    flux_1d_func, direction, output_size
                )
                flux_spatial = spatial_op(field_vals.flatten()).reshape(nx + 1, ny)
            else:  # direction == 'y'
                output_size = nx * (ny + 1)
                spatial_op = stencil.create_2d_spatial_core_func(
                    flux_1d_func, direction, output_size
                )
                flux_spatial = spatial_op(field_vals.flatten()).reshape(nx, ny + 1)

            theta_core = theta_func(np.ones((1, 1))).flatten()
            phi_core = phi_func(np.ones((1, 1))).flatten()

            flux_component = (
                flux_spatial[..., np.newaxis, np.newaxis]
                * theta_core[np.newaxis, np.newaxis, :, np.newaxis]
                * phi_core[np.newaxis, np.newaxis, np.newaxis, :]
            )

            if direction == "x":
                total_x_flux += flux_component
            else:
                total_y_flux += flux_component

        hx, hy = disc_2d.grid.dx
        div_x = (total_x_flux[1:, :, :, :] - total_x_flux[:-1, :, :, :]) / hx
        div_y = (total_y_flux[:, 1:, :, :] - total_y_flux[:, :-1, :, :]) / hy
        result_manual_rhs = div_x + div_y

        # --- 4. Comparison ---
        np.testing.assert_allclose(result_direct_rhs, result_manual_rhs)


class TestRusanovStencil:
    """Tests for the RusanovStencil implementation."""

    def test_stencil1d_logic(self, mock_config_1d, disc_1d, angle_params):
        """Test the core logic of the 1D Rusanov flux calculation."""
        wave_speed = 2.0
        stencil = RusanovStencil(
            wave_speed, 1.0, *angle_params, disc_1d, mock_config_1d
        )
        ul = np.array([1.0, 2.0])
        ur = np.array([3.0, 4.0])

        first = stencil.first_half(ul, ur)
        expected_first = (ul + ur) / 2.0
        np.testing.assert_allclose(first, expected_first)

        second = stencil.second_half(ul, ur)
        expected_second = (ul - ur) / 2.0 * wave_speed
        np.testing.assert_allclose(second, expected_second)

    def test_stencil1d_operator(self, mock_config_1d, disc_1d, angle_params):
        """Verify the full 1D Rusanov TT operator."""
        # 1. Setup problem: I(x) = x with outflow BCs.
        field_vals = np.array([0.125, 0.125, 0.375, 0.625, 0.875, 0.875])
        n_space_total = field_vals.shape[0]
        wave_speed = 2.0

        # 2. Create input Tensor Network
        n_theta = mock_config_1d.angles.n_theta
        n_phi = mock_config_1d.angles.n_phi
        space_ind = pytens.Index("x", n_space_total)
        theta_ind = pytens.Index("theta", n_theta)
        phi_ind = pytens.Index("phi", n_phi)
        indices = [space_ind, theta_ind, phi_ind]
        arrays = [field_vals, np.ones(n_theta), np.ones(n_phi)]
        input_tn = pytens.tt_rank1(indices, arrays)

        # 3. Instantiate stencil and get operator
        sin_theta, cos_phi, sin_phi = angle_params
        stencil = RusanovStencil(
            wave_speed,
            mock_config_1d.speed_of_light,
            sin_theta,
            cos_phi,
            sin_phi,
            disc_1d,
            mock_config_1d,
        )
        out_indices = Indices.from_config(mock_config_1d)
        op = stencil.get_ttop(out_indices, scale=1.0)

        # 4. Apply operator and get result array
        tn_op_list = op([input_tn], spatial_vars={})
        result_tn = tn_op_list.evaluate()
        result_array = result_tn.contract().value

        # 5. Calculate expected result manually
        h = disc_1d.grid.dx[0]
        c = mock_config_1d.speed_of_light
        ul = stencil.get_ul_dc(field_vals, 0)
        ur = stencil.get_ur_dc(field_vals, 0)

        # First term (central difference part)
        flux1_r = 0.5 * c * cos_phi[0] * (ul + ur)
        flux1_l = 0.5 * c * cos_phi[1] * (ul + ur)
        rhs1_r = (flux1_r[1:] - flux1_r[:-1]) / h
        rhs1_l = (flux1_l[1:] - flux1_l[:-1]) / h

        # Second term (artificial dissipation part)
        flux2 = -0.5 * wave_speed * (ur - ul)
        rhs2 = (flux2[1:] - flux2[:-1]) / h

        # Combine and reshape
        expected_array = np.zeros((out_indices.space.size, n_theta, n_phi))
        expected_array[:, 0, 0] = rhs1_r + rhs2
        expected_array[:, 0, 1] = rhs1_l + rhs2

        # 6. Assert
        np.testing.assert_allclose(result_array, expected_array)

    def test_stencil2d_operator(self, mock_config_2d, disc_2d, angle_params_2d):
        """Verify the full 2D Rusanov TT operator."""
        # 1. Setup problem: I(x,y) = x+y with outflow BCs.
        nx, ny = disc_2d.grid.num_cells
        ngx = int(disc_2d.grid.num_ghost[0] / 2)
        ngy = int(disc_2d.grid.num_ghost[1] / 2)
        wave_speed = 2.0

        xc = disc_2d.grid.cell_centers[0]
        yc = disc_2d.grid.cell_centers[1]
        xx, yy = np.meshgrid(xc, yc, indexing="ij")
        field_interior = xx + yy

        field_vals = np.zeros((nx + 2 * ngx, ny + 2 * ngy))
        field_vals[ngx:-ngx, ngy:-ngy] = field_interior
        field_vals[:ngx, ngy:-ngy] = field_interior[0, :]
        field_vals[-ngx:, ngy:-ngy] = field_interior[-1, :]
        field_vals[:, :ngy] = field_vals[:, ngy : ngy + 1]
        field_vals[:, -ngy:] = field_vals[:, -ngy - 1 : -ngy]

        # 2. Create input Tensor Network
        n_space_total = field_vals.size
        n_theta = mock_config_2d.angles.n_theta
        n_phi = mock_config_2d.angles.n_phi

        space_ind = pytens.Index("x", n_space_total)
        theta_ind = pytens.Index("theta", n_theta)
        phi_ind = pytens.Index("phi", n_phi)
        indices = [space_ind, theta_ind, phi_ind]
        arrays = [field_vals.flatten(), np.ones(n_theta), np.ones(n_phi)]
        input_tn = pytens.tt_rank1(indices, arrays)

        # 3. Instantiate stencil and get operator
        sin_theta, cos_phi, sin_phi = angle_params_2d
        stencil = RusanovStencil(
            wave_speed,
            mock_config_2d.speed_of_light,
            sin_theta,
            cos_phi,
            sin_phi,
            disc_2d,
            mock_config_2d,
        )
        out_indices = Indices.from_config(mock_config_2d)
        op = stencil.get_ttop(out_indices, scale=1.0)

        # 4. Apply operator and get result array
        tn_op_list = op([input_tn], spatial_vars={})
        result_tn = tn_op_list.evaluate()
        result_array = result_tn.contract().value.reshape(nx, ny, n_theta, n_phi)

        # 5. Calculate expected result manually
        hx, hy = disc_2d.grid.dx
        c = mock_config_2d.speed_of_light
        expected_array = np.zeros_like(result_array)

        for i in range(n_phi):
            omega_x = c * cos_phi[i]
            omega_y = c * sin_phi[i]

            # X-direction calculation
            ul_x = field_vals[:-1, :]
            ur_x = field_vals[1:, :]
            flux_x_central = 0.5 * omega_x * (ul_x + ur_x)
            flux_x_diss = -0.5 * wave_speed * (ur_x - ul_x)
            div_x = (
                (flux_x_central[1:, :] - flux_x_central[:-1, :])
                + (flux_x_diss[1:, :] - flux_x_diss[:-1, :])
            ) / hx
            rhs_x = div_x[:, ngy:-ngy]

            # Y-direction calculation
            ul_y = field_vals[:, :-1]
            ur_y = field_vals[:, 1:]
            flux_y_central = 0.5 * omega_y * (ul_y + ur_y)
            flux_y_diss = -0.5 * wave_speed * (ur_y - ul_y)
            div_y = (
                (flux_y_central[:, 1:] - flux_y_central[:, :-1])
                + (flux_y_diss[:, 1:] - flux_y_diss[:, :-1])
            ) / hy
            rhs_y = div_y[ngx:-ngx, :]

            expected_array[:, :, 0, i] = rhs_x + rhs_y

        # 6. Assert
        np.testing.assert_allclose(result_array, expected_array)


class TestJiangStencil:
    """Tests for the Jiang Asymptotic Preserving Stencil."""

    @pytest.fixture
    def jiang_stencil_1d(self, mock_config_1d, disc_1d, angle_params):
        """Provides a JiangStencil instance for 1D tests."""
        return JiangStencil(
            mock_config_1d.speed_of_light,
            *angle_params,
            disc_1d,
            mock_config_1d,
            tau_threshold=1e-3,
        )

    def test_get_tau(self, jiang_stencil_1d, disc_1d):
        """Verify the calculation of optical depth tau."""
        dx = disc_1d.grid.dx[0]
        op = np.array([1.0, 1.0, 2.0, 3.0, 4.0, 4.0])

        tau = jiang_stencil_1d.get_tau(dx, op, op)

        op_sum = op * 2
        op_inv = 1.0 / op_sum
        expected_tau_1 = 2 * 4.0 * dx / (op_inv[1] + op_inv[2])

        assert tau.shape == (5,)
        assert np.isclose(tau[1], expected_tau_1)

    def test_get_tau_switch_conditions(self, jiang_stencil_1d):
        """Verify the switching functions for thin and thick regimes."""
        # Optically thin case
        tau_thin = np.array([1e-4, 1e-5])
        term1_thin, term2_thin = jiang_stencil_1d.get_tau_switch_conditions(tau_thin)
        np.testing.assert_allclose(term1_thin, np.sqrt(1 - 0.5 * tau_thin**2))
        np.testing.assert_allclose(term2_thin, -tau_thin)

        # Optically thick case
        tau_thick = np.array([10.0, 20.0])
        term1_thick, term2_thick = jiang_stencil_1d.get_tau_switch_conditions(tau_thick)
        tau_s = tau_thick**2
        np.testing.assert_allclose(term1_thick, np.sqrt((1 - np.exp(-tau_s)) / tau_s))
        np.testing.assert_allclose(
            term2_thick, -np.sqrt((1 - np.exp(-(tau_s**2))) / tau_s)
        )

    def test_apf_flux(self, jiang_stencil_1d):
        """Verify the final assembly of the asymptotic preserving flux."""
        ul, ur = 1.0, 2.0
        sr, sl = 0.9, -0.1
        prod, diff = -0.09, 1.0
        flux = jiang_stencil_1d.apf_flux(ul, ur, sr, sl, prod, diff)
        assert np.isclose(flux, 1.01)

    def test_apf_flux_division_by_zero(self, jiang_stencil_1d):
        """Verify apf_flux handles division by zero."""
        # 1. Define inputs where the denominator `diff_term` is exactly zero.
        ul, ur = 1.0, 2.0
        sr, sl = 0.5, 0.5  # This makes sr - sl = 0
        prod_term = sr * sl
        diff_term = 0.0

        # 2. Call the function. This would produce `inf` without the safeguard.
        with pytest.warns(RuntimeWarning, match="divide by zero"):
            flux = jiang_stencil_1d.apf_flux(ul, ur, sr, sl, prod_term, diff_term)

        # 3. Assert that the result is finite and has been converted to zero.
        assert np.isfinite(flux)
        assert np.isclose(flux, 0.0)

    def test_jiang_cores_update(self, jiang_stencil_1d, mock_config_1d, disc_1d):
        """Verify that spatial variables are correctly applied to JiangStencilCores."""
        stencil_cores = jiang_stencil_1d.stencil1d()

        space_idx = mock_config_1d.solver.order.index("x")
        original_func = stencil_cores.cores[0][space_idx]

        # Mock input vector `v`; shape is num_cells + num_ghost
        mock_v = np.zeros(disc_1d.grid.num_cells[0] + disc_1d.grid.num_ghost[0])
        # The wrapper expects a 2D or 3D core, so we reshape.
        mock_v = mock_v.reshape(-1, 1)

        # Original function needs 3 args (a, s, v), but is wrapped.
        # Calling with 1 arg `v` should fail inside the original lambda.
        with pytest.raises(TypeError):
            original_func(mock_v)

        spatial_vars = {
            "absorption_opacity": np.ones(mock_v.shape),
            "scattering_opacity": np.ones(mock_v.shape),
        }
        updated_cores = stencil_cores.apply_spatial_vars_to_cores(spatial_vars)

        updated_func = updated_cores.cores[0][space_idx]

        # Updated func has opacities applied, so it should only need `v`.
        # A successful call is sufficient to prove it works.
        try:
            result = updated_func(mock_v)
            # Result shape should be (num_interior_cells, rank_change)
            assert result.shape[0] == disc_1d.grid.num_cells[0]
        except TypeError:
            pytest.fail("updated_func should not raise a TypeError with one argument.")

    def test_stencil1d_operator(
        self, jiang_stencil_1d, mock_config_1d, disc_1d, angle_params
    ):
        """Verify the full 1D Jiang stencil TT operator."""
        # 1. Setup problem: I(x) = x with outflow BCs, plus opacities.
        field_vals = np.array([0.125, 0.125, 0.375, 0.625, 0.875, 0.875])
        n_space_total = field_vals.shape[0]

        absorption_opacity = np.ones(field_vals.shape) * 0.1
        scattering_opacity = np.ones(field_vals.shape) * 10.0
        spatial_vars = {
            "absorption_opacity": absorption_opacity,
            "scattering_opacity": scattering_opacity,
        }

        # 2. Create input Tensor Network
        n_theta = mock_config_1d.angles.n_theta
        n_phi = mock_config_1d.angles.n_phi
        space_ind = pytens.Index("x", n_space_total)
        theta_ind = pytens.Index("theta", n_theta)
        phi_ind = pytens.Index("phi", n_phi)
        indices = [space_ind, theta_ind, phi_ind]
        arrays = [field_vals, np.ones(n_theta), np.ones(n_phi)]
        input_tn = pytens.tt_rank1(indices, arrays)

        # 3. Get and apply operator
        out_indices = Indices.from_config(mock_config_1d)
        op = jiang_stencil_1d.get_ttop(out_indices, scale=1.0)
        tn_op_list = op([input_tn], spatial_vars=spatial_vars)
        result_array = tn_op_list.evaluate().contract().value

        # 4. Manually calculate expected result using JiangStencil helpers
        h = disc_1d.grid.dx[0]
        c = mock_config_1d.speed_of_light
        _, cos_phi, _ = angle_params
        ul = jiang_stencil_1d.get_ul_dc(field_vals, 0)
        ur = jiang_stencil_1d.get_ur_dc(field_vals, 0)

        # Reshape to column vectors to match broadcasting inside flux helpers
        ul = ul.reshape(-1, 1)
        ur = ur.reshape(-1, 1)

        # Calculate flux for right-moving and left-moving angles
        flux_right = (
            c
            * cos_phi[0]
            * jiang_stencil_1d.flux_plus(
                h, absorption_opacity, scattering_opacity, ul, ur
            )
        )
        flux_left = (
            c
            * cos_phi[1]
            * jiang_stencil_1d.flux_minus(
                h, absorption_opacity, scattering_opacity, ul, ur
            )
        )

        # Calculate divergence of fluxes
        rhs_right = jiang_stencil_1d.get_rhs(flux_right, h)
        rhs_left = jiang_stencil_1d.get_rhs(flux_left, h)

        # Assemble expected array
        expected_array = np.zeros((out_indices.space.size, n_theta, n_phi))
        expected_array[:, 0, 0] = rhs_right.flatten()
        expected_array[:, 0, 1] = rhs_left.flatten()

        # 5. Assert arrays are close
        np.testing.assert_allclose(result_array, expected_array)

    @pytest.mark.parametrize(
        "order",
        list(itertools.permutations(["x", "theta", "phi"])),
        ids=lambda o: "-".join(o),
    )
    def test_jiang_operator_any_order_matches_default(
        self, order, disc_1d, angle_params
    ):
        """Verify 1D Jiang operator matches default ordering for any order."""
        # Default-order config
        config_default = MagicMock(spec=Config)
        config_default.solver = MagicMock(spec=Solver)
        config_default.solver.order = ["x", "theta", "phi"]
        config_default.cfl_factor = 0.5
        config_default.speed_of_light = 1.0
        config_default.geometry = MagicMock(spec=Geometry)
        config_default.geometry.n = [4]
        config_default.geometry.dimension = 1
        config_default.angles = MagicMock(spec=Angles)
        config_default.angles.n_theta = 1
        config_default.angles.n_phi = 2

        # Permuted-order config
        config_perm = MagicMock(spec=Config)
        config_perm.solver = MagicMock(spec=Solver)
        config_perm.solver.order = list(order)
        config_perm.cfl_factor = 0.5
        config_perm.speed_of_light = 1.0
        config_perm.geometry = MagicMock(spec=Geometry)
        config_perm.geometry.n = [4]
        config_perm.geometry.dimension = 1
        config_perm.angles = MagicMock(spec=Angles)
        config_perm.angles.n_theta = 1
        config_perm.angles.n_phi = 2

        field_vals = np.array([0.125, 0.125, 0.375, 0.625, 0.875, 0.875])
        n_space_total = field_vals.shape[0]

        absorption_opacity = np.ones(field_vals.shape) * 0.1
        scattering_opacity = np.ones(field_vals.shape) * 10.0
        spatial_vars = {
            "absorption_opacity": absorption_opacity,
            "scattering_opacity": scattering_opacity,
        }

        n_theta = config_default.angles.n_theta
        n_phi = config_default.angles.n_phi
        n_space = config_default.geometry.n[0]

        space_ind = pytens.Index("x", n_space_total)
        theta_ind = pytens.Index("theta", n_theta)
        phi_ind = pytens.Index("phi", n_phi)
        indices = [space_ind, theta_ind, phi_ind]
        arrays = [field_vals, np.ones(n_theta), np.ones(n_phi)]

        # Default-order input
        input_default = pytens.tt_rank1(indices, arrays)

        # Permuted-order input
        from pytens_radtrans.utils import encode_order, reorder_list

        permut, inv_permut = encode_order(config_perm.solver.order)
        reordered_indices = reorder_list(indices, permut)
        reordered_arrays = reorder_list(arrays, permut)
        input_perm = pytens.tt_rank1(reordered_indices, reordered_arrays)

        # Build operators
        sin_theta, cos_phi, sin_phi = angle_params
        stencil_default = JiangStencil(
            config_default.speed_of_light,
            sin_theta,
            cos_phi,
            sin_phi,
            disc_1d,
            config_default,
            tau_threshold=1e-3,
        )
        stencil_perm = JiangStencil(
            config_perm.speed_of_light,
            sin_theta,
            cos_phi,
            sin_phi,
            disc_1d,
            config_perm,
            tau_threshold=1e-3,
        )

        out_indices_default = Indices.from_config(config_default)
        out_indices_perm = Indices.from_config(config_perm)
        op_default = stencil_default.get_ttop(out_indices_default, scale=1.0)
        op_perm = stencil_perm.get_ttop(out_indices_perm, scale=1.0)

        # Apply operators
        result_default = op_default([input_default], spatial_vars=spatial_vars).evaluate()
        result_perm = op_perm([input_perm], spatial_vars=spatial_vars).evaluate()

        result_default_array = result_default.contract().value
        result_perm_array = result_perm.contract().value

        # Reorder permuted result back to canonical (x, theta, phi)
        default_sizes = [n_space, n_theta, n_phi]
        reshaped = result_perm_array.reshape(reorder_list(default_sizes, permut))
        result_perm_reordered = reshaped.transpose(inv_permut)

        # Compare to default ordering
        result_default_array = result_default_array.reshape(
            (n_space, n_theta, n_phi)
        )
        np.testing.assert_allclose(result_perm_reordered, result_default_array)

    @pytest.fixture
    def jiang_stencil_2d(self, mock_config_2d, disc_2d, angle_params_2d):
        """Provides a JiangStencil instance for 2D tests."""
        return JiangStencil(
            mock_config_2d.speed_of_light,
            *angle_params_2d,
            disc_2d,
            mock_config_2d,
            tau_threshold=1e-3,
        )

    def test_stencil2d_operator(
        self, jiang_stencil_2d, mock_config_2d, disc_2d, angle_params_2d
    ):
        """Verify the full 2D Jiang stencil TT operator."""
        # 1. Setup problem: I(x,y) = x+y with outflow BCs and opacities
        nx, ny = disc_2d.grid.num_cells
        ngx = int(disc_2d.grid.num_ghost[0] / 2)
        ngy = int(disc_2d.grid.num_ghost[1] / 2)

        xc, yc = disc_2d.grid.cell_centers
        xx, yy = np.meshgrid(xc, yc, indexing="ij")
        field_interior = xx + yy

        field_vals = np.zeros((nx + 2 * ngx, ny + 2 * ngy))
        field_vals[ngx:-ngx, ngy:-ngy] = field_interior
        field_vals[:ngx, ngy:-ngy] = field_interior[0, :]
        field_vals[-ngx:, ngy:-ngy] = field_interior[-1, :]
        field_vals[:, :ngy] = field_vals[:, ngy : ngy + 1]
        field_vals[:, -ngy:] = field_vals[:, -ngy - 1 : -ngy]

        absorption_opacity = np.ones(field_vals.shape) * 0.1
        scattering_opacity = np.ones(field_vals.shape) * 10.0
        spatial_vars = {
            "absorption_opacity": absorption_opacity,
            "scattering_opacity": scattering_opacity,
        }

        # 2. Create input Tensor Network
        n_space_total = field_vals.size
        n_theta = mock_config_2d.angles.n_theta
        n_phi = mock_config_2d.angles.n_phi
        indices = [
            pytens.Index("x", n_space_total),
            pytens.Index("theta", n_theta),
            pytens.Index("phi", n_phi),
        ]
        arrays = [field_vals.flatten(), np.ones(n_theta), np.ones(n_phi)]
        input_tn = pytens.tt_rank1(indices, arrays)

        # 3. Apply operator
        out_indices = Indices.from_config(mock_config_2d)
        op = jiang_stencil_2d.get_ttop(out_indices, scale=1.0)
        result_array = (
            op([input_tn], spatial_vars=spatial_vars)
            .evaluate()
            .contract()
            .value.reshape(nx, ny, n_theta, n_phi)
        )

        # 4. Manually calculate expected result
        hx, hy = disc_2d.grid.dx
        c = mock_config_2d.speed_of_light
        _, cos_phi, sin_phi = angle_params_2d
        expected_array = np.zeros_like(result_array)

        for i in range(n_phi):
            omega_x, omega_y = c * cos_phi[i], c * sin_phi[i]
            rhs_x, rhs_y = np.zeros((nx, ny)), np.zeros((nx, ny))

            # X-direction
            if omega_x != 0:
                ul = jiang_stencil_2d.get_ul_dc(field_vals, 0)
                ur = jiang_stencil_2d.get_ur_dc(field_vals, 0)
                a_slice = absorption_opacity[ngx - 1 : nx + ngx + 1, :]
                s_slice = scattering_opacity[ngx - 1 : nx + ngx + 1, :]
                flux_func = (
                    jiang_stencil_2d.flux_plus
                    if omega_x > 0
                    else jiang_stencil_2d.flux_minus
                )
                flux = omega_x * flux_func(
                    hx, a_slice, s_slice, ul[..., np.newaxis], ur[..., np.newaxis]
                )
                div = jiang_stencil_2d.get_rhs(flux, hx)
                rhs_x = div[:, ngy:-ngy, 0]

            # Y-direction
            if omega_y != 0:
                field_T = field_vals.T
                ul = jiang_stencil_2d.get_ul_dc(field_T, 1)
                ur = jiang_stencil_2d.get_ur_dc(field_T, 1)
                a_slice = absorption_opacity.T[ngy - 1 : ny + ngy + 1, :]
                s_slice = scattering_opacity.T[ngy - 1 : ny + ngy + 1, :]
                flux_func = (
                    jiang_stencil_2d.flux_plus
                    if omega_y > 0
                    else jiang_stencil_2d.flux_minus
                )
                flux = omega_y * flux_func(
                    hy, a_slice, s_slice, ul[..., np.newaxis], ur[..., np.newaxis]
                )
                div = jiang_stencil_2d.get_rhs(flux, hy)
                rhs_y = div[:, ngx:-ngx, 0].T

            expected_array[:, :, 0, i] = rhs_x + rhs_y

        # 5. Assert
        np.testing.assert_allclose(result_array, expected_array)

    def test_stencil1d_operator_optically_thin(
        self, mock_config_1d, disc_1d, angle_params
    ):
        """Verify JiangStencil approaches UpwindStencil in the optically thin limit."""
        # 1. Setup problem with very low opacities
        field_vals = np.array([0.125, 0.125, 0.375, 0.625, 0.875, 0.875])
        n_space_total = field_vals.shape[0]

        spatial_vars = {
            "absorption_opacity": np.full(field_vals.shape, 1e-8),
            "scattering_opacity": np.full(field_vals.shape, 1e-8),
        }

        # 2. Create input Tensor Network
        n_theta = mock_config_1d.angles.n_theta
        n_phi = mock_config_1d.angles.n_phi
        space_ind = pytens.Index("x", n_space_total)
        theta_ind = pytens.Index("theta", n_theta)
        phi_ind = pytens.Index("phi", n_phi)
        indices = [space_ind, theta_ind, phi_ind]
        arrays = [field_vals, np.ones(n_theta), np.ones(n_phi)]
        input_tn = pytens.tt_rank1(indices, arrays)

        # 3. Get JiangStencil result
        jiang_stencil = JiangStencil(
            mock_config_1d.speed_of_light,
            *angle_params,
            disc_1d,
            mock_config_1d,
        )
        out_indices = Indices.from_config(mock_config_1d)
        op_jiang = jiang_stencil.get_ttop(out_indices, scale=1.0)
        result_jiang = (
            op_jiang([input_tn], spatial_vars=spatial_vars).evaluate().contract().value
        )

        # 4. Get UpwindStencil result (for comparison)
        upwind_stencil = UpwindStencil(
            mock_config_1d.speed_of_light,
            *angle_params,
            disc_1d,
            mock_config_1d,
        )
        op_upwind = upwind_stencil.get_ttop(out_indices, scale=1.0)
        result_upwind = (
            op_upwind([input_tn], spatial_vars={}).evaluate().contract().value
        )

        # 5. Assert results are close
        np.testing.assert_allclose(result_jiang, result_upwind, rtol=1e-5, atol=1e-12)

    def test_stencil1d_operator_optically_thick(
        self, jiang_stencil_1d, mock_config_1d, disc_1d
    ):
        """Verify JiangStencil is numerically stable in the optically thick limit."""
        # 1. Setup problem with very high opacities
        field_vals = np.array([0.125, 0.125, 0.375, 0.625, 0.875, 0.875])
        n_space_total = field_vals.shape[0]

        spatial_vars = {
            "absorption_opacity": np.full(field_vals.shape, 1e8),
            "scattering_opacity": np.full(field_vals.shape, 1e8),
        }

        # 2. Create input Tensor Network
        n_theta = mock_config_1d.angles.n_theta
        n_phi = mock_config_1d.angles.n_phi
        space_ind = pytens.Index("x", n_space_total)
        theta_ind = pytens.Index("theta", n_theta)
        phi_ind = pytens.Index("phi", n_phi)
        indices = [space_ind, theta_ind, phi_ind]
        arrays = [field_vals, np.ones(n_theta), np.ones(n_phi)]
        input_tn = pytens.tt_rank1(indices, arrays)

        # 3. Get and apply operator
        out_indices = Indices.from_config(mock_config_1d)
        op = jiang_stencil_1d.get_ttop(out_indices, scale=1.0)
        result_array = (
            op([input_tn], spatial_vars=spatial_vars).evaluate().contract().value
        )

        # 4. Assert that the result is numerically stable (no NaNs or infs)
        assert np.all(np.isfinite(result_array))

    def test_stencil2d_operator_optically_thin(
        self, mock_config_2d, disc_2d, angle_params_2d
    ):
        """Verify 2D JiangStencil approaches UpwindStencil in thin limit."""
        # 1. Setup 2D problem with very low opacities
        nx, ny = disc_2d.grid.num_cells
        ngx = int(disc_2d.grid.num_ghost[0] / 2)
        ngy = int(disc_2d.grid.num_ghost[1] / 2)

        xc, yc = disc_2d.grid.cell_centers
        xx, yy = np.meshgrid(xc, yc, indexing="ij")
        field_interior = xx + yy

        field_vals = np.zeros((nx + 2 * ngx, ny + 2 * ngy))
        field_vals[ngx:-ngx, ngy:-ngy] = field_interior
        field_vals[:ngx, ngy:-ngy] = field_interior[0, :]
        field_vals[-ngx:, ngy:-ngy] = field_interior[-1, :]
        field_vals[:, :ngy] = field_vals[:, ngy : ngy + 1]
        field_vals[:, -ngy:] = field_vals[:, -ngy - 1 : -ngy]

        spatial_vars = {
            "absorption_opacity": np.full(field_vals.shape, 1e-8),
            "scattering_opacity": np.full(field_vals.shape, 1e-8),
        }

        # 2. Create input Tensor Network
        n_space_total = field_vals.size
        n_theta = mock_config_2d.angles.n_theta
        n_phi = mock_config_2d.angles.n_phi
        indices = [
            pytens.Index("x", n_space_total),
            pytens.Index("theta", n_theta),
            pytens.Index("phi", n_phi),
        ]
        arrays = [field_vals.flatten(), np.ones(n_theta), np.ones(n_phi)]
        input_tn = pytens.tt_rank1(indices, arrays)

        # 3. Get JiangStencil result
        jiang_stencil = JiangStencil(
            mock_config_2d.speed_of_light,
            *angle_params_2d,
            disc_2d,
            mock_config_2d,
        )
        out_indices = Indices.from_config(mock_config_2d)
        op_jiang = jiang_stencil.get_ttop(out_indices, scale=1.0)
        result_jiang = (
            op_jiang([input_tn], spatial_vars=spatial_vars).evaluate().contract().value
        )

        # 4. Get UpwindStencil result
        upwind_stencil = UpwindStencil(
            mock_config_2d.speed_of_light,
            *angle_params_2d,
            disc_2d,
            mock_config_2d,
        )
        op_upwind = upwind_stencil.get_ttop(out_indices, scale=1.0)
        result_upwind = (
            op_upwind([input_tn], spatial_vars={}).evaluate().contract().value
        )

        # 5. Assert results are close
        np.testing.assert_allclose(result_jiang, result_upwind, rtol=1e-5, atol=1e-12)

    def test_stencil2d_operator_optically_thick(
        self, jiang_stencil_2d, mock_config_2d, disc_2d
    ):
        """Verify 2D JiangStencil is stable in the optically thick limit."""
        # 1. Setup 2D problem with very high opacities
        nx, ny = disc_2d.grid.num_cells
        ngx = int(disc_2d.grid.num_ghost[0] / 2)
        ngy = int(disc_2d.grid.num_ghost[1] / 2)

        xc, yc = disc_2d.grid.cell_centers
        xx, yy = np.meshgrid(xc, yc, indexing="ij")
        field_interior = xx + yy

        field_vals = np.zeros((nx + 2 * ngx, ny + 2 * ngy))
        field_vals[ngx:-ngx, ngy:-ngy] = field_interior
        field_vals[:ngx, ngy:-ngy] = field_interior[0, :]
        field_vals[-ngx:, ngy:-ngy] = field_interior[-1, :]
        field_vals[:, :ngy] = field_vals[:, ngy : ngy + 1]
        field_vals[:, -ngy:] = field_vals[:, -ngy - 1 : -ngy]

        spatial_vars = {
            "absorption_opacity": np.full(field_vals.shape, 1e8),
            "scattering_opacity": np.full(field_vals.shape, 1e8),
        }

        # 2. Create input Tensor Network
        n_space_total = field_vals.size
        n_theta = mock_config_2d.angles.n_theta
        n_phi = mock_config_2d.angles.n_phi
        indices = [
            pytens.Index("x", n_space_total),
            pytens.Index("theta", n_theta),
            pytens.Index("phi", n_phi),
        ]
        arrays = [field_vals.flatten(), np.ones(n_theta), np.ones(n_phi)]
        input_tn = pytens.tt_rank1(indices, arrays)

        # 3. Apply operator
        out_indices = Indices.from_config(mock_config_2d)
        op = jiang_stencil_2d.get_ttop(out_indices, scale=1.0)
        result_array = (
            op([input_tn], spatial_vars=spatial_vars).evaluate().contract().value
        )

        # 4. Assert that the result is numerically stable
        assert np.all(np.isfinite(result_array))
