from unittest.mock import Mock

import numpy as np
import pytest

from pytens_radtrans.bcs import Dirichlet, Outflow, Periodic
from pytens_radtrans.discretization import Discretization
from pytens_radtrans.domain_decomp import Direction

mock_disc_1d = Mock(spec=Discretization)
mock_disc_1d.dimension = 1
mock_disc_2d = Mock(spec=Discretization)
mock_disc_2d.dimension = 2


def test_dirichlet_condition_scalar():
    """Tests that the Dirichlet condition returns its scalar value."""
    condition = Dirichlet(value=5.0)
    # The other arguments are not used by this simple condition
    result = condition.get_value(
        arr=np.array([]), side=Direction.WEST, disc=mock_disc_1d
    )
    assert result == 5.0


def test_dirichlet_condition_array():
    """Tests that the Dirichlet condition returns its array value."""
    bc_array = np.array([1.0, 2.0, 3.0])
    condition = Dirichlet(value=bc_array)
    result = condition.get_value(
        arr=np.array([]), side=Direction.WEST, disc=mock_disc_1d
    )
    np.testing.assert_array_equal(result, bc_array)


@pytest.mark.parametrize(
    "side, expected_slice",
    [
        (Direction.WEST, 0),
        (Direction.EAST, -1),
    ],
)
def test_outflow_condition_1d(side, expected_slice):
    """Tests the Outflow condition for a 1D array."""
    arr = np.array([10, 20, 30, 40])
    condition = Outflow()
    result = condition.get_value(arr=arr, side=side, disc=mock_disc_1d)
    assert result == arr[expected_slice]


def test_outflow_condition_2d():
    """Tests the Outflow condition for a 2D array."""
    arr = np.array([[1, 2, 3], [4, 5, 6], [7, 8, 9]])
    condition = Outflow()

    # West boundary
    west_val = condition.get_value(arr=arr, side=Direction.WEST, disc=mock_disc_2d)
    np.testing.assert_array_equal(west_val, arr[0])

    # East boundary
    east_val = condition.get_value(arr=arr, side=Direction.EAST, disc=mock_disc_2d)
    np.testing.assert_array_equal(east_val, arr[-1])

    # South boundary
    south_val = condition.get_value(arr=arr, side=Direction.SOUTH, disc=mock_disc_2d)
    np.testing.assert_array_equal(south_val, arr[:, 0])

    # North boundary
    north_val = condition.get_value(arr=arr, side=Direction.NORTH, disc=mock_disc_2d)
    np.testing.assert_array_equal(north_val, arr[:, -1])


@pytest.mark.parametrize(
    "side, expected_slice",
    [
        (Direction.WEST, -1),  # gets from EAST
        (Direction.EAST, 0),  # gets from WEST
    ],
)
def test_periodic_condition_1d(side, expected_slice):
    """Tests the Periodic condition for a 1D array."""
    arr = np.array([10, 20, 30, 40])
    condition = Periodic()
    result = condition.get_value(arr=arr, side=side, disc=mock_disc_1d)
    assert result == arr[expected_slice]


def test_periodic_condition_2d():
    """Tests the Periodic condition for a 2D array."""
    arr = np.array([[1, 2, 3], [4, 5, 6], [7, 8, 9]])
    condition = Periodic()

    # West boundary
    west_val = condition.get_value(arr=arr, side=Direction.WEST, disc=mock_disc_2d)
    np.testing.assert_array_equal(west_val, arr[-1])  # Gets from EAST

    # East boundary
    east_val = condition.get_value(arr=arr, side=Direction.EAST, disc=mock_disc_2d)
    np.testing.assert_array_equal(east_val, arr[0])  # Gets from WEST

    # South boundary
    south_val = condition.get_value(arr=arr, side=Direction.SOUTH, disc=mock_disc_2d)
    np.testing.assert_array_equal(south_val, arr[:, -1])  # Gets from NORTH

    # North boundary
    north_val = condition.get_value(arr=arr, side=Direction.NORTH, disc=mock_disc_2d)
    np.testing.assert_array_equal(north_val, arr[:, 0])  # Gets from SOUTH
