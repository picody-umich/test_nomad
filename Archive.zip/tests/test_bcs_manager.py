import itertools
from unittest.mock import MagicMock, patch

import numpy as np
import pytens
import pytest

from pytens_radtrans import utils
from pytens_radtrans.bcs import BoundaryConditions, Dirichlet, Outflow, Periodic
from pytens_radtrans.discretization import Discretization
from pytens_radtrans.discretization import Indices as DiscIndices
from pytens_radtrans.load_config import Config
from pytens_radtrans.types import Direction


@pytest.fixture
def mock_config() -> Config:
    """A mock configuration object."""
    config = MagicMock()
    config.solver.order = ["x", "theta", "phi"]
    return config


@pytest.fixture
def disc_1d() -> Discretization:
    """A 1D Discretization fixture."""
    return Discretization.from_geom(lb=[0.0], ub=[1.0], n=[4], num_ghost=[2])


@pytest.fixture
def disc_2d() -> Discretization:
    """A 2D Discretization fixture."""
    return Discretization.from_geom(
        lb=[0.0, 0.0], ub=[1.0, 1.0], n=[2, 3], num_ghost=[2, 2]
    )


def test_add_bc_ghost_to_core_1d(disc_1d: Discretization, mock_config: Config) -> None:
    """Tests non-Dirichlet BC application on a 1D array."""
    bounds = [Direction.WEST, Direction.EAST]
    bcs = BoundaryConditions(disc_1d, mock_config, bounds)
    bcs.add_condition(Direction.WEST, Periodic())
    bcs.add_condition(Direction.EAST, Outflow())

    # Reshape to (nx, 1) to match expectation of an extra non-spatial dimension
    arr = np.array([10.0, 20.0, 30.0, 40.0])[:, np.newaxis]
    result = bcs.add_bc_ghost_to_core(arr)

    # Expected: [periodic_west, interior..., outflow_east]
    # West ghost gets value from far East (40.0)
    # East ghost gets value from adjacent East (40.0)
    expected = np.array([40.0, 10.0, 20.0, 30.0, 40.0, 40.0])[:, np.newaxis]
    np.testing.assert_array_equal(result, expected)


def test_add_bc_ghost_to_core_2d(disc_2d: Discretization, mock_config: Config) -> None:
    """Tests non-Dirichlet BC application on a 2D array."""
    bounds = [Direction.WEST, Direction.EAST, Direction.SOUTH, Direction.NORTH]
    bcs = BoundaryConditions(disc_2d, mock_config, bounds)
    bcs.add_condition(Direction.WEST, Outflow())
    bcs.add_condition(Direction.EAST, Periodic())
    bcs.add_condition(Direction.SOUTH, Periodic())
    bcs.add_condition(Direction.NORTH, Outflow())

    # Reshape to (nx, ny, 1) to match expectation of an extra non-spatial dimension
    arr = np.array([[1, 2, 3], [4, 5, 6]])[..., np.newaxis]
    result = bcs.add_bc_ghost_to_core(arr)

    # Interior is shape (2,3,1), with 1 ghost on each side -> (4,5,1)
    expected = np.zeros((4, 5, 1))
    expected[1:3, 1:4, :] = arr
    expected[0, 1:4, :] = arr[0, :, :]  # West Outflow
    expected[3, 1:4, :] = arr[0, :, :]  # East Periodic (from West)
    expected[1:3, 0, :] = arr[:, -1, :]  # South Periodic (from North)
    expected[1:3, 4, :] = arr[:, -1, :]  # North Outflow

    np.testing.assert_array_equal(result, expected)


def test_dirichlet_op_2d(disc_2d: Discretization, mock_config: Config) -> None:
    """Tests construction of the 2D Dirichlet operator."""
    bounds = [Direction.WEST, Direction.NORTH]
    bcs = BoundaryConditions(disc_2d, mock_config, bounds)
    bcs.add_condition(Direction.WEST, Dirichlet(value=5.0))
    # Value for North/South must be a column vector for correct broadcasting
    bcs.add_condition(
        Direction.NORTH, Dirichlet(value=np.array([10.0, 11.0]).reshape(-1, 1))
    )

    result = bcs.dirichlet_op()

    # Interior shape (2,3), with 1 ghost on each side -> (4,5)
    expected = np.zeros((4, 5))
    expected[0, 1:4] = 5.0  # West boundary
    expected[1:3, 4] = np.array([10.0, 11.0])  # North boundary

    np.testing.assert_array_equal(result, expected)


def test_dirichlet_op_empty(disc_1d: Discretization, mock_config: Config) -> None:
    """Tests that the Dirichlet operator is empty if no Dirichlet BCs exist."""
    bcs = BoundaryConditions(disc_1d, mock_config, [Direction.WEST])
    bcs.add_condition(Direction.WEST, Outflow())  # No Dirichlet BC
    result = bcs.dirichlet_op()
    assert result.size == 0


def test_add_and_fill_spatial_core_ghost_cells(
    disc_1d: Discretization, mock_config: Config
) -> None:
    """Tests adding ghost cells to a tensor core and idempotency."""
    bounds = [Direction.WEST, Direction.EAST]
    bcs = BoundaryConditions(disc_1d, mock_config, bounds)
    bcs.add_condition(Direction.WEST, Periodic())

    # Create a simple rank-1 tensor network matching the mock config
    inds = [
        pytens.Index(size=4, name="x"),
        pytens.Index(size=2, name="theta"),
        pytens.Index(size=1, name="phi"),
    ]
    vals = [np.arange(4, dtype=float), np.ones(2), np.ones(1)]
    tens = pytens.tt_rank1(inds, vals)

    # Action
    result_tens = bcs.add_and_fill_in_spatial_core_ghost_cells(tens)

    # Assertions for the first call
    new_spatial_core = result_tens.node_tensor(0).value
    assert new_spatial_core.shape[0] == 6  # 4 interior + 2 ghost
    # West ghost gets value from far East (3.0)
    expected_vals = np.array([3.0, 0.0, 1.0, 2.0, 3.0, 0.0]).reshape(6, 1)
    np.testing.assert_array_equal(new_spatial_core, expected_vals)

    # Test idempotency
    result_after_second_call = bcs.add_and_fill_in_spatial_core_ghost_cells(result_tens)
    np.testing.assert_array_equal(
        result_after_second_call.node_tensor(0).value, new_spatial_core
    )


@patch("pytens_radtrans.bcs.BoundaryConditions.dirichlet_op")
def test_get_dirichlet_op(
    mock_dirichlet_op: MagicMock, disc_1d: Discretization, mock_config: Config
) -> None:
    """Tests wrapping the Dirichlet operator into a tensor network."""
    mock_dirichlet_op.return_value = np.array([5.0, 0.0, 0.0, 0.0, 0.0, 5.0])
    bcs = BoundaryConditions(disc_1d, mock_config, [])

    ind_space = pytens.Index(name="x", size=4)
    ind_theta = pytens.Index(name="theta", size=2)
    ind_phi = pytens.Index(name="phi", size=1)
    indices = DiscIndices(dimension=1, space=ind_space, theta=ind_theta, phi=ind_phi)

    result_tn = bcs.get_dirichlet_op(indices)

    assert result_tn is not None
    assert all(r == 1 for r in result_tn.ranks())
    spatial_core = result_tn.node_tensor(0).value.flatten()
    np.testing.assert_array_equal(spatial_core, mock_dirichlet_op.return_value)
    # Check that other cores are ones
    np.testing.assert_array_equal(result_tn.node_tensor(1).value.flatten(), np.ones(2))


@patch("pytens_radtrans.bcs.BoundaryConditions.dirichlet_op")
def test_get_dirichlet_op_none(
    mock_dirichlet_op: MagicMock, disc_1d: Discretization, mock_config: Config
) -> None:
    """Tests that get_dirichlet_op returns None when the operator is empty."""
    mock_dirichlet_op.return_value = np.array([])
    bcs = BoundaryConditions(disc_1d, mock_config, [])
    indices = MagicMock(spec=DiscIndices)

    result = bcs.get_dirichlet_op(indices)
    assert result is None


@pytest.mark.parametrize(
    "order",
    list(itertools.permutations(["x", "theta", "phi"])),
    ids=lambda o: "-".join(o),
)
def test_add_and_fill_spatial_core_ghost_cells_any_order(
    disc_1d: Discretization, order
) -> None:
    """Verify ghost-cell insertion is correct for any tensor index order."""
    config = MagicMock()
    config.solver.order = list(order)

    bounds = [Direction.WEST, Direction.EAST]
    bcs = BoundaryConditions(disc_1d, config, bounds)
    bcs.add_condition(Direction.WEST, Periodic())

    indices = [
        pytens.Index(size=4, name="x"),
        pytens.Index(size=2, name="theta"),
        pytens.Index(size=1, name="phi"),
    ]
    arrays = [np.arange(4, dtype=float), np.ones(2), np.ones(1)]

    permut, inv_permut = utils.encode_order(list(order))
    tn_in = pytens.tt_rank1(
        utils.reorder_list(indices, permut),
        utils.reorder_list(arrays, permut),
    )

    result_tn = bcs.add_and_fill_in_spatial_core_ghost_cells(tn_in)
    result_array = result_tn.contract().value

    canonical_sizes = [6, 2, 1]
    reshaped = result_array.reshape(utils.reorder_list(canonical_sizes, permut))
    result_canonical = reshaped.transpose(inv_permut)

    expected_space = np.array([3.0, 0.0, 1.0, 2.0, 3.0, 0.0])
    expected_array = np.kron(expected_space, np.kron(np.ones(2), np.ones(1))).reshape(
        6, 2, 1
    )

    np.testing.assert_array_equal(result_canonical, expected_array)


@pytest.mark.parametrize(
    "order",
    list(itertools.permutations(["x", "theta", "phi"])),
    ids=lambda o: "-".join(o),
)
def test_get_dirichlet_op_any_order(disc_1d: Discretization, order) -> None:
    """Verify get_dirichlet_op builds the same tensor for any index order."""
    config = MagicMock()
    config.solver.order = list(order)

    bcs = BoundaryConditions(disc_1d, config, [Direction.WEST, Direction.EAST])
    bcs.add_condition(Direction.WEST, Dirichlet(value=5.0))
    bcs.add_condition(Direction.EAST, Dirichlet(value=7.0))

    indices = DiscIndices(
        dimension=1,
        space=pytens.Index(name="x", size=4),
        theta=pytens.Index(name="theta", size=2),
        phi=pytens.Index(name="phi", size=1),
    )

    result_tn = bcs.get_dirichlet_op(indices)
    assert result_tn is not None

    permut, inv_permut = utils.encode_order(list(order))
    result_array = result_tn.contract().value
    canonical_sizes = [6, 2, 1]
    reshaped = result_array.reshape(utils.reorder_list(canonical_sizes, permut))
    result_canonical = reshaped.transpose(inv_permut)

    expected_space = np.array([5.0, 0.0, 0.0, 0.0, 0.0, 7.0])
    expected_array = np.kron(expected_space, np.kron(np.ones(2), np.ones(1))).reshape(
        6, 2, 1
    )

    np.testing.assert_array_equal(result_canonical, expected_array)
