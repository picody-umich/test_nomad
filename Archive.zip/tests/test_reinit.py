"""Tests for the re-initialization capability."""

import logging

import numpy as np

from pytens_radtrans import main_loop_utils
from pytens_radtrans.load_config import (
    Angles,
    Config,
    Equations,
    GaussianDiffusion,
    Geometry,
    NoSource,
    Rounding,
    Saving,
    Solver,
    UpwindStencil,
)

# Configure a basic logger for tests
logging.basicConfig(level=logging.INFO)
logger = logging.getLogger("test_reinit")


def create_config() -> Config:
    """Creates a minimal valid config for testing."""
    return Config(
        geometry=Geometry(
            dimension=1,
            lb=[0.0],
            ub=[1.0],
            n=[10],
            n_ghost=[2],
        ),
        angles=Angles(n_theta=2, n_phi=2),
        solver=Solver(
            num_steps=5,
            cfl=0.5,
            method="forward euler",
            stencil=UpwindStencil(name="upwind"),
            # Disable tt_sum for SVD rounding as it is not implemented
            rounding=Rounding(method="svd", tol=1e-8, freq=1, tt_sum=False),
            order=["x", "theta", "phi"],
        ),
        equations=Equations(
            speed_of_light=1.0,
            specific_absorption_opacity=0.0,
            specific_scattering_opacity=1.0,
            density=1.0,
            source=NoSource(name="none"),
        ),
        problem=GaussianDiffusion(name="gaussian diffusion", A=1.0, t0=0.1),
        saving=Saving(directory="."),
    )


def test_rebuild_topology_operators_stability():
    """
    Test that calling rebuild_topology_operators mid-simulation
    does not crash and preserves simulation continuity.
    """
    config = create_config()

    # 1. Initialize Simulation normally
    # This implicitly tests that initialize_simulation calls
    # rebuild_topology_operators correctly.
    init_data = main_loop_utils.initialize_simulation(config, logger)

    # 2. Run a few steps to change the state
    for ii in range(1, 3):
        updates = main_loop_utils.perform_halo_exchange(
            init_data, main_loop_utils.comm, logger
        )
        init_data.local_sol = main_loop_utils.advance_local_solutions(
            config, updates, init_data, ii, logger
        )
        init_data.time += init_data.dt

    # Capture state before rebuild
    # (In a real AMR scenario, the domain_manager would change here)

    # 3. Trigger Rebuild (The "Re-Init")
    # We pass the *existing* topology and state to verify stability
    (
        local_bc,
        local_bc_dirichlet,
        local_rhs,
        local_flux_calculators,
        pack_ops,
        reconstruct_ops,
        receive_plans,
    ) = main_loop_utils.rebuild_topology_operators(
        config,
        init_data.problem,
        init_data.domain_manager,
        init_data.local_indices,
        init_data.dt,
        init_data.dimension,
        init_data.permut,
        init_data.inv_permut,
        logger,
    )

    # Update init_data with "new" operators
    init_data.local_bc = local_bc
    init_data.local_bc_dirichlet = local_bc_dirichlet
    init_data.local_rhs = local_rhs
    init_data.local_flux_calculators = local_flux_calculators
    init_data.pack_ops_by_leaf = pack_ops
    init_data.reconstruct_ops_by_leaf = reconstruct_ops
    init_data.receive_plans_by_leaf = receive_plans

    # 4. Run more steps to ensure the new operators work
    for ii in range(3, 6):
        updates = main_loop_utils.perform_halo_exchange(
            init_data, main_loop_utils.comm, logger
        )
        init_data.local_sol = main_loop_utils.advance_local_solutions(
            config, updates, init_data, ii, logger
        )
        init_data.time += init_data.dt

    # 5. Assertions
    # Check that solution is valid (not NaN)
    for sol in init_data.local_sol:
        assert not np.any(np.isnan(sol.space["absorption_opacity"]))

    # Check that time advanced correctly
    assert init_data.time > 0.0
    # Check that we have solutions
    assert len(init_data.local_sol) > 0
