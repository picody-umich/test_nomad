import unittest
from unittest.mock import MagicMock, patch

import numpy as np

from pytens_radtrans import utils
from pytens_radtrans.load_config import Rounding


class TestUtils(unittest.TestCase):
    def test_num_parameters(self):
        class TN:
            def cost(self):
                return 123

        self.assertEqual(utils.num_parameters(TN()), 123)

    def test_reorder_list(self):
        lst = ["a", "b", "c", "d"]
        order = [3, 0, 1, 2]
        expected = ["d", "a", "b", "c"]
        self.assertEqual(utils.reorder_list(lst, order), expected)

    def test_encode_order(self):
        # Default: x=0, theta=1, phi=2
        # New order: phi, x, theta -> 2, 0, 1
        new_order = ["phi", "x", "theta"]
        permut, inv_permut = utils.encode_order(new_order)

        self.assertEqual(permut, [2, 0, 1])
        # Inverse: 0 is at index 1, 1 is at index 2, 2 is at index 0 -> [1, 2, 0]
        self.assertEqual(inv_permut, [1, 2, 0])

    def test_flatten_list_simple(self):
        # Test simple flattening
        nested = [[1, 2], [3, 4], [5]]
        expected = [1, 2, 3, 4, 5]
        result = utils.flatten_list(nested)
        self.assertEqual(result, expected)

    def test_flatten_list_mixed(self):
        nested = [[1, 2], 3, [4, [5, 6]]]
        expected = [1, 2, 3, 4, 5, 6]
        result = utils.flatten_list(nested)
        self.assertEqual(result, expected)

    def test_quartic_solve(self):
        # Solve c4 * T^4 + T + c0 = 0
        # Let T = 2. c4 = 1.
        # 1 * 16 + 2 + c0 = 0 => c0 = -18
        c4 = np.array([1.0])
        c0 = np.array([-18.0])
        roots = utils.quartic_solve(c4, c0)
        np.testing.assert_allclose(roots, [2.0], rtol=1e-5)

        # Vectorized test
        # Case 1: T=1, c4=1 => 1+1+c0=0 => c0=-2
        # Case 2: T=2, c4=0.5 => 0.5*16 + 2 + c0 = 0 => 8+2+c0=0 => c0=-10
        c4 = np.array([1.0, 0.5])
        c0 = np.array([-2.0, -10.0])
        roots = utils.quartic_solve(c4, c0)
        np.testing.assert_allclose(roots, [1.0, 2.0], rtol=1e-5)

    def test_apply_func_to_core_2d(self):
        # Test applying function to a 2D core (first or last core)
        # Core shape (n, r)
        core = np.ones((3, 4))

        # Dummy function that adds 1 to the core
        def func(c):
            return c + 1

        # core_num = 0 (first core)
        wrapped = utils.apply_func_to_core(func, core_num=0)
        res = wrapped(core)
        np.testing.assert_array_equal(res, core + 1)

        # core_num = -1 (last core, treated as transposed in logic?)
        # The logic for last core: f(*args, core.T).T
        wrapped_last = utils.apply_func_to_core(func, core_num=1)  # non-zero
        # If core is (3,4), core.T is (4,3). func returns (4,3). result.T is (3,4).
        res_last = wrapped_last(core)
        np.testing.assert_array_equal(res_last, core + 1)

    def test_apply_func_to_core_3d(self):
        # Test applying function to a 3D core (middle core)
        # Core shape (r1, n, r2)
        core = np.zeros((2, 3, 4))

        # Function expects (n, -1)
        def func(c):
            # c shape should be (3, 2*4) = (3, 8)
            self.assertEqual(c.shape, (3, 8))
            return c + 1

        wrapped = utils.apply_func_to_core(func, core_num=1)
        res = wrapped(core)

        self.assertEqual(res.shape, (2, 3, 4))
        np.testing.assert_array_equal(res, core + 1)

    @patch("pytens_radtrans.utils.pytens")
    def test_tt_classes(self, mock_pytens):
        # Mock TensorNetwork
        mock_tn = MagicMock()

        # Test TT
        tt_obj = utils.TT(mock_tn)
        self.assertEqual(tt_obj.evaluate(), mock_tn)
        self.assertEqual(tt_obj.evaluate_to_list(), [mock_tn])

        # Test TNOPList
        tnop_list = utils.TNOPList([tt_obj])
        tnop_list.append(tt_obj)

        # Mock tt_sum
        mock_pytens.tt_sum.return_value = "summed_tn"
        self.assertEqual(tnop_list.evaluate(), "summed_tn")
        mock_pytens.tt_sum.assert_called_with([mock_tn, mock_tn])

    @patch("pytens_radtrans.utils.pytens")
    def test_tnoplist_rounding(self, mock_pytens):
        mock_tn = MagicMock()
        tt_obj = utils.TT(mock_tn)
        tnop_list = utils.TNOPList([tt_obj])

        # Mock Rounding config
        rounding_opts = MagicMock(spec=Rounding)
        rounding_opts.method = "svd"
        rounding_opts.tt_sum = False
        rounding_opts.tol = 1e-5

        mock_pytens.tt_svd_round.return_value = "rounded_tn"

        res = tnop_list.evaluate_round(rounding_opts, [])
        self.assertEqual(res, "rounded_tn")
        mock_pytens.tt_svd_round.assert_called()
