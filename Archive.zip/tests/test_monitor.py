"""Tests for monitor.py."""

import pathlib
from unittest.mock import MagicMock, mock_open, patch

import numpy as np
import pytest
from matplotlib.figure import Figure

# Configure the MPI mock *before* importing monitor.
# This ensures that when monitor.py runs `rank = comm.Get_rank()`,
# it gets an integer (0), not a MagicMock object.
mock_mpi = MagicMock()
mock_mpi.COMM_WORLD.Get_rank.return_value = 0
mock_mpi.COMM_WORLD.Get_size.return_value = 1

with patch.dict("sys.modules", {"mpi4py": mock_mpi, "mpi4py.MPI": mock_mpi}):
    from pytens_radtrans import monitor
    from pytens_radtrans.domain_decomp import DomainManager
    from pytens_radtrans.problems import Problem
    from pytens_radtrans.solver import Solution


@pytest.fixture
def mock_domain_manager():
    """Creates a mock DomainManager."""
    dm = MagicMock(spec=DomainManager)
    dm.leaves = []
    # Mock leaves for compression plotting
    for _ in range(2):
        leaf = MagicMock()
        leaf.disc.grid.num_cells = [10, 10]
        dm.leaves.append(leaf)

    # Mock angles
    angles = MagicMock()
    angles.theta = np.zeros(4)
    angles.phi = np.zeros(4)
    dm.domain_angles = angles
    return dm


@pytest.fixture
def mock_problem():
    """Creates a mock Problem."""
    prob = MagicMock(spec=Problem)
    prob.indices = MagicMock()
    prob.config = MagicMock()
    prob.config.solver.order = ["x", "theta", "phi"]
    return prob


@pytest.fixture
def mock_solution():
    """Creates a mock Solution object."""
    sol = MagicMock(spec=Solution)
    sol.time = 1.0
    sol.intensity = MagicMock()
    sol.intensity.ranks.return_value = [5, 5]
    sol.space = {"temp": np.array([1.0, 2.0])}
    sol.aux = {}
    return sol


@pytest.fixture
def monitor_instance(mock_domain_manager, mock_problem):
    """Creates a Monitor instance with mocked dependencies."""
    # We don't need to patch rank here because the sys.modules patch
    # handled the module-level initialization.
    mon = monitor.Monitor(
        domain_manager=mock_domain_manager,
        problem=mock_problem,
        local_leaf_indices=[0, 1],
    )
    return mon


class TestMonitor:
    """Tests for the Monitor class."""

    def test_init(self, monitor_instance):
        """Test initialization."""
        assert monitor_instance.sol == []
        assert monitor_instance.time == []
        assert monitor_instance.ranks == []
        assert monitor_instance.local_leaf_indices == [0, 1]

    def test_add_solution(self, monitor_instance, mock_solution):
        """Test adding a solution."""
        sol_list = [mock_solution, mock_solution]
        time = 0.1

        monitor_instance.add_solution(sol_list, time)

        assert len(monitor_instance.sol) == 1
        assert len(monitor_instance.time) == 1
        assert len(monitor_instance.ranks) == 1
        assert monitor_instance.sol[0] == sol_list
        assert monitor_instance.time[0] == time
        # Check ranks were extracted
        assert monitor_instance.ranks[0] == [[5, 5], [5, 5]]

    def test_get_last_sol(self, monitor_instance, mock_solution):
        """Test retrieving the last solution."""
        sol_list = [mock_solution]
        monitor_instance.add_solution(sol_list, 0.1)
        assert monitor_instance.get_last_sol() == sol_list

    def test_del_prev_sol(self, monitor_instance):
        """Test deleting previous solution data."""
        # Create two distinct solution objects with mocked intensity for ranks() call
        sol1 = MagicMock(spec=Solution)
        sol1.intensity = MagicMock()
        sol1.intensity.ranks.return_value = [1, 1]
        sol1.space = "space1"

        sol2 = MagicMock(spec=Solution)
        sol2.intensity = MagicMock()
        sol2.intensity.ranks.return_value = [1, 1]
        sol2.space = "space2"

        # Add two time steps
        monitor_instance.add_solution([sol1], 0.1)
        monitor_instance.add_solution([sol2], 0.2)

        assert len(monitor_instance.sol) == 2

        # Action
        monitor_instance.del_prev_sol()

        # Verification: sol[-2] (sol1) should have attributes deleted
        with pytest.raises(AttributeError):
            _ = sol1.intensity
        with pytest.raises(AttributeError):
            _ = sol1.space

        # sol[-1] (sol2) should be untouched
        assert sol2.space == "space2"

    def test_compute_aux_last_sol(self, monitor_instance):
        """Test computing auxiliary variables."""
        # Create two DISTINCT mock solutions with required attributes
        sol1 = MagicMock(spec=Solution)
        sol1.intensity = MagicMock()
        sol1.intensity.ranks.return_value = [1, 1]
        sol1.aux = {}

        sol2 = MagicMock(spec=Solution)
        sol2.intensity = MagicMock()
        sol2.intensity.ranks.return_value = [1, 1]
        sol2.aux = {}

        # Use patch.object on the imported module reference
        with patch.object(monitor.solver, "mean_intensity") as mock_mean_int:
            mock_mean_int.return_value = np.array([0.5])

            monitor_instance.add_solution([sol1, sol2], 0.1)
            monitor_instance.compute_aux_last_sol()

            # Verify solver.mean_intensity was called for each local leaf
            assert mock_mean_int.call_count == 2
            assert sol1.aux["mean_intensity"] is not None
            assert sol2.aux["mean_intensity"] is not None

    def test_save_checkpoint_rank_0(self, monitor_instance, mock_solution):
        """Test saving checkpoint on rank 0."""
        monitor_instance.add_solution([mock_solution, mock_solution], 0.1)
        save_dir = pathlib.Path("/tmp/test")

        # Set rank directly on the instance
        monitor_instance.rank = 0

        # Patch open ONLY during the call to avoid messing up imports
        m_open = mock_open()
        with patch("builtins.open", m_open):
            with patch("pickle.dump") as mock_pickle:
                monitor_instance.save_checkpoint(save_dir, iteration=1)

                # Verify domain manager pickle dump (only on rank 0)
                assert m_open.call_count >= 1
                assert mock_pickle.call_count >= 1
                assert (
                    mock_pickle.call_args_list[0][0][0]
                    == monitor_instance.domain_manager
                )

        # Verify solution save calls
        assert mock_solution.save.call_count == 2

    def test_save_checkpoint_rank_1(self, monitor_instance, mock_solution):
        """Test saving checkpoint on rank 1 (should not save DM)."""
        monitor_instance.add_solution([mock_solution, mock_solution], 0.1)
        save_dir = pathlib.Path("/tmp/test")

        # Set rank directly on the instance
        monitor_instance.rank = 1

        m_open = mock_open()
        with patch("builtins.open", m_open):
            with patch("pickle.dump") as mock_pickle:
                monitor_instance.save_checkpoint(save_dir, iteration=1)

                # Verify NO domain manager pickle dump
                assert mock_pickle.call_count == 0

        # Verify solution save calls still happen
        assert mock_solution.save.call_count == 2

    @patch("numpy.savez")
    def test_save_datafiles(self, mock_savez, monitor_instance, mock_solution):
        """Test saving data files."""
        # Setup solution with aux data
        mock_solution.aux = {"mean_intensity": np.array([1.0])}
        monitor_instance.add_solution([mock_solution, mock_solution], 0.1)

        save_dir = pathlib.Path("/tmp/test")

        # Mock compute_aux_last_sol to avoid external calls
        with patch.object(monitor_instance, "compute_aux_last_sol") as mock_compute:
            monitor_instance.save_datafiles(save_dir, iteration=5)
            mock_compute.assert_called_once()

        # Expect 2 calls per local leaf (one for space vars, one for discretization)
        # Total 2 leaves * 2 calls = 4 calls
        assert mock_savez.call_count == 4

        # Check arguments for one call
        args, kwargs = mock_savez.call_args_list[0]
        assert "space_vars" in str(args[0])
        assert "mean_intensity" in kwargs
        assert "temp" in kwargs  # from mock_solution.space

    def test_plot_last_sol(self, monitor_instance):
        """Test plotting delegation."""
        save_dir = pathlib.Path("/tmp/test")
        global_plot_data = ["data"]

        # Mock problem plotting methods
        monitor_instance.problem.plot_per_step_overlay.return_value = MagicMock(
            spec=Figure
        )

        fig = monitor_instance.plot_last_sol(
            global_plot_data, time=0.5, save_dir=save_dir, iteration=10
        )

        monitor_instance.problem.plot_per_step_overlay.assert_called_once()
        monitor_instance.problem.plot_per_step.assert_called_once()
        assert isinstance(fig, Figure)

    def test_plot_ranks_compressions(self, monitor_instance):
        """Test rank compression plotting."""
        # Setup data: global_ranks_history [time][leaf] -> rank_list
        # 2 timesteps, 2 leaves. Rank list must be 2 elements (internal ranks)
        # for 3-core system
        global_ranks_history = [
            [[5, 5], [6, 6]],  # Time 0
            [[5, 5], [7, 7]],  # Time 1
        ]

        logger = MagicMock()
        filename = pathlib.Path("ranks.png")

        # Use patch.object on the imported plt reference
        with patch.object(monitor.plt, "subplots") as mock_subplots:
            with patch.object(monitor.plt, "savefig") as mock_savefig:
                mock_fig = MagicMock(spec=Figure)
                mock_ax1 = MagicMock()
                mock_ax2 = MagicMock()

                # Configure mocks to return empty lists for legend handles/labels
                # This fixes the "not enough values to unpack" error
                mock_ax1.get_legend_handles_labels.return_value = ([], [])
                mock_ax2.get_legend_handles_labels.return_value = ([], [])

                # Also configure the twinx() call to return a mock axis that
                # behaves similarly
                mock_ax2_twin = MagicMock()
                mock_ax2_twin.get_legend_handles_labels.return_value = ([], [])
                mock_ax1.twinx.return_value = mock_ax2_twin
                # Note: The code calls twinx() on axs[1], which is mock_ax2
                mock_ax2.twinx.return_value = mock_ax2_twin

                # Create numpy array of objects explicitly to avoid iteration issues
                axs_array = np.empty(2, dtype=object)
                axs_array[0] = mock_ax1
                axs_array[1] = mock_ax2

                mock_subplots.return_value = (mock_fig, axs_array)

                monitor_instance.plot_ranks_compressions(
                    global_ranks_history, filename, logger
                )

                # Verify plotting calls
                assert mock_subplots.called
                assert mock_ax1.plot.called
                assert mock_ax2.semilogy.called
                mock_savefig.assert_called_with(filename)

    def test_plot_ranks_compressions_uses_full_spatial_size_and_sums_domains(
        self, monitor_instance
    ):
        """Compressed size should use flattened spatial x and sum all domains."""
        monitor_instance.problem.config.solver.order = ["x", "theta", "phi"]

        global_ranks_history = [
            [[1, 1], [2, 3]],  # one time step, two domains
        ]
        logger = MagicMock()
        filename = pathlib.Path("ranks.png")

        with patch.object(monitor.plt, "subplots") as mock_subplots:
            with patch.object(monitor.plt, "savefig"):
                mock_fig = MagicMock(spec=Figure)
                mock_ax0 = MagicMock()
                mock_ax1 = MagicMock()
                mock_ax0.get_legend_handles_labels.return_value = ([], [])
                mock_ax1.get_legend_handles_labels.return_value = ([], [])

                mock_ax1_twin = MagicMock()
                mock_ax1_twin.get_legend_handles_labels.return_value = ([], [])
                mock_ax1.twinx.return_value = mock_ax1_twin

                axs_array = np.empty(2, dtype=object)
                axs_array[0] = mock_ax0
                axs_array[1] = mock_ax1
                mock_subplots.return_value = (mock_fig, axs_array)

                monitor_instance.plot_ranks_compressions(
                    global_ranks_history, filename, logger
                )

                # semilogy #1 on twin axis is uncompressed total
                unc_args = mock_ax1_twin.semilogy.call_args_list[0][0]
                uncompressed = unc_args[0]
                assert float(uncompressed[0]) == 3200.0

                # semilogy #2 on twin axis is compressed total
                # domain 1: 1*100 + 1*1*4 + 1*4 = 108
                # domain 2: 2*100 + 2*3*4 + 3*4 = 236
                # total = 344
                comp_args = mock_ax1_twin.semilogy.call_args_list[1][0]
                compressed = comp_args[1]
                assert float(compressed[0]) == 344.0
