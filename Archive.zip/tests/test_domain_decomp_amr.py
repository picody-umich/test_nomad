"""Tests for Adaptive Mesh Refinement logic in DomainManager."""

import unittest
from unittest.mock import MagicMock

import numpy as np

from pytens_radtrans.bcs import BoundaryConditions
from pytens_radtrans.domain_decomp import DomainManager
from pytens_radtrans.load_config import Config


class TestAMRLogic(unittest.TestCase):
    """Test suite for AMR tree manipulation and balancing."""

    def setUp(self):
        """Set up a basic 1D configuration for testing."""
        # Create a minimal valid config
        self.config_dict = {
            "problem": {"name": "gaussian diffusion", "A": 1.0, "t0": 0.1},
            "geometry": {
                "dimension": 1,
                "lb": [0.0],
                "ub": [1.0],
                "n": [10],
                "n_ghost": [2],
                "domain_decomp": [1, [0, 0]],  # Start with 2 domains
            },
            "angles": {"n_theta": 2, "n_phi": 1},
            "solver": {
                "cfl": 0.5,
                "stencil": {"name": "upwind"},
                "method": "forward euler",
                "num_steps": 10,
                "rounding": {
                    "method": "svd",
                    "tol": 1e-5,
                    "freq": 1,
                    "tt_sum": True,
                    "rank_increase_bound": 10,
                },
                "order": ["x", "theta", "phi"],
            },
            "equations": {
                "speed_of_light": 1.0,
                "source": {"name": "none"},
            },
            "saving": {"directory": ".", "plot_freq": 10},
        }
        self.config = Config(**self.config_dict)

        # Mock Problem
        self.problem = MagicMock()
        # Mock get_bc to return empty BCs (no periodic)
        mock_bcs = MagicMock(spec=BoundaryConditions)
        mock_bcs.conditions = {}
        self.problem.get_bc.return_value = mock_bcs

        # Create initial manager
        self.manager = DomainManager.from_config(self.config, self.problem)

    def test_tree_depth_and_merge(self):
        """Test basic tree depth calculation and merge operation."""
        # Initial state: Root -> [Leaf0, Leaf1]
        # Depths should be 1
        leaves = self.manager.leaves
        self.assertEqual(len(leaves), 2)
        self.assertEqual(leaves[0].depth, 1)
        self.assertEqual(leaves[1].depth, 1)

        # Manually split leaf 0
        leaves[0].split()
        new_leaves = self.manager.domain_tree.get_leaves()
        # Now: Root -> [ [L0a, L0b], L1 ]
        # L0a depth = 2, L1 depth = 1
        self.assertEqual(new_leaves[0].depth, 2)
        self.assertEqual(new_leaves[-1].depth, 1)

        # Merge leaf 0's parent
        parent = new_leaves[0].parent
        parent.merge()
        final_leaves = self.manager.domain_tree.get_leaves()
        self.assertEqual(len(final_leaves), 2)
        self.assertEqual(final_leaves[0].depth, 1)

    def test_max_level_diff_calculation(self):
        """Test the calculation of max_level_diff."""
        # N=10, Ghost=2 -> Ratio=10 -> log2(10) = 3.32 -> floor = 3
        self.assertEqual(self.manager.max_level_diff, 3)

        # Change config to stricter ghost cells
        self.config.geometry.n_ghost = [4]
        # N=10, Ghost=4 -> Ratio=5 -> log2(5) = 2.32 -> floor = 2
        manager2 = DomainManager.from_config(self.config, self.problem)
        self.assertEqual(manager2.max_level_diff, 2)

    def test_refinement_simple(self):
        """Test simple refinement without ripple effects."""
        # Refine leaf 0. Current levels: [1, 1]. Target: [2, 1]. Diff=1 <= 3. OK.
        new_manager, lineage_map = self.manager.propose_refinement(
            [0], self.config, self.problem
        )
        self.assertEqual(len(new_manager.leaves), 3)  # 2 (from split) + 1 (original)
        depths = [leaf.depth for leaf in new_manager.leaves]
        self.assertEqual(depths, [2, 2, 1])

        # Check Map: Old 0 -> New [0, 1]
        self.assertIn(0, lineage_map)
        self.assertEqual(lineage_map[0], [0, 1])
        # Old 1 -> New [2] (shifted)
        self.assertIn(1, lineage_map)
        self.assertEqual(lineage_map[1], [2])

    def test_refinement_ripple_effect(self):
        """Test that refinement propagates to neighbors to maintain balance."""
        # Force a situation where max_diff is 1
        # N=4, Ghost=2 -> Ratio=4 -> log2(4)=2.
        # Wait, let's use N=2, Ghost=2 -> Ratio=2 -> log2(2)=1.
        self.config.geometry.n = [2]
        self.config.geometry.n_ghost = [2]
        manager = DomainManager.from_config(self.config, self.problem)
        self.assertEqual(manager.max_level_diff, 1)

        # Initial: [1, 1]
        # Refine leaf 0 -> [2, 2, 1]. Diff(2,1)=1. OK.
        manager, _ = manager.propose_refinement([0], self.config, self.problem)

        # Current leaves: [L0a(2), L0b(2), L1(1)]
        # Refine L0b (index 1). Target: [2, 3, 1].
        # Diff(3, 1) = 2 > 1. Violation!
        # L1 must refine to level 2.
        # Result should be: L0a(2), L0b_a(3), L0b_b(3), L1_a(2), L1_b(2)

        new_manager, lineage_map = manager.propose_refinement(
            [1], self.config, self.problem
        )

        depths = [leaf.depth for leaf in new_manager.leaves]
        # Expected: [2, 3, 3, 2, 2]
        self.assertEqual(depths, [2, 3, 3, 2, 2])

        # Check Map
        # Old 0 (L0a) -> New 0 (Unchanged)
        self.assertEqual(lineage_map[0], [0])
        # Old 1 (L0b) -> New [1, 2] (Split)
        self.assertEqual(lineage_map[1], [1, 2])
        # Old 2 (L1)  -> New [3, 4] (Forced Split)
        self.assertEqual(lineage_map[2], [3, 4])

    def test_coarsening_simple(self):
        """Test simple coarsening."""
        # First refine to get something to coarsen
        manager, _ = self.manager.propose_refinement([0], self.config, self.problem)
        # Leaves: [L0a, L0b, L1]

        # Coarsen L0a and L0b (indices 0 and 1)
        new_manager, lineage_map = manager.propose_coarsening(
            [0, 1], self.config, self.problem
        )
        self.assertEqual(len(new_manager.leaves), 2)
        depths = [leaf.depth for leaf in new_manager.leaves]
        self.assertEqual(depths, [1, 1])

        # Check Map
        # Old 0 -> New 0
        self.assertEqual(lineage_map[0], 0)
        # Old 1 -> New 0
        self.assertEqual(lineage_map[1], 0)
        # Old 2 -> New 1
        self.assertEqual(lineage_map[2], 1)

    def test_coarsening_missing_sibling(self):
        """Test that coarsening fails if a sibling is missing."""
        manager, _ = self.manager.propose_refinement([0], self.config, self.problem)
        # Leaves: [L0a, L0b, L1]

        # Try to coarsen only L0a
        new_manager, lineage_map = manager.propose_coarsening(
            [0], self.config, self.problem
        )

        # Should be unchanged
        self.assertEqual(len(new_manager.leaves), 3)

        # Map should be identity map of size 3
        self.assertEqual(len(lineage_map), 3)
        self.assertEqual(lineage_map[0], 0)
        self.assertEqual(lineage_map[1], 1)
        self.assertEqual(lineage_map[2], 2)

    def test_coarsening_balance_violation(self):
        """Test that coarsening is rejected if it violates balance."""
        # Setup: Use proper_nesting=True to force MaxDiff=1.
        # Use sufficient N to allow 3 levels of refinement (16 -> 8 -> 4 -> 2).
        self.config.geometry.n = [16]
        self.config.geometry.n_ghost = [2]
        self.config.refinement.proper_nesting = True
        manager = DomainManager.from_config(self.config, self.problem)

        # Initial: [L0(1), L1(1)]

        # Step 1: Refine L0 -> [L0a(2), L0b(2), L1(1)]
        manager, _ = manager.propose_refinement([0], self.config, self.problem)

        # Step 2: Refine L1 -> [L0a(2), L0b(2), L1a(2), L1b(2)]
        manager, _ = manager.propose_refinement([2], self.config, self.problem)

        # Step 3: Refine L0b -> [L0a(2), L0b_a(3), L0b_b(3), L1a(2), L1b(2)]
        # Neighbors of L0b: L0a(2) and L1a(2). Diff is 1. OK.
        manager, _ = manager.propose_refinement([1], self.config, self.problem)
        self.assertEqual(len(manager.leaves), 5)

        # Now try to coarsen L1a, L1b back to Level 1.
        # If L1 becomes Level 1, and L0b_b is Level 3.
        # L0b_b touches L1. Diff = 3 - 1 = 2 > 1.
        # Coarsening should be rejected.

        # Indices of L1a, L1b are 3, 4.
        new_manager, lineage_map = manager.propose_coarsening(
            [3, 4], self.config, self.problem
        )

        # Should be unchanged (5 leaves)
        self.assertEqual(len(new_manager.leaves), 5)
        self.assertEqual(new_manager.leaves[3].depth, 2)

        # Map should be identity map of size 5
        self.assertEqual(len(lineage_map), 5)
        for i in range(5):
            self.assertEqual(lineage_map[i], i)

    def test_proper_nesting_enforcement(self):
        """Test that proper_nesting=True forces 2:1 ratio even if ghosts allow more."""
        # Setup: N=10, Ghost=2 -> Ratio=10 -> log2(10)=3.
        # Normally this allows a level diff of 3.
        self.assertEqual(self.manager.get_max_level_diff(proper_nesting=False), 3)

        # Enable proper nesting
        self.config.refinement.proper_nesting = True
        self.assertEqual(self.manager.get_max_level_diff(proper_nesting=True), 1)

        # Refine leaf 0 -> Level 2. Neighbor is Level 1. Diff=1. OK.
        manager, _ = self.manager.propose_refinement([0], self.config, self.problem)

        # Refine leaf 0's child (L0a) -> Level 3.
        # Leaves: [L0a(2), L0b(2), L1(1)]
        # Refine L0a (index 0).
        # L0a neighbors: L0b(2). Diff 3-2=1. OK.
        # L0b neighbors: L0a(3), L1(1). Diff 3-2=1, 2-1=1. OK.
        # L1 is NOT a neighbor of L0a. So L1 is NOT forced to split.
        new_manager, _ = manager.propose_refinement([0], self.config, self.problem)

        depths = [leaf.depth for leaf in new_manager.leaves]
        # Expected: [L0a_a(3), L0a_b(3), L0b(2), L1(1)]
        self.assertEqual(depths, [3, 3, 2, 1])

    def test_neighbor_map_integrity(self):
        """Test that the neighbor map is correctly rebuilt after refinement."""
        # Initial: L0 <-> L1
        # Refine L0 -> L0a, L0b.
        # New Map:
        # L0a (West) <-> Boundary
        # L0a (East) <-> L0b
        # L0b (West) <-> L0a
        # L0b (East) <-> L1
        # L1 (West) <-> L0b

        new_manager, _ = self.manager.propose_refinement([0], self.config, self.problem)
        # Indices: 0=L0a, 1=L0b, 2=L1

        # Check L0b (index 1) neighbors
        map_item = new_manager.leaf_neighbor_map[1]
        self.assertIsNotNone(map_item)
        neighbors = map_item[0].neighbors

        # Should have West neighbor (L0a, index 0) and East neighbor (L1, index 2)
        west_n = next((n for n in neighbors if n.direction.name == "WEST"), None)
        east_n = next((n for n in neighbors if n.direction.name == "EAST"), None)

        self.assertIsNotNone(west_n)
        self.assertEqual(west_n.neighbor, 0)

        self.assertIsNotNone(east_n)
        self.assertEqual(east_n.neighbor, 2)


class TestAMRLogic2D(unittest.TestCase):
    """Test suite for AMR logic in 2D."""

    def setUp(self):
        """Set up a basic 2D configuration."""
        self.config_dict = {
            "problem": {"name": "gaussian diffusion", "A": 1.0, "t0": 0.1},
            "geometry": {
                "dimension": 2,
                "lb": [0.0, 0.0],
                "ub": [1.0, 1.0],
                "n": [10, 10],
                "n_ghost": [2, 2],
                # Start with 1 domain for simplicity
                "domain_decomp": 0,
            },
            "angles": {"n_theta": 2, "n_phi": 1},
            "solver": {
                "cfl": 0.5,
                "stencil": {"name": "upwind"},
                "method": "forward euler",
                "num_steps": 10,
                "rounding": {
                    "method": "svd",
                    "tol": 1e-5,
                    "freq": 1,
                    "tt_sum": True,
                    "rank_increase_bound": 10,
                },
                "order": ["x", "y", "theta", "phi"],
            },
            "equations": {
                "speed_of_light": 1.0,
                "source": {"name": "none"},
            },
            "saving": {"directory": ".", "plot_freq": 10},
        }
        self.config = Config(**self.config_dict)
        self.problem = MagicMock()
        mock_bcs = MagicMock(spec=BoundaryConditions)
        mock_bcs.conditions = {}
        self.problem.get_bc.return_value = mock_bcs
        self.manager = DomainManager.from_config(self.config, self.problem)

    def test_2d_split_topology(self):
        """Test that splitting a 2D leaf creates 4 children."""
        # Initial: 1 leaf
        self.assertEqual(len(self.manager.leaves), 1)

        # Refine leaf 0
        new_manager, lineage_map = self.manager.propose_refinement(
            [0], self.config, self.problem
        )

        # Should have 4 leaves (quadtree split)
        self.assertEqual(len(new_manager.leaves), 4)
        for leaf in new_manager.leaves:
            self.assertEqual(leaf.depth, 1)

        # Map: 0 -> [0, 1, 2, 3]
        self.assertEqual(lineage_map[0], [0, 1, 2, 3])

    def test_2d_split_indices(self):
        """Test that the split order corresponds to SW, NW, NE, SE."""
        # Refine the single domain into 4 quadrants.
        new_manager, _ = self.manager.propose_refinement([0], self.config, self.problem)
        leaves = new_manager.leaves

        # Expected Order:
        # 0: SW [0, 0.5] x [0, 0.5]
        # 1: NW [0, 0.5] x [0.5, 1]
        # 2: NE [0.5, 1] x [0.5, 1]
        # 3: SE [0.5, 1] x [0, 0.5]

        # Check SW (0)
        self.assertTrue(np.isclose(leaves[0].disc.grid.cell_edges[0][0], 0.0))
        self.assertTrue(np.isclose(leaves[0].disc.grid.cell_edges[1][0], 0.0))

        # Check NW (1)
        self.assertTrue(np.isclose(leaves[1].disc.grid.cell_edges[0][0], 0.0))
        self.assertTrue(np.isclose(leaves[1].disc.grid.cell_edges[1][0], 0.5))

        # Check NE (2)
        self.assertTrue(np.isclose(leaves[2].disc.grid.cell_edges[0][0], 0.5))
        self.assertTrue(np.isclose(leaves[2].disc.grid.cell_edges[1][0], 0.5))

        # Check SE (3)
        self.assertTrue(np.isclose(leaves[3].disc.grid.cell_edges[0][0], 0.5))
        self.assertTrue(np.isclose(leaves[3].disc.grid.cell_edges[1][0], 0.0))

    def test_2d_neighbor_map(self):
        """Test neighbor connections after a 2D split."""
        # Refine the single domain into 4 quadrants.
        # Ordering is Clockwise: SW(0), NW(1), NE(2), SE(3).
        new_manager, _ = self.manager.propose_refinement([0], self.config, self.problem)

        # Check SW (0) neighbors
        # Should have East neighbor (SE, 3) and North neighbor (NW, 1)
        map_item = new_manager.leaf_neighbor_map[0]
        self.assertIsNotNone(map_item)
        neighbors = map_item[0].neighbors

        east = next((n for n in neighbors if n.direction.name == "EAST"), None)
        north = next((n for n in neighbors if n.direction.name == "NORTH"), None)

        self.assertIsNotNone(east)
        self.assertEqual(east.neighbor, 3)  # SE is 3
        self.assertIsNotNone(north)
        self.assertEqual(north.neighbor, 1)  # NW is 1

        # Check NE (2) neighbors
        # Should have West neighbor (NW, 1) and South neighbor (SE, 3)
        map_item = new_manager.leaf_neighbor_map[2]
        neighbors = map_item[0].neighbors

        west = next((n for n in neighbors if n.direction.name == "WEST"), None)
        south = next((n for n in neighbors if n.direction.name == "SOUTH"), None)

        self.assertIsNotNone(west)
        self.assertEqual(west.neighbor, 1)  # NW is 1
        self.assertIsNotNone(south)
        self.assertEqual(south.neighbor, 3)  # SE is 3

    def test_2d_proper_nesting(self):
        """Test proper nesting propagation in 2D."""
        self.config.refinement.proper_nesting = True

        # 1. Split Root -> 4 quadrants (Level 1)
        manager, _ = self.manager.propose_refinement([0], self.config, self.problem)

        # Find SW leaf (Level 1)
        sw_idx = -1
        for i, leaf in enumerate(manager.leaves):
            if np.isclose(leaf.disc.grid.cell_edges[0][0], 0.0) and np.isclose(
                leaf.disc.grid.cell_edges[1][0], 0.0
            ):
                sw_idx = i
                break

        # 2. Split SW -> 4 sub-quadrants (Level 2)
        manager, _ = manager.propose_refinement([sw_idx], self.config, self.problem)

        # Find SW_sw leaf (Level 2) - Bottom Left corner
        sw_sw_idx = -1
        for i, leaf in enumerate(manager.leaves):
            if np.isclose(leaf.disc.grid.cell_edges[0][0], 0.0) and np.isclose(
                leaf.disc.grid.cell_edges[1][0], 0.0
            ):
                sw_sw_idx = i
                break
        self.assertEqual(manager.leaves[sw_sw_idx].depth, 2)

        # 3. Split SW_sw -> Level 3.
        manager_iso, _ = manager.propose_refinement(
            [sw_sw_idx], self.config, self.problem
        )

        # Find SE quadrant (Level 1). It is at x=[0.5, 1.0], y=[0.0, 0.5].
        se_idx = -1
        for i, leaf in enumerate(manager_iso.leaves):
            if np.isclose(leaf.disc.grid.cell_edges[0][0], 0.5) and np.isclose(
                leaf.disc.grid.cell_edges[1][0], 0.0
            ):
                se_idx = i
                break

        # Assert SE is still Level 1
        self.assertEqual(manager_iso.leaves[se_idx].depth, 1)

        # 4. Now split SW_se (Level 2).
        # Find SW_se in the *current* manager (manager_iso).
        # It is at x=[0.25, 0.5], y=[0.0, 0.25].
        sw_se_idx = -1
        for i, leaf in enumerate(manager_iso.leaves):
            if np.isclose(leaf.disc.grid.cell_edges[0][0], 0.25) and np.isclose(
                leaf.disc.grid.cell_edges[1][0], 0.0
            ):
                sw_se_idx = i
                break

        manager_prop, _ = manager_iso.propose_refinement(
            [sw_se_idx], self.config, self.problem
        )

        # Check SE quadrant again. It should now be split into 4 children (Level 2).
        # We check if the leaf at (0.5, 0.0) has depth 2.
        se_child_idx = -1
        for i, leaf in enumerate(manager_prop.leaves):
            if np.isclose(leaf.disc.grid.cell_edges[0][0], 0.5) and np.isclose(
                leaf.disc.grid.cell_edges[1][0], 0.0
            ):
                se_child_idx = i
                break

        self.assertEqual(manager_prop.leaves[se_child_idx].depth, 2)


if __name__ == "__main__":
    unittest.main()
