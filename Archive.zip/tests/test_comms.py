"""Unit tests for communication helpers."""

import logging
from unittest import mock
from unittest.mock import MagicMock, patch

from pytens_radtrans import comms


def test_exchange_packages_mpi_avoids_pair_tag_collisions() -> None:
    """Distinct (receiver, sender) pairs must produce distinct MPI tag bases."""
    init_data = MagicMock()
    init_data.domain_manager = MagicMock()
    init_data.domain_manager.num_domains.return_value = 2001
    init_data.local_indices = [500, 1500]
    init_data.leaf_to_rank_map = {
        500: 0,
        1500: 0,
        1: 1,
        2: 1,
    }
    init_data.receive_plans_by_leaf = {}

    all_outgoing_packages = {
        # These pairs collide under (receiver * 1000 + sender) encoding:
        # (1, 1500) and (2, 500).
        (1500, 1): {"tn": MagicMock(), "arrays": {}},
        (500, 2): {"tn": MagicMock(), "arrays": {}},
    }

    captured = {}
    logger = logging.getLogger("test_comms")

    def _capture_transfer(outgoing_payloads, incoming_expectations, *_args, **_kwargs):
        captured["outgoing_payloads"] = outgoing_payloads
        captured["incoming_expectations"] = incoming_expectations
        return {}

    with patch("pytens_radtrans.comms.rank", 0):
        with patch("pytens_radtrans.comms._transfer_data_payloads") as mock_transfer:
            mock_transfer.side_effect = _capture_transfer
            result = comms.exchange_packages_mpi(
                all_outgoing_packages, init_data, MagicMock(), logger
            )

    assert result == {}
    assert "outgoing_payloads" in captured
    assert len(captured["outgoing_payloads"]) == 2
    tag_bases = {tag_base for (_dest, tag_base) in captured["outgoing_payloads"]}
    assert len(tag_bases) == 2


def test_exchange_packages_mpi_rejects_duplicate_local_indices() -> None:
    """Duplicate local indices indicate corrupted ownership state."""
    init_data = MagicMock()
    init_data.domain_manager = MagicMock()
    init_data.domain_manager.num_domains.return_value = 4
    init_data.local_indices = [3, 3]
    init_data.leaf_to_rank_map = {3: 0}
    init_data.receive_plans_by_leaf = {}

    with patch("pytens_radtrans.comms.rank", 0):
        try:
            comms.exchange_packages_mpi({}, init_data, MagicMock(), logging.getLogger())
        except RuntimeError as exc:
            assert "duplicate leaf index" in str(exc)
        else:
            raise AssertionError("Expected RuntimeError for duplicate local indices.")


def test_exchange_packages_mpi_rejects_local_rank_map_mismatch_for_receiver() -> None:
    """Receiver mapped local but not actually local must fail fast."""
    init_data = MagicMock()
    init_data.domain_manager = MagicMock()
    init_data.domain_manager.num_domains.return_value = 4
    init_data.local_indices = [0]
    init_data.leaf_to_rank_map = {
        0: 0,
        1: 0,  # stale/incorrect: receiver 1 is marked local but is not local here
    }
    init_data.receive_plans_by_leaf = {}

    outgoing = {
        (0, 1): {"tn": MagicMock(), "arrays": {}},
    }

    with patch("pytens_radtrans.comms.rank", 0):
        try:
            comms.exchange_packages_mpi(
                outgoing, init_data, MagicMock(), logging.getLogger()
            )
        except RuntimeError as exc:
            assert "Leaf ownership mismatch" in str(exc)
        else:
            raise AssertionError("Expected RuntimeError for local rank-map mismatch.")


def test_exchange_packages_mpi_rejects_remote_rank_map_mismatch_for_receiver() -> None:
    """Receiver local but mapped remote must fail fast."""
    init_data = MagicMock()
    init_data.domain_manager = MagicMock()
    init_data.domain_manager.num_domains.return_value = 4
    init_data.local_indices = [0, 1]
    init_data.leaf_to_rank_map = {
        0: 0,
        1: 1,  # stale/incorrect: receiver 1 is local but mapped to rank 1
    }
    init_data.receive_plans_by_leaf = {}

    outgoing = {
        (0, 1): {"tn": MagicMock(), "arrays": {}},
    }

    with patch("pytens_radtrans.comms.rank", 0):
        try:
            comms.exchange_packages_mpi(
                outgoing, init_data, MagicMock(), logging.getLogger()
            )
        except RuntimeError as exc:
            assert "Leaf ownership mismatch" in str(exc)
        else:
            raise AssertionError("Expected RuntimeError for remote rank-map mismatch.")


def test_exchange_packages_mpi_rejects_missing_expected_sender_package() -> None:
    """Missing sender packages for a local receiver should raise."""
    init_data = MagicMock()
    init_data.domain_manager = MagicMock()
    init_data.domain_manager.num_domains.return_value = 4
    init_data.local_indices = [1]
    init_data.leaf_to_rank_map = {0: 1, 1: 0}

    plan = MagicMock()
    plan.sender_leaf_idx = 0
    init_data.receive_plans_by_leaf = {1: [plan]}

    with patch("pytens_radtrans.comms.rank", 0):
        with patch("pytens_radtrans.comms._transfer_data_payloads") as mock_transfer:
            # No incoming payload from sender 0 -> receiver 1
            mock_transfer.return_value = {}
            try:
                comms.exchange_packages_mpi(
                    {}, init_data, MagicMock(), logging.getLogger()
                )
            except RuntimeError as exc:
                assert "Halo package mismatch" in str(exc)
            else:
                raise AssertionError(
                    "Expected RuntimeError for missing sender package."
                )


def test_exchange_packages_mpi_sorts_expected_senders_deterministically() -> None:
    """Sender expectations should be sorted to keep reductions deterministic."""
    init_data = MagicMock()
    init_data.domain_manager = MagicMock()
    init_data.domain_manager.num_domains.return_value = 16
    init_data.local_indices = [10]
    init_data.leaf_to_rank_map = {
        1: 1,
        2: 1,
        10: 0,
    }
    plan_a = MagicMock()
    plan_a.sender_leaf_idx = 2
    plan_b = MagicMock()
    plan_b.sender_leaf_idx = 1
    init_data.receive_plans_by_leaf = {10: [plan_a, plan_b]}

    captured = {}

    def _capture_transfer(_outgoing_payloads, incoming_expectations, *_args, **_kwargs):
        captured["incoming_expectations"] = incoming_expectations
        return {
            (1, (10, 1)): {
                "tn": MagicMock(),
                "arrays": {},
                "extra": {
                    "sender_leaf_idx": 1,
                    "receiver_leaf_idx": 10,
                    "halo_iteration": None,
                },
            },
            (1, (10, 2)): {
                "tn": MagicMock(),
                "arrays": {},
                "extra": {
                    "sender_leaf_idx": 2,
                    "receiver_leaf_idx": 10,
                    "halo_iteration": None,
                },
            },
        }

    with patch("pytens_radtrans.comms.rank", 0):
        with patch("pytens_radtrans.comms._transfer_data_payloads") as mock_transfer:
            mock_transfer.side_effect = _capture_transfer
            result = comms.exchange_packages_mpi(
                {}, init_data, MagicMock(), logging.getLogger("test_comms")
            )

    assert "incoming_expectations" in captured
    sender_order = [uid[1] for (_src, uid, _tag) in captured["incoming_expectations"]]
    assert sender_order == [1, 2]
    assert list(result[0].keys()) == [1, 2]


def test_exchange_packages_mpi_rejects_payload_identity_mismatch() -> None:
    """Received payload metadata must match expected sender/receiver identity."""
    init_data = MagicMock()
    init_data.domain_manager = MagicMock()
    init_data.domain_manager.num_domains.return_value = 16
    init_data.local_indices = [10]
    init_data.leaf_to_rank_map = {
        1: 1,
        10: 0,
    }
    plan = MagicMock()
    plan.sender_leaf_idx = 1
    init_data.receive_plans_by_leaf = {10: [plan]}

    def _bad_identity(_outgoing_payloads, _incoming_expectations, *_args, **_kwargs):
        return {
            (1, (10, 1)): {
                "tn": MagicMock(),
                "arrays": {},
                "extra": {
                    "sender_leaf_idx": 999,
                    "receiver_leaf_idx": 10,
                    "halo_iteration": None,
                },
            }
        }

    with patch("pytens_radtrans.comms.rank", 0):
        with patch("pytens_radtrans.comms._transfer_data_payloads") as mock_transfer:
            mock_transfer.side_effect = _bad_identity
            try:
                comms.exchange_packages_mpi(
                    {}, init_data, MagicMock(), logging.getLogger("test_comms")
                )
            except RuntimeError as exc:
                assert "identity mismatch" in str(exc)
            else:
                raise AssertionError(
                    "Expected RuntimeError for payload identity mismatch."
                )


def test_exchange_packages_mpi_epoch_tags_require_iteration() -> None:
    """Epoch-tag mode requires an iteration number for halo exchange."""
    init_data = MagicMock()
    init_data.domain_manager = MagicMock()
    init_data.domain_manager.num_domains.return_value = 4
    init_data.local_indices = [0]
    init_data.leaf_to_rank_map = {0: 0, 1: 1}
    init_data.receive_plans_by_leaf = {}

    outgoing = {
        (0, 1): {"tn": MagicMock(), "arrays": {}},
    }

    with mock.patch.dict("os.environ", {"PYTENS_MPI_EPOCH_TAGS": "1"}):
        with patch("pytens_radtrans.comms.rank", 0):
            try:
                comms.exchange_packages_mpi(
                    outgoing, init_data, MagicMock(), logging.getLogger("test_comms")
                )
            except RuntimeError as exc:
                assert "no halo iteration was provided" in str(exc)
            else:
                raise AssertionError(
                    "Expected RuntimeError when epoch tags are enabled "
                    "without iteration."
                )
