"""Tests for the AMR adaptation loop."""

import logging
import unittest
from unittest.mock import MagicMock, patch

import numpy as np

from pytens_radtrans import main_loop_utils
from pytens_radtrans.domain_decomp import DomainManager
from pytens_radtrans.load_config import (
    Config,
    IntensityRefinementConfig,
    RankRefinementConfig,
)
from pytens_radtrans.main_loop_utils import InitializationData
from pytens_radtrans.problems import Problem
from pytens_radtrans.solver import Solution


class TestAMRLoop(unittest.TestCase):
    """Tests for the AMR adaptation loop."""

    def setUp(self):
        """Set up test fixtures."""
        self.logger = logging.getLogger("test_amr")
        self.logger.setLevel(logging.DEBUG)

    def _create_mock_init_data(self, enabled: bool = True):
        """Create a mock InitializationData and Config object."""
        # Mock Config
        config = MagicMock(spec=Config)
        config.refinement = MagicMock(spec=RankRefinementConfig)
        config.refinement.enabled = enabled
        config.refinement.frequency = 1
        config.refinement.strategy = "rank"
        config.refinement.max_rank = 10
        config.refinement.min_rank = 2
        config.refinement.proper_nesting = False
        config.refinement.max_level = 5
        # Default to False for existing tests to preserve behavior
        config.refinement.refine_neighbors = False

        config.load_balancing = MagicMock()
        config.load_balancing.enabled = False
        config.solver = MagicMock()
        config.solver.rounding = MagicMock()
        config.equations = MagicMock()
        config.equations.speed_of_light = 1.0

        # Mock DomainManager
        domain_manager = MagicMock(spec=DomainManager)
        domain_manager.num_domains.return_value = 1
        domain_manager.min_dx.return_value = 0.1
        domain_manager.leaves = [MagicMock()]
        domain_manager.leaves[0].disc = MagicMock()
        domain_manager.domain_angles = MagicMock()
        # Mock leaf_neighbor_map: leaf 0 has no neighbors (boundary)
        # Structure: list[tuple[LeafNeighbor, list[Direction]] | None]
        mock_neighbor_info = MagicMock()
        mock_neighbor_info.neighbors = []
        domain_manager.leaf_neighbor_map = [(mock_neighbor_info, [])]

        # Mock Solution
        sol = MagicMock(spec=Solution)
        sol.intensity = MagicMock()
        sol.intensity.ranks.return_value = [5]  # Default rank
        sol.time = 0.0

        # Mock InitializationData
        init_data = MagicMock(spec=InitializationData)
        init_data.domain_manager = domain_manager
        init_data.local_sol = [sol]
        init_data.local_indices = [0]
        init_data.leaf_to_rank_map = {0: 0}
        init_data.dt = 0.01
        init_data.problem = MagicMock(spec=Problem)
        init_data.permut = [0, 1, 2]
        init_data.inv_permut = [0, 1, 2]  # Add inv_permut attribute
        init_data.monitor = MagicMock()
        init_data.dimension = 1  # Add dimension attribute

        return init_data, config

    def test_amr_disabled(self):
        """Test that nothing happens if AMR is disabled."""
        init_data, config = self._create_mock_init_data(enabled=False)

        # Run
        result = main_loop_utils.handle_adaptation(
            init_data, config, self.logger, iteration=1
        )

        # Assertions
        self.assertEqual(result, init_data)
        # Ensure no triggers were checked (mock shouldn't be called)
        init_data.local_sol[0].intensity.ranks.assert_not_called()

    def test_no_triggers_fired(self):
        """Test that loop continues if no refinement/coarsening is triggered."""
        init_data, config = self._create_mock_init_data(enabled=True)

        # Mock MPI gather to return empty lists (no requests from any rank)
        with patch("pytens_radtrans.main_loop_utils.comm") as mock_comm:
            mock_comm.gather.return_value = [[], []]  # refine=[], coarsen=[]
            mock_comm.bcast.side_effect = lambda val, root: val  # Pass through

            result = main_loop_utils.handle_adaptation(
                init_data, config, self.logger, iteration=1
            )

        # Assertions
        self.assertEqual(result, init_data)
        # Verify triggers were checked
        init_data.local_sol[0].intensity.ranks.assert_called()

    def test_trigger_fires_but_topology_unchanged(self):
        """Test trigger fires, but DomainManager returns same topology."""
        init_data, config = self._create_mock_init_data(enabled=True)

        # Ensure trigger condition IS met (rank 15 > max 10)
        init_data.local_sol[0].intensity.ranks.return_value = [15]

        # Mock DomainManager to return ITSELF when propose_refinement is called
        # Return tuple: (manager, map)
        # Map is identity for index 0
        init_data.domain_manager.propose_refinement.return_value = (
            init_data.domain_manager,
            {0: [0]},
        )

        # Mock MPI interactions
        with patch("pytens_radtrans.main_loop_utils.comm") as mock_comm:
            # Rank 0 gathers requests: Rank 0 wants to refine index 0
            mock_comm.gather.side_effect = [
                [[0]],  # refine requests
                [[]],  # coarsen requests
            ]
            # Bcast pass-through
            mock_comm.bcast.side_effect = lambda val, root: val
            # Allgather for _update_rank_map: Rank 0 owns [0]
            mock_comm.allgather.return_value = [[0]]

            # PATCH rebuild_topology_operators to avoid running real logic on mocks
            with (
                patch(
                    "pytens_radtrans.main_loop_utils.rebuild_topology_operators"
                ) as mock_rebuild,
                patch(
                    "pytens_radtrans.main_loop_utils._partition_domain"
                ) as mock_partition,
            ):
                # Return dummy empty operators
                mock_rebuild.return_value = ([], [], [], [], {}, {}, {})

                # Mock partition domain to return same indices
                mock_partition.return_value = (
                    init_data.local_indices,
                    {},
                    None,
                )

                # Ensure domain_angles are numpy arrays for np.sin/cos
                init_data.domain_manager.domain_angles.theta = np.array([0.0])
                init_data.domain_manager.domain_angles.phi = np.array([0.0])

                main_loop_utils.handle_adaptation(
                    init_data, config, self.logger, iteration=1
                )

        # Assertions
        # Even if topology is same, if refinement_occurred=True (which it is,
        # because list was not empty), it proceeds to rebuild.
        # However, since map was identity, no split_solution should be called.
        # But rebuild_topology_operators SHOULD be called.
        mock_rebuild.assert_called()

    def test_topology_change_flow(self):
        """Test that the loop proceeds correctly when topology changes."""
        init_data, config = self._create_mock_init_data(enabled=True)
        init_data.local_sol[0].intensity.ranks.return_value = [15]  # Trigger

        # Create a NEW domain manager to simulate change
        new_dm = MagicMock(spec=DomainManager)
        new_dm.num_domains.return_value = 2  # Changed from 1
        new_dm.comm_plans = []  # Ensure iterable
        new_dm.domain_angles = MagicMock()  # Needed for transport term
        new_dm.domain_angles.theta = np.array([0.0])
        new_dm.domain_angles.phi = np.array([0.0])
        new_dm.min_dx.return_value = 0.05  # Smaller dx

        # Ensure leaf_neighbor_map is accessible for new manager
        mock_neighbor_info = MagicMock()
        mock_neighbor_info.neighbors = []
        new_dm.leaf_neighbor_map = [
            (mock_neighbor_info, []),
            (mock_neighbor_info, []),
        ]

        # Mock leaves for the new manager (indices 0 and 1)
        leaf0 = MagicMock()
        leaf0.disc.grid.num_cells = [10]
        leaf0.disc.grid.num_ghost = [2]
        leaf0.disc.dimension = 1

        leaf1 = MagicMock()
        leaf1.disc.grid.num_cells = [10]
        leaf1.disc.grid.num_ghost = [2]
        leaf1.disc.dimension = 1

        new_dm.leaves = [leaf0, leaf1]

        # propose_refinement returns (new_manager, map)
        # Map: Old 0 -> New [0, 1]
        init_data.domain_manager.propose_refinement.return_value = (
            new_dm,
            {0: [0, 1]},
        )

        # Mock MPI interactions
        with patch("pytens_radtrans.main_loop_utils.comm") as mock_comm:
            # Rank 0 gathers requests: Rank 0 wants to refine index 0
            mock_comm.gather.side_effect = [
                [[0]],  # refine requests
                [[]],  # coarsen requests
            ]
            # Bcast pass-through
            mock_comm.bcast.side_effect = lambda val, root: val
            # Allgather for _update_rank_map: Rank 0 owns [0, 1]
            mock_comm.allgather.return_value = [[0, 1]]

            # Mock partition to return NEW indices (simulating split)
            with (
                patch(
                    "pytens_radtrans.main_loop_utils._partition_domain"
                ) as mock_partition,
                patch(
                    "pytens_radtrans.main_loop_utils.rebuild_topology_operators"
                ) as mock_rebuild,
                patch("pytens_radtrans.refinement.split_solution") as mock_split,
            ):
                # Partition returns new indices
                mock_partition.return_value = ([0, 1], {}, None)

                # Mock split_solution to return 2 dummy solutions
                mock_split.return_value = [MagicMock(), MagicMock()]

                # Mock rebuild to return dummy operators
                mock_rebuild.return_value = ([], [], [], [], {}, {}, {})

                result = main_loop_utils.handle_adaptation(
                    init_data, config, self.logger, iteration=1
                )

        # Assertions
        self.assertEqual(result.domain_manager, new_dm)
        self.assertEqual(len(result.local_sol), 2)
        self.assertEqual(result.local_indices, [0, 1])
        mock_split.assert_called_once()
        mock_rebuild.assert_called_once()

    def test_mean_intensity_strategy_flow(self):
        """Test that the mean_intensity strategy is correctly instantiated and used."""
        init_data, config = self._create_mock_init_data(enabled=True)

        # 1. Configure for Mean Intensity Strategy
        # We need to mock the config object to look like IntensityRefinementConfig
        config.refinement = MagicMock(spec=IntensityRefinementConfig)
        config.refinement.enabled = True
        config.refinement.strategy = "mean_intensity"
        config.refinement.refine_fraction = 0.2
        config.refinement.coarsen_fraction = 0.5
        config.refinement.frequency = 1
        config.refinement.refine_neighbors = False

        # 2. Mock the Trigger class
        with patch(
            "pytens_radtrans.main_loop_utils.refinement.MeanIntensityTrigger"
        ) as mock_trigger_cls:
            mock_trigger = mock_trigger_cls.return_value
            # Setup trigger behavior: No refinement needed
            mock_trigger.should_refine.return_value = False
            mock_trigger.should_coarsen.return_value = False

            # 3. Mock MPI
            with patch("pytens_radtrans.main_loop_utils.comm") as mock_comm:
                mock_comm.gather.return_value = [[], []]
                mock_comm.bcast.side_effect = lambda val, root: val

                # 4. Run
                main_loop_utils.handle_adaptation(
                    init_data, config, self.logger, iteration=1
                )

            # 5. Verify
            mock_trigger_cls.assert_called_once_with(
                refine_fraction=0.2, coarsen_fraction=0.5
            )
            mock_trigger.update_global_stats.assert_called_once()

    def test_neighbor_refinement_trigger(self):
        """Test that neighbors are added to refinement candidates."""
        init_data, config = self._create_mock_init_data(enabled=True)
        config.refinement.refine_neighbors = True

        # Setup: Leaf 0 triggers refinement. Leaf 0 has neighbor Leaf 1.
        # We need to mock the neighbor map to show this relationship.
        # Leaf 0 -> Neighbor 1 (East)
        # Leaf 1 -> Neighbor 0 (West)
        mock_n0 = MagicMock()
        mock_n0.neighbor = 1
        mock_n0.direction = "EAST"

        mock_n1 = MagicMock()
        mock_n1.neighbor = 0
        mock_n1.direction = "WEST"

        # Map structure: list where index i is tuple(LeafNeighbor, boundaries)
        # Leaf 0 info
        ln0 = MagicMock()
        ln0.neighbors = [mock_n0]
        # Leaf 1 info
        ln1 = MagicMock()
        ln1.neighbors = [mock_n1]

        init_data.domain_manager.leaf_neighbor_map = [
            (ln0, []),  # Index 0
            (ln1, []),  # Index 1
        ]
        # IMPORTANT: Update num_domains to match the map we just created (2 domains)
        init_data.domain_manager.num_domains.return_value = 2

        # Mock MPI to simulate Rank 0 gathering requests
        # Rank 0 says "Refine 0". Rank 1 says "Nothing".
        with patch("pytens_radtrans.main_loop_utils.comm") as mock_comm:
            mock_comm.gather.side_effect = [
                [[0], []],  # Refine requests: [Rank0=[0], Rank1=[]]
                [[], []],  # Coarsen requests
            ]
            mock_comm.bcast.side_effect = lambda val, root: val
            # Allgather for rank map update (not critical for test logic but needed)
            mock_comm.allgather.return_value = [[0], [1]]

            # Mock propose_refinement to verify what it receives
            init_data.domain_manager.propose_refinement.return_value = (
                init_data.domain_manager,
                {0: [0], 1: [1]},  # Dummy identity map
            )

            with (
                patch(
                    "pytens_radtrans.main_loop_utils.rebuild_topology_operators"
                ) as mock_rebuild,
                patch(
                    "pytens_radtrans.main_loop_utils._partition_domain"
                ) as mock_partition,
            ):
                mock_rebuild.return_value = ([], [], [], [], {}, {}, {})
                mock_partition.return_value = ([0], {}, None)

                main_loop_utils.handle_adaptation(
                    init_data, config, self.logger, iteration=1
                )

                # VERIFICATION
                # Check that propose_refinement was called with BOTH 0 and 1
                # The order in the list doesn't matter, so we check set equality
                call_args = init_data.domain_manager.propose_refinement.call_args
                candidates_arg = call_args[0][0]  # First positional arg
                self.assertEqual(set(candidates_arg), {0, 1})
