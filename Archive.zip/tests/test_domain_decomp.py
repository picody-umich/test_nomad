"""Tests for domain_decomp.py."""

import itertools
import logging
import pathlib
import pickle
from unittest.mock import MagicMock

import numpy as np
import pytens
import pytest
from pytest_mock import MockerFixture

from pytens_radtrans import bcs, solver, utils
from pytens_radtrans.discretization import Discretization
from pytens_radtrans.domain_decomp import (
    CommPlan,
    DomainManager,
    NeighborRelationship,
    Tree,
    create_domain_manager,
    create_pack_executor,
    create_reconstruct_executor,
    intervals_overlap,
    point_match,
    transfer_boundaries,
)
from pytens_radtrans.load_config import Angles, Config, Geometry
from pytens_radtrans.types import Direction


def pack_data_for_test(source_array: np.ndarray, plan: CommPlan) -> np.ndarray:
    """Simulates packing data for a test, mirroring `create_pack_executor`."""
    flat_source = source_array.flatten()
    return flat_source[plan.sender_indices]


def reconstruct_data_for_test(
    target_array: np.ndarray, packed_buffer: np.ndarray, plan: CommPlan
) -> np.ndarray:
    """Simulates reconstructing data for a test.

    This mirrors the logic of `create_reconstruct_executor`.
    """
    weighted_buffer = packed_buffer * plan.weights
    flat_target = target_array.flatten()
    np.add.at(flat_target, plan.receiver_indices, weighted_buffer)
    return flat_target.reshape(target_array.shape)


@pytest.mark.parametrize(
    ("a0", "a1", "b0", "b1", "expected"),
    [
        (0, 2, 1, 3, True),  # Standard overlap
        (1, 3, 0, 2, True),  # Standard overlap (swapped)
        (0, 4, 1, 3, True),  # b is contained in a
        (1, 3, 0, 4, True),  # a is contained in b
        (0, 1, 1, 2, False),  # Touching at endpoint
        (1, 2, 0, 1, False),  # Touching at endpoint (swapped)
        (0, 1, 2, 3, False),  # No overlap
        (2, 3, 0, 1, False),  # No overlap (swapped)
        (0, 1, 1 - 1e-14, 2, False),  # Overlap smaller than tolerance
        (0, 1, 1 - 1e-12, 2, True),  # Overlap greater than tolerance
    ],
)
def test_intervals_overlap(
    a0: float, a1: float, b0: float, b1: float, expected: bool
) -> None:
    """Test the intervals_overlap function."""
    assert intervals_overlap(a0, a1, b0, b1) == expected


@pytest.mark.parametrize(
    ("a", "b", "expected"),
    [
        (1.0, 1.0, True),  # Identical
        (1.0, 1.0 + 1e-14, True),  # Within tolerance
        (1.0, 1.0 - 1e-14, True),  # Within tolerance (negative)
        (1.0, 1.0 + 1e-12, False),  # Outside tolerance
        (1.0, 1.0 - 1e-12, False),  # Outside tolerance (negative)
        (1.0, 2.0, False),  # Clearly different
    ],
)
def test_point_match(a: float, b: float, expected: bool) -> None:
    """Test the point_match function."""
    assert point_match(a, b) == expected


@pytest.fixture
def disc_1d() -> Discretization:
    """Returns a 1D Discretization object."""
    return Discretization.from_geom(lb=[0.0], ub=[1.0], n=[10], num_ghost=[2])


@pytest.fixture
def disc_2d() -> Discretization:
    """Returns a 2D Discretization object."""
    return Discretization.from_geom(
        lb=[0.0, 0.0], ub=[1.0, 1.0], n=[10, 10], num_ghost=[2, 2]
    )


class TestTree:
    """Tests for the Tree class."""

    def test_initialization(self, disc_1d: Discretization) -> None:
        """Test Tree initialization."""
        tree = Tree(disc_1d, parent=None)
        assert tree.disc == disc_1d
        assert tree.parent is None
        assert tree.children is None

    def test_split_1d(self, disc_1d: Discretization) -> None:
        """Test splitting a 1D domain."""
        tree = Tree(disc_1d, parent=None)
        children = tree.split()
        assert len(children) == 2
        assert all(isinstance(child, Tree) for child in children)
        assert children[0].parent == tree
        assert children[0].disc.grid.num_cells[0] == 10
        assert children[1].disc.grid.num_cells[0] == 10

    def test_split_2d(self, disc_2d: Discretization) -> None:
        """Test splitting a 2D domain."""
        tree = Tree(disc_2d, parent=None)
        children = tree.split()
        assert len(children) == 4
        assert all(isinstance(child, Tree) for child in children)
        assert children[0].parent == tree
        assert np.array_equal(children[0].disc.grid.num_cells, [10, 10])

    def test_split_on_list_no_split(self, disc_1d: Discretization) -> None:
        """Test split_on_list with no split command."""
        tree = Tree(disc_1d, parent=None)
        tree.split_on_list(0)
        assert tree.children is None

    def test_split_on_list_1d(self, disc_1d: Discretization) -> None:
        """Test split_on_list for a simple 1D split."""
        tree = Tree(disc_1d, parent=None)
        tree.split_on_list([1, [0, 0]])
        assert tree.children is not None
        assert len(tree.children) == 2
        assert tree.children[0].children is None
        assert tree.children[1].children is None

    def test_split_on_list_2d_simple(self, disc_2d: Discretization) -> None:
        """Test split_on_list for a simple 2D split."""
        tree = Tree(disc_2d, parent=None)
        tree.split_on_list([1, [0, 0, 0, 0]])
        assert tree.children is not None
        assert len(tree.children) == 4
        assert all(child.children is None for child in tree.children)

    def test_split_on_list_2d_nested(self, disc_2d: Discretization) -> None:
        """Test split_on_list for a nested 2D split."""
        tree = Tree(disc_2d, parent=None)
        # Split root, then recursively split the top-right child (index 3)
        tree.split_on_list([1, [0, 0, 0, [1, [0, 0, 0, 0]]]])

        assert tree.children is not None
        assert len(tree.children) == 4
        assert tree.children[0].children is None
        assert tree.children[1].children is None
        assert tree.children[2].children is None
        assert tree.children[3].children is not None
        assert len(tree.children[3].children) == 4

    def test_get_leaves_unsplit(self, disc_1d: Discretization) -> None:
        """Test get_leaves on an unsplit tree."""
        tree = Tree(disc_1d, parent=None)
        leaves = tree.get_leaves()
        assert len(leaves) == 1
        assert leaves[0] == tree

    def test_get_leaves_split(self, disc_1d: Discretization) -> None:
        """Test get_leaves on a split tree."""
        tree = Tree(disc_1d, parent=None)
        children = tree.split()
        leaves = tree.get_leaves()
        assert len(leaves) == 2
        assert children[0] in leaves
        assert children[1] in leaves

    def test_map_leaves_1d(self, disc_1d: Discretization) -> None:
        """Test neighbor mapping in 1D."""
        tree = Tree(disc_1d, parent=None)
        tree.split()
        leaves = tree.get_leaves()  # [left_leaf, right_leaf]
        neighbor_map = Tree.map_leaves(leaves, tree)

        assert neighbor_map[0] is not None
        leaf0_neighbor_info = neighbor_map[0][0].neighbors
        leaf0_neighbors = {n.direction: n.neighbor for n in leaf0_neighbor_info}
        assert leaf0_neighbors[Direction.WEST] == -1  # Boundary
        assert leaf0_neighbors[Direction.EAST] == 1  # Neighbor is leaf 1

        assert neighbor_map[1] is not None
        leaf1_neighbor_info = neighbor_map[1][0].neighbors
        leaf1_neighbors = {n.direction: n.neighbor for n in leaf1_neighbor_info}
        assert leaf1_neighbors[Direction.WEST] == 0  # Neighbor is leaf 0
        assert leaf1_neighbors[Direction.EAST] == -1  # Boundary

    def test_map_leaves_1d_refined(self) -> None:
        """Test neighbor mapping in 1D with grid refinement."""
        # Domain [0, 1] with 20 cells.
        disc = Discretization.from_geom(lb=[0.0], ub=[1.0], n=[20], num_ghost=[2])
        tree = Tree(disc, parent=None)

        # Split into a coarse left half and a recursively split (finer) right half.
        # This results in 3 leaves:
        # Leaf 0: [0, 0.5], dx = 0.5 / 20 = 0.025 (coarse)
        # Leaf 1: [0.5, 0.75], dx = 0.25 / 20 = 0.0125 (fine)
        # Leaf 2: [0.75, 1.0], dx = 0.25 / 20 = 0.0125 (fine)
        tree.split_on_list([1, [0, [1, [0, 0]]]])
        leaves = tree.get_leaves()
        neighbor_map = Tree.map_leaves(leaves, tree)

        # Sanity checks
        assert len(leaves) == 3
        assert leaves[0].disc.grid.dx[0] > leaves[1].disc.grid.dx[0]
        assert np.isclose(leaves[1].disc.grid.dx[0], leaves[2].disc.grid.dx[0])

        # --- Assertions for Leaf 0 (coarse) ---
        assert neighbor_map[0] is not None
        leaf0_neighbors = {n.direction: n for n in neighbor_map[0][0].neighbors}
        assert leaf0_neighbors[Direction.WEST].neighbor == -1
        assert leaf0_neighbors[Direction.EAST].neighbor == 1
        assert (
            leaf0_neighbors[Direction.EAST].relationship
            == NeighborRelationship.COARSE_TO_FINE
        )

        # --- Assertions for Leaf 1 (fine, middle) ---
        assert neighbor_map[1] is not None
        leaf1_neighbors = {n.direction: n for n in neighbor_map[1][0].neighbors}
        assert leaf1_neighbors[Direction.WEST].neighbor == 0
        assert (
            leaf1_neighbors[Direction.WEST].relationship
            == NeighborRelationship.FINE_TO_COARSE
        )
        assert leaf1_neighbors[Direction.EAST].neighbor == 2
        assert (
            leaf1_neighbors[Direction.EAST].relationship == NeighborRelationship.MATCHED
        )

        # --- Assertions for Leaf 2 (fine, right) ---
        assert neighbor_map[2] is not None
        leaf2_neighbors = {n.direction: n for n in neighbor_map[2][0].neighbors}
        assert leaf2_neighbors[Direction.WEST].neighbor == 1
        assert (
            leaf2_neighbors[Direction.WEST].relationship == NeighborRelationship.MATCHED
        )
        assert leaf2_neighbors[Direction.EAST].neighbor == -1

    def test_map_leaves_2d(self, disc_2d: Discretization) -> None:
        """Test neighbor mapping in 2D."""
        tree = Tree(disc_2d, parent=None)
        tree.split()  # Creates a 2x2 grid of 4 children
        leaves = tree.get_leaves()
        # Actual order: bottom-left(0), top-left(1), top-right(2), bottom-right(3)
        neighbor_map = Tree.map_leaves(leaves, tree)

        # Bottom-left leaf (leaf 0)
        assert neighbor_map[0] is not None
        bl_neighbors = {n.direction: n.neighbor for n in neighbor_map[0][0].neighbors}
        assert bl_neighbors[Direction.SOUTH] == -1
        assert bl_neighbors[Direction.WEST] == -1
        assert bl_neighbors[Direction.NORTH] == 1  # top-left
        assert bl_neighbors[Direction.EAST] == 3  # bottom-right

        # Top-right leaf (leaf 2)
        assert neighbor_map[2] is not None
        tr_neighbors = {n.direction: n.neighbor for n in neighbor_map[2][0].neighbors}
        assert tr_neighbors[Direction.SOUTH] == 3  # bottom-right
        assert tr_neighbors[Direction.WEST] == 1  # top-left
        assert tr_neighbors[Direction.NORTH] == -1
        assert tr_neighbors[Direction.EAST] == -1


@pytest.fixture
def config_1d() -> Config:
    """Returns a mock 1D Config object."""
    mock_config = MagicMock(spec=Config)
    mock_config.geometry = MagicMock(spec=Geometry)
    mock_config.geometry.lb = [0.0]
    mock_config.geometry.ub = [1.0]
    mock_config.geometry.n = [10]
    mock_config.geometry.n_ghost = [2]
    # Simple split into two domains
    mock_config.geometry.domain_decomp = [1, [0, 0]]
    mock_config.geometry.dimension = 1
    mock_config.angles = MagicMock(spec=Angles)
    mock_config.angles.n_theta = 4
    mock_config.angles.n_phi = 1
    mock_config.solver = MagicMock()
    mock_config.solver.order = ["x", "theta", "phi"]
    mock_config.refinement = MagicMock()
    mock_config.refinement.max_level = 10
    mock_config.refinement.proper_nesting = False
    return mock_config


@pytest.fixture
def config_2d() -> Config:
    """Returns a mock 2D Config object."""
    mock_config = MagicMock(spec=Config)
    mock_config.geometry = MagicMock(spec=Geometry)
    mock_config.geometry.lb = [0.0, 0.0]
    mock_config.geometry.ub = [1.0, 2.0]
    mock_config.geometry.n = [10, 10]
    mock_config.geometry.n_ghost = [2, 2]
    # Simple 2x2 split
    mock_config.geometry.domain_decomp = [1, [0, 0, 0, 0]]
    mock_config.geometry.dimension = 2
    mock_config.angles = MagicMock(spec=Angles)
    mock_config.angles.n_theta = 4
    mock_config.angles.n_phi = 4
    return mock_config


@pytest.fixture
def dm_2d_refined_ew() -> DomainManager:
    """Returns a DM with an East-West coarse-fine interface."""
    mock_config = MagicMock(spec=Config)
    mock_config.geometry = MagicMock(spec=Geometry)
    mock_config.geometry.lb = [0.0, 0.0]
    mock_config.geometry.ub = [2.0, 2.0]
    mock_config.geometry.n = [10, 10]
    mock_config.geometry.n_ghost = [4, 4]  # 2 on each side
    # Refine the BR quadrant (index 3), which is east of the BL quadrant (index 0).
    mock_config.geometry.domain_decomp = [1, [0, 0, 0, [1, [0, 0, 0, 0]]]]
    mock_config.geometry.dimension = 2
    mock_config.angles = MagicMock(spec=Angles)
    mock_config.angles.n_theta = 4
    mock_config.angles.n_phi = 1
    mock_problem = MagicMock()
    return DomainManager.from_config(mock_config, mock_problem)


@pytest.fixture
def dm_2d_refined_tr() -> DomainManager:
    """Returns a DM with a Top-Right coarse-fine interface on a non-square grid."""
    mock_config = MagicMock(spec=Config)
    mock_config.geometry = MagicMock(spec=Geometry)
    mock_config.geometry.lb = [0.0, 0.0]
    mock_config.geometry.ub = [2.0, 2.0]
    mock_config.geometry.n = [8, 6]  # nx=8, ny=6 cells per leaf
    mock_config.geometry.n_ghost = [4, 4]
    # Refine the TR quadrant (child index 2). Split order is BL, TL, TR, BR.
    mock_config.geometry.domain_decomp = [1, [0, 0, [1, [0, 0, 0, 0]], 0]]
    mock_config.geometry.dimension = 2
    mock_config.angles = MagicMock(spec=Angles)
    mock_config.angles.n_theta = 4
    mock_config.angles.n_phi = 1
    mock_problem = MagicMock()
    return DomainManager.from_config(mock_config, mock_problem)


class TestDomainManager:
    """Tests for the DomainManager class."""

    def test_from_config_1d(self, config_1d: Config) -> None:
        """Test DomainManager creation from a 1D config."""
        mock_problem = MagicMock()
        dm = DomainManager.from_config(config_1d, mock_problem)

        assert dm.dimension() == 1
        assert dm.num_domains() == 2
        assert dm.lb_x() == 0.0
        assert dm.ub_x() == 1.0
        assert len(dm.leaves) == 2
        assert len(dm.leaf_neighbor_map) == 2
        assert isinstance(dm.comm_plans, list)
        assert len(dm.comm_plans) == 2

    def test_build_communication_plans_1d_refined(self) -> None:
        """Test CommPlan creation for a 1D refined grid."""
        mock_config = MagicMock(spec=Config)
        mock_config.geometry = MagicMock(spec=Geometry)
        mock_config.geometry.lb = [0.0]
        mock_config.geometry.ub = [1.0]
        mock_config.geometry.n = [20]  # n per leaf
        mock_config.geometry.n_ghost = [2]  # 1 on each side
        # Decomp: [0, 1] -> [0, 0.5] & [0.5, 1].
        # Then [0.5, 1] -> [0.5, 0.75] & [0.75, 1]
        # Leaf 0: [0, 0.5] dx = 0.5/20 = 0.025 (coarse)
        # Leaf 1: [0.5, 0.75] dx = 0.25/20 = 0.0125 (fine)
        # Leaf 2: [0.75, 1.0] dx = 0.25/20 = 0.0125 (fine)
        mock_config.geometry.domain_decomp = [1, [0, [1, [0, 0]]]]
        mock_config.geometry.dimension = 1
        mock_config.angles = MagicMock(spec=Angles)
        mock_config.angles.n_theta = 4
        mock_config.angles.n_phi = 1
        mock_problem = MagicMock()

        dm = DomainManager.from_config(mock_config, mock_problem)

        assert len(dm.comm_plans) == 4  # 0->1, 1->0, 1->2, 2->1

        # Organize plans by sender->receiver for easier testing
        plans = {(p.sender_leaf_idx, p.receiver_leaf_idx): p for p in dm.comm_plans}

        # --- Test 1: Coarse-to-Fine (Sender 0 -> Receiver 1) ---
        c2f_plan = plans[(0, 1)]
        assert c2f_plan is not None
        assert np.array_equal(c2f_plan.sender_indices, [19])
        assert np.array_equal(c2f_plan.receiver_indices, [0])  # Ghost cell index
        assert np.allclose(c2f_plan.weights, [1.0])

        # --- Test 2: Fine-to-Coarse (Sender 1 -> Receiver 0) ---
        f2c_plan = plans[(1, 0)]
        assert f2c_plan is not None
        # Receiver 0 ghost cell is [0.5, 0.525]. Sender 1 has 2 cells inside.
        assert np.array_equal(f2c_plan.sender_indices, [0, 1])
        assert np.array_equal(f2c_plan.receiver_indices, [21, 21])
        assert np.allclose(f2c_plan.weights, [0.5, 0.5])

        # --- Test 3: Matched (Sender 1 -> Receiver 2) ---
        m_plan12 = plans[(1, 2)]
        assert m_plan12 is not None
        assert np.array_equal(m_plan12.sender_indices, [19])
        assert np.array_equal(m_plan12.receiver_indices, [0])
        assert np.allclose(m_plan12.weights, [1.0])

        # --- Test 4: Matched (Sender 2 -> Receiver 1) ---
        m_plan21 = plans[(2, 1)]
        assert m_plan21 is not None
        assert np.array_equal(m_plan21.sender_indices, [0])
        assert np.array_equal(m_plan21.receiver_indices, [21])
        assert np.allclose(m_plan21.weights, [1.0])

    def test_from_config_2d(self, config_2d: Config) -> None:
        """Test DomainManager creation from a 2D config."""
        mock_problem = MagicMock()
        dm = DomainManager.from_config(config_2d, mock_problem)

        assert dm.dimension() == 2
        assert dm.num_domains() == 4
        assert dm.lb_x() == 0.0
        assert dm.ub_x() == 1.0
        assert dm.lb_y() == 0.0
        assert dm.ub_y() == 2.0
        assert len(dm.leaves) == 4
        assert len(dm.leaf_neighbor_map) == 4
        assert isinstance(dm.comm_plans, list)
        assert len(dm.comm_plans) == 8  # 4 leaves, 4 internal faces = 8 plans total

    def test_build_communication_plans_2d_matched(self) -> None:
        """Test CommPlan creation for a 2D matched grid."""
        mock_config = MagicMock(spec=Config)
        mock_config.geometry = MagicMock(spec=Geometry)
        mock_config.geometry.lb = [0.0, 0.0]
        mock_config.geometry.ub = [2.0, 2.0]
        mock_config.geometry.n = [10, 10]  # n per leaf
        mock_config.geometry.n_ghost = [4, 4]  # 2 on each side
        mock_config.geometry.domain_decomp = [1, [0, 0, 0, 0]]  # 2x2 grid
        mock_config.geometry.dimension = 2
        mock_config.angles = MagicMock(spec=Angles)
        mock_config.angles.n_theta = 4
        mock_config.angles.n_phi = 1
        mock_problem = MagicMock()

        dm = DomainManager.from_config(mock_config, mock_problem)
        assert len(dm.comm_plans) == 8

        plans = {(p.sender_leaf_idx, p.receiver_leaf_idx): p for p in dm.comm_plans}

        # Test plan from Leaf 0 (BL) to Leaf 3 (BR) -> EAST communication
        plan = plans.get((0, 3))
        assert plan is not None

        # Sender: 10x10 cells. Receiver (with ghosts): 14x14 grid.
        ny_s = 10
        ny_r_full = 14

        # Expected sender indices (column-major): x * ny + y
        # x=[8, 9], y=[0-9]
        exp_s_x, exp_s_y = np.meshgrid(np.arange(8, 10), np.arange(ny_s))
        exp_s_flat = (exp_s_x * ny_s + exp_s_y).flatten()
        assert np.array_equal(plan.sender_indices, exp_s_flat)

        # Expected receiver indices (column-major): x * ny + y
        # ghost_x=[0, 1], phys_y=[2-11]
        exp_r_x, exp_r_y = np.meshgrid(np.arange(0, 2), np.arange(2, 12))
        exp_r_flat = (exp_r_x * ny_r_full + exp_r_y).flatten()
        assert np.array_equal(plan.receiver_indices, exp_r_flat)
        assert np.allclose(plan.weights, 1.0)

    def test_build_communication_plans_2d_matched_north_south(self) -> None:
        """Test the indices for a N/S matched grid CommPlan."""
        mock_config = MagicMock(spec=Config)
        mock_config.geometry = MagicMock(spec=Geometry)
        mock_config.geometry.lb = [0.0, 0.0]
        mock_config.geometry.ub = [2.0, 2.0]
        mock_config.geometry.n = [10, 10]  # n per leaf
        mock_config.geometry.n_ghost = [4, 4]  # 2 on each side
        mock_config.geometry.domain_decomp = [1, [0, 0, 0, 0]]  # 2x2 grid
        mock_config.geometry.dimension = 2
        mock_config.angles = MagicMock(spec=Angles)
        mock_config.angles.n_theta = 4
        mock_config.angles.n_phi = 1
        mock_problem = MagicMock()

        dm = DomainManager.from_config(mock_config, mock_problem)
        plans = {(p.sender_leaf_idx, p.receiver_leaf_idx): p for p in dm.comm_plans}

        # Test plan from Leaf 0 (BL) to Leaf 1 (TL) -> NORTH communication
        plan = plans.get((0, 1))
        assert plan is not None

        ny_s = 10
        ny_r_full = 14  # 10 phys + 2 ghosts on each side

        # Expected sender indices (column-major): x * ny + y
        # top 2 rows (y=8,9) of a 10x10 grid.
        x_coords_s = np.arange(10)
        y_coords_s = np.arange(8, 10)
        exp_s_x, exp_s_y = np.meshgrid(x_coords_s, y_coords_s)
        exp_s_flat = (exp_s_x * ny_s + exp_s_y).flatten(order="C")
        assert np.array_equal(plan.sender_indices, exp_s_flat)

        # Expected receiver indices (column-major): x * ny + y
        # bottom 2 ghost rows (y=0,1) of a 14x14 grid.
        # Overlap in x is [0..9], which is [2..11] in ghosted grid.
        y_coords_r = np.arange(0, 2)
        x_coords_r = np.arange(2, 12)
        exp_r_x, exp_r_y = np.meshgrid(x_coords_r, y_coords_r)
        exp_r_flat = (exp_r_x * ny_r_full + exp_r_y).flatten(order="C")
        assert np.array_equal(plan.receiver_indices, exp_r_flat)

    def test_comm_plan_2d_c2f_ew(self, dm_2d_refined_ew: DomainManager) -> None:
        """Test a coarse-to-fine 2D CommPlan (East-West)."""
        plans = {
            (p.sender_leaf_idx, p.receiver_leaf_idx): p
            for p in dm_2d_refined_ew.comm_plans
        }
        c2f_plan = plans.get((0, 3))
        assert c2f_plan is not None

        sender_data = np.array(
            [j * 100 + i for j in range(10) for i in range(10)]
        ).reshape(10, 10)
        sender_data = sender_data.T
        receiver_grid = np.zeros((14, 14))

        buffer = pack_data_for_test(sender_data, c2f_plan)
        result = reconstruct_data_for_test(receiver_grid, buffer, c2f_plan).reshape(
            14, 14
        )

        assert np.isclose(result[0, 2], 9)
        assert np.isclose(result[0, 3], 9)
        assert np.isclose(result[0, 4], 109)
        assert np.isclose(result[1, 2], 9)

    def test_comm_plan_2d_f2c_ew(self, dm_2d_refined_ew: DomainManager) -> None:
        """Test a fine-to-coarse 2D CommPlan (East-West)."""
        plans = {
            (p.sender_leaf_idx, p.receiver_leaf_idx): p
            for p in dm_2d_refined_ew.comm_plans
        }
        f2c_plan = plans.get((3, 0))
        assert f2c_plan is not None

        sender_data = np.array(
            [j * 100 + i for j in range(10) for i in range(10)]
        ).reshape(10, 10)
        sender_data = sender_data.T
        receiver_grid = np.zeros((14, 14))

        buffer = pack_data_for_test(sender_data, f2c_plan)
        result = reconstruct_data_for_test(receiver_grid, buffer, f2c_plan).reshape(
            14, 14
        )

        assert np.isclose(result[12, 2], 50.5)
        assert np.isclose(result[12, 3], 250.5)
        assert np.isclose(result[13, 2], 52.5)

    @pytest.fixture
    def dm_2d_refined_ns(self) -> DomainManager:
        """Returns a DM with a North-South coarse-fine interface."""
        mock_config = MagicMock(spec=Config)
        mock_config.geometry = MagicMock(spec=Geometry)
        mock_config.geometry.lb = [0.0, 0.0]
        mock_config.geometry.ub = [2.0, 2.0]
        mock_config.geometry.n = [10, 10]
        mock_config.geometry.n_ghost = [4, 4]
        mock_config.geometry.domain_decomp = [1, [0, [1, [0, 0, 0, 0]], 0, 0]]
        mock_config.geometry.dimension = 2
        mock_config.angles = MagicMock(spec=Angles)
        mock_config.angles.n_theta = 4
        mock_config.angles.n_phi = 1
        mock_problem = MagicMock()
        return DomainManager.from_config(mock_config, mock_problem)

    def test_comm_plan_2d_c2f_ns(self, dm_2d_refined_ns: DomainManager) -> None:
        """Test a coarse-to-fine 2D CommPlan (North-South)."""
        plans = {
            (p.sender_leaf_idx, p.receiver_leaf_idx): p
            for p in dm_2d_refined_ns.comm_plans
        }
        c2f_plan = plans.get((0, 4))
        assert c2f_plan is not None

        sender_data = np.array(
            [j * 100 + i for j in range(10) for i in range(10)]
        ).reshape(10, 10)
        sender_data = sender_data.T
        receiver_grid = np.zeros((14, 14))

        buffer = pack_data_for_test(sender_data, c2f_plan)
        result = reconstruct_data_for_test(receiver_grid, buffer, c2f_plan).reshape(
            14, 14
        )

        assert np.isclose(result[7, 0], 907)
        assert np.isclose(result[7, 1], 907)

    def test_comm_plan_2d_f2c_ns(self, dm_2d_refined_ns: DomainManager) -> None:
        """Test a fine-to-coarse 2D CommPlan (North-South)."""
        plans = {
            (p.sender_leaf_idx, p.receiver_leaf_idx): p
            for p in dm_2d_refined_ns.comm_plans
        }
        f2c_plan = plans.get((4, 0))
        assert f2c_plan is not None

        sender_data = np.array(
            [j * 100 + i for j in range(10) for i in range(10)]
        ).reshape(10, 10)
        sender_data = sender_data.T
        receiver_grid = np.zeros((14, 14))

        buffer = pack_data_for_test(sender_data, f2c_plan)
        result = reconstruct_data_for_test(receiver_grid, buffer, f2c_plan).reshape(
            14, 14
        )

        assert np.isclose(result[7, 12], 50.5)
        assert np.isclose(result[7, 13], 250.5)

    def test_propose_refinement_max_level_limit(self, config_1d: Config) -> None:
        """Test that refinement is blocked when max_level is reached."""
        # config_1d creates a tree with leaves at Level 1 (Root -> [L, R]).
        # Set max_level to 1. This should prevent further splitting to Level 2.
        config_1d.refinement.max_level = 1
        config_1d.refinement.proper_nesting = False

        mock_problem = MagicMock()
        dm = DomainManager.from_config(config_1d, mock_problem)
        initial_domains = dm.num_domains()  # Should be 2

        # Try to refine leaf 0
        new_dm, refine_map = dm.propose_refinement([0], config_1d, mock_problem)

        # Assert no change occurred because we hit max_level
        assert new_dm.num_domains() == initial_domains
        assert len(refine_map[0]) == 1


class TestCreateDomainManager:
    """Tests for the create_domain_manager factory function."""

    def test_creation_from_config(
        self, config_1d: Config, mocker: MockerFixture
    ) -> None:
        """Test creating DomainManager from config when no checkpoint is specified."""
        config_1d.checkpoint_directory = None
        mock_problem = MagicMock()
        mock_logger = MagicMock(spec=logging.Logger)

        mock_from_config = mocker.patch(
            "pytens_radtrans.domain_decomp.DomainManager.from_config"
        )

        create_domain_manager(config_1d, mock_problem, mock_logger)

        mock_from_config.assert_called_once_with(config_1d, mock_problem)

    def test_loading_from_checkpoint_success(
        self, config_1d: Config, tmp_path: pathlib.Path
    ) -> None:
        """Test successfully loading DomainManager from a checkpoint."""
        mock_problem = MagicMock()
        # Create a real DomainManager to be pickled
        real_dm = DomainManager.from_config(config_1d, mock_problem)
        checkpoint_file = tmp_path / "step_0_domain_manager_rank_0.pkl"
        with open(checkpoint_file, "wb") as f:
            pickle.dump(real_dm, f)

        config_1d.checkpoint_directory = tmp_path
        mock_problem = MagicMock()
        mock_logger = MagicMock(spec=logging.Logger)

        loaded_dm = create_domain_manager(config_1d, mock_problem, mock_logger)

        assert isinstance(loaded_dm, DomainManager)
        mock_logger.info.assert_any_call(
            "Found DomainManager file: %s", str(checkpoint_file)
        )

    def test_loading_from_checkpoint_not_found(
        self, config_1d: Config, tmp_path: pathlib.Path
    ) -> None:
        """Test that FileNotFoundError is raised if no checkpoint file is found."""
        config_1d.checkpoint_directory = tmp_path  # an empty directory
        mock_problem = MagicMock()
        mock_logger = MagicMock(spec=logging.Logger)

        with pytest.raises(FileNotFoundError, match="No DomainManager file found"):
            create_domain_manager(config_1d, mock_problem, mock_logger)

    def test_loading_from_checkpoint_multiple_files(
        self, config_1d: Config, tmp_path: pathlib.Path
    ) -> None:
        """Test that OSError is raised if multiple checkpoint files are found."""
        # Create dummy files with simple, pickle-able objects
        with open(tmp_path / "step_0_domain_manager_rank_0.pkl", "wb") as f:
            pickle.dump("dummy_data_1", f)
        with open(tmp_path / "step_1_domain_manager_rank_0.pkl", "wb") as f:
            pickle.dump("dummy_data_2", f)

        config_1d.checkpoint_directory = tmp_path
        mock_problem = MagicMock()
        mock_logger = MagicMock(spec=logging.Logger)

        with pytest.raises(OSError, match="Found multiple DomainManager files"):
            create_domain_manager(config_1d, mock_problem, mock_logger)


class MockPeriodicProblem(MagicMock):
    """A mock problem that defines periodic boundary conditions for testing."""

    def get_bc(
        self, disc: Discretization, config: Config, bounds: list[Direction]
    ) -> bcs.BoundaryConditions:
        bc_manager = bcs.BoundaryConditions(disc, config, bounds)
        if Direction.WEST in bounds:
            bc_manager.add_condition(Direction.WEST, bcs.Periodic())
        if Direction.EAST in bounds:
            bc_manager.add_condition(Direction.EAST, bcs.Periodic())
        if disc.dimension > 1:
            if Direction.SOUTH in bounds:
                bc_manager.add_condition(Direction.SOUTH, bcs.Periodic())
            if Direction.NORTH in bounds:
                bc_manager.add_condition(Direction.NORTH, bcs.Periodic())
        return bc_manager


class TestPeriodicBCs:
    """Tests for periodic boundary condition handling in DomainManager."""

    def test_periodic_bc_1d(self, config_1d: Config) -> None:
        """Test that periodic neighbors and comm plans are created correctly in 1D."""
        mock_problem = MockPeriodicProblem()
        dm = DomainManager.from_config(config_1d, mock_problem)

        # There are 2 leaves. With periodic BCs, they are neighbors in both directions.
        # This results in 4 CommPlans: 0->1(internal), 1->0(internal),
        # 0->1(periodic), and 1->0(periodic).
        assert dm.num_domains() == 2
        assert len(dm.comm_plans) == 4

        # Check that the neighbor map was updated correctly
        # Leaf 0 (west-most)
        leaf0_neighbors = {n.direction: n for n in dm.leaf_neighbor_map[0][0].neighbors}
        assert leaf0_neighbors[Direction.EAST].neighbor == 1
        assert leaf0_neighbors[Direction.WEST].neighbor == 1  # Periodic neighbor

        # Leaf 1 (east-most)
        leaf1_neighbors = {n.direction: n for n in dm.leaf_neighbor_map[1][0].neighbors}
        assert leaf1_neighbors[Direction.WEST].neighbor == 0
        assert leaf1_neighbors[Direction.EAST].neighbor == 0  # Periodic neighbor

        # Check the generated CommPlans
        # Each leaf has 10 cells + 1 ghost on each side = 12 total grid points.
        plans = {(p.sender_leaf_idx, p.receiver_leaf_idx): [] for p in dm.comm_plans}
        for p in dm.comm_plans:
            plans[(p.sender_leaf_idx, p.receiver_leaf_idx)].append(p)

        # Find the internal and periodic plans connecting leaf 1 to 0
        plans_1_to_0 = plans.get((1, 0), [])
        assert len(plans_1_to_0) == 2

        # Identify which plan is internal and which is periodic based on sender indices
        internal_plan = None
        periodic_plan = None
        for p in plans_1_to_0:
            if p.sender_indices[0] == 0:  # Internal sends from left edge of leaf 1
                internal_plan = p
            elif p.sender_indices[0] == 9:  # Periodic sends from right edge of leaf 1
                periodic_plan = p

        # Assert that both the internal and periodic plans were successfully found
        assert internal_plan is not None, "Internal plan from 1 to 0 not found."
        assert periodic_plan is not None, "Periodic plan from 1 to 0 not found."

        # Verify internal plan: sender's first cell -> receiver's east ghost
        assert np.array_equal(internal_plan.sender_indices, [0])
        assert np.array_equal(internal_plan.receiver_indices, [11])

        # Verify periodic plan: sender's last cell -> receiver's west ghost
        assert np.array_equal(periodic_plan.sender_indices, [9])
        assert np.array_equal(periodic_plan.receiver_indices, [0])

    def test_periodic_bc_leaf_boundaries(self, config_1d: Config) -> None:
        """Test that periodic boundaries are removed from a leaf's boundary list."""
        mock_problem = MockPeriodicProblem()
        dm = DomainManager.from_config(config_1d, mock_problem)

        # Leaf 0 is the west-most leaf. Its WEST boundary should now be a periodic
        # connection, not a physical boundary.
        leaf_0_boundaries = dm.leaf_neighbor_map[0][1]
        assert Direction.WEST not in leaf_0_boundaries

        # For a 1D domain split in 2, there are no other physical boundaries.
        assert not leaf_0_boundaries

        # Leaf 1 is the east-most leaf. Its EAST boundary should be periodic.
        leaf_1_boundaries = dm.leaf_neighbor_map[1][1]
        assert Direction.EAST not in leaf_1_boundaries
        assert not leaf_1_boundaries

    @pytest.fixture
    def config_2d_periodic(self) -> Config:
        """Returns a mock 2D Config object with periodic BCs."""
        mock_config = MagicMock(spec=Config)
        mock_config.geometry = MagicMock(spec=Geometry)
        mock_config.geometry.lb = [0.0, 0.0]
        mock_config.geometry.ub = [1.0, 1.0]
        mock_config.geometry.n = [10, 10]
        mock_config.geometry.n_ghost = [2, 2]
        # Simple 2x2 split
        mock_config.geometry.domain_decomp = [1, [0, 0, 0, 0]]
        mock_config.geometry.dimension = 2
        mock_config.angles = MagicMock(spec=Angles)
        mock_config.angles.n_theta = 4
        mock_config.angles.n_phi = 1
        mock_config.solver = MagicMock()
        mock_config.solver.order = ["x", "theta", "phi"]
        return mock_config

    def test_periodic_bc_2d(self, config_2d_periodic: Config) -> None:
        """Test that periodic neighbors and comm plans are created correctly in 2D."""
        mock_problem = MockPeriodicProblem()
        dm = DomainManager.from_config(config_2d_periodic, mock_problem)

        # 4 leaves. With full periodic BCs, each leaf has 4 neighbors.
        # 4 internal faces * 2 plans/face = 8 internal plans
        # 4 periodic faces * 2 plans/face = 8 periodic plans
        # Total = 16 plans.
        assert dm.num_domains() == 4
        assert len(dm.comm_plans) == 16

        # Check neighbor map for leaf 0 (bottom-left)
        # Order: bottom-left(0), top-left(1), top-right(2), bottom-right(3)
        l0_neighbors = {n.direction: n for n in dm.leaf_neighbor_map[0][0].neighbors}
        assert l0_neighbors[Direction.EAST].neighbor == 3  # Internal
        assert l0_neighbors[Direction.NORTH].neighbor == 1  # Internal
        assert l0_neighbors[Direction.WEST].neighbor == 3  # Periodic
        assert l0_neighbors[Direction.SOUTH].neighbor == 1  # Periodic

        # Check physical boundaries are gone
        assert not dm.leaf_neighbor_map[0][1]
        assert not dm.leaf_neighbor_map[1][1]
        assert not dm.leaf_neighbor_map[2][1]
        assert not dm.leaf_neighbor_map[3][1]

    @pytest.fixture
    def config_2d_periodic_refined(self) -> Config:
        """Returns a 2D config with periodic BCs and a refined interface."""
        mock_config = MagicMock(spec=Config)
        mock_config.geometry = MagicMock(spec=Geometry)
        mock_config.geometry.lb = [0.0, 0.0]
        mock_config.geometry.ub = [1.0, 1.0]
        mock_config.geometry.n = [10, 10]
        mock_config.geometry.n_ghost = [2, 2]
        # Decomp: Split the top-right quadrant into 4 sub-quadrants.
        # This creates a refined grid to test periodic BCs against.
        # Tree split order is BL, TL, BR, TR. We split child 3 (TR).
        mock_config.geometry.domain_decomp = [1, [0, 0, 0, [1, [0, 0, 0, 0]]]]
        mock_config.geometry.dimension = 2
        mock_config.angles = MagicMock(spec=Angles)
        mock_config.angles.n_theta = 4
        mock_config.angles.n_phi = 1
        mock_config.solver = MagicMock()
        mock_config.solver.order = ["x", "theta", "phi"]
        return mock_config

    def test_periodic_bc_2d_refined(self, config_2d_periodic_refined: Config) -> None:
        """Test periodic BCs with a refined grid interface."""
        mock_problem = MockPeriodicProblem()
        dm = DomainManager.from_config(config_2d_periodic_refined, mock_problem)

        # 7 leaves: 3 coarse, and 4 fine from the refined top-right quadrant.
        assert dm.num_domains() == 7

        # Leaf ordering is depth-first based on BL, TL, TR, BR split order.
        # Decomp: [1, [0, 0, 0, [1, [0, 0, 0, 0]]]] splits the BR quadrant.
        # Leaf map: 0(BL), 1(TL), 2(TR), 3-6(fine BR subs).
        # West leaves {0, 1}, East leaves {2, 5, 6}.
        #
        # Leaf Coords:
        # L0: x=[0, .5], y=[0, .5] | L1: x=[0, .5], y=[.5, 1]
        # L2: x=[.5, 1], y=[.5, 1]
        # L5: x=[.75, 1], y=[.25, .5] (TR of BR's TL sub-quad)
        # L6: x=[.75, 1], y=[0, .25] (BR of BR's BR sub-quad)

        # Check coarse leaf 0 (BL, y=[0, 0.5])
        l0_neighbors = dm.leaf_neighbor_map[0][0].neighbors
        l0_west_neighbors = [n for n in l0_neighbors if n.direction == Direction.WEST]
        # Should connect to fine leaves 5 and 6 on the east boundary.
        assert len(l0_west_neighbors) == 2
        assert {n.neighbor for n in l0_west_neighbors} == {5, 6}
        assert all(
            n.relationship == NeighborRelationship.COARSE_TO_FINE
            for n in l0_west_neighbors
        )

        # Check coarse leaf 1 (TL, y=[0.5, 1.0])
        l1_neighbors = dm.leaf_neighbor_map[1][0].neighbors
        l1_west_neighbors = [n for n in l1_neighbors if n.direction == Direction.WEST]
        # Should connect only to coarse leaf 2 on the east boundary.
        assert len(l1_west_neighbors) == 1
        assert l1_west_neighbors[0].neighbor == 2
        assert l1_west_neighbors[0].relationship == NeighborRelationship.MATCHED

        # Check fine leaf 6 (BR of BR's BR sub-quad, y=[0, 0.25])
        l6_neighbors = dm.leaf_neighbor_map[6][0].neighbors
        l6_east_neighbors = [n for n in l6_neighbors if n.direction == Direction.EAST]
        # Should connect to coarse leaf 0 on the west boundary.
        assert len(l6_east_neighbors) == 1
        assert l6_east_neighbors[0].neighbor == 0
        assert l6_east_neighbors[0].relationship == NeighborRelationship.FINE_TO_COARSE

    def test_periodic_plan_2d_refined(self, config_2d_periodic_refined: Config) -> None:
        """Test that periodic CommPlans for refined grids are valid."""
        mock_problem = MockPeriodicProblem()
        dm = DomainManager.from_config(config_2d_periodic_refined, mock_problem)

        # Leaf map: 0(BL), 1(TL), 2(TR), 3-6(fine BR subs).
        # Test plan from coarse Leaf 0 (sender) to fine Leaf 5 (receiver),
        # which is a periodic connection.
        plan_0_to_5 = None
        for plan in dm.comm_plans:
            if plan.sender_leaf_idx == 0 and plan.receiver_leaf_idx == 5:
                sender_neighbors = dm.leaf_neighbor_map[0][0].neighbors
                is_periodic = any(
                    n.neighbor == 5 and n.direction == Direction.WEST
                    for n in sender_neighbors
                )
                if is_periodic:
                    plan_0_to_5 = plan
                    break

        assert plan_0_to_5 is not None, "Periodic plan from Leaf 0 to 5 not found."

        # Ensure sender indices are within the bounds of the sender's grid.
        # This is the key check that would have caught the IndexError.
        sender_leaf = dm.leaves[0]
        num_sender_cells = np.prod(sender_leaf.disc.grid.num_cells)
        assert np.all(plan_0_to_5.sender_indices < num_sender_cells)

        # Also check the reverse direction (fine-to-coarse).
        plan_5_to_0 = None
        for plan in dm.comm_plans:
            if plan.sender_leaf_idx == 5 and plan.receiver_leaf_idx == 0:
                sender_neighbors = dm.leaf_neighbor_map[5][0].neighbors
                is_periodic = any(
                    n.neighbor == 0 and n.direction == Direction.EAST
                    for n in sender_neighbors
                )
                if is_periodic:
                    plan_5_to_0 = plan
                    break

        assert plan_5_to_0 is not None, "Periodic plan from Leaf 5 to 0 not found."
        sender_leaf_5 = dm.leaves[5]
        num_sender_cells_5 = np.prod(sender_leaf_5.disc.grid.num_cells)
        assert np.all(plan_5_to_0.sender_indices < num_sender_cells_5)


@pytest.fixture
def comm_plan_2d_matched_ew() -> CommPlan:
    """Creates a simple CommPlan for an East-West matched interface."""
    # Sender is a 4x4 physical grid (16 cells)
    # Receiver is a 4x4 physical grid with 1 ghost cell on each side (6x6 total)
    # Sender sends its rightmost column (x=3) to receiver's left ghost (x=0)

    # Sender indices for column x=3, y=0..3 (column-major index = x*ny + y)
    # 3*4+0=12, 3*4+1=13, ...
    sender_indices = np.array([12, 13, 14, 15])

    # Receiver indices for ghost column x=0, physical rows y=1..4
    # (column-major index = x*ny_full + y)
    # 0*6+1=1, 0*6+2=2, ...
    receiver_indices = np.array([1, 2, 3, 4])

    return CommPlan(
        sender_leaf_idx=0,
        receiver_leaf_idx=1,
        sender_indices=sender_indices,
        receiver_indices=receiver_indices,
        weights=np.ones_like(sender_indices, dtype=float),
        num_sender_indices=len(sender_indices),
    )


def test_create_pack_executor(comm_plan_2d_matched_ew: CommPlan) -> None:
    """Test that `create_pack_executor` correctly extracts data."""
    plan = comm_plan_2d_matched_ew
    executor = create_pack_executor(plan)

    # Create a fake sender TT core of shape (16, 2) i.e. rank=2
    sender_core = np.arange(32, dtype=float).reshape(16, 2)

    # Execute the packer
    packed_buffer = executor(sender_core)

    # The output should be a small, dense buffer with shape (num_indices, rank)
    assert packed_buffer.shape == (plan.num_sender_indices, 2)
    # The values should be exactly those from the sender_core at the specified indices
    expected_buffer = sender_core[plan.sender_indices]
    assert np.array_equal(packed_buffer, expected_buffer)


def test_create_reconstruct_executor(comm_plan_2d_matched_ew: CommPlan) -> None:
    """Test that `create_reconstruct_executor` produces a correct operator."""
    plan = comm_plan_2d_matched_ew
    receiver_flat_dim_with_ghosts = 36  # 6x6 grid

    reconstructor = create_reconstruct_executor(plan, receiver_flat_dim_with_ghosts)

    # Create a fake dense buffer that would be received via MPI.
    # Shape is (num_sender_indices, rank)
    buffer = np.arange(plan.num_sender_indices * 2, dtype=float).reshape(
        plan.num_sender_indices, 2
    )

    # Execute the reconstructor
    output_core = reconstructor(buffer)

    assert output_core.shape == (receiver_flat_dim_with_ghosts, 2)

    # --- Check the result for the first rank/column ---
    expected_col_0 = np.zeros(receiver_flat_dim_with_ghosts)
    # The reconstructor applies weights then scatters. Here weights are all 1.
    weighted_buffer_col0 = buffer[:, 0] * plan.weights
    np.add.at(expected_col_0, plan.receiver_indices, weighted_buffer_col0)
    assert np.array_equal(output_core[:, 0], expected_col_0)

    # --- Check the result for the second rank/column ---
    expected_col_1 = np.zeros(receiver_flat_dim_with_ghosts)
    weighted_buffer_col1 = buffer[:, 1] * plan.weights
    np.add.at(expected_col_1, plan.receiver_indices, weighted_buffer_col1)
    assert np.array_equal(output_core[:, 1], expected_col_1)


def test_transfer_boundaries() -> None:
    """Test the transfer_boundaries function for creating a TT operator."""
    # --- Setup ---
    # Define a simple 2D spatial domain (3x2) and a 1D angle
    indices_in = solver.Indices(
        2, pytens.Index("x", 6), pytens.Index("th", 2), pytens.Index("ph", 1)
    )
    # The output domain will have a different spatial size
    indices_out = solver.Indices(
        2, pytens.Index("x", 10), pytens.Index("th", 2), pytens.Index("ph", 1)
    )
    permut = [0, 1, 2]  # order: space, theta, phi
    inv_permut = [0, 1, 2]

    # Create a simple transformation function for the spatial core
    def space_func(core_col: np.ndarray) -> np.ndarray:
        """A dummy executor that doubles values and puts them in a new grid."""
        # This simulates a plan executor but is much simpler for a unit test.
        # It takes 6 input points and maps them to 10 output points.
        output_col = np.zeros((10, core_col.shape[1]))
        output_col[2:8, :] = core_col * 2.0  # Double values and place them
        return output_col

    # Create a simple rank-1 TensorNetwork
    space_data = np.arange(1, 7, dtype=float)  # 1..6
    theta_data = np.array([10.0, 20.0])
    phi_data = np.array([1.0])
    tn_in = pytens.tt_rank1(
        utils.reorder_list(
            [indices_in.space, indices_in.theta, indices_in.phi], permut
        ),
        utils.reorder_list([space_data, theta_data, phi_data], permut),
    )

    # --- Action ---
    # Create the TT operator using transfer_boundaries
    run_op = transfer_boundaries(
        space_func, indices_in, indices_out, permut, inv_permut
    )
    # Apply the operator
    tn_out = run_op(tn_in)
    # Evaluate the result to a full tensor for comparison
    result_tensor = tn_out.contract().value

    # --- Verification ---
    # Manually compute the expected result
    expected_space = np.zeros(10)
    expected_space[2:8] = space_data * 2.0
    expected_tensor = np.kron(expected_space, np.kron(theta_data, phi_data)).reshape(
        10, 2, 1
    )

    assert result_tensor.shape == (10, 2, 1)
    assert np.allclose(result_tensor, expected_tensor)


class TestFluxCorrectionPlans:
    """Tests for the FluxCorrectionPlan creation logic."""

    def test_flux_plans_for_1d(self) -> None:
        """Verify that flux correction plans are created for 1D problems."""
        mock_config = MagicMock(spec=Config)
        mock_config.geometry = MagicMock(spec=Geometry)
        mock_config.geometry.lb = [0.0]
        mock_config.geometry.ub = [1.0]
        mock_config.geometry.n = [20]
        mock_config.geometry.n_ghost = [2]
        # 1D refined: [0, 1] -> [0, 0.5] (Leaf 0) & [0.5, 1]
        # [0.5, 1] -> [0.5, 0.75] (Leaf 1) & [0.75, 1] (Leaf 2)
        mock_config.geometry.domain_decomp = [1, [0, [1, [0, 0]]]]
        mock_config.geometry.dimension = 1
        mock_config.angles = MagicMock(spec=Angles)
        mock_config.angles.n_theta = 4
        mock_config.angles.n_phi = 1
        mock_problem = MagicMock()

        dm = DomainManager.from_config(mock_config, mock_problem)

        # We expect a flux plan for the interface between Leaf 0 (Coarse) and Leaf 1
        # (Fine).
        # Leaf 0 is [0, 0.5]. Leaf 1 is [0.5, 0.75].
        # Leaf 1 is to the EAST of Leaf 0.
        # The plan is attached to the Fine-to-Coarse communication (1 -> 0).
        # Receiver is 0, Sender is 1.

        f2c_plan = next(
            (
                p
                for p in dm.comm_plans
                if p.sender_leaf_idx == 1 and p.receiver_leaf_idx == 0
            ),
            None,
        )
        assert f2c_plan is not None
        assert f2c_plan.flux_correction_plan is not None

        fcp = f2c_plan.flux_correction_plan
        assert fcp.direction == Direction.EAST
        # Coarse cell index at interface (East face) is the last cell (19)
        assert fcp.coarse_cell_indices[0] == 19
        # Temporary fine disc should be 2 cells wide
        assert tuple(fcp.temporary_fine_disc.grid.num_cells) == (2,)

    def test_flux_plan_for_2d_refined_ew(self, dm_2d_refined_ew: DomainManager) -> None:
        """Verify the correct creation of per-neighbor FluxCorrectionPlans."""
        # This fixture refines the BR quadrant. Each leaf has 10x10 cells.
        # This creates 4 coarse-fine interfaces (and thus 4 plans).
        all_flux_plans = [
            p.flux_correction_plan
            for p in dm_2d_refined_ew.comm_plans
            if p.flux_correction_plan is not None
        ]
        assert len(all_flux_plans) == 4
        # Collect plans by (coarse_idx, fine_idx) for easier testing.
        # Note: receiver is coarse, sender is fine for F2C comm plans.
        plans_by_idx = {
            (p.receiver_leaf_idx, p.sender_leaf_idx): p.flux_correction_plan
            for p in dm_2d_refined_ew.comm_plans
            if p.flux_correction_plan is not None
        }
        # Get all CommPlans for easy lookup
        comm_plans_by_pair = {
            (p.sender_leaf_idx, p.receiver_leaf_idx): p
            for p in dm_2d_refined_ew.comm_plans
        }

        # --- Verify Interface 1: East face of coarse leaf 0 (BL) ---
        # Coarse leaf 0 borders fine leaves 3 and 4 on its east face.
        assert (0, 3) in plans_by_idx
        assert (0, 4) in plans_by_idx

        plan_0_3 = plans_by_idx[(0, 3)]
        assert plan_0_3.direction == Direction.EAST
        # Coarse face is at x=9. Overlap is with lower half of y-cells (y=0..4).
        expected_indices_0_3 = np.repeat(9 * 10 + np.arange(5), 2)
        np.testing.assert_array_equal(
            plan_0_3.coarse_cell_indices, expected_indices_0_3
        )
        assert np.array_equal(plan_0_3.temporary_fine_disc.grid.num_cells, [2, 10])
        comm_plan_3_0 = comm_plans_by_pair[(3, 0)]
        assert (
            len(plan_0_3.fine_face_indices_in_buffer) < comm_plan_3_0.num_sender_indices
        )
        fine_face_global_indices = comm_plan_3_0.sender_indices[
            plan_0_3.fine_face_indices_in_buffer
        ]
        coarse_leaf = dm_2d_refined_ew.leaves[0]
        fine_leaf = dm_2d_refined_ew.leaves[3]
        coarse_ny = coarse_leaf.disc.grid.num_cells[1]
        fine_ny = fine_leaf.disc.grid.num_cells[1]
        coarse_ix = plan_0_3.coarse_cell_indices // coarse_ny
        coarse_x_edges = coarse_leaf.disc.grid.cell_edges[0][coarse_ix + 1]
        fine_ix = fine_face_global_indices // fine_ny
        fine_x_edges = fine_leaf.disc.grid.cell_edges[0][fine_ix]
        for c, f in zip(coarse_x_edges, fine_x_edges, strict=False):
            assert point_match(c, f)

        plan_0_4 = plans_by_idx[(0, 4)]
        assert plan_0_4.direction == Direction.EAST
        # Coarse face is at x=9. Overlap is with upper half of y-cells (y=5..9).
        expected_indices_0_4 = np.repeat(9 * 10 + np.arange(5, 10), 2)
        np.testing.assert_array_equal(
            plan_0_4.coarse_cell_indices, expected_indices_0_4
        )
        assert np.array_equal(plan_0_4.temporary_fine_disc.grid.num_cells, [2, 10])
        comm_plan_4_0 = comm_plans_by_pair[(4, 0)]
        assert (
            len(plan_0_4.fine_face_indices_in_buffer) < comm_plan_4_0.num_sender_indices
        )
        fine_face_global_indices = comm_plan_4_0.sender_indices[
            plan_0_4.fine_face_indices_in_buffer
        ]
        coarse_leaf = dm_2d_refined_ew.leaves[0]
        fine_leaf = dm_2d_refined_ew.leaves[4]
        coarse_ny = coarse_leaf.disc.grid.num_cells[1]
        fine_ny = fine_leaf.disc.grid.num_cells[1]
        coarse_ix = plan_0_4.coarse_cell_indices // coarse_ny
        coarse_x_edges = coarse_leaf.disc.grid.cell_edges[0][coarse_ix + 1]
        fine_ix = fine_face_global_indices // fine_ny
        fine_x_edges = fine_leaf.disc.grid.cell_edges[0][fine_ix]
        for c, f in zip(coarse_x_edges, fine_x_edges, strict=False):
            assert point_match(c, f)

        # --- Verify Interface 2: South face of coarse leaf 2 (TR) ---
        # Coarse leaf 2 borders fine leaves 4 and 5 on its south face.
        assert (2, 4) in plans_by_idx
        assert (2, 5) in plans_by_idx

        plan_2_4 = plans_by_idx[(2, 4)]
        assert plan_2_4.direction == Direction.SOUTH
        # Coarse face is at y=0. Overlap is with west half of x-cells (x=0..4).
        expected_indices_2_4 = np.repeat(np.arange(5) * 10 + 0, 2)
        np.testing.assert_array_equal(
            plan_2_4.coarse_cell_indices, expected_indices_2_4
        )
        assert np.array_equal(plan_2_4.temporary_fine_disc.grid.num_cells, [10, 2])
        comm_plan_4_2 = comm_plans_by_pair[(4, 2)]
        assert (
            len(plan_2_4.fine_face_indices_in_buffer) < comm_plan_4_2.num_sender_indices
        )
        fine_face_global_indices = comm_plan_4_2.sender_indices[
            plan_2_4.fine_face_indices_in_buffer
        ]
        coarse_leaf = dm_2d_refined_ew.leaves[2]
        fine_leaf = dm_2d_refined_ew.leaves[4]
        coarse_ny = coarse_leaf.disc.grid.num_cells[1]
        fine_ny = fine_leaf.disc.grid.num_cells[1]
        coarse_iy = plan_2_4.coarse_cell_indices % coarse_ny
        coarse_y_edges = coarse_leaf.disc.grid.cell_edges[1][coarse_iy]
        fine_iy = fine_face_global_indices % fine_ny
        fine_y_edges = fine_leaf.disc.grid.cell_edges[1][fine_iy + 1]
        for c, f in zip(coarse_y_edges, fine_y_edges, strict=False):
            assert point_match(c, f)

        plan_2_5 = plans_by_idx[(2, 5)]
        assert plan_2_5.direction == Direction.SOUTH
        # Coarse face is at y=0. Overlap is with east half of x-cells (x=5..9).
        expected_indices_2_5 = np.repeat(np.arange(5, 10) * 10 + 0, 2)
        np.testing.assert_array_equal(
            plan_2_5.coarse_cell_indices, expected_indices_2_5
        )
        assert np.array_equal(plan_2_5.temporary_fine_disc.grid.num_cells, [10, 2])
        comm_plan_5_2 = comm_plans_by_pair[(5, 2)]
        assert (
            len(plan_2_5.fine_face_indices_in_buffer) < comm_plan_5_2.num_sender_indices
        )
        fine_face_global_indices = comm_plan_5_2.sender_indices[
            plan_2_5.fine_face_indices_in_buffer
        ]
        coarse_leaf = dm_2d_refined_ew.leaves[2]
        fine_leaf = dm_2d_refined_ew.leaves[5]
        coarse_ny = coarse_leaf.disc.grid.num_cells[1]
        fine_ny = fine_leaf.disc.grid.num_cells[1]
        coarse_iy = plan_2_5.coarse_cell_indices % coarse_ny
        coarse_y_edges = coarse_leaf.disc.grid.cell_edges[1][coarse_iy]
        fine_iy = fine_face_global_indices % fine_ny
        fine_y_edges = fine_leaf.disc.grid.cell_edges[1][fine_iy + 1]
        for c, f in zip(coarse_y_edges, fine_y_edges, strict=False):
            assert point_match(c, f)

    def test_flux_plan_for_2d_refined_tr(self, dm_2d_refined_tr: DomainManager) -> None:
        """Verify FluxCorrectionPlans for a non-square grid with TR refinement."""
        # This fixture refines the TR quadrant. Coarse leaves are 8x6.
        all_flux_plans = [
            p.flux_correction_plan
            for p in dm_2d_refined_tr.comm_plans
            if p.flux_correction_plan is not None
        ]
        assert len(all_flux_plans) == 4
        plans_by_idx = {
            (p.receiver_leaf_idx, p.sender_leaf_idx): p.flux_correction_plan
            for p in dm_2d_refined_tr.comm_plans
            if p.flux_correction_plan is not None
        }
        comm_plans_by_pair = {
            (p.sender_leaf_idx, p.receiver_leaf_idx): p
            for p in dm_2d_refined_tr.comm_plans
        }

        # Leaf map: 0(BL), 1(TL), 2-5(fine TR subs), 6(BR).
        nx_c, ny_c = 8, 6

        # --- Interface 1: East face of coarse leaf 1 (TL) ---
        # Coarse leaf 1 borders fine leaves 2 and 3.
        assert (1, 2) in plans_by_idx
        assert (1, 3) in plans_by_idx

        plan_1_2 = plans_by_idx[(1, 2)]
        assert plan_1_2.direction == Direction.EAST
        # Face at x=7, lower half of y-cells (y=0..2)
        expected_1_2 = np.repeat((nx_c - 1) * ny_c + np.arange(ny_c // 2), 2)
        np.testing.assert_array_equal(plan_1_2.coarse_cell_indices, expected_1_2)
        assert np.array_equal(plan_1_2.temporary_fine_disc.grid.num_cells, [2, 6])
        comm_plan_2_1 = comm_plans_by_pair[(2, 1)]
        assert (
            len(plan_1_2.fine_face_indices_in_buffer) < comm_plan_2_1.num_sender_indices
        )
        fine_face_global_indices = comm_plan_2_1.sender_indices[
            plan_1_2.fine_face_indices_in_buffer
        ]
        coarse_leaf = dm_2d_refined_tr.leaves[1]
        fine_leaf = dm_2d_refined_tr.leaves[2]
        coarse_ny = coarse_leaf.disc.grid.num_cells[1]
        fine_ny = fine_leaf.disc.grid.num_cells[1]
        coarse_ix = plan_1_2.coarse_cell_indices // coarse_ny
        coarse_x_edges = coarse_leaf.disc.grid.cell_edges[0][coarse_ix + 1]
        fine_ix = fine_face_global_indices // fine_ny
        fine_x_edges = fine_leaf.disc.grid.cell_edges[0][fine_ix]
        for c, f in zip(coarse_x_edges, fine_x_edges, strict=False):
            assert point_match(c, f)

        plan_1_3 = plans_by_idx[(1, 3)]
        assert plan_1_3.direction == Direction.EAST
        # Face at x=7, upper half of y-cells (y=3..5)
        expected_1_3 = np.repeat((nx_c - 1) * ny_c + np.arange(ny_c // 2, ny_c), 2)
        np.testing.assert_array_equal(plan_1_3.coarse_cell_indices, expected_1_3)
        assert np.array_equal(plan_1_3.temporary_fine_disc.grid.num_cells, [2, 6])
        comm_plan_3_1 = comm_plans_by_pair[(3, 1)]
        assert (
            len(plan_1_3.fine_face_indices_in_buffer) < comm_plan_3_1.num_sender_indices
        )
        fine_face_global_indices = comm_plan_3_1.sender_indices[
            plan_1_3.fine_face_indices_in_buffer
        ]
        coarse_leaf = dm_2d_refined_tr.leaves[1]
        fine_leaf = dm_2d_refined_tr.leaves[3]
        coarse_ny = coarse_leaf.disc.grid.num_cells[1]
        fine_ny = fine_leaf.disc.grid.num_cells[1]
        coarse_ix = plan_1_3.coarse_cell_indices // coarse_ny
        coarse_x_edges = coarse_leaf.disc.grid.cell_edges[0][coarse_ix + 1]
        fine_ix = fine_face_global_indices // fine_ny
        fine_x_edges = fine_leaf.disc.grid.cell_edges[0][fine_ix]
        for c, f in zip(coarse_x_edges, fine_x_edges, strict=False):
            assert point_match(c, f)

        # --- Interface 2: North face of coarse leaf 6 (BR) ---
        # Coarse leaf 6 borders fine leaves 2 and 5.
        assert (6, 2) in plans_by_idx
        assert (6, 5) in plans_by_idx

        plan_6_2 = plans_by_idx[(6, 2)]
        assert plan_6_2.direction == Direction.NORTH
        # Face at y=5, west half of x-cells (x=0..3)
        expected_6_2 = np.repeat(np.arange(nx_c // 2) * ny_c + (ny_c - 1), 2)
        np.testing.assert_array_equal(plan_6_2.coarse_cell_indices, expected_6_2)
        assert np.array_equal(plan_6_2.temporary_fine_disc.grid.num_cells, [8, 2])
        comm_plan_2_6 = comm_plans_by_pair[(2, 6)]
        assert (
            len(plan_6_2.fine_face_indices_in_buffer) < comm_plan_2_6.num_sender_indices
        )
        fine_face_global_indices = comm_plan_2_6.sender_indices[
            plan_6_2.fine_face_indices_in_buffer
        ]
        coarse_leaf = dm_2d_refined_tr.leaves[6]
        fine_leaf = dm_2d_refined_tr.leaves[2]
        coarse_ny = coarse_leaf.disc.grid.num_cells[1]
        fine_ny = fine_leaf.disc.grid.num_cells[1]
        coarse_iy = plan_6_2.coarse_cell_indices % coarse_ny
        coarse_y_edges = coarse_leaf.disc.grid.cell_edges[1][coarse_iy + 1]
        fine_iy = fine_face_global_indices % fine_ny
        fine_y_edges = fine_leaf.disc.grid.cell_edges[1][fine_iy]
        for c, f in zip(coarse_y_edges, fine_y_edges, strict=False):
            assert point_match(c, f)

        plan_6_5 = plans_by_idx[(6, 5)]
        assert plan_6_5.direction == Direction.NORTH
        # Face at y=5, east half of x-cells (x=4..7)
        expected_6_5 = np.repeat(np.arange(nx_c // 2, nx_c) * ny_c + (ny_c - 1), 2)
        np.testing.assert_array_equal(plan_6_5.coarse_cell_indices, expected_6_5)
        assert np.array_equal(plan_6_5.temporary_fine_disc.grid.num_cells, [8, 2])
        comm_plan_5_6 = comm_plans_by_pair[(5, 6)]
        assert (
            len(plan_6_5.fine_face_indices_in_buffer) < comm_plan_5_6.num_sender_indices
        )
        fine_face_global_indices = comm_plan_5_6.sender_indices[
            plan_6_5.fine_face_indices_in_buffer
        ]
        coarse_leaf = dm_2d_refined_tr.leaves[6]
        fine_leaf = dm_2d_refined_tr.leaves[5]
        coarse_ny = coarse_leaf.disc.grid.num_cells[1]
        fine_ny = fine_leaf.disc.grid.num_cells[1]
        coarse_iy = plan_6_5.coarse_cell_indices % coarse_ny
        coarse_y_edges = coarse_leaf.disc.grid.cell_edges[1][coarse_iy + 1]
        fine_iy = fine_face_global_indices % fine_ny
        fine_y_edges = fine_leaf.disc.grid.cell_edges[1][fine_iy]
        for c, f in zip(coarse_y_edges, fine_y_edges, strict=False):
            assert point_match(c, f)


@pytest.mark.parametrize(
    "order",
    list(itertools.permutations(["x", "theta", "phi"])),
    ids=lambda o: "-".join(o),
)
def test_transfer_boundaries_any_order(order) -> None:
    """Verify transfer_boundaries works for any tensor index ordering."""
    indices_in = solver.Indices(
        2, pytens.Index("x", 6), pytens.Index("theta", 2), pytens.Index("phi", 1)
    )
    indices_out = solver.Indices(
        2, pytens.Index("x", 10), pytens.Index("theta", 2), pytens.Index("phi", 1)
    )

    permut, inv_permut = utils.encode_order(list(order))

    def space_func(core_col: np.ndarray) -> np.ndarray:
        """Map 6 spatial points to 10 and scale by 2."""
        output_col = np.zeros((10, core_col.shape[1]))
        output_col[2:8, :] = core_col * 2.0
        return output_col

    space_data = np.arange(1, 7, dtype=float)
    theta_data = np.array([10.0, 20.0])
    phi_data = np.array([1.0])

    tn_in = pytens.tt_rank1(
        utils.reorder_list(
            [indices_in.space, indices_in.theta, indices_in.phi], permut
        ),
        utils.reorder_list([space_data, theta_data, phi_data], permut),
    )

    run_op = transfer_boundaries(
        space_func, indices_in, indices_out, permut, inv_permut
    )
    result_tensor = run_op(tn_in).contract().value

    # Reorder result to canonical (x, theta, phi) for comparison.
    canonical_sizes = [
        indices_out.space.size,
        indices_out.theta.size,
        indices_out.phi.size,
    ]
    reshaped = result_tensor.reshape(utils.reorder_list(canonical_sizes, permut))
    result_canonical = reshaped.transpose(inv_permut)

    expected_space = np.zeros(10)
    expected_space[2:8] = space_data * 2.0
    expected_tensor = np.kron(expected_space, np.kron(theta_data, phi_data)).reshape(
        10, 2, 1
    )

    assert result_canonical.shape == (10, 2, 1)
    assert np.allclose(result_canonical, expected_tensor)
