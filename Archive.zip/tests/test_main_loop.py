import pathlib
import unittest
from unittest.mock import MagicMock, patch

from pytens_radtrans import main_loop


class TestMainLoop(unittest.TestCase):
    @patch("pytens_radtrans.main_loop.main_loop_utils")
    @patch("pytens_radtrans.main_loop.plt")
    @patch("pytens_radtrans.main_loop.tqdm")
    @patch("pytens_radtrans.main_loop.comm")
    def test_main_loop_flow(self, mock_comm, mock_tqdm, mock_plt, mock_utils):
        # Setup Mocks
        mock_config = MagicMock()
        mock_config.solver.num_steps = 2
        mock_config.saving.keep_all = True
        mock_config.refinement.frequency = 1

        mock_logger = MagicMock()
        save_dir = pathlib.Path("/tmp/test_sim")

        # Mock MPI Rank/Size
        mock_comm.Get_rank.return_value = 0
        mock_comm.Get_size.return_value = 1

        # Mock gather to return a list of lists (structure expected by code)
        # Structure: [rank0_data, rank1_data, ...]
        # For plot data: [[{...}], ...]
        # For ranks: [[step1_ranks, step2_ranks], ...]
        mock_comm.gather.side_effect = [
            [[{"mean_intensity": 1, "temperature": 1}]],  # Initial plot gather
            # Final ranks gather (list of steps, each step list of domains)
            [[[1], [1]]],
            # Final history gather
            [[[{"mean_intensity": 1}], [{"mean_intensity": 1}]]],
        ]

        # Mock Init Data
        mock_init_data = MagicMock()
        mock_init_data.local_sol = [MagicMock()]
        mock_init_data.local_sol[0].aux = {"mean_intensity": 1}
        mock_init_data.local_sol[0].space = {"temperature": 1}
        mock_init_data.local_indices_chunked = [[0]]  # Rank 0 has domain 0
        mock_init_data.domain_manager.num_domains.return_value = 1
        mock_init_data.time = 0.0

        # Mock Monitor history for final plot
        # sol[t][domain_idx]
        mock_init_data.monitor.sol = [
            [mock_init_data.local_sol[0]],
            [mock_init_data.local_sol[0]],
        ]
        mock_init_data.monitor.time = [0.0, 0.1]
        mock_init_data.monitor.ranks = [[1], [1]]

        mock_utils.initialize_simulation.return_value = mock_init_data

        # Mock Loop Utils returns
        # handle_post_step_io returns (init_data, fig_overlay)
        mock_utils.handle_post_step_io.return_value = (mock_init_data, None)

        # handle_adaptation should return the init_data passed to it (or the mock)
        mock_utils.handle_adaptation.return_value = mock_init_data

        # Run
        main_loop.main_loop(mock_config, mock_logger, save_dir)

        # Assertions
        mock_utils.initialize_simulation.assert_called_once()

        # Check loop calls
        self.assertEqual(mock_utils.perform_halo_exchange.call_count, 2)
        self.assertEqual(mock_utils.advance_local_solutions.call_count, 2)
        self.assertEqual(mock_utils.handle_post_step_io.call_count, 2)
        self.assertEqual(mock_utils.handle_adaptation.call_count, 2)

        # Check final plotting
        mock_init_data.monitor.plot_ranks_compressions.assert_called_once()
        mock_init_data.problem.plot_all_sols.assert_called_once()
