"""Tests for main_loop_utils.py."""

import logging
import unittest
from unittest.mock import MagicMock, patch

import numpy as np

from pytens_radtrans import domain_decomp, main_loop_utils, problems, solver
from pytens_radtrans.discretization import Discretization
from pytens_radtrans.load_config import Config


class TestMainLoopUtils(unittest.TestCase):
    """Tests for main_loop_utils functions."""

    def setUp(self):
        """Set up test fixtures."""
        self.logger = logging.getLogger("test_logger")

    def test_load_checkpoint_metadata_rank0(self):
        """Test loading checkpoint metadata on rank 0."""
        config = MagicMock(spec=Config)
        config.checkpoint_directory = "checkpoints"

        with patch("glob.glob") as mock_glob:
            mock_glob.return_value = [
                "checkpoints/checkpoint_100_domain_0_1.23e-01.pkl"
            ]
            with patch("pytens_radtrans.main_loop_utils.comm") as mock_comm:
                # Patch the global rank variable
                with patch("pytens_radtrans.main_loop_utils.rank", 0):
                    mock_comm.bcast.side_effect = lambda val, root: val

                    metadata = main_loop_utils._load_checkpoint_metadata(config)

                    self.assertEqual(metadata["dir"], "checkpoints")
                    self.assertEqual(metadata["itera"], 100)
                    self.assertEqual(metadata["time_str"], "1.23e-01")

    def test_load_checkpoint_metadata_rank1(self):
        """Test receiving checkpoint metadata on rank 1."""
        config = MagicMock(spec=Config)
        config.checkpoint_directory = "checkpoints"

        with patch("pytens_radtrans.main_loop_utils.comm") as mock_comm:
            # Patch the global rank variable
            with patch("pytens_radtrans.main_loop_utils.rank", 1):
                expected_metadata = {
                    "dir": "checkpoints",
                    "itera": 100,
                    "time_str": "1.23e-01",
                }
                mock_comm.bcast.return_value = expected_metadata

                metadata = main_loop_utils._load_checkpoint_metadata(config)

                self.assertEqual(metadata, expected_metadata)

    def test_initialize_solutions_new(self):
        """Test initializing new solutions from problem definition."""
        config = MagicMock(spec=Config)
        config.checkpoint_directory = None
        problem = MagicMock(spec=problems.Problem)
        # Fix: Return a list of arrays for fields to match permut length (2)
        problem.ic_intensity.return_value = (
            [1, 2],
            [np.array([1.0]), np.array([1.0])],
        )
        problem.ic_space.return_value = {"temp": np.array([100.0])}
        problem.indices = MagicMock()

        domain_manager = MagicMock(spec=domain_decomp.DomainManager)
        leaf = MagicMock()
        leaf.disc = MagicMock()
        domain_manager.leaves = [leaf]

        local_indices = [0]
        permut = [0, 1]

        with patch("pytens.tt_rank1") as mock_tt:
            mock_tt.return_value = MagicMock()
            with patch("pytens_radtrans.main_loop_utils.comm") as mock_comm:
                mock_comm.bcast.return_value = 0.0  # Time

                sols, time = main_loop_utils.initialize_solutions(
                    config,
                    problem,
                    permut,
                    domain_manager,
                    local_indices,
                    self.logger,
                )

                self.assertEqual(len(sols), 1)
                self.assertEqual(time, 0.0)
                problem.ic_intensity.assert_called()

    def test_partition_domain_rank0(self):
        """Test domain partitioning on rank 0."""
        domain_manager = MagicMock(spec=domain_decomp.DomainManager)
        domain_manager.num_domains.return_value = 4

        with patch("pytens_radtrans.main_loop_utils.comm") as mock_comm:
            # Patch global rank and size
            with patch("pytens_radtrans.main_loop_utils.rank", 0):
                with patch("pytens_radtrans.main_loop_utils.size", 2):
                    # Scatter returns the chunk for this rank
                    mock_comm.scatter.return_value = np.array([0, 1])
                    # Bcast returns the full map
                    mock_comm.bcast.return_value = {0: 0, 1: 0, 2: 1, 3: 1}

                    (
                        local_indices,
                        rank_map,
                        chunked,
                    ) = main_loop_utils._partition_domain(domain_manager, self.logger)

                    self.assertEqual(local_indices, [0, 1])
                    self.assertEqual(rank_map[0], 0)
                    self.assertEqual(rank_map[3], 1)
                    self.assertIsNotNone(chunked)
                    self.assertEqual(len(chunked), 2)

    def test_update_rank_map(self):
        """Test dynamic rank map reconstruction."""
        local_indices = [0, 1]
        num_domains = 4

        with patch("pytens_radtrans.main_loop_utils.comm") as mock_comm:
            # Simulate 2 ranks: Rank 0 has [0, 1], Rank 1 has [2, 3]
            mock_comm.allgather.return_value = [[0, 1], [2, 3]]

            rank_map, chunked = main_loop_utils._update_rank_map(
                local_indices, num_domains, self.logger
            )

            self.assertEqual(rank_map[0], 0)
            self.assertEqual(rank_map[1], 0)
            self.assertEqual(rank_map[2], 1)
            self.assertEqual(rank_map[3], 1)
            self.assertEqual(len(chunked), 2)

    def test_order_children_for_parent_merge_2d_by_geometry(self):
        """Merge child ordering should follow parent split geometry, not indices."""
        parent_disc = Discretization.from_geom([0.0, 0.0], [1.0, 1.0], [4, 4], [0, 0])
        split_children = parent_disc.split()

        # Scrambled order: UR, LL, LR, UL
        child_items = [
            (20, MagicMock(), split_children[2]),
            (10, MagicMock(), split_children[0]),
            (40, MagicMock(), split_children[3]),
            (30, MagicMock(), split_children[1]),
        ]

        ordered = main_loop_utils._order_children_for_parent_merge(
            parent_disc, child_items
        )
        ordered_indices = [item[0] for item in ordered]

        # Canonical split order in Discretization.split():
        # LL, UL, UR, LR
        self.assertEqual(ordered_indices, [10, 30, 20, 40])

    def test_update_rank_map_duplicate_error(self):
        """Test error detection for duplicate ownership."""
        local_indices = [0]
        num_domains = 2

        with patch("pytens_radtrans.main_loop_utils.comm") as mock_comm:
            # Error: Both ranks claim domain 0
            mock_comm.allgather.return_value = [[0], [0]]

            with self.assertRaises(RuntimeError):
                main_loop_utils._update_rank_map(
                    local_indices, num_domains, self.logger
                )

    def test_update_rank_map_missing_error(self):
        """Test error detection for missing domains."""
        local_indices = [0]
        num_domains = 3  # Expecting 0, 1, 2

        with patch("pytens_radtrans.main_loop_utils.comm") as mock_comm:
            # Error: Domain 2 is missing
            mock_comm.allgather.return_value = [[0], [1]]

            with self.assertRaises(RuntimeError):
                main_loop_utils._update_rank_map(
                    local_indices, num_domains, self.logger
                )

    def test_migrate_solutions(self):
        """Test migrating solutions between ranks."""
        # Setup initial state
        sol0 = MagicMock(spec=solver.Solution)
        sol1 = MagicMock(spec=solver.Solution)
        init_data = MagicMock(spec=main_loop_utils.InitializationData)
        init_data.local_indices = [0, 1]
        init_data.local_sol = [sol0, sol1]
        init_data.leaf_to_rank_map = {0: 0, 1: 0, 2: 1}

        # Plan: Move domain 1 to rank 1
        migration_map = {1: 1}

        with patch("pytens_radtrans.comms.transfer_solutions") as mock_transfer:
            # Mock transfer returning nothing (we are sending, not receiving)
            mock_transfer.return_value = []

            with patch("pytens_radtrans.main_loop_utils.comm"):
                # Patch global rank
                with patch("pytens_radtrans.main_loop_utils.rank", 0):
                    new_data = main_loop_utils.migrate_solutions(
                        init_data, migration_map, self.logger
                    )

                    # Verify outgoing call
                    # We expect to send domain 1 to rank 1
                    args, _ = mock_transfer.call_args
                    outgoing = args[0]
                    self.assertIn(1, outgoing)  # Target rank 1
                    self.assertEqual(outgoing[1][0][0], 1)  # Domain index 1

                    # Verify local state update
                    # Domain 1 should be gone, Domain 0 remains
                    self.assertEqual(new_data.local_indices, [0])
                    self.assertEqual(len(new_data.local_sol), 1)
                    self.assertEqual(new_data.leaf_to_rank_map[1], 1)

    def test_organize_comm_plans(self):
        """Test filtering communication plans."""
        dm = MagicMock(spec=domain_decomp.DomainManager)
        # Plan 1: 0 -> 1
        p1 = MagicMock(spec=domain_decomp.CommPlan)
        p1.sender_leaf_idx = 0
        p1.receiver_leaf_idx = 1
        # Plan 2: 1 -> 0
        p2 = MagicMock(spec=domain_decomp.CommPlan)
        p2.sender_leaf_idx = 1
        p2.receiver_leaf_idx = 0
        # Plan 3: 2 -> 3 (irrelevant for rank owning 0, 1)
        p3 = MagicMock(spec=domain_decomp.CommPlan)
        p3.sender_leaf_idx = 2
        p3.receiver_leaf_idx = 3

        dm.comm_plans = [p1, p2, p3]
        local_indices = [0]

        send, recv = main_loop_utils._organize_comm_plans(dm, local_indices)

        # Rank owns 0.
        # Should send in p1 (0->1)
        self.assertIn(p1, send[0])
        # Should receive in p2 (1->0)
        self.assertIn(p2, recv[0])
        # Should not see p3
        self.assertEqual(len(send), 1)

    def test_precompute_pack_ops(self):
        """Test creation of pack operators."""
        dm = MagicMock(spec=domain_decomp.DomainManager)
        local_indices = [0]

        # Plan: 0 -> 1
        plan = MagicMock(spec=domain_decomp.CommPlan)
        plan.sender_leaf_idx = 0
        plan.receiver_leaf_idx = 1
        plan.sender_indices = np.array([0, 1])
        plan.receiver_indices = np.array([0, 1])
        plan.weights = np.array([1.0, 1.0])
        plan.num_sender_indices = 2

        send_plans = {0: [plan]}

        problem = MagicMock(spec=problems.Problem)
        problem.indices = MagicMock()

        with patch("pytens_radtrans.domain_decomp.create_pack_executor") as mock_create:
            with patch("pytens_radtrans.domain_decomp.transfer_boundaries") as mock_tt:
                ops = main_loop_utils._precompute_pack_ops(
                    dm, local_indices, send_plans, 1, problem, [0], [0]
                )

                self.assertIn(0, ops)
                self.assertEqual(len(ops[0]), 1)
                self.assertEqual(ops[0][0].receiver_idx, 1)
                mock_create.assert_called()
                mock_tt.assert_called()

    def test_precompute_reconstruct_ops(self):
        """Test creation of reconstruct operators."""
        dm = MagicMock(spec=domain_decomp.DomainManager)
        # Mock leaf for receiver
        leaf = MagicMock()
        leaf.disc.grid.num_cells = [10]
        leaf.disc.grid.num_ghost = [2]
        dm.leaves = {0: leaf}  # Access by index

        local_indices = [0]

        # Plan: 1 -> 0
        plan = MagicMock(spec=domain_decomp.CommPlan)
        plan.sender_leaf_idx = 1
        plan.receiver_leaf_idx = 0
        plan.sender_indices = np.array([0])
        plan.receiver_indices = np.array([0])
        plan.weights = np.array([1.0])
        plan.num_sender_indices = 1

        recv_plans = {0: [plan]}

        problem = MagicMock(spec=problems.Problem)
        problem.indices = MagicMock()

        with patch(
            "pytens_radtrans.domain_decomp.create_reconstruct_executor"
        ) as mock_create:
            with patch("pytens_radtrans.domain_decomp.transfer_boundaries"):
                ops = main_loop_utils._precompute_reconstruct_ops(
                    dm, local_indices, recv_plans, 1, problem, [0], [0]
                )

                self.assertIn(0, ops)
                self.assertEqual(len(ops[0]), 1)
                self.assertEqual(ops[0][0].sender_idx, 1)
                mock_create.assert_called()

    def test_prepare_ghost_packages(self):
        """Test packing data for ghost exchange."""
        sol = MagicMock(spec=solver.Solution)
        sol.intensity = MagicMock()  # TensorNetwork
        sol.space = {"temp": np.array([1, 2])}

        # Mock PackOp
        op = MagicMock(spec=main_loop_utils.PackOp)
        op.receiver_idx = 1
        op.tt_func.return_value = "packed_tt"
        op.space_func.return_value = np.array([1])  # Packed array

        pack_ops = [op]
        init_data = MagicMock()

        packages = main_loop_utils.prepare_ghost_packages_for_leaf(
            sol, pack_ops, init_data
        )

        self.assertIn(1, packages)
        self.assertEqual(packages[1]["tn"], "packed_tt")
        self.assertIn("temp", packages[1]["arrays"])

    def test_aggregate_ghost_packages(self):
        """Test reconstructing and aggregating ghost data."""
        # Incoming package from sender 1
        pkg = {
            "tn": "packed_tt",
            "arrays": {
                "absorption_opacity": np.array([1]),
                "scattering_opacity": np.array([1]),
            },
        }
        incoming = {1: pkg}

        # Mock ReconstructOp
        op = MagicMock(spec=main_loop_utils.ReconstructOp)
        op.sender_idx = 1
        op.tt_func.return_value = "recon_tt"
        op.space_func.return_value = np.array([10.0])  # Reconstructed array

        ops = [op]

        updates, a_ghost, s_ghost = main_loop_utils.aggregate_ghost_packages_for_leaf(
            incoming, ops
        )

        self.assertEqual(updates, ["recon_tt"])
        self.assertEqual(a_ghost, np.array([10.0]))
        self.assertEqual(s_ghost, np.array([10.0]))

    def test_handle_adaptation_no_trigger(self):
        """Test adaptation loop when no triggers fire."""
        init_data = MagicMock(spec=main_loop_utils.InitializationData)
        config = MagicMock(spec=Config)
        # Fix: Explicitly mock refinement attribute
        config.refinement = MagicMock()
        config.refinement.enabled = False
        # Fix: Explicitly mock load_balancing attribute
        config.load_balancing = MagicMock()
        config.load_balancing.enabled = False

        result = main_loop_utils.handle_adaptation(init_data, config, self.logger, 1)

        self.assertEqual(result, init_data)

    def test_mixed_refine_coarsen_siblings(self):
        """Test that coarsening is aborted if a sibling refines in the same step."""
        # Setup: Leaf 0 wants to coarsen, Leaf 1 wants to refine.
        # They are siblings.
        config = MagicMock(spec=Config)
        config.refinement = MagicMock()
        config.refinement.enabled = True
        # FIX: Set strategy
        config.refinement.strategy = "rank"
        config.refinement.max_rank = 10
        config.refinement.min_rank = 2
        config.refinement.frequency = 1
        # FIX: Set refine_neighbors to True (default) or False, but ensure it exists
        config.refinement.refine_neighbors = True

        config.load_balancing = MagicMock()
        config.load_balancing.enabled = False
        config.load_balancing.frequency = 1

        config.solver = MagicMock()
        config.solver.rounding = MagicMock()
        config.equations = MagicMock()
        config.equations.speed_of_light = 1.0

        # Initial Topology: Parent -> [Leaf0, Leaf1]
        parent = MagicMock()
        leaf0 = MagicMock()
        leaf1 = MagicMock()
        leaf0.parent = parent
        leaf1.parent = parent
        parent.children = [leaf0, leaf1]

        # Initial DM
        dm = MagicMock(spec=domain_decomp.DomainManager)
        dm.leaves = [leaf0, leaf1]
        dm.num_domains.return_value = 2
        dm.min_dx.return_value = 0.1
        # FIX: Add leaf_neighbor_map to avoid AttributeError
        # Leaf 0 has neighbor 1, Leaf 1 has neighbor 0
        mock_n0 = MagicMock()
        mock_n0.neighbor = 1
        mock_n1 = MagicMock()
        mock_n1.neighbor = 0
        dm.leaf_neighbor_map = [
            (MagicMock(neighbors=[mock_n0]), []),
            (MagicMock(neighbors=[mock_n1]), []),
        ]

        # Refinement Logic: Leaf 1 splits into Leaf1_A, Leaf1_B
        leaf1_a = MagicMock()
        leaf1_b = MagicMock()

        # New DM after refinement
        new_dm = MagicMock(spec=domain_decomp.DomainManager)
        new_dm.leaves = [leaf0, leaf1_a, leaf1_b]  # Leaf 1 is gone!
        new_dm.num_domains.return_value = 3
        new_dm.min_dx.return_value = 0.05
        # Mock neighbor map for new DM as well (though not strictly needed)
        new_dm.leaf_neighbor_map = [None, None, None]

        # Refine Map: 0->[0], 1->[1, 2]
        refine_map = {0: [0], 1: [1, 2]}

        dm.propose_refinement.return_value = (new_dm, refine_map)

        # Init Data
        init_data = MagicMock(spec=main_loop_utils.InitializationData)
        init_data.domain_manager = dm
        init_data.local_indices = [0, 1]

        # FIX: Configure solutions for triggers
        # Leaf 0: Rank 1 (< min 2) -> Coarsen
        # Leaf 1: Rank 15 (> max 10) -> Refine
        sol0 = MagicMock()
        sol0.intensity.ranks.return_value = [1]
        sol1 = MagicMock()
        sol1.intensity.ranks.return_value = [15]

        init_data.local_sol = [sol0, sol1]
        init_data.leaf_to_rank_map = {0: 0, 1: 0}
        init_data.problem = MagicMock()
        init_data.permut = np.array([0])
        init_data.inv_permut = np.array([0])
        init_data.dimension = 1
        init_data.dt = 0.1
        init_data.domain_manager.domain_angles = MagicMock()
        init_data.monitor = MagicMock()

        with patch("pytens_radtrans.main_loop_utils.comm") as mock_comm:
            # Patch global rank
            with patch("pytens_radtrans.main_loop_utils.rank", 0):
                # Rank 0 requests: Refine [1], Coarsen [0]
                mock_comm.gather.side_effect = [
                    [[1]],  # Refine
                    [[0]],  # Coarsen
                ]
                mock_comm.bcast.side_effect = lambda val, root: val
                mock_comm.allgather.return_value = [[0, 1, 2]]  # New indices

                with (
                    patch(
                        "pytens_radtrans.main_loop_utils.refinement.split_solution"
                    ) as mock_split,
                    patch(
                        "pytens_radtrans.main_loop_utils.rebuild_topology_operators"
                    ) as mock_rebuild,
                    patch(
                        "pytens_radtrans.main_loop_utils._update_rank_map"
                    ) as mock_update_map,
                ):
                    mock_split.return_value = [MagicMock(), MagicMock()]
                    mock_update_map.return_value = (
                        {0: 0, 1: 0, 2: 0},
                        [np.array([0, 1, 2])],
                    )
                    mock_rebuild.return_value = ([], [], [], [], {}, {}, {})

                    # Run
                    # This should NOT raise KeyError
                    main_loop_utils.handle_adaptation(
                        init_data, config, self.logger, iteration=1
                    )

                    # Verify Refinement Happened
                    dm.propose_refinement.assert_called()
                    mock_split.assert_called()

                    # Verify Coarsening was ABORTED
                    # propose_coarsening should NOT be called because Leaf 0's sibling
                    # (Leaf 1) was refined, so they are no longer siblings in the new
                    # mesh.
                    dm.propose_coarsening.assert_not_called()

    def test_coarsen_migration_uses_post_refinement_rank_map(self):
        """Regression: migration lookups must use post-refinement leaf indices."""
        config = MagicMock(spec=Config)
        config.refinement = MagicMock()
        config.refinement.enabled = True
        config.refinement.strategy = "rank"
        config.refinement.max_rank = 10
        config.refinement.min_rank = 2
        config.refinement.frequency = 1
        config.refinement.refine_neighbors = False

        config.load_balancing = MagicMock()
        config.load_balancing.enabled = False
        config.load_balancing.frequency = 1

        config.solver = MagicMock()
        config.solver.rounding = MagicMock()
        config.solver.cfl = 0.5
        config.equations = MagicMock()
        config.equations.speed_of_light = 1.0

        old_dm = MagicMock(spec=domain_decomp.DomainManager)
        old_dm.leaves = [MagicMock() for _ in range(4)]
        old_dm.num_domains.return_value = 4
        old_dm.min_dx.return_value = 0.1
        old_dm.domain_angles = MagicMock()
        old_dm.leaf_neighbor_map = [None] * 4

        new_dm = MagicMock(spec=domain_decomp.DomainManager)
        parent = MagicMock()
        leaf4 = MagicMock()
        leaf5 = MagicMock()
        leaf4.parent = parent
        leaf5.parent = parent
        parent.children = [leaf4, leaf5]

        leaf0 = MagicMock()
        leaf1 = MagicMock()
        leaf2 = MagicMock()
        leaf3 = MagicMock()
        for leaf in [leaf0, leaf1, leaf2, leaf3]:
            leaf.parent = None

        new_dm.leaves = [leaf0, leaf1, leaf2, leaf3, leaf4, leaf5]
        new_dm.num_domains.return_value = 6
        new_dm.min_dx.return_value = 0.1
        new_dm.domain_angles = MagicMock()
        new_dm.propose_coarsening.return_value = (
            new_dm,
            {i: i for i in range(new_dm.num_domains.return_value)},
        )

        # Refinement remaps old leaves to new indices.
        old_dm.propose_refinement.return_value = (
            new_dm,
            {0: [4], 1: [5], 2: [2], 3: [3]},
        )

        init_data = MagicMock(spec=main_loop_utils.InitializationData)
        init_data.domain_manager = old_dm
        init_data.local_indices = [0]
        local_sol = MagicMock()
        local_sol.intensity.ranks.return_value = [1]
        init_data.local_sol = [local_sol]
        init_data.leaf_to_rank_map = {0: 0, 1: 1, 2: 0, 3: 1}
        init_data.problem = MagicMock()
        init_data.permut = np.array([0])
        init_data.inv_permut = np.array([0])
        init_data.dimension = 1
        init_data.dt = 0.1
        init_data.monitor = MagicMock()

        with patch("pytens_radtrans.main_loop_utils.comm") as mock_comm:
            with patch("pytens_radtrans.main_loop_utils.rank", 0):
                mock_comm.gather.side_effect = [
                    [[2], []],  # Refine requests
                    [[0], [1]],  # Coarsen requests
                ]
                mock_comm.bcast.side_effect = lambda val, root: val

                with (
                    patch(
                        "pytens_radtrans.main_loop_utils.comms.transfer_solutions"
                    ) as mock_transfer,
                    patch(
                        "pytens_radtrans.main_loop_utils.rebuild_topology_operators"
                    ) as mock_rebuild,
                    patch(
                        "pytens_radtrans.main_loop_utils._update_rank_map"
                    ) as mock_update_map,
                ):
                    mock_transfer.return_value = []
                    mock_rebuild.return_value = ([], [], [], [], {}, {}, {})
                    mock_update_map.return_value = (
                        {0: 0, 1: 1, 2: 0, 3: 1, 4: 0, 5: 1},
                        [np.array([4])],
                    )

                    result = main_loop_utils.handle_adaptation(
                        init_data, config, self.logger, iteration=1
                    )

                    self.assertEqual(result.local_indices, [4])
                    args, _ = mock_transfer.call_args
                    incoming_expectations = args[1]
                    self.assertIn((1, 5), incoming_expectations)

    def test_coarsen_migration_does_not_rebuild_rank_map_before_transfer(self):
        """Regression: avoid premature rank-map reconstruction in coarsen migration."""
        config = MagicMock(spec=Config)
        config.refinement = MagicMock()
        config.refinement.enabled = True
        config.refinement.strategy = "rank"
        config.refinement.max_rank = 10
        config.refinement.min_rank = 2
        config.refinement.frequency = 1
        config.refinement.refine_neighbors = False

        config.load_balancing = MagicMock()
        config.load_balancing.enabled = False
        config.load_balancing.frequency = 1

        config.solver = MagicMock()
        config.solver.rounding = MagicMock()
        config.solver.cfl = 0.5
        config.equations = MagicMock()
        config.equations.speed_of_light = 1.0

        old_dm = MagicMock(spec=domain_decomp.DomainManager)
        old_dm.leaves = [MagicMock() for _ in range(4)]
        old_dm.num_domains.return_value = 4
        old_dm.min_dx.return_value = 0.1
        old_dm.domain_angles = MagicMock()
        old_dm.leaf_neighbor_map = [None] * 4

        refined_dm = MagicMock(spec=domain_decomp.DomainManager)
        parent = MagicMock()
        leaf4 = MagicMock()
        leaf5 = MagicMock()
        merge_parent_disc = Discretization.from_geom([0.0], [1.0], [4], [0])
        merge_child_discs = merge_parent_disc.split()
        leaf4.disc = merge_child_discs[0]
        leaf5.disc = merge_child_discs[1]
        leaf4.parent = parent
        leaf5.parent = parent
        parent.children = [leaf4, leaf5]
        leaf0 = MagicMock()
        leaf1 = MagicMock()
        leaf2 = MagicMock()
        leaf3 = MagicMock()
        for leaf in [leaf0, leaf1, leaf2, leaf3]:
            leaf.parent = None
        refined_dm.leaves = [leaf0, leaf1, leaf2, leaf3, leaf4, leaf5]
        refined_dm.num_domains.return_value = 6
        refined_dm.min_dx.return_value = 0.05
        refined_dm.domain_angles = MagicMock()

        # Coarsen 4 and 5 into 4 (domains 6 -> 5).
        coarsened_dm = MagicMock(spec=domain_decomp.DomainManager)
        coarsened_dm.num_domains.return_value = 5
        coarsened_dm.min_dx.return_value = 0.05
        coarsened_dm.domain_angles = MagicMock()
        coarsened_parent_leaf = MagicMock()
        coarsened_parent_leaf.parent = None
        coarsened_parent_leaf.disc = merge_parent_disc
        coarsened_dm.leaves = [
            MagicMock(),
            MagicMock(),
            MagicMock(),
            MagicMock(),
            coarsened_parent_leaf,
        ]

        old_dm.propose_refinement.return_value = (
            refined_dm,
            {0: [4], 1: [5], 2: [2], 3: [3]},
        )
        refined_dm.propose_coarsening.return_value = (
            coarsened_dm,
            {0: 0, 1: 1, 2: 2, 3: 3, 4: 4, 5: 4},
        )

        init_data = MagicMock(spec=main_loop_utils.InitializationData)
        init_data.domain_manager = old_dm
        init_data.local_indices = [0]
        sol0 = MagicMock()
        sol0.intensity.ranks.return_value = [1]
        init_data.local_sol = [sol0]
        init_data.leaf_to_rank_map = {0: 0, 1: 1, 2: 0, 3: 1}
        init_data.problem = MagicMock()
        init_data.permut = np.array([0])
        init_data.inv_permut = np.array([0])
        init_data.dimension = 1
        init_data.dt = 0.1
        init_data.monitor = MagicMock()

        transfer_done = {"value": False}

        with patch("pytens_radtrans.main_loop_utils.comm") as mock_comm:
            with patch("pytens_radtrans.main_loop_utils.rank", 0):
                mock_comm.gather.side_effect = [
                    [[2], []],  # Refine requests
                    [[0], [1]],  # Coarsen requests
                ]
                mock_comm.bcast.side_effect = lambda val, root: val

                with (
                    patch(
                        "pytens_radtrans.main_loop_utils.comms.transfer_solutions"
                    ) as mock_transfer,
                    patch(
                        "pytens_radtrans.main_loop_utils.refinement.merge_solution"
                    ) as mock_merge,
                    patch(
                        "pytens_radtrans.main_loop_utils.rebuild_topology_operators"
                    ) as mock_rebuild,
                    patch(
                        "pytens_radtrans.main_loop_utils._update_rank_map"
                    ) as mock_update_map,
                ):

                    def _transfer_side_effect(*_args, **_kwargs):
                        transfer_done["value"] = True
                        incoming_sol = MagicMock()
                        incoming_sol.intensity = MagicMock()
                        incoming_sol.space = {}
                        incoming_sol.aux = {}
                        incoming_sol.time = 0.0
                        return [(5, incoming_sol)]

                    def _update_rank_map_side_effect(local_indices, *_args, **_kwargs):
                        # Before transfer, this mirrors the production failure path:
                        # a premature rank-map rebuild can fail on mixed topologies.
                        if not transfer_done["value"]:
                            raise RuntimeError(
                                "Rank map reconstruction failed: Missing domains."
                            )
                        return ({0: 1, 1: 1, 2: 0, 3: 1, 4: 0}, [np.array([4])])

                    mock_transfer.side_effect = _transfer_side_effect
                    mock_merge.return_value = MagicMock()
                    mock_rebuild.return_value = ([], [], [], [], {}, {}, {})
                    mock_update_map.side_effect = _update_rank_map_side_effect

                    result = main_loop_utils.handle_adaptation(
                        init_data, config, self.logger, iteration=1
                    )

                    self.assertEqual(result.local_indices, [4])
                    self.assertTrue(transfer_done["value"])
                    mock_merge.assert_called_once()

    def test_load_balancing_gather_mismatch_raises(self):
        """LB gather must provide one weight per gathered local index."""
        config = MagicMock(spec=Config)
        config.refinement = MagicMock()
        config.refinement.enabled = False
        config.refinement.frequency = 1

        config.load_balancing = MagicMock()
        config.load_balancing.enabled = True
        config.load_balancing.frequency = 1
        config.load_balancing.strategy = "count"
        config.load_balancing.imbalance_threshold = 1.01

        init_data = MagicMock(spec=main_loop_utils.InitializationData)
        init_data.domain_manager = MagicMock(spec=domain_decomp.DomainManager)
        init_data.domain_manager.num_domains.return_value = 2
        init_data.local_indices = [0]
        init_data.local_sol = [MagicMock()]

        with patch("pytens_radtrans.main_loop_utils.comm") as mock_comm:
            with (
                patch("pytens_radtrans.main_loop_utils.rank", 0),
                patch("pytens_radtrans.main_loop_utils.size", 2),
            ):
                mock_comm.gather.side_effect = [
                    [[1.0], [2.0, 3.0]],  # weights gathered from 2 ranks
                    [[0], [1]],  # indices gathered from 2 ranks
                ]
                mock_comm.bcast.side_effect = lambda val, root: val

                with self.assertRaisesRegex(
                    RuntimeError, "Load balancing gather mismatch"
                ):
                    main_loop_utils.handle_adaptation(
                        init_data, config, self.logger, iteration=1
                    )

    def test_ranks_summary(self):
        """Test logging rank summary."""
        init_data = MagicMock()
        sol = MagicMock()
        sol.intensity.ranks.return_value = [5, 5]
        init_data.local_sol = [sol]

        with patch("pytens_radtrans.main_loop_utils.comm") as mock_comm:
            # Patch global rank
            with patch("pytens_radtrans.main_loop_utils.rank", 0):
                mock_comm.gather.return_value = [[[5, 5]]]

                with self.assertLogs(self.logger, level="INFO") as cm:
                    main_loop_utils.ranks_summary(init_data, self.logger)
                    self.assertTrue(any("TT Ranks Summary" in o for o in cm.output))
