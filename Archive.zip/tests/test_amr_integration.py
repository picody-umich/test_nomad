"""Integration tests for the full AMR cycle."""

import logging
import shutil
import tempfile
import unittest
from pathlib import Path

from pytens_radtrans import main_loop
from pytens_radtrans.load_config import Config

# Configure logging to capture output
logging.basicConfig(level=logging.INFO)
logger = logging.getLogger("test_amr_integration")


class TestAMRIntegration(unittest.TestCase):
    def setUp(self):
        self.test_dir = Path(tempfile.mkdtemp())

    def tearDown(self):
        shutil.rmtree(self.test_dir)

    def test_refinement_cycle_1d(self):
        """Test that a 1D simulation can refine and continue running."""
        config_dict = {
            "problem": {"name": "gaussian diffusion", "A": 1.0, "t0": 0.1},
            "geometry": {
                "dimension": 1,
                "lb": [0.0],
                "ub": [1.0],
                "n": [10],
                "n_ghost": [2],
                "domain_decomp": 0,  # Start with 1 domain
            },
            "angles": {"n_theta": 4, "n_phi": 1},
            "equations": {
                "speed_of_light": 1.0,
                "source": {"name": "none"},
                # Add density to satisfy problem assertion
                "density": 1.0,
                "specific_scattering_opacity": 1.0,
            },
            "solver": {
                "cfl": 0.5,
                "stencil": {"name": "upwind"},
                "method": "forward euler",
                "num_steps": 5,  # Run for a few steps
                "rounding": {
                    "method": "svd",
                    "tol": 1e-5,
                    "freq": 1,
                    "tt_sum": False,
                    "rank_increase_bound": 10,
                },
                "order": ["x", "theta", "phi"],
            },
            "saving": {
                "directory": str(self.test_dir),
                "plot_freq": 10,
                "checkpoint_freq": 10,
                "spatial_save_freq": 10,
            },
            "refinement": {
                "enabled": True,
                "strategy": "rank",
                "max_rank": 2,
                "min_rank": 1,
            },
        }
        config = Config(**config_dict)

        # Run the main loop
        main_loop.main_loop(config, logger, self.test_dir)

    def test_refinement_cycle_2d(self):
        """Test that a 2D simulation can refine and continue running."""
        config_dict = {
            "problem": {"name": "gaussian diffusion", "A": 1.0, "t0": 0.1},
            "geometry": {
                "dimension": 2,
                "lb": [0.0, 0.0],
                "ub": [1.0, 1.0],
                "n": [8, 8],
                "n_ghost": [2, 2],
                "domain_decomp": 0,  # Start with 1 domain
            },
            "angles": {"n_theta": 4, "n_phi": 1},
            "equations": {
                "speed_of_light": 1.0,
                "source": {"name": "none"},
                # Add density to satisfy problem assertion
                "density": 1.0,
                "specific_scattering_opacity": 1.0,
            },
            "solver": {
                "cfl": 0.5,
                "stencil": {"name": "upwind"},
                "method": "forward euler",
                "num_steps": 3,  # Short run
                "rounding": {
                    "method": "svd",
                    "tol": 1e-5,
                    "freq": 1,
                    "tt_sum": False,
                    "rank_increase_bound": 10,
                },
                # FIX: Order must be ["x", "theta", "phi"] even for 2D
                "order": ["x", "theta", "phi"],
            },
            "saving": {
                "directory": str(self.test_dir),
                "plot_freq": 10,
                "checkpoint_freq": 10,
                "spatial_save_freq": 10,
            },
            "refinement": {
                "enabled": True,
                "strategy": "rank",
                "max_rank": 2,
                "min_rank": 1,
            },
        }
        config = Config(**config_dict)

        main_loop.main_loop(config, logger, self.test_dir)


if __name__ == "__main__":
    unittest.main()
