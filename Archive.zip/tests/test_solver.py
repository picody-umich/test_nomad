import pathlib
import pickle
from unittest.mock import MagicMock, patch

import numpy as np
import pytens
import pytest
from pydantic import BaseModel

from pytens_radtrans import solver
from pytens_radtrans.discretization import (
    AngleDiscretization,
    Discretization,
    Grid,
    Indices,
)
from pytens_radtrans.load_config import (
    APFStencil,
    Config,
    Equations,
    Geometry,
    IdealGas,
    NoSource,
    RusanovStencil,
    Solver,
    UpwindStencil,
)
from pytens_radtrans.utils import TNOPList


@pytest.fixture
def base_config() -> Config:
    """Returns a minimal, valid Config object."""
    return Config(
        problem={"name": "gaussian diffusion", "A": 1.0, "t0": 0.1},
        geometry=Geometry(
            dimension=1,
            lb=[0.0],
            ub=[1.0],
            n=[10],
            n_ghost=[2],
            domain_decomp=0,
        ),
        angles={"n_theta": 8, "n_phi": 8},
        equations=Equations(
            speed_of_light=1.0,
            radiation_constant=1.0,
            source={"name": "none"},
        ),
        solver=Solver(
            order=["x", "theta", "phi"],
            cfl=0.1,
            method="forward euler",
            num_steps=10,
            rounding={"method": "svd", "tol": 1e-8, "freq": 10},
            stencil={"name": "upwind"},
        ),
        saving={"directory": "test", "plot_freq": 1000},
    )


@pytest.fixture
def simple_discretization() -> Discretization:
    """A simple 1D spatial discretization."""
    edges = np.linspace(0, 1, 5)
    centers = (edges[:-1] + edges[1:]) / 2
    grid = Grid(
        cell_centers=(centers,),
        cell_edges=(edges,),
        dx=(0.25,),
        num_cells=(4,),
        num_ghost=(1,),
    )
    return Discretization(dimension=1, grid=grid)


@pytest.fixture
def simple_angle_discretization(base_config: Config) -> AngleDiscretization:
    """A simple angle discretization."""
    return AngleDiscretization.from_config(base_config)


@pytest.fixture
def simple_indices(simple_discretization: Discretization) -> Indices:
    """Simple indices for a 1D problem."""
    # A mock config that has just enough info for Indices.from_config
    mock_config = MagicMock()
    mock_config.geometry = MagicMock()
    mock_config.angles = MagicMock()

    mock_config.geometry.dimension = 1
    mock_config.geometry.n = [simple_discretization.num_space()]
    mock_config.angles.n_theta = 8
    mock_config.angles.n_phi = 8
    return Indices.from_config(mock_config)


def create_mock_solution(
    time: float,
    intensity_val: np.ndarray,
    space: dict[str, np.ndarray] | None,
) -> solver.Solution:
    """Helper to create a solution with a mock intensity tensor."""
    mock_intensity = MagicMock(spec=pytens.TensorNetwork)
    mock_intensity.contract.return_value.value = intensity_val
    mock_intensity.integrate.return_value = mock_intensity
    mock_intensity.__mul__ = lambda self, other: other
    return solver.Solution(time, mock_intensity, space)


class TestSolution:
    def test_solution_init(self):
        """Test the Solution class constructor."""
        time = 1.0
        intensity = MagicMock(spec=pytens.TensorNetwork)
        space = {"temperature": np.ones(10)}
        sol = solver.Solution(time, intensity, space)

        assert sol.time == time
        assert sol.intensity is intensity
        assert sol.space is space
        assert sol.aux == {}

    def test_solution_save_and_load(self, tmp_path: pathlib.Path):
        """Test saving a Solution object to a file and loading it back."""
        filepath = tmp_path / "solution.pkl"
        indices = [pytens.Index("i", 3), pytens.Index("j", 3)]
        tensor = pytens.Tensor(np.arange(9).reshape(3, 3), indices)
        intensity_tn = pytens.TensorNetwork()
        intensity_tn.add_node(0, tensor)
        original_sol = solver.Solution(
            time=0.5,
            intensity=intensity_tn,
            space={"density": np.array([1.0, 2.0])},
        )
        original_sol.aux = {"mean_intensity": np.array([0.5, 0.6])}

        original_sol.save(filepath)
        loaded_sol = solver.Solution.from_file(filepath)

        assert isinstance(loaded_sol, solver.Solution)
        assert loaded_sol.time == original_sol.time
        assert np.allclose(
            loaded_sol.intensity.contract().value,
            original_sol.intensity.contract().value,
        )
        assert loaded_sol.space is not None
        assert np.allclose(loaded_sol.space["density"], original_sol.space["density"])
        assert np.allclose(
            loaded_sol.aux["mean_intensity"], original_sol.aux["mean_intensity"]
        )
        with pytest.raises(FileNotFoundError):
            solver.Solution.from_file(pathlib.Path("nonexistent.pkl"))

        # Test assertion for wrong type
        with open(filepath, "wb") as f:
            pickle.dump("not a solution", f)
        with pytest.raises(AssertionError):
            solver.Solution.from_file(filepath)


class TestGetTransportTerm:
    @pytest.mark.parametrize(
        "stencil_name, stencil_config, stencil_class_path",
        [
            (
                "upwind",
                UpwindStencil(name="upwind"),
                "pytens_radtrans.stencil.UpwindStencil",
            ),
            (
                "rusanov",
                RusanovStencil(name="rusanov", wave_speed=1.0),
                "pytens_radtrans.stencil.RusanovStencil",
            ),
            (
                "jiang",
                APFStencil(
                    name="jiang",
                    beta=0.5,
                    tau_threshold=0.1,
                    alpha_threshold=0.1,
                ),
                "pytens_radtrans.stencil.JiangStencil",
            ),
        ],
    )
    def test_get_transport_term_stencil_selection(
        self,
        stencil_name,
        stencil_config,
        stencil_class_path,
        base_config,
        simple_indices,
        simple_discretization,
        simple_angle_discretization,
    ):
        """Verify that the correct stencil class is instantiated."""
        base_config.solver.stencil = stencil_config
        scale = 1.0

        with patch(stencil_class_path) as MockStencil:
            mock_instance = MockStencil.return_value
            transport_func = solver.get_transport_term(
                simple_indices,
                simple_discretization,
                simple_angle_discretization,
                base_config,
                scale,
            )
            assert callable(transport_func)
            MockStencil.assert_called_once()
            mock_instance.get_ttop.assert_called_once_with(simple_indices, scale, None)

    def test_get_transport_term_not_implemented(
        self,
        base_config,
        simple_indices,
        simple_discretization,
        simple_angle_discretization,
    ):
        """Test that an unsupported stencil raises NotImplementedError."""

        class UnknownStencil(BaseModel):
            name: str = "unknown"

        base_config.solver.stencil = UnknownStencil()
        with pytest.raises(NotImplementedError):
            solver.get_transport_term(
                simple_indices,
                simple_discretization,
                simple_angle_discretization,
                base_config,
                1.0,
            )


class TestMeanIntensity:
    def test_mean_intensity_constant(self, simple_indices, simple_angle_discretization):
        """Test mean intensity for a constant, isotropic field."""
        num_space = 4
        num_theta = simple_angle_discretization.theta.shape[0]
        num_phi = simple_angle_discretization.phi.shape[0]

        # J = 1.0 -> Intensity = 1.0
        # Integrated intensity over angle = I * 4pi = 4pi
        # Mean intensity J = (Integrated Intensity) / 4pi = 1.0
        intensity_vals = np.ones((num_space, num_theta, num_phi))
        indices = [simple_indices.space, simple_indices.theta, simple_indices.phi]
        tensor = pytens.Tensor(intensity_vals, indices)
        intensity_tn = pytens.TensorNetwork()
        intensity_tn.add_node(0, tensor)

        result = solver.mean_intensity(
            simple_indices, simple_angle_discretization, intensity_tn
        )

        assert result.shape == (num_space,)
        assert np.allclose(result, 1.0)

    def test_mean_intensity_spatially_varying(
        self, simple_indices, simple_angle_discretization
    ):
        """Test mean intensity for a spatially varying, isotropic field."""
        space_vals = np.array([1.0, 2.0, 3.0, 4.0])
        num_space = len(space_vals)
        num_theta = simple_angle_discretization.theta.shape[0]
        num_phi = simple_angle_discretization.phi.shape[0]

        # Intensity varies with space, constant with angle
        intensity_vals = np.ones((num_space, num_theta, num_phi))
        intensity_vals *= space_vals[:, np.newaxis, np.newaxis]
        indices = [simple_indices.space, simple_indices.theta, simple_indices.phi]
        tensor = pytens.Tensor(intensity_vals, indices)
        intensity_tn = pytens.TensorNetwork()
        intensity_tn.add_node(0, tensor)

        result = solver.mean_intensity(
            simple_indices, simple_angle_discretization, intensity_tn
        )

        assert result.shape == (num_space,)
        assert np.allclose(result, space_vals)


@pytest.fixture
def ideal_gas_config(base_config: Config) -> Config:
    """Fixture for a config with an IdealGas source."""
    base_config.equations.source = IdealGas(
        name="ideal gas", specific_heat_capacity=1.0
    )
    # Use a single spatial cell for simplicity in logic tests
    base_config.geometry.n = [1]
    return base_config


@pytest.fixture
def temp_eq_discretization(ideal_gas_config: Config) -> Discretization:
    return Discretization.from_config(ideal_gas_config)


@pytest.fixture
def temp_eq_indices(ideal_gas_config: Config) -> Indices:
    return Indices.from_config(ideal_gas_config)


class TestTempEquationIdealGas:
    def test_value_error_if_cv_is_none(
        self,
        ideal_gas_config,
        temp_eq_indices,
        simple_angle_discretization,
    ):
        """Test that a ValueError is raised if specific_heat_capacity is not set."""
        ideal_gas_config.equations.source.specific_heat_capacity = None
        mock_sol = create_mock_solution(0.0, np.array([]), {})
        with pytest.raises(ValueError, match="Specific heat capacity must be defined"):
            solver.temp_equation_ideal_gas(
                temp_eq_indices,
                simple_angle_discretization,
                0.1,
                mock_sol,
                ideal_gas_config,
            )

    def test_temp_equation_logic(
        self,
        ideal_gas_config,
        temp_eq_indices,
        simple_angle_discretization,
    ):
        """Test the core logic of the temperature equation update."""
        # Setup: 1 spatial cell, 1 theta, 1 phi for simplicity
        ideal_gas_config.angles.n_theta = 2  # min is 2
        ideal_gas_config.angles.n_phi = 2
        angle_disc = AngleDiscretization.from_config(ideal_gas_config)

        dt = 1.0
        # All constants to 1.0 for simple math
        ideal_gas_config.equations.speed_of_light = 1.0
        ideal_gas_config.equations.radiation_constant = 1.0
        ideal_gas_config.equations.source.specific_heat_capacity = 1.0

        space_sol = {
            "absorption_opacity": np.array([1.0]),
            "scattering_opacity": np.array([1.0]),
            "density": np.array([1.0]),
            "temperature": np.array([2.0]),
        }
        # Mock intensity to produce a known mean intensity (J)
        # --- Manual Calculation for Verification ---
        # c=1, dt=1, cdt=1, cv=1, density=1, a=1
        # alpha_a=1, alpha_s=1, T=2, J=3
        cdt, c4pi = 1.0, 1.0 / (4 * np.pi)
        alpha_a, alpha_s, density, T_curr = 1.0, 1.0, 1.0, 2.0
        cv = 1.0
        J = 3.0

        xi_a = (1.0 / cdt + alpha_a) ** -1  # (1+1)^-1 = 0.5
        zeta_a = alpha_a / (density * cv)  # 1 / (1*1) = 1.0
        const_term = -zeta_a * xi_a / c4pi * J - T_curr  # -1*0.5/(c4pi)*3 - 2
        fourth_term = zeta_a * xi_a * 1.0  # 1*0.5*1 = 0.5

        # Using mocked T'=1.5
        Tprime = 1.5
        term2 = alpha_a * c4pi * 1.0 * Tprime**4  # 1*c4pi*1 * 1.5^4
        Jprime = xi_a * (J / cdt + term2)  # 0.5 * (3/1 + term2)
        xi_t = (1.0 / cdt + alpha_a + alpha_s) ** -1  # (1+1+1)^-1 = 1/3
        const_term_intensity = xi_t * term2 + xi_t * alpha_s * Jprime

        with patch("pytens_radtrans.solver.mean_intensity") as mock_mean_intensity:
            # The solver calls mean_intensity three times. The first two get J from
            # the original intensity, the third gets the mean of the additive term.
            mock_mean_intensity.side_effect = [
                np.array([J]),
                np.array([J]),
                const_term_intensity,
            ]
            mock_sol = create_mock_solution(0.0, np.array([]), space_sol)
            mock_sol.intensity = MagicMock()

            # Mock quartic solve to return a predictable value
            with patch("pytens_radtrans.solver.quartic_solve") as mock_quartic:
                # T' = 1.5
                mock_quartic.return_value = np.array([1.5])
                next_intensity_tnop, next_temp = solver.temp_equation_ideal_gas(
                    temp_eq_indices, angle_disc, dt, mock_sol, ideal_gas_config
                )

        mock_quartic.assert_called_once()
        assert np.allclose(mock_quartic.call_args[0][0], fourth_term)
        assert np.allclose(mock_quartic.call_args[0][1], const_term)

        # Expected final temperature
        # den = c*density*cv = 1
        # next_mean_intensity = J * scale_term + mean(const_term)
        # scale_term is (1/cdt + a_a+a_s)^-1 / cdt = (1+1+1)^-1 / 1 = 1/3
        # The final temperature calculation is complex. We will trust the solver's
        # implementation and only verify that the inputs to the quartic solver
        # are correct, as this is the most critical pre-computation step.
        assert isinstance(next_intensity_tnop, TNOPList)
        assert next_temp is not None

    def test_zero_absorption_opacity(
        self,
        ideal_gas_config,
        temp_eq_indices,
        simple_angle_discretization,
    ):
        """If absorption is zero, temperature should not change."""
        dt = 0.1
        space_sol = {
            "absorption_opacity": np.array([0.0]),
            "scattering_opacity": np.array([1.0]),
            "density": np.array([1.0]),
            "temperature": np.array([100.0]),
        }
        mock_sol = create_mock_solution(0.0, np.array([]), space_sol)
        mock_sol.intensity = MagicMock()

        with patch(
            "pytens_radtrans.solver.mean_intensity", return_value=np.array([5.0])
        ):
            _, next_temp = solver.temp_equation_ideal_gas(
                temp_eq_indices,
                simple_angle_discretization,
                dt,
                mock_sol,
                ideal_gas_config,
            )

        assert np.allclose(next_temp, space_sol["temperature"])


class TestScatterSource:
    def test_no_source(
        self, ideal_gas_config, temp_eq_indices, simple_angle_discretization
    ):
        """Test that an empty TNOPList is returned for NoSource config."""
        ideal_gas_config.equations.source = NoSource(name="none")
        mock_sol = create_mock_solution(0.0, np.array([]), {})
        result = solver.scatter_source(
            temp_eq_indices,
            simple_angle_discretization,
            0.1,
            mock_sol,
            ideal_gas_config,
        )
        assert isinstance(result, TNOPList)
        assert not result.tt_list

    def test_scatter_logic(self, ideal_gas_config):
        """Test the core logic of the scatter source term."""
        ideal_gas_config.angles.n_theta = 2
        ideal_gas_config.angles.n_phi = 2
        temp_eq_indices = Indices.from_config(ideal_gas_config)
        angle_disc = AngleDiscretization.from_config(ideal_gas_config)

        dt = 1.0
        ideal_gas_config.equations.speed_of_light = 1.0
        cdt = 1.0
        alpha_s_val = 2.0
        space_sol = {"scattering_opacity": np.array([alpha_s_val])}
        intensity_val = 5.0
        J_val = intensity_val  # Isotropic

        # Mock Solution and mean_intensity
        mock_sol = create_mock_solution(0.0, np.array([intensity_val]), space_sol)
        mock_sol.intensity = pytens.tt_rank1(
            [temp_eq_indices.space, temp_eq_indices.theta, temp_eq_indices.phi],
            [
                np.full((temp_eq_indices.space.size,), intensity_val),
                np.ones(temp_eq_indices.theta.size),
                np.ones(temp_eq_indices.phi.size),
            ],
        )
        with patch(
            "pytens_radtrans.solver.mean_intensity", return_value=np.array([J_val])
        ):
            result_tnop = solver.scatter_source(
                temp_eq_indices, angle_disc, dt, mock_sol, ideal_gas_config
            )

        # Manual calculation
        xi_t = (1.0 / cdt + alpha_s_val) ** -1  # (1/1 + 2)^-1 = 1/3
        const_term = xi_t * alpha_s_val * J_val  # 1/3 * 2 * 5 = 10/3
        scale_term = xi_t / cdt  # (1/3) / 1 = 1/3

        expected_intensity = intensity_val * scale_term + const_term
        # (5 * 1/3) + 10/3 = 5/3 + 10/3 = 15/3 = 5.0
        assert np.allclose(expected_intensity, 5.0)

        evaluated_result = result_tnop.evaluate().contract().value
        assert np.allclose(evaluated_result, expected_intensity)

    def test_zero_scattering_opacity(self, ideal_gas_config):
        """With zero scattering, intensity should only be scaled by 1/cdt."""
        ideal_gas_config.angles.n_theta = 2
        ideal_gas_config.angles.n_phi = 2
        temp_eq_indices = Indices.from_config(ideal_gas_config)
        angle_disc = AngleDiscretization.from_config(ideal_gas_config)
        dt = 0.5
        ideal_gas_config.equations.speed_of_light = 2.0
        cdt = 1.0
        intensity_val = 10.0

        space_sol = {"scattering_opacity": np.array([0.0])}
        mock_sol = create_mock_solution(0.0, np.array([intensity_val]), space_sol)
        mock_sol.intensity = pytens.tt_rank1(
            [temp_eq_indices.space, temp_eq_indices.theta, temp_eq_indices.phi],
            [
                np.full((temp_eq_indices.space.size,), intensity_val),
                np.ones(temp_eq_indices.theta.size),
                np.ones(temp_eq_indices.phi.size),
            ],
        )
        with patch(
            "pytens_radtrans.solver.mean_intensity", return_value=np.array([0.0])
        ):
            result_tnop = solver.scatter_source(
                temp_eq_indices, angle_disc, dt, mock_sol, ideal_gas_config
            )

        # Manual calculation
        xi_t = (1.0 / cdt + 0.0) ** -1  # 1.0
        scale_term = xi_t / cdt  # 1.0 / 1.0 = 1.0
        const_term = 0.0
        expected_intensity = intensity_val * scale_term + const_term
        assert np.allclose(expected_intensity, intensity_val)

        evaluated_result = result_tnop.evaluate().contract().value
        assert np.allclose(evaluated_result, expected_intensity)
