"""Tests for discretization.py."""

import numpy as np
import pytens
import pytest
from pytest_mock import MockerFixture

from pytens_radtrans.discretization import (
    AngleDiscretization,
    Discretization,
    Grid,
    Indices,
)


class TestIndices:
    """Tests for the Indices class."""

    def test_initialization(self) -> None:
        """Test that an Indices object can be created and its attributes
        are set correctly.
        """
        space_idx = pytens.Index("x", 10)
        theta_idx = pytens.Index("theta", 4)
        phi_idx = pytens.Index("phi", 8)
        indices = Indices(dimension=1, space=space_idx, theta=theta_idx, phi=phi_idx)

        assert indices.dimension == 1
        assert indices.space == space_idx
        assert indices.theta == theta_idx
        assert indices.phi == phi_idx

    def test_increase_space_index(self) -> None:
        """Test that increase_space_index returns a new Indices object
        with space index size incremented.
        """
        space_idx = pytens.Index("x", 10)
        theta_idx = pytens.Index("theta", 4)
        phi_idx = pytens.Index("phi", 8)
        initial_indices = Indices(
            dimension=1, space=space_idx, theta=theta_idx, phi=phi_idx
        )

        increase_by = 5
        new_indices = initial_indices.increase_space_index(increase_by)

        assert new_indices.space.size == initial_indices.space.size + increase_by
        assert new_indices.dimension == initial_indices.dimension
        assert new_indices.theta == initial_indices.theta
        assert new_indices.phi == initial_indices.phi
        assert (
            initial_indices.space.size == 10
        ), "Original object should not be modified."

    def test_from_config(self, mocker: MockerFixture) -> None:
        """Test that the Indices object is instantiated with correct values
        from config.
        """
        # Create a mock config object with the required nested structure
        mock_config = mocker.MagicMock()
        mock_config.geometry.dimension = 2
        mock_config.geometry.n = [10, 20]
        mock_config.angles.n_theta = 4
        mock_config.angles.n_phi = 8

        indices = Indices.from_config(mock_config)

        assert indices.dimension == 2
        assert indices.space.name == "x"
        assert indices.space.size == 200  # 10 * 20
        assert indices.theta.name == "theta"
        assert indices.theta.size == 4
        assert indices.phi.name == "phi"
        assert indices.phi.size == 8


class TestGrid:
    """Tests for the Grid class."""

    def test_initialization_1d(self) -> None:
        """Test that a 1D Grid object is initialized correctly."""
        cell_centers = (np.array([0.5, 1.5]),)
        cell_edges = (np.array([0.0, 1.0, 2.0]),)
        dx = (1.0,)
        num_cells = (2,)
        num_ghost = (2,)

        grid = Grid(
            cell_centers=cell_centers,
            cell_edges=cell_edges,
            dx=dx,
            num_cells=num_cells,
            num_ghost=num_ghost,
        )

        assert np.array_equal(grid.cell_centers[0], cell_centers[0])
        assert np.array_equal(grid.cell_edges[0], cell_edges[0])
        assert grid.dx == dx
        assert grid.num_cells == num_cells
        assert grid.num_ghost == num_ghost

    def test_initialization_2d(self) -> None:
        """Test that a 2D Grid object is initialized correctly."""
        cell_centers = (np.array([0.5, 1.5]), np.array([0.25, 0.75]))
        cell_edges = (np.array([0.0, 1.0, 2.0]), np.array([0.0, 0.5, 1.0]))
        dx = (1.0, 0.5)
        num_cells = (2, 2)
        num_ghost = (2, 4)

        grid = Grid(
            cell_centers=cell_centers,
            cell_edges=cell_edges,
            dx=dx,
            num_cells=num_cells,
            num_ghost=num_ghost,
        )

        assert np.array_equal(grid.cell_centers[0], cell_centers[0])
        assert np.array_equal(grid.cell_centers[1], cell_centers[1])
        assert np.array_equal(grid.cell_edges[0], cell_edges[0])
        assert np.array_equal(grid.cell_edges[1], cell_edges[1])
        assert grid.dx == dx
        assert grid.num_cells == num_cells
        assert grid.num_ghost == num_ghost


class TestAngleDiscretization:
    """Tests for the AngleDiscretization class."""

    def test_from_config(self, mocker: MockerFixture) -> None:
        """Test that AngleDiscretization is created correctly from config."""
        mock_config = mocker.MagicMock()
        mock_config.angles.n_theta = 2
        mock_config.angles.n_phi = 4

        ad = AngleDiscretization.from_config(mock_config)

        # Expected values calculated manually based on the implementation
        expected_theta = np.array([1.0, np.pi - 1.0])
        expected_delta_theta = np.array([1.0, 1.0])
        expected_phi = np.array(
            [np.pi / 4, 3 * np.pi / 4, 5 * np.pi / 4, 7 * np.pi / 4]
        )
        expected_delta_phi = np.array([np.pi / 2, np.pi / 2, np.pi / 2, np.pi / 2])

        assert ad.theta.shape == (2,)
        assert ad.phi.shape == (4,)
        assert np.allclose(ad.theta, expected_theta)
        assert np.allclose(ad.delta_theta, expected_delta_theta)
        assert np.allclose(ad.phi, expected_phi)
        assert np.allclose(ad.delta_phi, expected_delta_phi)


@pytest.fixture
def mock_config_1d(mocker: MockerFixture) -> MockerFixture:
    """Provide a mock 1D config."""
    mock_config = mocker.MagicMock()
    mock_config.geometry.dimension = 1
    mock_config.geometry.lb = [0.0]
    mock_config.geometry.ub = [1.0]
    mock_config.geometry.n = [10]
    mock_config.geometry.n_ghost = [2]
    return mock_config


@pytest.fixture
def mock_config_2d(mocker: MockerFixture) -> MockerFixture:
    """Provide a mock 2D config."""
    mock_config = mocker.MagicMock()
    mock_config.geometry.dimension = 2
    mock_config.geometry.lb = [0.0, 0.0]
    mock_config.geometry.ub = [1.0, 2.0]
    mock_config.geometry.n = [10, 20]
    mock_config.geometry.n_ghost = [2, 4]
    return mock_config


@pytest.fixture
def disc_1d(mock_config_1d: MockerFixture) -> Discretization:
    """Provide a 1D Discretization object."""
    return Discretization.from_config(mock_config_1d)


@pytest.fixture
def disc_2d(mock_config_2d: MockerFixture) -> Discretization:
    """Provide a 2D Discretization object."""
    return Discretization.from_config(mock_config_2d)


class TestDiscretization:
    """Tests for the Discretization class."""

    def test_from_config_1d(self, mock_config_1d: MockerFixture) -> None:
        """Test creating a 1D Discretization from config."""
        disc = Discretization.from_config(mock_config_1d)
        assert disc.dimension == 1
        assert disc.grid.num_cells == (10,)
        assert np.allclose(disc.grid.cell_edges[0], np.linspace(0.0, 1.0, 11))

    def test_from_config_2d(self, mock_config_2d: MockerFixture) -> None:
        """Test creating a 2D Discretization from config."""
        disc = Discretization.from_config(mock_config_2d)
        assert disc.dimension == 2
        assert disc.grid.num_cells == (10, 20)
        assert np.allclose(disc.grid.cell_edges[0], np.linspace(0.0, 1.0, 11))
        assert np.allclose(disc.grid.cell_edges[1], np.linspace(0.0, 2.0, 21))

    def test_num_space(self, disc_1d: Discretization, disc_2d: Discretization) -> None:
        """Test num_space returns correct number of cells."""
        assert disc_1d.num_space() == 10
        assert disc_2d.num_space() == 200

    def test_to_field(self, disc_1d: Discretization, disc_2d: Discretization) -> None:
        """Test converting a scalar or array to a field."""
        # 1. 1D Discretization with Scalar Input
        scalar_val = 5.0
        field_1d = disc_1d.to_field(scalar_val)
        assert field_1d.shape == (10,)
        assert np.all(field_1d == scalar_val)

        # 2. 2D Discretization with Scalar Input
        field_2d = disc_2d.to_field(scalar_val)
        assert field_2d.shape == (10, 20)
        assert np.all(field_2d == scalar_val)

        # 3. 1D Discretization with Array Input
        array_1d = np.random.rand(*disc_1d.grid.num_cells)
        assert np.array_equal(disc_1d.to_field(array_1d), array_1d)

        # 4. 2D Discretization with Array Input
        array_2d = np.random.rand(*disc_2d.grid.num_cells)
        assert np.array_equal(disc_2d.to_field(array_2d), array_2d)

    def test_add_ghost_1d(self, disc_1d: Discretization) -> None:
        """Test adding ghost cells to a 1D array."""
        val = np.ones(disc_1d.grid.num_cells[0])
        val_with_ghost = disc_1d.add_ghost(val)
        assert val_with_ghost.shape == (12,)
        assert np.all(val_with_ghost[1:-1] == 1)
        assert val_with_ghost[0] == 0
        assert val_with_ghost[-1] == 0

    def test_add_ghost_2d(self, disc_2d: Discretization) -> None:
        """Test adding ghost cells to a 2D array."""
        val = np.ones(disc_2d.grid.num_cells)
        val_with_ghost = disc_2d.add_ghost(val)
        assert val_with_ghost.shape == (12, 24)
        assert np.all(val_with_ghost[1:-1, 2:-2] == 1)
        assert val_with_ghost[0, 0] == 0
        assert val_with_ghost[-1, -1] == 0

    def test_update_ghost_1d(self, disc_1d: Discretization) -> None:
        """Test updating ghost cells on a 1D array."""
        val = np.zeros(
            (disc_1d.grid.num_cells[0] + disc_1d.grid.num_ghost[0], 2)
        )  # Extra dim
        updated_val = disc_1d.update_ghost(val, 5.0, 10.0, 0.0, 0.0)
        assert np.all(updated_val[0, :] == 5.0)
        assert np.all(updated_val[-1, :] == 10.0)

    def test_update_ghost_2d(self, disc_2d: Discretization) -> None:
        """Test updating ghost cells on a 2D array."""
        val = np.zeros(
            (
                disc_2d.grid.num_cells[0] + disc_2d.grid.num_ghost[0],
                disc_2d.grid.num_cells[1] + disc_2d.grid.num_ghost[1],
                3,
            )
        )
        updated_val = disc_2d.update_ghost(val, 1.0, 2.0, 3.0, 4.0)
        # Left boundary
        assert np.all(updated_val[0, 2:-2, :] == 1.0)
        # Right boundary
        assert np.all(updated_val[-1, 2:-2, :] == 2.0)
        # Bottom boundary (check both layers)
        assert np.all(updated_val[1:-1, 0, :] == 3.0)
        assert np.all(updated_val[1:-1, 1, :] == 3.0)
        # Top boundary (check both layers)
        assert np.all(updated_val[1:-1, -2, :] == 4.0)
        assert np.all(updated_val[1:-1, -1, :] == 4.0)

    def test_update_ghost_2d_array_bcs(self, disc_2d: Discretization) -> None:
        """Test updating ghost cells on a 2D array with array BCs."""
        val = np.zeros(
            (
                disc_2d.grid.num_cells[0] + disc_2d.grid.num_ghost[0],
                disc_2d.grid.num_cells[1] + disc_2d.grid.num_ghost[1],
                3,
            )
        )
        # Create array-valued boundary conditions
        left_bc = np.random.rand(disc_2d.grid.num_cells[1], 3)
        right_bc = np.random.rand(disc_2d.grid.num_cells[1], 3)
        bottom_bc = np.random.rand(disc_2d.grid.num_cells[0], 3)
        top_bc = np.random.rand(disc_2d.grid.num_cells[0], 3)

        updated_val = disc_2d.update_ghost(val, left_bc, right_bc, bottom_bc, top_bc)

        # ind1_s = 1, ind2_s = 2 from fixture
        # Left boundary
        assert np.all(updated_val[0, 2:-2, :] == left_bc)
        # Right boundary
        assert np.all(updated_val[-1, 2:-2, :] == right_bc)
        # Bottom boundary (check both layers)
        assert np.all(updated_val[1:-1, 0, :] == bottom_bc)
        assert np.all(updated_val[1:-1, 1, :] == bottom_bc)
        # Top boundary (check both layers)
        assert np.all(updated_val[1:-1, -2, :] == top_bc)
        assert np.all(updated_val[1:-1, -1, :] == top_bc)

    def test_split_1d(self, disc_1d: Discretization) -> None:
        """Test splitting a 1D discretization."""
        split_discs = disc_1d.split()
        assert len(split_discs) == 2
        left, right = split_discs
        assert left.grid.cell_edges[0][0] == 0.0
        assert left.grid.cell_edges[0][-1] == 0.5
        assert right.grid.cell_edges[0][0] == 0.5
        assert right.grid.cell_edges[0][-1] == 1.0
        assert left.grid.num_cells[0] == 10
        assert right.grid.num_cells[0] == 10

    def test_split_2d(self, disc_2d: Discretization) -> None:
        """Test splitting a 2D discretization."""
        split_discs = disc_2d.split()
        assert len(split_discs) == 4
        # Unpack in the order they are created: ll, ul, ur, lr
        ll, ul, ur, lr = split_discs

        # Check bounds of each new discretization
        assert ll.grid.cell_edges[0][0] == 0.0 and ll.grid.cell_edges[0][-1] == 0.5
        assert ll.grid.cell_edges[1][0] == 0.0 and ll.grid.cell_edges[1][-1] == 1.0

        assert ul.grid.cell_edges[0][0] == 0.0 and ul.grid.cell_edges[0][-1] == 0.5
        assert ul.grid.cell_edges[1][0] == 1.0 and ul.grid.cell_edges[1][-1] == 2.0

        assert ur.grid.cell_edges[0][0] == 0.5 and ur.grid.cell_edges[0][-1] == 1.0
        assert ur.grid.cell_edges[1][0] == 1.0 and ur.grid.cell_edges[1][-1] == 2.0

        assert lr.grid.cell_edges[0][0] == 0.5 and lr.grid.cell_edges[0][-1] == 1.0
        assert lr.grid.cell_edges[1][0] == 0.0 and lr.grid.cell_edges[1][-1] == 1.0

        # Check number of cells is preserved in children
        for disc in split_discs:
            assert disc.grid.num_cells == (10, 20)
