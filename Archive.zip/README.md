# Transport Solvers with Tensor Networks

[![Documentation](https://img.shields.io/badge/docs-latest-blue.svg)](https://gorodetsky-umich.github.io/pytens_transport_solvers/)
[![CI](https://github.com/gorodetsky-umich/pytens_transport_solvers/actions/workflows/ci.yml/badge.svg)](https://github.com/gorodetsky-umich/pytens_transport_solvers/actions/workflows/ci.yml)
[![License: MIT](https://img.shields.io/badge/License-MIT-yellow.svg)](https://opensource.org/licenses/MIT)
[![Python 3.12+](https://img.shields.io/badge/python-3.12+-blue.svg)](https://www.python.org/downloads/)
[![Code style: ruff](https://img.shields.io/endpoint?url=https://raw.githubusercontent.com/astral-sh/ruff/main/assets/badge/v2.json)](https://github.com/astral-sh/ruff)

Solvers with Tensor Networks

For full usage details, see the [documentation website](https://gorodetsky-umich.github.io/pytens_transport_solvers/).

## Getting Started

The easiest way to get started is to follow the official documentation website.

1.  **Installation**: See the [Installation Guide](https://gorodetsky-umich.github.io/pytens_transport_solvers/user_guide/installation/).
2.  **Running Examples**: See the [Running Simulations Guide](https://gorodetsky-umich.github.io/pytens_transport_solvers/user_guide/running/).

## Author
Copyright 2024,2025 Alex Gorodetsky (goroda@umich.edu), Aditya Deshpande (dadity@umich.edu)
